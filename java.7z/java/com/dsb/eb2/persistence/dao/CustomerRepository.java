package com.dsb.eb2.persistence.dao;

import java.util.List;
import java.util.stream.Stream;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dsb.eb2.framework.repository.BaseRepository;
import com.dsb.eb2.persistence.model.Customer;

//@Repository
@NoRepositoryBean
public interface CustomerRepository extends BaseRepository<Customer, Long> {

	List<Customer> findByFullName(String fullName);
	
	Customer findByCustId(String custId);
	
	Customer findByEbid(String ebid);
	
	@Query("select c from Customer c where c.mobNumber = :mobNumber")
	Stream<Customer> findByMobNumberReturnSteam(@Param("mobNumber") String mobNunmber);
	
}
