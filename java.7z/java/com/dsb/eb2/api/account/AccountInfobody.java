package com.dsb.eb2.api.account;

import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;

public class AccountInfobody {
	

	@JSONField(name="fromCache") 
	private String fromCache;
	

	@JSONField(name="filter") 
	private List<Filter> filter;


	public String getFromCache() {
		return fromCache;
	}


	public void setFromCache(String fromCache) {
		this.fromCache = fromCache;
	}


	public List<Filter> getFilter() {
		return filter;
	}


	public void setFilter(List<Filter> filter) {
		this.filter = filter;
	}
	

}
