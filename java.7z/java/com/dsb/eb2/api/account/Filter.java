package com.dsb.eb2.api.account;



import java.util.Arrays;

import com.alibaba.fastjson.annotation.JSONField;

public class Filter {
	
		
		@Override
	public String toString() {
		return "Filter [acctType=" + Arrays.toString(acctType) + ", acctNum=" + Arrays.toString(acctNum) + "]";
	}

		@JSONField(name="AcctType") 
		private String[] acctType;
		
		@JSONField(name="AcctNum") 
		private String[] acctNum;

		public String[] getAcctType() {
			return acctType;
		}

		public void setAcctType(String[] acctType) {
			this.acctType = acctType;
		}

		public String[] getAcctNum() {
			return acctNum;
		}

		public void setAcctNum(String[] acctNum) {
			this.acctNum = acctNum;
		}

		
		
		

}
