package com.dsb.eb2.api.account;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.dsb.eb2.api.account.AccountInfo;
import com.dsb.eb2.api.account.AllAccount;
import com.dsb.eb2.api.account.OtherBalanceDetail;
import com.dsb.eb2.backOffice.connect.EMSQueueConnector;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsMsgFactory;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsRepMsg;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsReqMsg;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmHdr;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1107.AcctDetails;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1107.NF1107RepData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1109.BalanceDetails;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1109.NF1109RepData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1109.NF1109ReqData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1110.LatestCashSurrValueInfo;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1110.NF1110RepData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1110.NF1110ReqData;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.account.AccountType;
import com.dsb.eb2.bankApp.account.ProductSubCode;
import com.dsb.eb2.bankApp.dao.sysAcctDescription.SysAcctDesciptionDao;
import com.dsb.eb2.bankApp.dao.sysAcctDescription.SysAcctDescriptionBean;
import com.dsb.eb2.util.StringUtils;



@Service
public class AllAccountService {
	
	@Autowired
	SysAcctDesciptionDao SysAcctDesciptionDao;

	public AllAccount getAccountInfo(NF1107RepData frmData, String custId) throws Exception {
		
		AllAccount allAccount = new AllAccount();
		
		ArrayList<AccountInfo> arrayList = new ArrayList<AccountInfo>();
		
		List<AcctDetails> acctDetailsList = frmData.getAcctDetails();
		
		for (AcctDetails acctDetails : acctDetailsList) {
			
			AccountInfo accountInfo = new AccountInfo();
			
			String acctNum = acctDetails.getAcctNum().trim();
			String iacctInd = acctDetails.getIacctInd();
			String acctType = acctDetails.getAcctType();
			String prodSubCode = acctDetails.getProdSubCode();
			String currencyCode = acctDetails.getCurrencyCode();
			String balance = acctDetails.getBalance();
			
			accountInfo.setAcctNum(acctNum);
			SysAcctDescriptionBean acc = SysAcctDesciptionDao.getAcctDesciptionByType(acctType, prodSubCode);
			
			if(acc != null) {
				accountInfo.setAcctTypeEn(acc.getEngDesc());
				accountInfo.setAcctTypeZh(acc.getChiDesc());
			}else {
				accountInfo.setAcctTypeEn("");
				accountInfo.setAcctTypeZh("");
			}
			accountInfo.setCurrency(currencyCode);
			accountInfo.setTotalBalanceInHKD(balance);
			//TODO
			accountInfo.setIconType("");
			
			if(acctType.equals(AccountType.CURRENT)) {
				// call NF1110
				NF1110ReqData req = new NF1110ReqData();
				req.setAccountNumber(acctNum);
				req.setClosureIndicator(null);
				req.setFiller1(null);
				EmsReqMsg emsReqMsg = EmsMsgFactory.createEmsReqMsg(req, custId);
				EMSQueueConnector connector = new EMSQueueConnector();
				EmsRepMsg emsRepMsg = connector.invoke(emsReqMsg, new NF1110RepData());
				NF1110RepData response = (NF1110RepData)emsRepMsg.getFrmData();
				FrmHdr frmHdr = emsRepMsg.getFrmHdr();
				
				if(frmHdr.getReturnCode().equals(String.valueOf(SystemStatusCode.SSC_NORMAL_EMS_RESPONE))) {
					
					ArrayList<OtherBalanceDetail> otherList = new ArrayList<OtherBalanceDetail>();
					
					List<LatestCashSurrValueInfo> latestCashSurrValueInfoLsit = response.getLatestCashSurrValueInfo();
					
					if(latestCashSurrValueInfoLsit.size() > 0) {
						for (LatestCashSurrValueInfo info : latestCashSurrValueInfoLsit) {
							OtherBalanceDetail other = new OtherBalanceDetail();
							other.setCurrency(info.getCCY());
							other.setBalance(info.getAmt());
							otherList.add(other);
						}
					}
					
					accountInfo.setOtherBalance(otherList);
				}else {
					ArrayList<OtherBalanceDetail> otherList = new ArrayList<OtherBalanceDetail>();
					accountInfo.setOtherBalance(otherList);
				}
		
			}
			
			if(acctType.equals(AccountType.SAVINGS)) {
				
				if ((StringUtils.isEmpty(prodSubCode))|| (!(prodSubCode.equals(ProductSubCode.TARGET_SAVING)))) {
					// call NF1109
					NF1109ReqData req = new NF1109ReqData();
					req.setAccountNumber(acctNum);
					req.setClosureIndicator(iacctInd);
					EmsReqMsg emsReqMsg = EmsMsgFactory.createEmsReqMsg(req, custId);
					EMSQueueConnector connector = new EMSQueueConnector();
					EmsRepMsg emsRepMsg = connector.invoke(emsReqMsg, new NF1109RepData());
					NF1109RepData response = (NF1109RepData)emsRepMsg.getFrmData();
					FrmHdr frmHdr = emsRepMsg.getFrmHdr();
					if(frmHdr.getReturnCode().equals(String.valueOf(SystemStatusCode.SSC_NORMAL_EMS_RESPONE))) {
						ArrayList<OtherBalanceDetail> otherList = new ArrayList<OtherBalanceDetail>();
						
						List<BalanceDetails> BalanceDetailsList = response.getBBalanceDetails();
						
						if(BalanceDetailsList.size() > 0) {
							for (BalanceDetails detail : BalanceDetailsList) {
								OtherBalanceDetail other = new OtherBalanceDetail();
								other.setCurrency(detail.getCurrency());
								other.setBalance(detail.getBal());
								otherList.add(other);
							}
						}
						
						accountInfo.setOtherBalance(otherList);
					}else {
						ArrayList<OtherBalanceDetail> otherList = new ArrayList<OtherBalanceDetail>();
						accountInfo.setOtherBalance(otherList);
					}
					
				}else {
					// call NF1116
//				
//					NF1116ReqData req = new NF1116ReqData();
//					req.setAcctNum(acctNum);
//					EmsReqMsg emsReqMsg = EmsMsgFactory.createEmsReqMsg(req, custId);
//					EMSQueueConnector connector = new EMSQueueConnector();
//					EmsRepMsg emsRepMsg = connector.invoke(emsReqMsg, new NF1116RepData());
//					NF1116RepData response = (NF1116RepData)emsRepMsg.getFrmData();
//					FrmHdr frmHdr = emsRepMsg.getFrmHdr();
//					if(frmHdr.getReturnCode().equals(String.valueOf(SystemStatusCode.SSC_NORMAL_EMS_RESPONE))) {
//						ArrayList<OtherBalanceDetail> otherList = new ArrayList<OtherBalanceDetail>();
//						accountInfo.setOtherBalance(otherList);
//					}else {
//						ArrayList<OtherBalanceDetail> otherList = new ArrayList<OtherBalanceDetail>();
//						accountInfo.setOtherBalance(otherList);
//					}
//				
//					
					ArrayList<OtherBalanceDetail> otherList = new ArrayList<OtherBalanceDetail>();
					accountInfo.setOtherBalance(otherList);
				}
				
			}
			
			if(!acctType.equals(AccountType.SAVINGS) && !acctType.equals(AccountType.CURRENT)) {
				ArrayList<OtherBalanceDetail> otherList = new ArrayList<OtherBalanceDetail>();
				accountInfo.setOtherBalance(otherList);
			}
			
		/*
			if(acctType.equals(AccountType.FIXED_DEPOSIT)) {
				// call NF1112
				NF1112ReqData req = new NF1112ReqData();
				req.setAccountNumber(acctNum);
				req.setPenaltyOption(null);
				req.setSettlementDate(null);
				EmsReqMsg emsReqMsg = EmsMsgFactory.createEmsReqMsg(req, custId);
				EMSQueueConnector connector = new EMSQueueConnector();
				EmsRepMsg emsRepMsg = connector.invoke(emsReqMsg, new NF1112RepData());
				NF1112RepData response = (NF1112RepData)emsRepMsg.getFrmData();
				FrmHdr frmHdr = emsRepMsg.getFrmHdr();
				if(frmHdr.getReturnCode().equals(String.valueOf(SystemStatusCode.SSC_NORMAL_EMS_RESPONE))) {
					ArrayList<OtherBalanceDetail> otherList = new ArrayList<OtherBalanceDetail>();
					accountInfo.setOtherBalance(otherList);
				}else {
					ArrayList<OtherBalanceDetail> otherList = new ArrayList<OtherBalanceDetail>();
					accountInfo.setOtherBalance(otherList);
				}
			}
			
			if(acctType.equals(AccountType.PERSONAL_LOAN)) {
				// call NF1615
				NF1615ReqData req = new NF1615ReqData();
				req.setAccountNumber(acctNum);
				req.setDepositNumber(null);
				EmsReqMsg emsReqMsg = EmsMsgFactory.createEmsReqMsg(req, custId);
				EMSQueueConnector connector = new EMSQueueConnector();
				EmsRepMsg emsRepMsg = connector.invoke(emsReqMsg, new NF1615RepData());
				NF1615RepData response = (NF1615RepData)emsRepMsg.getFrmData();
				FrmHdr frmHdr = emsRepMsg.getFrmHdr();
				if(frmHdr.getReturnCode().equals(String.valueOf(SystemStatusCode.SSC_NORMAL_EMS_RESPONE))) {
					ArrayList<OtherBalanceDetail> otherList = new ArrayList<OtherBalanceDetail>();
					accountInfo.setOtherBalance(otherList);
				}else {
					ArrayList<OtherBalanceDetail> otherList = new ArrayList<OtherBalanceDetail>();
					accountInfo.setOtherBalance(otherList);
				}
			}
			
			if(acctType.equals(AccountType.MORTGAGE_LOAN)) {
				// call NF1113
				NF1113ReqData req = new NF1113ReqData();
				req.setAccountNumber(acctNum);
				EmsReqMsg emsReqMsg = EmsMsgFactory.createEmsReqMsg(req, custId);
				EMSQueueConnector connector = new EMSQueueConnector();
				EmsRepMsg emsRepMsg = connector.invoke(emsReqMsg, new NF1113RepData());
				NF1113RepData response = (NF1113RepData)emsRepMsg.getFrmData();
				FrmHdr frmHdr = emsRepMsg.getFrmHdr();
				if(frmHdr.getReturnCode().equals(String.valueOf(SystemStatusCode.SSC_NORMAL_EMS_RESPONE))) {
					ArrayList<OtherBalanceDetail> otherList = new ArrayList<OtherBalanceDetail>();
					accountInfo.setOtherBalance(otherList);
				}else {
					ArrayList<OtherBalanceDetail> otherList = new ArrayList<OtherBalanceDetail>();
					accountInfo.setOtherBalance(otherList);
				}
			}
			
			if (acctType.equals(AccountType.CREDIT_CARD)) { 
				ArrayList<OtherBalanceDetail> otherList = new ArrayList<OtherBalanceDetail>();
				accountInfo.setOtherBalance(otherList);
			}
			
			if (acctType.equals(AccountType.CASH_CARD)) {   
				ArrayList<OtherBalanceDetail> otherList = new ArrayList<OtherBalanceDetail>();
				accountInfo.setOtherBalance(otherList);
			}
			
			if (acctType.equals(AccountType.SHARE_MARGIN)) {  
				ArrayList<OtherBalanceDetail> otherList = new ArrayList<OtherBalanceDetail>();
				accountInfo.setOtherBalance(otherList);
			}
			
			if (acctType.equals(AccountType.UNIT_TRUST)) { 
				ArrayList<OtherBalanceDetail> otherList = new ArrayList<OtherBalanceDetail>();
				accountInfo.setOtherBalance(otherList);
			}
			
			if (prodSubCode.equals(ProductSubCode.RETAIL_BOND) || prodSubCode.equals(ProductSubCode.PRIVATE_BANKING_PBN) || prodSubCode.equals(ProductSubCode.PRIVATE_BANKING_PPB)) {
				// call NF1658
				ArrayList<OtherBalanceDetail> otherList = new ArrayList<OtherBalanceDetail>();
				accountInfo.setOtherBalance(otherList);
			}
		*/
			
			arrayList.add(accountInfo);
		}
		
		allAccount.setStatus(true);
		
		allAccount.setData(arrayList);
		
		return allAccount;
	}

	
	
}
