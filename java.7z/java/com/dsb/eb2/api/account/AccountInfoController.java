package com.dsb.eb2.api.account;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.logging.LogLevel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.dsb.eb2.backOffice.connect.EMSQueueConnector;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsMsgFactory;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsRepMsg;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsReqMsg;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmHdr;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1107.AcctDetails;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1107.NF1107RepData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1107.NF1107ReqData;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.dao.sysAcctDescription.SysAcctDesciptionDao;
import com.dsb.eb2.framework.controller.ApiController;
import com.dsb.eb2.framework.controller.BaseController;
import com.dsb.eb2.framework.controller.RequestCorrelation;
import com.dsb.eb2.framework.log.Loggable;
import com.dsb.eb2.util.StringUtils;

@RestController
@RequestMapping(ApiController.API_PATH)
@Loggable
public class AccountInfoController extends BaseController {
	
	private static Logger logger = LoggerFactory.getLogger(AccountInfoController.class);
	
	@Autowired
	AllAccountService allAccountService;

	@Autowired
	SysAcctDesciptionDao SysAcctDesciptionDao;

	@RequestMapping(value = "/account/service/getAccountInfo", method = RequestMethod.POST, produces = "application/json")
	@Loggable(result = false, value = LogLevel.INFO)
	@ResponseBody
	public ResponseEntity getAccountInfo(HttpServletRequest request, HttpServletResponse response,
			@RequestBody String accountInfobody) throws IOException, Exception {

		Map<String, Object> map = new HashMap<String, Object>();

		try {
			AccountInfobody accountInfobodys = JSONObject.parseObject(accountInfobody, AccountInfobody.class);
			String[] acctNum = accountInfobodys.getFilter().get(0).getAcctNum();
			String[] acctType = accountInfobodys.getFilter().get(0).getAcctType();
			String fromCache = accountInfobodys.getFromCache();

			String custId = RequestCorrelation.getClientID();
			if (StringUtils.isEmpty(custId)) {
				custId = "IDR8601517";
			} else {
				custId = custId;
			}
			NF1107ReqData reqData = new NF1107ReqData();
			EmsReqMsg emsReqMsg = EmsMsgFactory.createEmsReqMsg(reqData, custId);
			EMSQueueConnector connector = new EMSQueueConnector();
			if (fromCache.equals("Y")) {
				EmsRepMsg emsRepMsg = connector.invoke(emsReqMsg, new NF1107RepData(), true);
			} else {
				EmsRepMsg emsRepMsg = connector.invoke(emsReqMsg, new NF1107RepData());
			}
			EmsRepMsg emsRepMsg = connector.invoke(emsReqMsg, new NF1107RepData());
			NF1107RepData frmData = (NF1107RepData) emsRepMsg.getFrmData();
			FrmHdr frmHdr = emsRepMsg.getFrmHdr();

			NF1107RepData nf1107 = new NF1107RepData();
			List<AcctDetails> acctDetailsrep = new ArrayList<AcctDetails>();
			for (int i = 0; i < frmData.getAcctDetails().size(); i++) {
				String acctNumrep = frmData.getAcctDetails().get(i).getAcctNum().trim();
				String cctTyperep = frmData.getAcctDetails().get(i).getAcctType().trim();

				boolean acctnumb = false;
				for (int j = 0; j < acctNum.length; j++) {
					if (acctNum[j].equals(acctNumrep)) {
						acctnumb = true;
					}
				}

				boolean acctTypeb = false;
				for (int k = 0; k < acctType.length; k++) {
					if (acctType[k].equals(cctTyperep)) {
						acctTypeb = true;
					}
				}

				if (acctTypeb && acctnumb) {
					AcctDetails acctDetails = frmData.getAcctDetails().get(i);
					acctDetailsrep.add(acctDetails);
				}

			}

			nf1107.setAcctDetails(acctDetailsrep);
			nf1107.setNumOfAccts(acctDetailsrep.size() + "");

			if (frmHdr.getReturnCode().equals(String.valueOf(SystemStatusCode.SSC_NORMAL_EMS_RESPONE))) {
				String nf1107RepDate = JSON.toJSONString(nf1107);
				return (new ResponseEntity<>(nf1107RepDate, HttpStatus.OK));

			} else {
				map.put("timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()));
				map.put("status", "500");
				map.put("error", frmHdr.getReturnCode());
				map.put("message", "NF1107 return error");
				map.put("path", ApiController.API_PATH + "/account/service/getAccountInfo");
				return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
			}
		} catch (Exception e) {
			e.printStackTrace();
			map.put("timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()));
			map.put("message", e.getMessage());
			return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
		}

	}

	@RequestMapping(value = "/accounts/service/getAllAccounts", method = RequestMethod.GET, produces = "application/json")
	@Loggable(result = false, value = LogLevel.INFO)
	@ResponseBody
	public Object getAllAccounts(HttpServletRequest request, HttpServletResponse response) {

		String custId = RequestCorrelation.getClientID();
		if (StringUtils.isEmpty(custId)) {
			custId = "IDK2369117";
		} else {
			custId = custId;
		}
		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("path", ApiController.PWS_PATH + "/accounts/service/getAllAccounts");

		try {

			NF1107ReqData reqData = new NF1107ReqData();
			EmsReqMsg emsReqMsg = EmsMsgFactory.createEmsReqMsg(reqData, custId);
			EMSQueueConnector connector = new EMSQueueConnector();
			EmsRepMsg emsRepMsg = connector.invoke(emsReqMsg, new NF1107RepData(), true);
			FrmHdr frmHdr = emsRepMsg.getFrmHdr();
			if (frmHdr.getReturnCode().equals(String.valueOf(SystemStatusCode.SSC_NORMAL_EMS_RESPONE))) {

				NF1107RepData frmData = (NF1107RepData) emsRepMsg.getFrmData();

				AllAccount allAccount = allAccountService.getAccountInfo(frmData, custId);

				return allAccount;
			} else {
			//	AllAccount allAccount = new AllAccount();
			//	allAccount.setStatus(false);
			//	allAccount.setData(new ArrayList<AccountInfo>());
			//	return allAccount;
				
			map.put("timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()));
			map.put("status", "500");
			map.put("error", frmHdr.getReturnCode());
			map.put("message", "NF1107 return error");
			return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
				
			}

		} catch (Exception e) {
			e.printStackTrace();
			map.put("timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()));
			map.put("message", e.getMessage());
			return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
		}

	}
	
	
	
}
