package com.dsb.eb2.api.account;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class AllAccount {
	
	public Boolean status;
	
	public List<AccountInfo> data;

}
