package com.dsb.eb2.api.account;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class AccountInfo {
	
	public String acctTypeEn;
	
	public String acctTypeZh;
	
	public String acctNum;
	
	public String currency;
	
	public String totalBalanceInHKD;
	
	public List<OtherBalanceDetail> otherBalance;
	
	public String iconType;

}
