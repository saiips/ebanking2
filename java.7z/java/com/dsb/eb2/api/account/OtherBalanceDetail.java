package com.dsb.eb2.api.account;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class OtherBalanceDetail {

	public String currency;
	
	public String balance;
}
