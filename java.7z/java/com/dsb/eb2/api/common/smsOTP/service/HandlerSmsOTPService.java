package com.dsb.eb2.api.common.smsOTP.service;

import java.util.Map;

import com.dsb.eb2.api.common.smsOTP.model.SMSSecurityFrontEndBean;
import com.dsb.eb2.bankApp.System.exeption.SystemException;

public interface HandlerSmsOTPService {
	String getSmsLang(String smsLang ,String custId,String prefType)throws SystemException;
	
	String sendSmsOTP(SMSSecurityFrontEndBean bean)throws SystemException;
	
	int verifySMS(SMSSecurityFrontEndBean bean) throws SystemException;
	
	Map<String, Object> createResponseMsg(boolean status,String message,int code,String path);
}
