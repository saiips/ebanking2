package com.dsb.eb2.api.common.smsOTP.dao;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.logging.LogLevel;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.System.exeption.SystemException;
import com.dsb.eb2.framework.controller.ApiGateway;
import com.dsb.eb2.framework.log.Loggable;
import com.dsb.eb2.sso.controller.LoginController;
import com.dsb.eb2.util.FormatUtils;
import com.dsb.eb2.util.JSONUtils;
@Component
@Loggable
public class SMSOTPOSBDao extends ApiGateway{
	private static Logger log = LoggerFactory.getLogger(LoginController.class);
	//SELECT TRIM(TO_CHAR(EMSSOA_SMS_OTP_SEQ.NEXTVAL, '00000000')) AS SEQ FROM DUAL
	@Loggable(result = false, value = LogLevel.INFO)
	public String genEmsSoaSmsOTPSeqno(String request) throws SystemException{
		JSONObject json = null;
		String refno = "";
		try {
			String serviceURL = super.getGatewayURL() + "/Dual/GetRefnoService/submit";
			String response = super.doRequest("DATA", "POST", "OTHERS", "N", null, serviceURL, "POST",JSONUtils.objToJson(request));
			json = (JSONObject)JSONUtils.JsonToObj(response, new JSONObject());
			refno = json.getString("REFNO");
			return refno;
		}catch (IOException e) {
			log.info(FormatUtils.getStackTrace(e));
			throw new SystemException(SystemStatusCode.SCC_SEND_SMS_OTP_ERROR);
		} catch (Exception e) {
			log.info(FormatUtils.getStackTrace(e));
			throw new SystemException(SystemStatusCode.SCC_SEND_SMS_OTP_ERROR);
		}
	}
}
