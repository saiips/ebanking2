package com.dsb.eb2.api.common.smsOTP.service;

import com.dsb.eb2.bankApp.System.exeption.SystemException;
import com.dsb.eb2.bankApp.dao.eBankKeyPair.EBankKeyPariBean;

public interface EBankKeyPariService {
	EBankKeyPariBean findRecord() throws SystemException;
}
