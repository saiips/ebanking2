package com.dsb.eb2.api.common.smsOTP.service;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.System.exeption.SystemException;
import com.dsb.eb2.bankApp.dao.eBankKeyPair.EBankKeyPariBean;
import com.dsb.eb2.bankApp.dao.eBankKeyPair.EBankKeyPariOSBDao;
import com.dsb.eb2.sso.controller.LoginController;
import com.dsb.eb2.util.FormatUtils;

@Service
public class EBankKeyPariServiceImpl implements EBankKeyPariService{
	
	private static Logger log = LoggerFactory.getLogger(LoginController.class);
	
	@Autowired
	private EBankKeyPariOSBDao eBankKeyPariOSBDao;
	@Override
	public EBankKeyPariBean findRecord() throws SystemException{
		String name = "";
		String keyIndex = "";
		String privateKey = "";
		String publicKey = "";
		String request = "{}";
		EBankKeyPariBean bean = new EBankKeyPariBean();
		try {
			JSONObject response =  eBankKeyPariOSBDao.findSMSOtpKey(request);
			name = response.getString("KEY_NAME");
			keyIndex = response.getString("KEY_INDEX");
			privateKey = response.getString("PRIVATE_KEY");
			publicKey = response.getString("PUBLIC_KEY");
			bean.setName(name);
			bean.setKeyIndex(keyIndex);
			bean.setPrivateKey(privateKey);
			bean.setPublicKey(publicKey);
			return bean;
		} catch (IOException e) {
			log.info(FormatUtils.getStackTrace(e));
			throw new SystemException(SystemStatusCode.SCC_SEND_SMS_OTP_ERROR);
		} catch (Exception e) {
			log.info(FormatUtils.getStackTrace(e));
			throw new SystemException(SystemStatusCode.SCC_SEND_SMS_OTP_ERROR);
		}
	}

}
