package com.dsb.eb2.api.common.smsOTP.constant;

public class SMSOTPConstant {
	 // language
	  public static final int LANG_PREF_ENGLISH = 0;
	  public static final int LANG_PREF_CHINESE = 1;
	//sms invalid time
	  public static final int SMS_OTP_INVALID_TIME = 100;	//100s
	  
	  public static final String EBANK_KEYPAIR_NAME_PREFIX = "EB_OTP";
	  public static final String EBANK_KEYPAIR_NAME_DELIMITER = "_";
	  
	  public static final String SMS_AUTH_FLAG = "SMS_AUTH_SUCCESS_FLAG";
	  
	  public static final String SMS_AUTH_ERROR = "SmsAuthError";
	  
	  public static final String LOCAL_AREA_CODE = "852";
	  public static final int  OVERSEA_NUMBER_MIN_INL_LEN = 9;
	  public static final String[] VALID_LOCAL_PREIX	= {"4", "5", "6", "7", "8", "9"};	

}
