package com.dsb.eb2.api.common.smsOTP.model;

import lombok.Data;



@Data
public class SMSSecurityFrontEndBean{
	
	private int mainType = -1;
	
	private int subType = -1;
	
	private int extendedType = -1;
	
	private String publicKey;
	
   	private String privateKey;
   	
   	private String smsotpRefno;
   	
   	private int smsMsgType = -1;
   	
   	private String smsTemplateId;
   	
   	private String SmsSupportOverseaFlag;
   
   	private int smsInvalidTime = -1;
   	
   	
   	private String deptCode;
   	
   	private String smsMobileNo;
   	
   	private boolean validMobile;

   	private String ip;
   	
   	private String sessionID;

   	private String custId;
   	
   	private String smsLang;
   	//verify
   	private String encryptSmsotp;
   	
   	private String smsType;
   	
}
