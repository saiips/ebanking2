package com.dsb.eb2.api.common.smsOTP.model;


import java.util.List;

import lombok.Data;

@Data
public class SmsSecurityOTPBean{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String custId;
	int ActCodeFormat;
	int ActCodeLength;
	String AcctNum;
	String Recipient;
	int SmsMsgType;
	String SmsLang;
	String SmsSupportOverseaFlag;
	String SmsTemplateID;
	List<String> SmsTemplateContent;
	String RefNum;
	String Key3Des;
	String deptCode;
}
