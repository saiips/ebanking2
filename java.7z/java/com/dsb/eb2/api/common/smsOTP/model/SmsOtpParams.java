package com.dsb.eb2.api.common.smsOTP.model;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class SmsOtpParams {
	
	private String smsTemplateId;
	private String SmsSupportOverseaFlag;
	private String deptCode;
	private int smsMsgType;
	private int  mainType;
	private int subType;
	private int extendedType;
	
	public SmsOtpParams(String smsTemplateId, String smsSupportOverseaFlag, String deptCode, int smsMsgType, int mainType,
			int subType, int extendedType) {
		super();
		this.smsTemplateId = smsTemplateId;
		SmsSupportOverseaFlag = smsSupportOverseaFlag;
		this.deptCode = deptCode;
		this.smsMsgType = smsMsgType;
		this.mainType = mainType;
		this.subType = subType;
		this.extendedType = extendedType;
	}
	
	
}
