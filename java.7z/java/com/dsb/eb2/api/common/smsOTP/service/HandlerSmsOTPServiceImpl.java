package com.dsb.eb2.api.common.smsOTP.service;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.logging.LogLevel;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dsb.eb2.api.common.smsOTP.dao.SMSOTPOSBDao;
import com.dsb.eb2.api.common.smsOTP.model.SMSSecurityFrontEndBean;
import com.dsb.eb2.api.common.smsOTP.model.SmsOtpSecurityBean;
import com.dsb.eb2.backOffice.connect.webService.emsOTPAlgorithm.ThalesGenActCodeResponse;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.System.exeption.SystemException;
import com.dsb.eb2.bankApp.dao.otbMgnt.OtbMgntBean;
import com.dsb.eb2.bankApp.dao.otbMgnt.OtbMgntOSBDao;
import com.dsb.eb2.bankApp.dao.otbMgnt.OtbMgntRepository;
import com.dsb.eb2.bankApp.dao.preference.CusPreferenceOSBDao;
import com.dsb.eb2.common.commonFun.smsOTP.EMSOTPAlgProcessor;
import com.dsb.eb2.framework.log.Loggable;
import com.dsb.eb2.sso.controller.LoginController;
import com.dsb.eb2.util.DESCoder;
import com.dsb.eb2.util.FormatUtils;
import com.dsb.eb2.util.SecurityUtils;
import com.dsb.eb2.util.StringUtils;

@Service
@Loggable
public class HandlerSmsOTPServiceImpl implements HandlerSmsOTPService{
	
	private static Logger log = LoggerFactory.getLogger(LoginController.class);
	@Autowired
	private SMSOTPOSBDao smsOTPOSBDao;
	@Autowired
	private OtbMgntRepository otbMgntRepository;
	@Autowired
	private CusPreferenceOSBDao cusPreferenceOSBDao;
	@Autowired
	private OtbMgntOSBDao otbMgntOSBDao;
	
	@Loggable(result = false, value = LogLevel.INFO)
	public String getSmsLang(String smsLang ,String custId,String prefType) throws SystemException{
		String smsLangAfterCheck = "T";
		if(!SecurityUtils.isEmpty(smsLang) && "Y".equals(smsLang)) {
			return smsLangAfterCheck = "E";
		}else {
			try {
				smsLangAfterCheck = cusPreferenceOSBDao.getSmsLang(custId,prefType);
			} catch (SystemException e) {
				log.info(FormatUtils.getStackTrace(e));
				throw new SystemException(SystemStatusCode.SCC_SEND_SMS_OTP_ERROR);
			}
		}
		return smsLangAfterCheck;
	}
	@Loggable(result = false, value = LogLevel.INFO)
	public String sendSmsOTP(SMSSecurityFrontEndBean bean) throws SystemException {
		String custId = "";
		String sessionID = "";
		String ip = "";
		int msgType = 0;
		String templateId = "";
		String SmsSupportOverseaFlag = ""; 
		String deptCode = "";
		String smsLang = "";
		String smsMobileNo = "";
		try {
			custId = bean.getCustId();
			sessionID = bean.getSessionID();
			ip = bean.getIp();
			msgType = bean.getSmsMsgType();
			templateId = bean.getSmsTemplateId();
			SmsSupportOverseaFlag = bean.getSmsSupportOverseaFlag();
			deptCode = bean.getDeptCode();
			smsLang = bean.getSmsLang();
			smsMobileNo = bean.getSmsMobileNo();
			return sendSmsOTP(custId,sessionID,ip,msgType,templateId,SmsSupportOverseaFlag,deptCode,smsLang,smsMobileNo);
		}catch(Exception e) {
			log.info(FormatUtils.getStackTrace(e));
			throw new SystemException(SystemStatusCode.SCC_SEND_SMS_OTP_ERROR);
		}
	}
	@Loggable(result = false, value = LogLevel.INFO)
	private String sendSmsOTP(String custId, String sessionID, String ip, int msgType, String templateId,String SmsSupportOverseaFlag, String deptCode, String smsLang, String smsMobileNo) throws Exception{
		SmsOtpSecurityBean bean = null;
		String createTime = "";
		String refno = "";
		String encActCode = "";
		String  request = "{}";
		try{
			refno = smsOTPOSBDao.genEmsSoaSmsOTPSeqno(request);
			bean = createSendSmsOTPRequestBean(refno,custId,sessionID,ip, msgType, templateId, SmsSupportOverseaFlag, deptCode, smsLang, smsMobileNo);
			EMSOTPAlgProcessor processor = new EMSOTPAlgProcessor(bean);
			ThalesGenActCodeResponse response =	processor.getResponse();
			if(response != null){
				String returnCode = response.getEmsHeader().getReturnCode();
				if(String.valueOf(SystemStatusCode.SSC_NORMAL_EMS_RESPONE).equals(returnCode)){
					createTime = response.getEmsHeader().getTxDateTime();
					encActCode = response.getEncActCode();
					saveSmsOTP(custId,encActCode,ip,refno,createTime);	
				}else{
					throw new SystemException(SystemStatusCode.SCC_SEND_SMS_OTP_ERROR);
				}
			}else{
				throw new SystemException(SystemStatusCode.SCC_SEND_SMS_OTP_ERROR);
			}
		}catch(SQLException e) {
			log.info(FormatUtils.getStackTrace(e));
			throw new SystemException(SystemStatusCode.SSC_DBMS_GENERAL);
		}
		catch(SystemException e){
			log.info(FormatUtils.getStackTrace(e));
			throw new SystemException(SystemStatusCode.SCC_SEND_SMS_OTP_ERROR);
		}
		catch(Exception e){
			log.info(FormatUtils.getStackTrace(e));
			throw new SystemException(SystemStatusCode.SCC_SEND_SMS_OTP_ERROR);
		}
		return refno;
	}
	
	@Loggable(result = false, value = LogLevel.INFO)
	public int verifySMS(SMSSecurityFrontEndBean bean) throws SystemException {
		String custId = "";
		String sessionID = "";
		String ip = "";
		String privateKey = "";
		String refno = "";
		String encryptSmsotp = "";
		int smsInvalidTime = 0;
		custId = bean.getCustId();
		ip = bean.getIp();
		refno = bean.getSmsotpRefno();
		privateKey = bean.getPrivateKey();
		encryptSmsotp = bean.getEncryptSmsotp();
		sessionID = bean.getSessionID();
		smsInvalidTime = bean.getSmsInvalidTime();
		return verifySMS(custId,ip,refno,privateKey,encryptSmsotp,sessionID,smsInvalidTime);
	}
	@Loggable(result = false, value = LogLevel.INFO)
	public Map<String, Object> createResponseMsg(boolean status,String message,int code,String path){
		Map<String, Object> json = new HashMap<String, Object>();
    	json.put("timestamp",System.currentTimeMillis());
		json.put("status",status);
		json.put("message", message); 
		json.put("code", code);
		json.put("path", path);
	    return json;
	}
	
	@Loggable(result = false, value = LogLevel.INFO)
	private int verifySMS(String custId, String ip,String refno,String privateKey,
			String inputOTP,String sessionID, int smsInvalidTime) throws SystemException
	{
		int status = SystemStatusCode.SSC_NORMAL_EMS_RESPONE;
		String db_ip = "";
		String db_refno = "";
		String db_OTP = "";
		String decDBOTP = "";
		String decInputOTP = "";
		int failCount = 0;
		SimpleDateFormat sdf = null;
		Date db_createTime = null;
		Date currentdate = new Date();
		OtbMgntBean bean = null;
		try {
			bean = otbMgntOSBDao.selectOTP(custId);
			if(bean != null){
				db_ip = bean.getIp();
				db_refno = bean.getRefNo();
				failCount = bean.getFailcount();
				sdf = new SimpleDateFormat("yyyyMMddHHmmss");
				db_createTime = sdf.parse(bean.getCreateTime());
				db_OTP = bean.getOtp();
				if(db_ip.equals(ip) && db_refno.equals(refno)){
		            long dateGap = currentdate.getTime() - db_createTime.getTime();
		            long timeGap = dateGap / 1000;	//time gap is s 
					if(timeGap < smsInvalidTime){
						decDBOTP = DESCoder.decryptData(sessionID,db_OTP); 
						decInputOTP = SecurityUtils.decryptOTP(inputOTP, privateKey);
						if(decInputOTP.equals(decDBOTP))
						{
							otbMgntRepository.updateSMSOTPFailCount(0,custId);
						}else{
							otbMgntRepository.updateSMSOTPFailCount(failCount+1,custId);
							status = SystemStatusCode.SCC_SMS_OTP_AUTH_FAILED;
						}
					}else{
						status = SystemStatusCode.SCC_SMS_OTP_AUTH_FAILED;
					}
				
				}else{
					status = SystemStatusCode.SSC_UNEXPECTED;
				}
			}else{
				status = SystemStatusCode.SSC_UNEXPECTED;
			}
		 } catch (Exception e) {
			 log.info(FormatUtils.getStackTrace(e));
			  throw new SystemException(SystemStatusCode.SSC_UNEXPECTED);
		}
		return status;
	 }
	@Loggable(result = false, value = LogLevel.INFO)
	private SmsOtpSecurityBean createSendSmsOTPRequestBean(String refno ,String custId, String sessionID, String ip, int msgType, String templateId,String SmsSupportOverseaFlag, String deptCode, String smsLang, String smsMobileNo) throws SystemException{
		String Key3Des = "";
		int ActCodeFormat = 0;
		int ActCodeLength = 6;
		String AcctNum = "";
		List<String> smsTemplateContent = null;
		SmsOtpSecurityBean bean = null;
		try {
			Key3Des = DESCoder.convertSessionId2Key3Des(sessionID);
			smsTemplateContent = new ArrayList<String>();
			bean = new SmsOtpSecurityBean();
			if(!StringUtils.isEmpty(custId)) bean.setCustId(custId);
			bean.setActCodeFormat(ActCodeFormat);
			bean.setActCodeLength(ActCodeLength);
			if(!StringUtils.isEmpty(AcctNum)) bean.setAcctNum(AcctNum);
			if(!StringUtils.isEmpty(smsMobileNo)) bean.setRecipient(smsMobileNo);
			if(!StringUtils.isEmpty(String.valueOf(msgType))) bean.setSmsMsgType(msgType);
			if(!StringUtils.isEmpty(smsLang)) bean.setSmsLang(smsLang);
			if(!StringUtils.isEmpty(SmsSupportOverseaFlag)) bean.setSmsSupportOverseaFlag(SmsSupportOverseaFlag);
			if(!StringUtils.isEmpty(templateId)) bean.setSmsTemplateID(templateId);
			bean.setSmsTemplateContent(smsTemplateContent);
			if(!StringUtils.isEmpty(refno)) bean.setRefNum(refno);
			if(!StringUtils.isEmpty(Key3Des)) bean.setKey3Des(Key3Des);
			if(!StringUtils.isEmpty(deptCode)) bean.setDeptCode(deptCode);
		}catch(Exception e) {
			log.info(FormatUtils.getStackTrace(e));
			throw new SystemException(SystemStatusCode.SCC_SEND_SMS_OTP_ERROR);
		}
		return bean;
	}
	@Transactional
	@Loggable(result = false, value = LogLevel.INFO)
	private void saveSmsOTP(String custId,String OTP,String ip,String refno,String createTime)throws Exception{
		Map<String,String> map = new HashMap<String,String>();
		map.put("CUST_ID", custId);
		if(otbMgntOSBDao.selectSMSOTP(map)) {
			otbMgntRepository.updateSMSOTP(refno,createTime,ip,OTP,custId);
		}else {
			otbMgntRepository.insertSMSOTP(refno,custId,createTime,ip,OTP);
		}
	}
}
