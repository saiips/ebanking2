package com.dsb.eb2.api.common.smsOTP.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.logging.LogLevel;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dsb.eb2.api.common.smsOTP.constant.SMSOTPConstant;
import com.dsb.eb2.api.common.smsOTP.model.SMSSecurityFrontEndBean;
import com.dsb.eb2.api.common.smsOTP.model.SmsOtpParams;
import com.dsb.eb2.api.common.smsOTP.service.EBankKeyPariService;
import com.dsb.eb2.api.common.smsOTP.service.HandlerSmsOTPService;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.System.exeption.SystemException;
import com.dsb.eb2.bankApp.System.maintenance.ActivityLog;
import com.dsb.eb2.bankApp.dao.activityLog.ActivityLogBean;
import com.dsb.eb2.bankApp.dao.eBankKeyPair.EBankKeyPariBean;
import com.dsb.eb2.bankApp.massagedMobileNo.MassagedMobileNo;
import com.dsb.eb2.common.commonFun.smsOTP.SmsOtpEnums;
import com.dsb.eb2.framework.controller.BaseController;
import com.dsb.eb2.framework.controller.RequestCorrelation;
import com.dsb.eb2.framework.log.Loggable;
import com.dsb.eb2.sso.controller.LoginController;
import com.dsb.eb2.util.CollectionUtil;
import com.dsb.eb2.util.FormatUtils;
import com.dsb.eb2.util.SecurityUtils;
import com.dsb.eb2.util.StringUtils;
@RestController
@RequestMapping("/api/user")///api/user
public class SmsOtpCommonController extends BaseController{
	
	private static Logger log = LoggerFactory.getLogger(LoginController.class);
	
	@Autowired
	private HandlerSmsOTPService handlerSmsOTPService;
	@Autowired
	private EBankKeyPariService eBankKeyPariService;
	@Autowired
    private ActivityLog activityLog;
	
	@ResponseBody
	@RequestMapping(value="/sendSmsOtp",method = {RequestMethod.POST,RequestMethod.GET}, produces = "application/json")
	@Loggable(result = false, value = LogLevel.INFO)
	public ResponseEntity<Map<String, Object>> smsAuthInput(HttpServletRequest request, HttpServletResponse response,@RequestBody Map<String, Object> inputSmsOtpReqMap) {
		String smsMobileNo = "";
		boolean validMobile = false;
		EBankKeyPariBean eBankKeyPariBean = null;
		String smsotpRefno = "";
		String smsLang = "";
		HttpSession session = request.getSession();
		Map<String, Object> json = null;
		HttpHeaders header = null;
		String path = request.getRequestURL().toString();
		SMSSecurityFrontEndBean bean = null;
		int errorCode = SystemStatusCode.SSC_NORMAL_EMS_RESPONE;
		String prefType = "SMS_PREF";
		String custId = "";
		try {
			if(CollectionUtil.isEmpty(inputSmsOtpReqMap)) {
				throw new SystemException(SystemStatusCode.SSC_SESSION_TIME_OUT);
			}
			bean = new SMSSecurityFrontEndBean();
			custId = RequestCorrelation.getClientID();
			/*if(StringUtils.isEmpty(custId)) {
				custId = "IDK2369117";
			}*/
			bean.setCustId(custId);
			//192.168.2.1
			bean.setIp(String.valueOf(inputSmsOtpReqMap.get("ipAddr")));
			//111111
			bean.setSessionID(String.valueOf(inputSmsOtpReqMap.get("sessionID")));
			//LOGIN_PREF,SMS_PREF
			bean.setSmsLang(String.valueOf(inputSmsOtpReqMap.get("langFlag")));
			bean.setSmsType(String.valueOf(inputSmsOtpReqMap.get("smsType")).toLowerCase().trim());
			//以下參數來自於系統内部
			SmsOtpParams params = SmsOtpEnums.getValues(bean.getSmsType());
			bean.setSmsMsgType(Integer.valueOf(params.getSmsMsgType()));
			bean.setSmsTemplateId(String.valueOf(params.getSmsTemplateId()));
			bean.setSmsSupportOverseaFlag(String.valueOf(params.getSmsSupportOverseaFlag()));
			bean.setDeptCode(String.valueOf(params.getDeptCode()));
			bean.setMainType(Integer.valueOf(params.getMainType()));
			bean.setSubType(Integer.valueOf(params.getSubType()));
			bean.setExtendedType(Integer.valueOf(params.getExtendedType()));
			
			smsLang = handlerSmsOTPService.getSmsLang(bean.getSmsLang(),bean.getCustId(),prefType);
			bean.setSmsLang(smsLang);
			smsMobileNo = MassagedMobileNo.getMassagedMobileNo(bean.getCustId());
//			smsMobileNo = "59199329";
//			System.out.println("smsMobileNo:"+smsMobileNo);
			validMobile = SecurityUtils.checkValidMobile(smsMobileNo,true);
			if(!validMobile) {
				ActivityLogBean activityLogbean = new ActivityLogBean();
				activityLogbean.setCustId( bean.getCustId());
				activityLogbean.setMainType(bean.getMainType());
				activityLogbean.setSubType(bean.getSubType());
				activityLogbean.setReturnCode(SystemStatusCode.SCC_EMPTY_PHONENO);
		    	activityLog.setBean(activityLogbean);
				if(bean.getExtendedType() != -1)
				{
					activityLogbean.setExtendedType(bean.getExtendedType());
				}
				activityLog.record();
				throw new SystemException(SystemStatusCode.SCC_EMPTY_PHONENO);
			}
			bean.setSmsMobileNo(smsMobileNo);
			eBankKeyPariBean = eBankKeyPariService.findRecord();
			if(eBankKeyPariBean != null){
				bean.setPublicKey(eBankKeyPariBean.getPublicKey());
				bean.setPrivateKey(eBankKeyPariBean.getPrivateKey());
			}
			smsotpRefno = handlerSmsOTPService.sendSmsOTP(bean);
			bean.setSmsotpRefno(smsotpRefno);
			session.setAttribute("SMSSecurityFrontEndBean", bean);
			json = handlerSmsOTPService.createResponseMsg(true, "send SMS OTP Successfully", errorCode, path);
			json.put("pubKey", bean.getPublicKey());
			return (new ResponseEntity<Map<String, Object>>(json,header, HttpStatus.OK));
		}catch (Exception e) {
			log.info(FormatUtils.getStackTrace(e));
			if(e instanceof SystemException) {
				errorCode = ((SystemException) e).getErrorCode();
			}
			if(errorCode == SystemStatusCode.SSC_SESSION_TIME_OUT) {
				json = handlerSmsOTPService.createResponseMsg(false, "this SMSSecurityFrontEndBean is null", errorCode, path);
				return (new ResponseEntity<Map<String, Object>>(json,header, HttpStatus.UNAUTHORIZED));
			}else if(errorCode == SystemStatusCode.SCC_EMPTY_PHONENO) {
				json = handlerSmsOTPService.createResponseMsg(false, "this mobileNo is null", errorCode, path);
				return (new ResponseEntity<Map<String, Object>>(json,header, HttpStatus.INTERNAL_SERVER_ERROR));
			}else if(errorCode == SystemStatusCode.SCC_SEND_SMS_OTP_ERROR) {
				json = handlerSmsOTPService.createResponseMsg(false, "send sms otp error", errorCode, path);
				return (new ResponseEntity<Map<String, Object>>(json,header, HttpStatus.INTERNAL_SERVER_ERROR));
			}else if (errorCode == SystemStatusCode.SSC_DBMS_GENERAL) {
				json = handlerSmsOTPService.createResponseMsg(false, e.getMessage(), errorCode, path);
				return (new ResponseEntity<Map<String, Object>>(json,header, HttpStatus.INTERNAL_SERVER_ERROR));
			}else {
				json = handlerSmsOTPService.createResponseMsg(false, "send sms otp error", errorCode, path);
				return (new ResponseEntity<Map<String, Object>>(json,header, HttpStatus.INTERNAL_SERVER_ERROR));
			}
		}
	}
	
	@RequestMapping(value="/authenSmsOtp",method = {RequestMethod.POST,RequestMethod.GET}, produces = "application/json")
	@Loggable(result = false, value = LogLevel.INFO)
	public ResponseEntity<Map<String, Object>> smsAuthVerity(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> smsAuthVerityReqMap){
		String encryptSmsotp = "";
		int smsInvalidTime = 100;
		int frontEndSmsInvalidTime = 0;
		SMSSecurityFrontEndBean bean = null;
		HttpSession session = request.getSession();
		Map<String, Object> json = null;
		HttpHeaders header = null;
		String path = request.getRequestURL().toString();
		int errorCode = SystemStatusCode.SSC_NORMAL_EMS_RESPONE;
		try {
			bean = (SMSSecurityFrontEndBean) session.getAttribute("SMSSecurityFrontEndBean");
			if(bean == null  ) {
				throw new SystemException(SystemStatusCode.SSC_SESSION_TIME_OUT);
			}
			if(CollectionUtil.isEmpty(smsAuthVerityReqMap)) {
				throw new SystemException(SystemStatusCode.SSC_SESSION_TIME_OUT);
			}
			encryptSmsotp = String.valueOf(smsAuthVerityReqMap.get("encryptSmsotp"));
			if(StringUtils.isEmpty(encryptSmsotp)){
				throw new SystemException(SystemStatusCode.SCC_SVTS_SMS_OTP_AUTH_FAILED);
			}else{
				try{
					bean.setEncryptSmsotp(encryptSmsotp);
					frontEndSmsInvalidTime = bean.getSmsInvalidTime();
					frontEndSmsInvalidTime = frontEndSmsInvalidTime == -1 ? SMSOTPConstant.SMS_OTP_INVALID_TIME : smsInvalidTime;
					bean.setSmsInvalidTime(frontEndSmsInvalidTime);
					errorCode = handlerSmsOTPService.verifySMS(bean);
					if(errorCode == SystemStatusCode.SCC_SMS_OTP_AUTH_FAILED) {
						json = handlerSmsOTPService.createResponseMsg(false, "Authentication SMS OTP overtime or execute sql exception ", errorCode, path);
						return (new ResponseEntity<Map<String, Object>>(json,header, HttpStatus.UNAUTHORIZED));
					}
					if(errorCode == SystemStatusCode.SSC_UNEXPECTED) {
						json = handlerSmsOTPService.createResponseMsg(false, "Authentication SMS OTP failed", errorCode, path);
						return (new ResponseEntity<Map<String, Object>>(json,header, HttpStatus.UNAUTHORIZED));
					}
					json = handlerSmsOTPService.createResponseMsg(true, "Authentication SMS OTP Successfully", errorCode, path);
					return (new ResponseEntity<Map<String, Object>>(json,header, HttpStatus.OK));
				}catch(SystemException e){
					ActivityLogBean activityLogbean = new ActivityLogBean();
					activityLogbean.setCustId( bean.getCustId());
					activityLogbean.setMainType(bean.getMainType());
					activityLogbean.setSubType(bean.getSubType());
					activityLogbean.setReturnCode(SystemStatusCode.SCC_SVTS_SMS_OTP_AUTH_FAILED);
			    	activityLog.setBean(activityLogbean);
					if(bean.getExtendedType() != -1)
					{
						activityLogbean.setExtendedType(bean.getExtendedType());
					}
					activityLog.record();
					throw new SystemException(SystemStatusCode.SCC_SVTS_SMS_OTP_AUTH_FAILED);
				}
			}
		}catch (Exception e) {
			log.info(FormatUtils.getStackTrace(e));
			if(e instanceof SystemException) {
				errorCode = ((SystemException) e).getErrorCode();
			}
			if(errorCode == SystemStatusCode.SSC_SESSION_TIME_OUT) {
				json = handlerSmsOTPService.createResponseMsg(false, "session exception or request parameters is null", errorCode, path);
				return (new ResponseEntity<Map<String, Object>>(json,header, HttpStatus.UNAUTHORIZED));
			}else if(errorCode == SystemStatusCode.SCC_SVTS_SMS_OTP_AUTH_FAILED){
				json = handlerSmsOTPService.createResponseMsg(false, "invalidate request parameters ", errorCode, path);
				return (new ResponseEntity<Map<String, Object>>(json,header, HttpStatus.INTERNAL_SERVER_ERROR));
			}else if(errorCode == SystemStatusCode.SSC_UNEXPECTED){
				json = handlerSmsOTPService.createResponseMsg(false, "authenSmsOtp failed", errorCode, path);
				return (new ResponseEntity<Map<String, Object>>(json,header, HttpStatus.INTERNAL_SERVER_ERROR));
			}else {
				json = handlerSmsOTPService.createResponseMsg(false, "authenSmsOtp failed", errorCode, path);
				return (new ResponseEntity<Map<String, Object>>(json,header, HttpStatus.INTERNAL_SERVER_ERROR));
			}
		}
	}
}
