package com.dsb.eb2.api.model;

public class CnOceanCust {

}
