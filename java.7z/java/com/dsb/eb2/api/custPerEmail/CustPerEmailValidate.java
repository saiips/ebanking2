package com.dsb.eb2.api.custPerEmail;

public class CustPerEmailValidate{
	
}
