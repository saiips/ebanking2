package com.dsb.eb2.api.custPerEmail;

import java.text.SimpleDateFormat;
import java.util.Locale;

public class EmailConsolidationConstant {

	public static final String EBANK_PRODC_DOMAIN = "www.dahsing.com";
	public static final String EBANK_UAT_DOMAIN = "ebuat.dahsing.com";
	public static final String EBANK_SIT_DOMAIN = "ebdev.dahsing.com";
	public static final String MBANK_UAT_DOMAIN = "mbuat.dahsing.com";
	public static final String YES = "Y";
	public static final String NO = "N";
	public static final String BLANK = " ";
	public static final String EB_CHANNEL = "EB";
	public static final String MB_CHANNEL = "MB";
	public static final String NORMALLY_UPDATED = "00";
	public static final String PENDING = "P";
	public static final String EXPIRED = "E";
	public static final String PENDING_STATUS = "PENDING_STATUS";
	public static final String PERMANENT_EMAIL_TYPE = "P";
	public static final String PERMANENT_ACTION_UPDATE = "U";
	public static final String PERMANENT_ACTION_VERIFY = "V";
	public static final String PERMANENT_ACTION_RESEND = "S";
	
	public static final String DATE_FORMAT1 = "dd MMM yyyy";
	public static final String DATE_FORMAT1_ENG = "dd-MMM-yyyy";
	public static final String DATE_FORMAT1_CHI = "yyyy年MM月dd日";
	public static final String DATE_FORMAT2 = "yyyyMMdd";
	public static final String DATE_FORMAT3 = "HHmmss";
	public static final String DATE_FORMAT4 = "(MMM, yyyy)";
	public static final String DATE_FORMAT5 = "（yyyy年MM月）";
	public static final String DATE_FORMAT6 = "（yyyy年MM月dd日）";
	public static final String DATE_FORMAT7 = "dd-MM-yyyy";
	public static final String DATE_FORMAT8 = "yyyy-MM-dd HH:mm:ss";
	
	public static final SimpleDateFormat SDF_01 = new SimpleDateFormat("yyyyMMdd");
	public static final SimpleDateFormat SDF_01_ENG = new SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH);
	public static final SimpleDateFormat SDF_01_CHI = new SimpleDateFormat("yyyy年MM月dd日", Locale.CHINESE);
	
	//parameter
	public static final String PERMANENT_EMAIL = "permanentEmail";
	public static final String TEMP_EMAIL = "tempEmail";
	public static final String REFERENCE_NUMBER = "referenceNumber"; 
	public static final String HOST_EMAIL_UPDATE_DATE = "hostEmailUpdateDate";
	public static final String EXPIRED_DATE = "expiredDate";
	public static final String EMAIL_UPDATE_STATUS = "emailUpdateStatus";
	public static final String RESP_CODE="responseCode";

	
	public static final String SQL_SELECT_CUST_EMAIL_ADD = " SELECT "
															+ " CUST_ID "
															+ " , PERM_EMAIL "
															+ " , TEMP_EMAIL "
															+ " , HOST_RETURN_REF_NUM "				
															+ " , HOST_EMAIL_UPDATE_DATE "
															+ " FROM CUS_EMAIL_ADDRESS";
	
	public static final String SQL_CUST_EMAIL_ADD_BY_CUSTID = " WHERE CUST_ID = ? ";
	public static final String SQL_CUST_EMAIL_ADD_BY_REF = " WHERE HOST_RETURN_REF_NUM = ? ";
	
	public static final String SQL_UPDATE_CUST_EMAIL_ADD = " UPDATE CUS_EMAIL_ADDRESS SET "
															+ " PERM_EMAIL = ? "
															+ " , TEMP_EMAIL = ? "
															+ " , LAST_UPDATE_BY = ? "
															+ " , LAST_UPDATE_DATE = ? "
															+ " , HOST_RETURN_REF_NUM = ? "
															+ " , HOST_EMAIL_UPDATE_DATE = ? "
															+ " WHERE CUST_ID = ? ";
	
	public static final String SQL_UPDATE_CUST_EMAIL_ADD_BODY = " UPDATE CUS_EMAIL_ADDRESS SET ";
	public static final String CLAUSE_TEMP_EMAIL = " TEMP_EMAIL = ? ";
	public static final String CLAUSE_REFERENCE_NUMBER = " HOST_RETURN_REF_NUM = ? ";

}
