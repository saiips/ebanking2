package  com.dsb.eb2.api.custPerEmail;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class CustEmailBean {
	
	private String custId;
	private String tempEmail;
	private String addEmailResultFlag;
}
