package com.dsb.eb2.api.custPerEmail;

import com.dsb.eb2.sso.model.CustomerInfo;
import com.dsb.eb2.util.Env;


public interface CustPerEmailService {
	

	public Env getCifEmailInfo(String custId)throws Exception;
	
	public Env addChangeEmail(String custId, String tempEmail)throws Exception;
	
	public Env addChangeEmail(String custId, String tempEmail, String isEmailSkip)throws Exception;

	public Env addChangeEmail(String custId, String tempEmail, String isEmailSkip, CustomerInfo cust)throws Exception;
	
	public String custVerifyEmail(String custId, String tempEmail, String refNo)throws Exception;
	
	public String resendVerifyEmail(String custId, String tempEmail, String refNo)throws Exception;
	
	public boolean isNeedToAddChgEmailAddr(CustomerInfo customer) throws Exception;
	
	public Env callNF1619(String custId) throws Exception;
		
	public Env callNF1619(String custId, String option, String historyInd, String refNo) throws Exception;
	
	public Env callNF1620(String custId, String action, String email, String refNo) throws Exception;
	
	public Env callNF1620(String custId, String channelId, String option, String action, 
				String email, String remark, String refNo, String publicSiteInd) throws Exception;
	
	
	//========================================== call DB ========================================================
	
	public String[] getRecordByCustId(String custId)throws Exception;
	
	
	public String[] getRecordByRefNo(String refNo)throws Exception;
	
	
	public int updatePermanentEmail(String custId
								  , String permanentEmail
								  , String tempEmail
								  , String referenceNumber
								  , String hostEmailUpdateDate)throws Exception;
	
	
	
	public int updateTempEmail(String custId
							 , String tempEmail
							 , String referenceNumber)throws Exception;
	
	
	
	
}
