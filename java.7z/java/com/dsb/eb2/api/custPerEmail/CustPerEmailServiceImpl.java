package com.dsb.eb2.api.custPerEmail;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.logging.LogLevel;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.sf.json.JSONObject;
import com.dsb.eb2.backOffice.connect.EMSQueueConnector;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsMsgFactory;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsRepMsg;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsReqMsg;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1619.NF1619RepData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1619.NF1619ReqData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1619.PendingConfirmEmailDetails;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1619.PermEmailDetails;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1619.PreferredEmailDetails;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1620.NF1620RepData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1620.NF1620ReqData;
import com.dsb.eb2.bankApp.System.FunctionType;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.System.exeption.SystemException;
import com.dsb.eb2.bankApp.System.maintenance.ActivityLog;
import com.dsb.eb2.bankApp.dao.activityLog.ActivityLogBean;
import com.dsb.eb2.bankApp.dao.custPerEmail.CustPerEmailDao;
import com.dsb.eb2.bankApp.dao.custPerEmail.CustPerEmailRepository;
import com.dsb.eb2.common.constant.EnvKey;
import com.dsb.eb2.framework.log.Loggable;
import com.dsb.eb2.sso.model.CustomerInfo;
import com.dsb.eb2.util.Env;


@Loggable
@Service
public class CustPerEmailServiceImpl implements CustPerEmailService{

	private static Logger logger = LoggerFactory.getLogger(CustPerEmailService.class);
	
	private static int RECORD_COUNT = 7;
	
	@Autowired
	private CustPerEmailRepository custPerEmailRepository;

	@Autowired
	private CustPerEmailDao custPerEmailDao;
	
	@Autowired
    private ActivityLog activityLog;
	
	public Env getCifEmailInfo(String custId)throws Exception
	{
		String functionName = "getCifEmailInfo";
		
		Env cifEmailInfo = null;
		
		try
		{
			Env nf1619Result = callNF1619(custId);
			
			String responseCode = nf1619Result.getStr(EnvKey.RESPSTATUS);
			cifEmailInfo = new Env();
			cifEmailInfo.put(EmailConsolidationConstant.RESP_CODE, responseCode);
			
			if(String.valueOf(SystemStatusCode.SSC_NORMAL_EMS_RESPONE).equals(responseCode))
			{
				String permanent_address = nf1619Result.getStr(EnvKey.PERMANENT_EMAIL_ADDR);
				String permanent_reference_number = nf1619Result.getStr(EnvKey.PERMANENT_REFERENCE_NUMBER);
				
				String pending_email_addr = nf1619Result.getStr(EnvKey.PENDING_EMAIL_ADDR);
				String pending_ref_no = nf1619Result.getStr(EnvKey.PENDING_REF_NO);
				String pending_expiry_date = nf1619Result.getStr(EnvKey.PENDING_EXPIRY_DATE);
				

				
				if(CustPerEmailUtil.isEmpty(pending_email_addr))
				{
					cifEmailInfo.put(EmailConsolidationConstant.PENDING_STATUS, "");
					cifEmailInfo.put(EmailConsolidationConstant.PERMANENT_EMAIL, permanent_address);
					cifEmailInfo.put(EmailConsolidationConstant.TEMP_EMAIL, "");
					cifEmailInfo.put(EmailConsolidationConstant.REFERENCE_NUMBER, permanent_reference_number);
					cifEmailInfo.put(EmailConsolidationConstant.HOST_EMAIL_UPDATE_DATE, "");
					cifEmailInfo.put(EmailConsolidationConstant.EXPIRED_DATE, "");
				}else if(!CustPerEmailUtil.isEmailExpired(pending_expiry_date))
				{
					cifEmailInfo.put(EmailConsolidationConstant.PENDING_STATUS, EmailConsolidationConstant.PENDING);
					cifEmailInfo.put(EmailConsolidationConstant.PERMANENT_EMAIL, permanent_address);
					cifEmailInfo.put(EmailConsolidationConstant.TEMP_EMAIL, pending_email_addr);
					cifEmailInfo.put(EmailConsolidationConstant.REFERENCE_NUMBER, pending_ref_no);
					cifEmailInfo.put(EmailConsolidationConstant.HOST_EMAIL_UPDATE_DATE, "");
					cifEmailInfo.put(EmailConsolidationConstant.EXPIRED_DATE, pending_expiry_date);
				}else
				{
					cifEmailInfo.put(EmailConsolidationConstant.PENDING_STATUS, EmailConsolidationConstant.EXPIRED);
					cifEmailInfo.put(EmailConsolidationConstant.PERMANENT_EMAIL, permanent_address);
					cifEmailInfo.put(EmailConsolidationConstant.TEMP_EMAIL, pending_email_addr);
					cifEmailInfo.put(EmailConsolidationConstant.REFERENCE_NUMBER, pending_ref_no);
					cifEmailInfo.put(EmailConsolidationConstant.HOST_EMAIL_UPDATE_DATE, "");
					cifEmailInfo.put(EmailConsolidationConstant.EXPIRED_DATE, pending_expiry_date);
				}
			}
			
			CustPerEmailUtil.info(functionName, "end.getCifEmailInfo");
			
		} catch (Exception e){
			CustPerEmailUtil.error(functionName, e, null);
			throw e;
		}
		
		return cifEmailInfo;
	}
	
	public Env addChangeEmail(String custId, String tempEmail)throws Exception
	{
		return addChangeEmail(custId, tempEmail, null);
	}
	
	public Env addChangeEmail(String custId, String tempEmail, String isEmailSkip)throws Exception
	{
		return addChangeEmail(custId, tempEmail, isEmailSkip, null);
	}
	
	public Env addChangeEmail(String custId, String tempEmail, String isEmailSkip, CustomerInfo cust)throws Exception
	{
		String functionName = "addChangeEmail";
		Env addChangeEmailResult = null;
		
		////CustEmailAdd cea = null;
		
		try
		{
			CustPerEmailUtil.info(functionName, "beg.addChangeEmail isEmailSkip(" + isEmailSkip + ")");
			
			if( !CustPerEmailUtil.isEmpty(isEmailSkip) )
			{
				//For no duplicate record from web service, insert a record in DB if there is no record at first  
				////CustEmailAdd custEmail = CustEmailAddMtce.findByCustId(custId);
				////CustEmailAdd custEmail = null;
				////info(functionName, "custEmail=[" + custEmail + "]");
				////if (custEmail == null)
				{
					try
					{
						CustPerEmailUtil.info(functionName, "Add a new record by custId[" + custId + "]");
						
						////cea = new CustEmailAdd();
						////cea.setCustId(custId);
						
						if(cust != null)
						{
							CustPerEmailUtil.info(functionName, "Add a new record getTitle[" + cust.getTitle() + "]");
							CustPerEmailUtil.info(functionName, "Add a new record getName[" + cust.getName() + "]");
							////cea.setCustName((cust.getTitle() == null || cust.getTitle().equals(""))?cust.getName():cust.getTitle()+" "+cust.getName());
							////info(functionName, "Add a new record CustName[" + cea.getCustName() + "]");
						}
						
						////int addResult = CustEmailAddMtce.add(cea);
						int addResult=0;
						CustPerEmailUtil.info(functionName, "Add a new record addResult[" + addResult + "]");
						
						////info(functionName, "Add a new record custId[" + cea.getCustId() + "] createDate[" + formatDate(cea.getCreateDate(), EmailConsolidationConstant.DATE_FORMAT8, "") + "]");
						
								
					}catch (Exception e)
					{
						CustPerEmailUtil.error(functionName, null, "Add a new record by custId[" + custId + "] error:" + e.getMessage());
						CustPerEmailUtil.error(functionName, e, null);
					}
				}
			}
			
			Env nf1620Result = callNF1620(custId, EmailConsolidationConstant.PERMANENT_ACTION_UPDATE, tempEmail, "");
			
			String responseCode = nf1620Result.getStr(EnvKey.RESPSTATUS);
			
			addChangeEmailResult = new Env();
			addChangeEmailResult.put(EmailConsolidationConstant.RESP_CODE, responseCode);
			
			if(String.valueOf(SystemStatusCode.SSC_NORMAL_EMS_RESPONE).equals(responseCode))
			{
				
				
				String referenceNumber = nf1620Result.getStr(EnvKey.REF_NO);
				String hostEmailUpdateDate = nf1620Result.getStr(EnvKey.HOST_EMAIL_UPDATE_DATE);
				String emailUpdateStatus = nf1620Result.getStr(EnvKey.EMAIL_UPDATE_STATUS);
				CustPerEmailUtil.info(functionName, "referenceNumber=" + referenceNumber
									+ ", hostEmailUpdateDate=" + hostEmailUpdateDate
									+ ", emailUpdateStatus=" + emailUpdateStatus);
				if(CustPerEmailUtil.isEmpty(emailUpdateStatus) || !EmailConsolidationConstant.NORMALLY_UPDATED.equals(emailUpdateStatus.trim()))
				{
					throw new SystemException(SystemStatusCode.SSC_NO_EMAIL_UPDATE);
				}
				
				Env cifEmailInfo = getCifEmailInfo(custId);
				String expiredDate = cifEmailInfo.getStr(EmailConsolidationConstant.EXPIRED_DATE);
				String nf1619Ref = cifEmailInfo.getStr(EmailConsolidationConstant.REFERENCE_NUMBER);
				CustPerEmailUtil.info(functionName, "expiredDate=" + expiredDate
									+ ", nf1619Ref=" + nf1619Ref);
				
				if(CustPerEmailUtil.isEmpty(referenceNumber) && !CustPerEmailUtil.isEmpty(nf1619Ref))
				{
					referenceNumber = nf1619Ref;
				}
							
				addChangeEmailResult.put(EmailConsolidationConstant.TEMP_EMAIL, tempEmail);
				addChangeEmailResult.put(EmailConsolidationConstant.REFERENCE_NUMBER, referenceNumber);
				addChangeEmailResult.put(EmailConsolidationConstant.HOST_EMAIL_UPDATE_DATE, hostEmailUpdateDate);
				addChangeEmailResult.put(EmailConsolidationConstant.EXPIRED_DATE, expiredDate);
				addChangeEmailResult.put(EmailConsolidationConstant.EMAIL_UPDATE_STATUS, emailUpdateStatus);
				
				
			}
			
			CustPerEmailUtil.info(functionName, "end.addChangeEmail");
			
		} catch (Exception e){
			CustPerEmailUtil.error(functionName, e, null);
			throw e;
		}
		
		return addChangeEmailResult;
	}
	
	public String custVerifyEmail(String custId, String tempEmail, String refNo)throws Exception
	{
		String functionName = "custVerifyEmail";
		String verifyResult = "";
		try
		{
			CustPerEmailUtil.info(functionName, "beg.custVerifyEmail");
			
			Env nf1620Result = callNF1620(custId, EmailConsolidationConstant.PERMANENT_ACTION_VERIFY, tempEmail, refNo);
			
			String responseCode = nf1620Result.getStr(EnvKey.RESPSTATUS);
			
			if(String.valueOf(SystemStatusCode.SSC_NORMAL_EMS_RESPONE).equals(responseCode))
			{
				CustPerEmailUtil.info(functionName, "normal responseCode is [" + responseCode + "]");
				
				verifyResult = EmailConsolidationConstant.YES;
				String permanentEmail = nf1620Result.getStr(EnvKey.EMAIL_ADDR);
				String referenceNumber = nf1620Result.getStr(EnvKey.REF_NO);
				String hostEmailUpdateDate = nf1620Result.getStr(EnvKey.HOST_EMAIL_UPDATE_DATE);
				
				//E-Banking's CIF temp email address information will be deleted. E-Banking's CIF permanent email address will be updated.
				updatePermanentEmail(custId, permanentEmail, "", referenceNumber, hostEmailUpdateDate);
				CustPerEmailUtil.info(functionName, "## updatePermanentEmail successfully ##");
				
				//Customer's instruction (not yet execute) email address is updated to CIF permanent email address
				////CustEmailAddMtce.savePermanentEmailOneToInstr(custId, permanentEmail);
				CustPerEmailUtil.info(functionName, "## savePermanentEmailOneToInstr successfully ##");
				ActivityLogBean activityLogbean = new ActivityLogBean(custId,FunctionType.MF_PROFILE_MTCE,FunctionType.SF_EMAIL_ADDR_MTCE,SystemStatusCode.SSC_UNEXPECTED);
			}else
			{
				CustPerEmailUtil.info(functionName, "failed responseCode is [" + responseCode + "]");
				if("023196".equals(responseCode))	// record not found, treat preferred email address is empty
				{
					verifyResult = String.valueOf(SystemStatusCode.SSC_EMAIL_IS_EXPIRED);
				}
			}
			
			CustPerEmailUtil.info(functionName, "end.custVerifyEmail verifyResult=" + verifyResult);
		}catch (Exception e)
		{
			CustPerEmailUtil.error(functionName, e, null);
			//log0002956 : add activity log for the fail case of email conversion notification email link and email consolidation verification email link for call center to support			
			ActivityLogBean activityLogbean = new ActivityLogBean(custId,FunctionType.MF_PROFILE_MTCE,FunctionType.SF_EMAIL_ADDR_MTCE,SystemStatusCode.SSC_UNEXPECTED,e.getMessage());
//			activityLogbean.setCustId(custId);
//			activityLogbean.setMainType(FunctionType.MF_PROFILE_MTCE);
//			activityLogbean.setSubType(FunctionType.SF_EMAIL_ADDR_MTCE);
//			activityLogbean.setReturnCode(SystemStatusCode.SSC_UNEXPECTED);
//			activityLogbean.setDetails(e.getMessage());
	    	activityLog.setBean(activityLogbean);
	    	activityLog.record();
			throw e;
		}
		 
		return verifyResult;
	}
	
	public String resendVerifyEmail(String custId, String tempEmail, String refNo)throws Exception
	{
		String functionName = "custVerifyEmail";
		String newRefNo = "";
		try
		{
			CustPerEmailUtil.info(functionName, "beg.resendVerifyEmail");
			
			Env nf1620Result = callNF1620(custId, EmailConsolidationConstant.PERMANENT_ACTION_RESEND, tempEmail, refNo);
			
			String responseCode = nf1620Result.getStr(EnvKey.RESPSTATUS);
			
			if(String.valueOf(SystemStatusCode.SSC_NORMAL_EMS_RESPONE).equals(responseCode))
			{
				String referenceNumber = nf1620Result.getStr(EnvKey.REF_NO);
				newRefNo = referenceNumber;
				this.updateTempEmail(custId, "", referenceNumber);
			}
			
			CustPerEmailUtil.info(functionName, "end.resendVerifyEmail newRefNo=" + newRefNo);
		}catch (Exception e)
		{
			CustPerEmailUtil.error(functionName, e, null);
			throw e;
		}
		
		return newRefNo;
	}
	

	public boolean isNeedToAddChgEmailAddr(CustomerInfo customer) throws Exception{
			boolean rs = false;
			
			//NF1619 email address enquiry
			Env cifResp = callNF1619(customer.getCustId());
			String permanentEmail = cifResp.getStr(EnvKey.PERMANENT_EMAIL_ADDR);
			String penddingEmail = cifResp.getStr(EnvKey.PENDING_EMAIL_ADDR);
			String pendingExpiryDate = cifResp.getStr(EnvKey.PENDING_EXPIRY_DATE);	//YYYYMMDD
			logger.debug("LoginHelper.isNeedToAddChgEmailAddr(): permanentEmail=" + permanentEmail + ",penddingEmail=" + penddingEmail + ",pendingExpiryDate=" + pendingExpiryDate);
			if(permanentEmail == null || "".equals(permanentEmail.trim())){
				boolean isExpiry = false;
				if(pendingExpiryDate != null && pendingExpiryDate.length() == 8){
					SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
					int cal = new Integer(df.format(Calendar.getInstance().getTime()));
					int datein = new Integer(pendingExpiryDate);
					if(cal > datein){
						isExpiry = true;
					}
				}
				logger.debug("LoginHelper.isNeedToAddChgEmailAddr(): isExpiry=" + isExpiry);
				if(penddingEmail == null || "".equals(penddingEmail.trim()) || isExpiry) {
					rs = true;
				}
			}
			logger.debug("LoginHelper.isNeedToAddChgEmailAddr(): rs=" + rs);
			return rs;
	 }
	
	
	
	
	public Env callNF1619(String custId) throws Exception
	{
			return callNF1619(custId, EmailConsolidationConstant.PERMANENT_EMAIL_TYPE, null, null);
	}
		
	public Env callNF1619(String custId, String option, String historyInd, String refNo) throws Exception
	{
			String functionName = "callNF1619";
			
			Env output = null;
			
			try
			{
				CustPerEmailUtil.info(functionName, "custId=" + custId
												+ ", option=" + option
												+ ", historyInd=" + historyInd
												+ ", refNo=" + refNo);
				
				NF1619ReqData reqData = new NF1619ReqData();
				reqData.setOption(option);
				reqData.setHistoryInd(historyInd);
				reqData.setRefNum(refNo);
				
				EmsReqMsg emsReqMsg = EmsMsgFactory.createEmsReqMsg(reqData,custId);
					
				EMSQueueConnector connector = new EMSQueueConnector();
				 
				EmsRepMsg emsRepMsg = connector.invoke(emsReqMsg, new NF1619RepData());
				NF1619RepData repData=(NF1619RepData)emsRepMsg.getFrmData();
				
				String returnCode=emsRepMsg.getReturnCode();
				List <PermEmailDetails> permEmailDetails=repData.getPermEmailDetails();
				List <PendingConfirmEmailDetails> pendingConfirmEmailDetails=repData.getPendingConfirmEmailDetails();

				List <PreferredEmailDetails> preferredEmailDetails=repData.getPreferredEmailDetails();
				
				
				
				output = new Env();
				
				output.put(EnvKey.RESPSTATUS,returnCode);
				if(String.valueOf(SystemStatusCode.SSC_NORMAL_EMS_RESPONE).equals(returnCode)) {
					
					if(permEmailDetails!=null) {
						output.put(EnvKey.PERMANENT_EMAIL_ADDR, permEmailDetails.get(0).getAddress());
						output.put(EnvKey.PERMANENT_EMAIL_REMARK, permEmailDetails.get(0).getRemark());
						output.put(EnvKey.PERMANENT_UPDATE_CHANNEL, permEmailDetails.get(0).getUpdChannel());
						output.put(EnvKey.PERMANENT_UPDATE_DATE, permEmailDetails.get(0).getUpdDate());
						output.put(EnvKey.PERMANENT_UPDATE_TIME, permEmailDetails.get(0).getUpdTime());
						output.put(EnvKey.PERMANENT_UPDATE_USER, permEmailDetails.get(0).getUpdUser());
						output.put(EnvKey.PERMANENT_REFERENCE_NUMBER, permEmailDetails.get(0).getRefNum());
					}
				
					if(pendingConfirmEmailDetails!=null) {
						output.put(EnvKey.PENDING_EMAIL_ADDR, pendingConfirmEmailDetails.get(0).getAddress());
						output.put(EnvKey.PENDING_EMAIL_REMARK, pendingConfirmEmailDetails.get(0).getRemark());
						output.put(EnvKey.PENDING_UPDATE_CHANNEL, pendingConfirmEmailDetails.get(0).getUpdChannel());
						output.put(EnvKey.PENDING_UPDATE_DATE, pendingConfirmEmailDetails.get(0).getUpdDate());
						output.put(EnvKey.PENDING_UPDATE_TIME, pendingConfirmEmailDetails.get(0).getUpdTime());
						output.put(EnvKey.PENDING_UPDATE_USER, pendingConfirmEmailDetails.get(0).getUpdUser());
						output.put(EnvKey.PENDING_REF_NO, pendingConfirmEmailDetails.get(0).getRefNum());
						output.put(EnvKey.PENDING_EXPIRY_DATE, pendingConfirmEmailDetails.get(0).getExpiryDate());
						output.put(EnvKey.PENDING_STATUS, pendingConfirmEmailDetails.get(0).getStatus());
					}
			
					if(preferredEmailDetails!=null) {
						output.put(EnvKey.PREFERED_EMAIL_ADDR, preferredEmailDetails.get(0).getAddress());
						output.put(EnvKey.PREFERED_UPDATE_CHANNEL, preferredEmailDetails.get(0).getUpdChannel());
						output.put(EnvKey.PREFERED_UPDATE_DATE, preferredEmailDetails.get(0).getUpdDate());
						output.put(EnvKey.PREFERED_UPDATE_TIME, preferredEmailDetails.get(0).getUpdTime());
						output.put(EnvKey.PREFERED_UPDATE_USER, preferredEmailDetails.get(0).getUpdUser());
						output.put(EnvKey.PREFERED_CONSENT_REQUIRED, preferredEmailDetails.get(0).getConsentRequired());
						output.put(EnvKey.PREFERED_CONSENT_OBTAINED, preferredEmailDetails.get(0).getConsentObtained());
					}
				}
			}catch (Exception e)
			{
				CustPerEmailUtil.error(functionName, e, null);
				throw e;
			}
			
			return output;
	}
		
	public Env callNF1620(String custId, String action, String email, String refNo) throws Exception
	{
			if(CustPerEmailUtil.isEmpty(email))
			{
				CustPerEmailUtil.error("EmailConsolidationUtil.callNF1620", null, "[" + custId + "] [" + action + "] (" + refNo + ") callNF1620 email is empty");
				throw new SystemException(SystemStatusCode.SSC_NO_EMAIL_UPDATE);
			}
			return callNF1620(custId
								, EmailConsolidationConstant.EB_CHANNEL
								, EmailConsolidationConstant.PERMANENT_EMAIL_TYPE
								, action
								, email
								, null
								, refNo
								, null);
	}
		
	public Env callNF1620(String custId, String channelId, String option, String action, 
				String email, String remark, String refNo, String publicSiteInd) throws Exception
	{
			String functionName = "callNF1620";
			
			Env output = null;
			
			try
			{
				CustPerEmailUtil.info(functionName, "custId=" + custId
									+ ", channelId=" + channelId
									+ ", option=" + option
									+ ", action=" + action
									+ ", email=" + email
									+ ", remark=" + remark
									+ ", refNo=" + refNo
									+ ", publicSiteInd=" + publicSiteInd);
				
				NF1620ReqData reqData = new NF1620ReqData();
				reqData.setOption(option);
				reqData.setAction(action);
				reqData.setEmailAddr(email);
				reqData.setRemark(remark);
				reqData.setRefNum(refNo);
				reqData.setPublicSiteInd(publicSiteInd);


				EmsReqMsg emsReqMsg = EmsMsgFactory.createEmsReqMsg(reqData,custId);
					
				EMSQueueConnector connector = new EMSQueueConnector();
				 
				EmsRepMsg emsRepMsg = connector.invoke(emsReqMsg, new NF1620RepData());
				NF1620RepData repData=(NF1620RepData)emsRepMsg.getFrmData();
				String returnCode=emsRepMsg.getReturnCode();
				
				output = new Env();
				
				output.put(EnvKey.RESPSTATUS, returnCode);
				if(String.valueOf(SystemStatusCode.SSC_NORMAL_EMS_RESPONE).equals(returnCode)) {
					output.put(EnvKey.OPTION, repData.getOption());
					output.put(EnvKey.ACTION_CODE, repData.getAction());
					output.put(EnvKey.EMAIL_ADDR, repData.getEmailAddr());
					output.put(EnvKey.LOG_NUMBER, repData.getLogNum());
					output.put(EnvKey.REF_NO, repData.getNewRefNum());
					output.put(EnvKey.HOST_EMAIL_UPDATE_DATE, repData.getHostEmailUpdDate());
					output.put(EnvKey.EMAIL_UPDATE_STATUS, repData.getEmailUpdStatus());
				}

			}catch (Exception e)
			{
				CustPerEmailUtil.error(functionName, e, null);
				throw e;
			}
			
			return output;
	}

	
	
	//========================================== call DB ========================================================
	
	public String[] getRecordByCustId(String custId)throws Exception
	{
		String[] record = new String[RECORD_COUNT];
		
		String result=custPerEmailDao.getEmailDetailByCustId(custId);
		JSONObject jsonObj = JSONObject.fromObject(result);
		
		record[0] = jsonObj.getString("CUST_ID");
		return record;
	}
	
	public String[] getRecordByRefNo(String refNo)throws Exception
	{
		String[] record = new String[RECORD_COUNT];
		
		String result=custPerEmailDao.getEmailDetailByRefNo(refNo);
		JSONObject jsonObj = JSONObject.fromObject(result);
		
		record[0] = jsonObj.getString("CUST_ID");
		record[2] = jsonObj.getString("TEMP_EMAIL");
		
		return record;
	}
	
	@Transactional
	@Loggable(result = false, value = LogLevel.INFO)
	public int updatePermanentEmail(String custId
											, String permanentEmail
											, String tempEmail
											, String referenceNumber
											, String hostEmailUpdateDate)throws Exception
	{

		custPerEmailRepository.updatePermEmail(permanentEmail,tempEmail,"EB",referenceNumber,hostEmailUpdateDate,custId);
		
		return 1;
	}
	
	@Transactional
	@Loggable(result = false, value = LogLevel.INFO)
	public int updateTempEmail(String custId
									, String tempEmail
									, String referenceNumber)throws Exception
	{
		if(CustPerEmailUtil.isEmpty(tempEmail)) {
			custPerEmailRepository.updateTempEmailNORefNum(referenceNumber,custId);
		}else {
			custPerEmailRepository.updateTempEmail(tempEmail,"EB",referenceNumber,custId);
		}
		
		return 1;
	}
	
	
	
}
