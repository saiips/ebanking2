package com.dsb.eb2.api.custPerEmail;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.logging.LogLevel;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dsb.eb2.bankApp.System.FunctionType;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.System.maintenance.ActivityLog;
import com.dsb.eb2.bankApp.dao.activityLog.ActivityLogBean;
import com.dsb.eb2.framework.controller.ApiController;
import com.dsb.eb2.framework.controller.BaseController;
import com.dsb.eb2.framework.controller.RequestCorrelation;
import com.dsb.eb2.framework.log.Loggable;
import com.dsb.eb2.util.Env;

@RestController
@RequestMapping(ApiController.PWS_PATH)
@Loggable
public class CustPerEmailController extends BaseController {
	
	private static Logger logger = LoggerFactory.getLogger(CustPerEmailController.class);
	
	@Autowired
	private CustPerEmailService custPerEmailService;
	
	@Autowired
    private ActivityLog activityLog;
	
	@Transactional
	@RequestMapping(value = "/user/emailAddrGet", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	@Loggable(result = false, value = LogLevel.INFO)
	public ResponseEntity<Map<String, Object>> getCifEmailInfo(HttpServletRequest request, HttpServletResponse response) {
		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("path", ApiController.PWS_PATH + "/user/emailAddrGet");
		HttpHeaders header = null;
		try {
			String custId=RequestCorrelation.getClientID();
			if(CustPerEmailUtil.isEmpty(custId)) {
				custId="IDK2369117";
			}
			Env out=custPerEmailService.getCifEmailInfo(custId);

			String responseCode=out.getStr(EmailConsolidationConstant.RESP_CODE);
			
			if(String.valueOf(SystemStatusCode.SSC_NORMAL_EMS_RESPONE).equals(responseCode)) {
				ActivityLogBean activityLogbean = new ActivityLogBean(custId,FunctionType.MF_PROFILE_MTCE,FunctionType.SF_EMAIL_ADDR_MTCE,SystemStatusCode.SSC_NORMAL);
		    	activityLog.setBean(activityLogbean);
		    	activityLog.record();
		    	
				header = createResponseHeader();
				String refNum =out.getStr(EmailConsolidationConstant.REFERENCE_NUMBER);
				String permanentEmail = out.getStr(EmailConsolidationConstant.PERMANENT_EMAIL);
				String tempEmail =out.getStr(EmailConsolidationConstant.TEMP_EMAIL);
				String expiryDate =out.getStr(EmailConsolidationConstant.EXPIRED_DATE);
				map.put("refNum", refNum);
				map.put("emailAddrPerm", permanentEmail.trim());
				map.put("emailAddrTemp", tempEmail.trim());
				map.put("expiryDate", expiryDate);
				return (new ResponseEntity<>(map,header,HttpStatus.OK));
			}else {
				map.put("timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date())); 
				map.put("status", "500");
				map.put("error", responseCode);
				map.put("message", "NF1619 return error");
				return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
			}
		}catch(Exception e) {
			e.printStackTrace();
			map.put("timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date())); 
			map.put("message", e.getMessage());
			return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
			
		}
		
		
	}
	
	@Transactional
	@RequestMapping(value = "/user/emailUpdateTemp", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	@Loggable(result = false, value = LogLevel.INFO)
	public ResponseEntity<Map<String, Object>> firstSendVerifyEmail(HttpServletRequest request, HttpServletResponse response ,@RequestBody Map<String, Object> reqMap) {
		String functionName="firstSendVerifyEmail()";
		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("path", ApiController.PWS_PATH + "/user/emailUpdateTemp");
		HttpHeaders header = null;
		try {
			String custId=RequestCorrelation.getClientID();
			if(CustPerEmailUtil.isEmpty(custId)) {
				custId="IDK2369117";
			}
			String refNum = String.valueOf(reqMap.get("refNum"));
			String tempEmail = String.valueOf(reqMap.get("emailAddr"));
			
			Env addChangeEmailResult = custPerEmailService.addChangeEmail(custId, tempEmail, EmailConsolidationConstant.NO);
			
			String responseCode=addChangeEmailResult.getStr(EmailConsolidationConstant.RESP_CODE);
			
			if(String.valueOf(SystemStatusCode.SSC_NORMAL_EMS_RESPONE).equals(responseCode)) {
				String referenceNumber = addChangeEmailResult.getStr(EmailConsolidationConstant.REFERENCE_NUMBER);
				String hostEmailUpdateDate = addChangeEmailResult.getStr(EmailConsolidationConstant.HOST_EMAIL_UPDATE_DATE);
				String expiredDate = addChangeEmailResult.getStr(EmailConsolidationConstant.EXPIRED_DATE);
				//CustPerEmailUtil.stringToGregorianCalendar(hostEmailUpdateDate));
				logger.info(functionName+":refNum=" + refNum + ":getReferenceNumber=" + referenceNumber + ", getHostEmailUpdateDate=" + hostEmailUpdateDate + ", expiredDate=" + expiredDate);

				//statusCode = formInfoBean.savePermanentEmailAdd();
				
				header = createResponseHeader();
				map.put("refNum",  referenceNumber);
				map.put("expiredDate", expiredDate);
				map.put("emailAddrPerm", "");
				map.put("emailAddrTemp", tempEmail);
				return (new ResponseEntity<>(map,header,HttpStatus.OK));
			}else {
				map.put("timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date())); 
				map.put("status", "500");
				map.put("error", responseCode);
				map.put("message", "email address setup error");
				return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
			}
		}catch(Exception e) {
			e.printStackTrace();
			map.put("timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date())); 
			map.put("message", e.getMessage());
			return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
		}
	}
	
	@Transactional
	@RequestMapping(value = "/user/emailSendVerify", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	@Loggable(result = false, value = LogLevel.INFO)
	public ResponseEntity<Map<String, Object>> resendVerifyEmail(HttpServletRequest request, HttpServletResponse response ,@RequestBody Map<String, Object> reqMap) {
		String functionName="resendVerifyEmail()";
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("path", ApiController.PWS_PATH + "/user/emailSendVerify");
		HttpHeaders header = null;
		
		String refNo = "";
		String tempEmail = "";

		try {
			String custId=RequestCorrelation.getClientID();
			if(CustPerEmailUtil.isEmpty(custId)) {
				custId="IDK2369117";
			}
			refNo = String.valueOf(reqMap.get("refNum"));
			tempEmail = String.valueOf(reqMap.get("emailAddr"));
			
			String newRefNo = custPerEmailService.resendVerifyEmail(custId, tempEmail, refNo);
		
			logger.info(functionName+"tempEmail=" + tempEmail + ", refNo=" + refNo + ", newRefNo=" + newRefNo);

			Env cifEmailInfo = custPerEmailService.getCifEmailInfo(custId);
			String expiredDate = cifEmailInfo.getStr(EmailConsolidationConstant.EXPIRED_DATE);
		
			StringBuffer sb = new StringBuffer();
			sb.append("Resend to New Pending-Confirm Email: " + tempEmail + "]");
			sb.append("<br/>");
			sb.append("[New Pending-Confirm Email confirmation deadline : " + CustPerEmailUtil.formatDate(expiredDate, EmailConsolidationConstant.DATE_FORMAT7, null) + "]");
			sb.append("<br/>");
			sb.append("[Ref no. display on CIF enquiry : " + newRefNo + "]");
		
			ActivityLogBean activityLogbean = new ActivityLogBean(custId,FunctionType.MF_PROFILE_MTCE,FunctionType.RESEND_VERIFICATION_EMAIL,SystemStatusCode.SSC_NORMAL,sb.toString());
	    	activityLog.setBean(activityLogbean);
	    	activityLog.record();

			header = createResponseHeader();
			map.put("refNum",  newRefNo);
			map.put("expiredDate", expiredDate);
			map.put("emailAddrPerm", "");
			map.put("emailAddrTemp", tempEmail);
			return (new ResponseEntity<>(map,header,HttpStatus.OK));
		}catch(Exception e) {
			e.printStackTrace();
			map.put("timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date())); 
			map.put("message", e.getMessage());
			return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
		}
	}
	
	@Transactional
	@RequestMapping(value = "/user/emailVerifyProc", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	@Loggable(result = false, value = LogLevel.INFO)
	public ResponseEntity<Map<String, Object>> verifyEmail(HttpServletRequest request, HttpServletResponse response ,@RequestBody Map<String, Object> reqMap) {
		String functionName="verifyEmail()";
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("path", ApiController.PWS_PATH + "/user/emailVerifyProc");
		HttpHeaders header = null;
		
		String refNo = "";
		String tempEmail = "";

		try {
			refNo = String.valueOf(reqMap.get("refNum"));
			tempEmail = String.valueOf(reqMap.get("emailAddr"));
			
			String[] record = custPerEmailService.getRecordByRefNo(refNo);
			String custId = record[0];
			String dbEmail = record[2];
			String md5DbEmail = CustPerEmailUtil.genMD5(dbEmail); 
		
			String cifTempEmail = "";
			String md5CifTempEmail = "";
			String expiredDate = "";
		

			if(!CustPerEmailUtil.isEmpty(custId))
			{
				Env cifEmailInfo = custPerEmailService.getCifEmailInfo(custId);
			
				cifTempEmail = cifEmailInfo.getStr(EmailConsolidationConstant.TEMP_EMAIL);
				cifTempEmail = cifTempEmail.trim();
				md5CifTempEmail = CustPerEmailUtil.genMD5(cifTempEmail);
				expiredDate = cifEmailInfo.getStr(EmailConsolidationConstant.EXPIRED_DATE);
			}
		
			CustPerEmailUtil.info(functionName, "refno=" + refNo
											+ ", tempEmail=" + tempEmail
											+ ", custId=" + custId
											+ ", dbEmail=" + dbEmail
											+ ", md5DbEmail=" + md5DbEmail
											+ ", cifTempEmail=" + cifTempEmail
											+ ", md5CifTempEmail=" + md5CifTempEmail
											+ ", expiredDate=" + expiredDate);
		
			String verifyResult = "";
		
			if(!CustPerEmailUtil.isEmpty(cifTempEmail)
					&& !CustPerEmailUtil.isEmpty(dbEmail)
					&& !cifTempEmail.equals(dbEmail))
			{
				CustPerEmailUtil.info(functionName, "EBANK AND CIF NOT MATCH, SO UPDATE EBANK DB.");
				custPerEmailService.updateTempEmail(custId, cifTempEmail, refNo);
			}
		
			if(CustPerEmailUtil.isEmpty(cifTempEmail))
			{
				verifyResult = String.valueOf(SystemStatusCode.SSC_NO_TEMP_EMAIL_IS_FOUND);
			}else if(CustPerEmailUtil.isEmailExpired(expiredDate))
			{
				verifyResult = String.valueOf(SystemStatusCode.SSC_EMAIL_IS_EXPIRED);
			}else if(!CustPerEmailUtil.isEmpty(md5CifTempEmail)
				&& !md5CifTempEmail.equals(tempEmail) )
			{
				verifyResult = String.valueOf(SystemStatusCode.SSC_EMAIL_DOES_NOT_MATCH);
			}else
			{
				verifyResult = custPerEmailService.custVerifyEmail(custId, cifTempEmail, refNo);
			}
			
			
			if(String.valueOf(SystemStatusCode.SSC_NORMAL_EMS_RESPONE).equals(verifyResult)) {
				header = createResponseHeader();
				map.put("refNum",  refNo);
				map.put("emailAddrPerm", cifTempEmail);
				map.put("emailAddrTemp", tempEmail);
				map.put("expiredDate", expiredDate);
				return (new ResponseEntity<>(map,header,HttpStatus.OK));
			}else {
				map.put("timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date())); 
				map.put("status", "500");
				map.put("error", verifyResult);
				map.put("message", "email address verify failed");
				return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
			}
			
		}catch(Exception e) {
			e.printStackTrace();
			map.put("timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date())); 
			map.put("message", e.getMessage());
			return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
		}
	}

	private HttpHeaders createResponseHeader() {
		HttpHeaders header = new HttpHeaders();
		header.add(ApiController.CONTENT_TYPE, ApiController.CONTENT_TYPE_APPL_JSON);
		return header;
	}
}
