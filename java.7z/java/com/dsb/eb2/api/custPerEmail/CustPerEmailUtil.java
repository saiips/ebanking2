package com.dsb.eb2.api.custPerEmail;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dsb.eb2.bankApp.System.exeption.SystemException;
import com.dsb.eb2.sso.model.CustomerInfo;
import com.dsb.eb2.util.MD5;


public class CustPerEmailUtil {

	private static Logger logger = LoggerFactory.getLogger(CustPerEmailUtil.class);
	
	private static String loggerFunctionName = "Add/Change Email Address";
	
	public static final Pattern BLANK_REGEX = Pattern.compile("^\\s*$");
	
	/* =========================== print logger beg =========================== */
	public static void info(String functionName, String msg)
	{
		logger.info(loggerFunctionName + " => function[" + functionName + "] | content[" + msg + "]");
	}
	
	public static void debug(String functionName, String msg)
	{
		logger.debug(loggerFunctionName + " => function[" + functionName + "] | content[" + msg + "]");
	}
	
	public static void error(String functionName, Exception e, String errorMsg)
	{
		if(e != null)
		{
			if(e instanceof SystemException)
			{
				int errorCode = ((SystemException) e).getErrorCode();
				logger.error(loggerFunctionName + " (error) => function[" + functionName + "] | errorCode [" + errorCode + "] | content[" + e.getMessage() + "] | errorDetail : ", e);
			}else
			{
				logger.error(loggerFunctionName + " (error) => function[" + functionName + "] | content[" + e.getMessage() + "] | errorDetail : ", e);
			}
		}else
		{
			logger.error(loggerFunctionName + " (error) => function[" + functionName + "] | content[" + errorMsg + "]");
		}
	}
	/* =========================== print logger end =========================== */
	
	public static boolean isEmpty(String val)
	{
		boolean result = false;
		
		if(val == null || BLANK_REGEX.matcher(val).find())
		{
			result = true;
		}
		
		return result;
	}
	
	public static boolean isChiLanguage(Object lang)
	{
		boolean result = false;
		
		if(lang instanceof Integer)
		{
			if(CustomerInfo.LANG_PREF_CHINESE == (Integer)lang)
			{
				result = true;
			}
		}else if(lang instanceof String)
		{
			if(CustomerInfo.LANG_PREF_ZH_TW.equals(lang))
			{
				result = true;
			}
		}
		
		return result;
	}

	public static GregorianCalendar stringToGregorianCalendar(String dtStr)
	{
		String functionName = "stringToGregorianCalendar";
		
		GregorianCalendar gc = null;
		
		try
		{
			if(!isEmpty(dtStr)
				&& (
						dtStr.length() == 8
						|| dtStr.length() == 14
					)
			)
			{
				SimpleDateFormat sdf = null;
				if(dtStr.length() == 8)
				{
					try
					{
						sdf = new SimpleDateFormat(EmailConsolidationConstant.DATE_FORMAT3);
						String HHmmss = sdf.format(Calendar.getInstance().getTime());
						dtStr = dtStr + HHmmss;
					}catch (Exception e)
					{
						error(functionName, e, null);
					}
					
				}
				sdf = new SimpleDateFormat(EmailConsolidationConstant.DATE_FORMAT2 + EmailConsolidationConstant.DATE_FORMAT3);
				Date dt = sdf.parse(dtStr);
				gc = new GregorianCalendar();
				gc.setTime(dt);
				
			}else
			{
				info(functionName, "invalid dtStr [" + dtStr + "]");
			}
		}catch (Exception e)
		{
			error(functionName, null, "exception: dtStr=[" + dtStr + "]");
			error(functionName, e, null);
		}
		
		return gc;
	}
	
	public static String showDate(Object dt)
	{
		return formatDate(dt, EmailConsolidationConstant.DATE_FORMAT2, "");
	}
	
	public static String showDate(Object dt, Object lang)
	{
		return showDate(dt, EmailConsolidationConstant.DATE_FORMAT1, EmailConsolidationConstant.DATE_FORMAT1_CHI, lang);
	}
	
	public static String showDate(Object dt, String dtFormatEng, String dtFormatChi, Object lang)
	{
		String dtFormat = dtFormatEng;
		if(isChiLanguage(lang))
		{
			dtFormat = dtFormatChi;
		}
		return formatDate(dt, dtFormat, lang);
	}
	
	public static String formatDate(Object tDt, String fmt, Object lang)
	{
		String functionName = "formatDate";
		
		String dt = "";
		
		try
		{
			SimpleDateFormat sdf = new SimpleDateFormat(fmt);
			
			if(lang != null)
			{
				if(isChiLanguage(lang))
				{
					sdf = new SimpleDateFormat(fmt, Locale.CHINESE);
				}else
				{
					sdf = new SimpleDateFormat(fmt, Locale.ENGLISH);
				}
			}
			
			if(tDt instanceof String)
			{
				SimpleDateFormat sdfTemp = new SimpleDateFormat(EmailConsolidationConstant.DATE_FORMAT2);
				Date dtTemp = sdfTemp.parse((String) tDt);
				dt = sdf.format(dtTemp);
			}else if(tDt instanceof Date)
			{
				dt = sdf.format((Date) tDt);
			}else if(tDt instanceof GregorianCalendar)
			{
				dt = sdf.format( ((GregorianCalendar) tDt).getTime());
			}else
			{
				info(functionName, "tDt=" + tDt + ", fmt=" + fmt);
			}
		}catch (Exception e)
		{
			error(functionName, null, "exception: tDt=" + tDt + ", fmt=" + fmt);
			error(functionName, e, null);
		}
		
		return dt;
	}
	
	
	public static String genMD5(String val) throws Exception
	{
		if(val == null)
		{
			return null;
		}
		MD5 md5 = new MD5();
		return md5.genHashValue(val);
	}
	
	public static boolean isEmailExpired(String expiredDate)throws Exception
	{
		String functionName = "isEmailExpired";
		
		boolean result = true;
		
		try
		{
			info(functionName, "expiredDate=" + expiredDate);
			Date c = Calendar.getInstance().getTime();
			info(functionName, "c="+c);
			int currentDt = 0;
			int expiredDateInt = 0;
			try
			{
				expiredDateInt = Integer.parseInt(expiredDate);
				
				SimpleDateFormat sdf = new SimpleDateFormat(EmailConsolidationConstant.DATE_FORMAT2);
				currentDt = Integer.parseInt(sdf.format(c));
				
				if(currentDt <= expiredDateInt)
				{
					result = false;
				}
			}catch(Exception e)
			{
				error(functionName, e, null);
			}
			  
		}catch (Exception e)
		{
			error(functionName, e, null);
			throw e;
		}
		
		return result;
	}
	
	
	public static String leftPad(String str, char c, int length)
	{
		str = (str==null ? "" : str.trim());
		
		int spaceLen = length - str.length();
        
        if (spaceLen > 0)
        {
            char cc[] = new char[spaceLen];     
            for(int i = 0; i < spaceLen; i++)
            {
            	cc[i] = c;
            }
            return ( new String(cc) + str );    
        }else
        {
            return str;
        }
	}
	
	public static String rightPad(String str, char c, int length)
	{
		str = (str==null ? "" : str.trim());
		
		int spaceLen = length - str.length();
        
        if (spaceLen > 0)
        {
            char cc[] = new char[spaceLen];     
            for(int i = 0; i < spaceLen; i++)
            {
            	cc[i] = c;
            }
            return ( str + new String(cc) );        
        }else
        {
            return str;
        }
	}
	
	
}
