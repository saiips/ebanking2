package com.dsb.eb2.api.rating;

import java.util.Map;

public class RatingUtil {
	public static boolean checkInputIsEmpty(Map<String,Object> map) {
		boolean flag = false;
		if(map == null || map.isEmpty()) {
			flag = true;
		}
		return flag;
	}
	public static boolean checkInputIsInvalidate(Object value) {
		boolean flag = false;
		if(value == null) {
			flag = true;
		}else if(value instanceof String) {
			if("".equals(value))
				return true;
		}else if(value instanceof Integer) {
			if(((Integer) value).intValue() < 0 || ((Integer) value).intValue() > 9)
				return true;
		}
		return flag;
	}
}
