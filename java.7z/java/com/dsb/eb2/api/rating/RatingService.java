package com.dsb.eb2.api.rating;

import java.util.Map;

import org.springframework.http.HttpHeaders;

import com.dsb.eb2.bankApp.System.exeption.SystemException;

public interface RatingService {
	
	boolean checkInputIsEmpty(Map<String,Object> map);
	
	boolean checkInputIsInvalidate(Object value);
	
	void saveRatingBean(String SESSION_UID,int RATING,String SUBMIT_DATE)throws Exception;
	
	HttpHeaders createResponseHeader();
	
	Map<String, Object> createResponseMsg(boolean status,int code,String message);
	
	boolean checkSessionUIDUNUnique(String sessionUID) throws Exception;
	
	boolean checkSessionUIDIsvalidate(String sessionUID) throws SystemException;
}
