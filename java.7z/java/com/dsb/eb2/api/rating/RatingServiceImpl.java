package com.dsb.eb2.api.rating;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.logging.LogLevel;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.System.exeption.SystemException;
import com.dsb.eb2.bankApp.dao.cusSession.CusSessionOSBDao;
import com.dsb.eb2.bankApp.dao.rating.RatingOSBDao;
import com.dsb.eb2.bankApp.dao.rating.RatingRepository;
import com.dsb.eb2.framework.controller.ApiController;
import com.dsb.eb2.framework.log.Loggable;
import com.dsb.eb2.util.StringUtils;
@Loggable
@Service
public class RatingServiceImpl implements RatingService{
	private static Logger logger = LoggerFactory.getLogger(RatingServiceImpl.class);
	@Autowired
	private RatingRepository ratingRepository;
	@Autowired
	private RatingOSBDao ratingOSBDao;
	@Autowired
	private CusSessionOSBDao cusSessionOSBDao;
	
	@Loggable(result = false, value = LogLevel.INFO)
	public boolean checkInputIsEmpty(Map<String,Object> map) {
		boolean flag = false;
		if(map == null || map.isEmpty()) {
			flag = true;
		}
		return flag;
	}
	@Loggable(result = false, value = LogLevel.INFO)
	public boolean checkInputIsInvalidate(Object value) {
		boolean flag = false;
		if(value == null) {
			flag = true;
		}else if(value instanceof String) {
			if("".equals(value))
				return true;
		}else if(value instanceof Integer) {
			if(((Integer) value).intValue() <= 0 || ((Integer) value).intValue() > 5)
				return true;
		}
		return flag;
	}
	@Transactional
	@Loggable(result = false, value = LogLevel.INFO)
	public void saveRatingBean(String SESSION_UID,int RATING,String SUBMIT_DATE)throws Exception {
		try {
			ratingRepository.saveRatingBean(SESSION_UID, RATING, SUBMIT_DATE);
		}catch(Exception e) {
			logger.error(e.getMessage(), e);
			e.printStackTrace();
		}
	}
	@Loggable(result = false, value = LogLevel.INFO)
	public HttpHeaders createResponseHeader() {
		HttpHeaders header = new HttpHeaders();
		header.add(ApiController.CONTENT_TYPE, ApiController.CONTENT_TYPE_APPL_JSON);
		return header;
	}
	@Loggable(result = false, value = LogLevel.INFO)
	public Map<String, Object> createResponseMsg(boolean status,int code,String message){
		Map<String, Object> json = new HashMap<String, Object>();
    	json.put("timestamp",System.currentTimeMillis());
		json.put("status",status);
		json.put("code", code);
	    json.put("message", message); 
	    return json;
	}
	@Loggable(result = false, value = LogLevel.INFO)
	public boolean checkSessionUIDIsvalidate(String sessionUID) throws SystemException {
		boolean flag = false;
		Map<String,String> map = new HashMap<String,String>();
		try {
			map.put("SESSION_ID", sessionUID);
			JSONObject response = cusSessionOSBDao.checkSessionUIDIsvalidate(map);
			String status = response.getString("STATUS");
			System.out.println(status);
			if(StringUtils.isEmpty(status)) {
				flag = true;
				return flag;
			}
			//"Y"表示擁護為登陸狀態，“N”表示為登出狀態
			if(!"N".equals(status)) {
				flag = true;
				return flag;
			}
		} catch (Exception e) {
			throw new SystemException(SystemStatusCode.SSC_UNEXPECTED);
		}
		return flag;
	}
	@Loggable(result = false, value = LogLevel.INFO)
	public boolean checkSessionUIDUNUnique(String sessionUID)throws Exception {
		Map<String,String> map = new HashMap<String,String>();
		map.put("SESSION_ID", sessionUID);
		JSONObject response =  ratingOSBDao.checkSessionUidUnique(map);
		int count = Integer.valueOf(response.getString("COUNT"));
		System.out.println(count);
		if(count == 0) {
			return false;
		}else {
			return true;
		}
	}
}
