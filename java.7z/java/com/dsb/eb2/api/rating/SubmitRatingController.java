package com.dsb.eb2.api.rating;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.logging.LogLevel;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.framework.controller.BaseController;
import com.dsb.eb2.framework.log.Loggable;
@Loggable
@RestController
@RequestMapping("/pws/rating/service")
public class SubmitRatingController extends BaseController{

	@Autowired
	private RatingService ratingService;
	
	@RequestMapping(value="/submitRating", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
    @Loggable(result = false, value = LogLevel.INFO)
	public ResponseEntity<Map<String, Object>> submitRating(HttpServletRequest request, HttpServletResponse response ,@RequestBody Map<String, Object> ratingReqMap) {
		String sessionUID = "";
		Integer RATING = 0;
		Date  date= new Date();
		String SUBMIT_DATE = "";
		boolean flag = false;
		HttpHeaders header = null;
		Map<String, Object> json = null;
		try {
			flag = ratingService.checkInputIsEmpty(ratingReqMap);
			sessionUID = String.valueOf(ratingReqMap.get("sessionUID"));
			System.out.println("sessionUID = " +sessionUID);
			flag = ratingService.checkInputIsInvalidate(sessionUID);
			System.out.println("flag = " +flag);
			if(flag) {
				json = ratingService.createResponseMsg(false, SystemStatusCode.SSC_UNEXPECTED, "Invalid Request");
				return (new ResponseEntity<Map<String, Object>>(json,header, HttpStatus.BAD_REQUEST));
			}
			// Why need to check with Session ID?
			/*
			flag = ratingService.checkSessionUIDIsvalidate(sessionUID);
			if(flag) {
				json = ratingService.createResponseMsg(false, SystemStatusCode.SSC_UNEXPECTED, "Invalid Request");
				return (new ResponseEntity<Map<String, Object>>(json,header, HttpStatus.BAD_REQUEST));
			}
			flag = ratingService.checkSessionUIDUNUnique(sessionUID);
			if(flag) {
				json = ratingService.createResponseMsg(false, SystemStatusCode.SSC_UNEXPECTED, "Invalid Request");
				return (new ResponseEntity<Map<String, Object>>(json,header, HttpStatus.BAD_REQUEST));
			}
			*/
			RATING = Integer.valueOf(String.valueOf(ratingReqMap.get("rating")));
			flag = ratingService.checkInputIsInvalidate(RATING);
			if(flag) {
				json = ratingService.createResponseMsg(false, SystemStatusCode.SSC_UNEXPECTED, "Invalid Request");
				return (new ResponseEntity<Map<String, Object>>(json,header, HttpStatus.BAD_REQUEST));
			}
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			SUBMIT_DATE = sdf.format(date);
			ratingService.saveRatingBean(sessionUID, RATING, SUBMIT_DATE);
			header = ratingService.createResponseHeader();
			json = ratingService.createResponseMsg(true,SystemStatusCode.SSC_NORMAL,"Customer Rating submitted");
			return (new ResponseEntity<Map<String, Object>>(json,header, HttpStatus.OK));
		}catch(Exception e) {
			json  = ratingService.createResponseMsg(false, SystemStatusCode.SSC_UNEXPECTED,"Internal Server Error");
			return (new ResponseEntity<Map<String, Object>>(json,header, HttpStatus.INTERNAL_SERVER_ERROR));
		}
	}
}	
