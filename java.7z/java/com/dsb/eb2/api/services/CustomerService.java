package com.dsb.eb2.api.services;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dsb.eb2.backOffice.connect.emsMsg.EmsRepMsg;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1108.NF1108RepData;
import com.dsb.eb2.bankApp.dao.customer.CustomerBean;
import com.dsb.eb2.bankApp.dao.customer.CustomerDao;

@Service
public class CustomerService {
	
	@Autowired
	private CustomerDao customerDao;
	
	
	public CustomerBean getCustomerByCustId(String custId) throws IOException, Exception{
		
		 CustomerBean cust = customerDao.getCustomerByCustId(custId);
		 
		 return cust;
		
	}
	
	public NF1108RepData loadCustDetailsFromAgent(String custId) throws IOException, Exception{
		 System.out.println("ddddd");
		 EmsRepMsg response = customerDao.loadCustDetailsFromAgent(custId);
		 return (NF1108RepData)response.getFrmData();
	}

}
