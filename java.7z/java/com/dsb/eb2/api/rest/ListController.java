package com.dsb.eb2.api.rest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.logging.LogLevel;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dsb.eb2.api.model.Course;
import com.dsb.eb2.framework.controller.ApiController;
import com.dsb.eb2.framework.controller.RequestCorrelation;
import com.dsb.eb2.framework.log.Loggable;
import com.dsb.eb2.framework.sessions.UserSession;

@RestController
@RequestMapping(ApiController.PWS_PATH)
@Loggable
//@PreAuthorize("hasRole('USER')")
public class ListController {
	
	private static Logger logger = LoggerFactory.getLogger(ListController.class);
	
	private static final List<String> COURSES = Arrays.asList("Angularjs", "Angular", "Reactjs", "Emberjs", "Vuejs");
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/courses", method = RequestMethod.GET, produces="application/json")
	@ResponseBody
	@Loggable(result = false, value = LogLevel.INFO)
	public List<String> handleCoursesList(HttpServletRequest request) {
		logger.info("it workds");
		
		logger.info("Customer = " + RequestCorrelation.getClientID());
		
		// construct the user session
		UserSession session = new UserSession(request.getSession());
		HashMap<String, Object> hmap = session.getSessionKeyValue();
		hmap.clear();
		hmap.put("requestUrl", request.getRequestURL());
		session.setSessionKeyValue(hmap);

		// assign to the session attribute
		request.getSession().setAttribute("USER_SESSION", session);
        request.getSession().setAttribute("OTHERS", COURSES);  
		
		return COURSES;
	}
	
    @RequestMapping(value = "/sessions", method = RequestMethod.GET, produces="application/json")  
    public Object sessions (HttpServletRequest request){  
        Map<String, Object> map = new HashMap<>();  
        
        // get the UserSession object
        UserSession session = (UserSession) request.getSession().getAttribute("USER_SESSION");
        
        if (session != null) {
        	map.put("sessionID", session.getSessionID());
        	map.put("OTHERS", request.getSession().getAttribute("OTHERS"));
        } else {
        	map.put("sessionID", "sorry no session woh!");
        }
        
        // logout and then invalidate the session as usual
        request.getSession().invalidate();
        
        return map;  
    } 
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/object", method = RequestMethod.POST, produces="application/json")
	@ResponseBody
	@Loggable(result = false, value = LogLevel.INFO)
	public List<Course> handleObjectList() {
		
		List<Course> courses = new ArrayList<Course>();
		
		courses.add(new Course("Angularjs"));
		courses.add(new Course("Angular"));
		courses.add(new Course("Reactjs"));
		
		return courses;
	}	
	
}
