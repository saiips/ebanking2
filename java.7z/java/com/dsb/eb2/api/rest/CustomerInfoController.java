package com.dsb.eb2.api.rest;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.boot.logging.LogLevel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dsb.eb2.backOffice.connect.EMSQueueConnector;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsMsgFactory;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsRepMsg;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsReqMsg;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmHdr;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1108.NF1108RepData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1108.NF1108ReqData;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.framework.controller.ApiController;
import com.dsb.eb2.framework.controller.BaseController;
import com.dsb.eb2.framework.controller.RequestCorrelation;
import com.dsb.eb2.framework.log.Loggable;
import com.dsb.eb2.util.StringUtils;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;



@RestController
@RequestMapping(ApiController.PWS_PATH)
@Loggable
public class CustomerInfoController  extends BaseController{
	
	@RequestMapping(value = "/customer/service/getCustomerInfo", method = RequestMethod.POST, produces="application/json")
    @ResponseBody
    @Loggable(result = false, value = LogLevel.INFO)	
	public ResponseEntity getCustomerInfo(HttpServletRequest request, HttpServletResponse response){
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("path", ApiController.PWS_PATH + "/customer/service/getCustomerInfo");
		try {
			 String custId = RequestCorrelation.getClientID();
			
			 if(StringUtils.isEmpty(custId)) {
			    map.put("timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date())); 
			    map.put("status", "500");
			    map.put("error", "500");
			    map.put("message", "is not login");
			    return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
			 }
		     EmsRepMsg emsRepMsg = null;
		
			 NF1108ReqData req = new NF1108ReqData();
			 EmsReqMsg emsReqMsg = EmsMsgFactory.createEmsReqMsg(req, custId);
			 EMSQueueConnector connector = new EMSQueueConnector();
			 emsRepMsg = connector.invoke(emsReqMsg, new NF1108RepData());
			 FrmHdr frmHdr = emsRepMsg.getFrmHdr();
			 if(frmHdr.getReturnCode().equals(String.valueOf(SystemStatusCode.SSC_NORMAL_EMS_RESPONE))) {
				 NF1108RepData frmData = (NF1108RepData) emsRepMsg.getFrmData();
				 String frmDataStr = JSON.toJSONString(frmData);
				 return (new ResponseEntity<>(frmDataStr,HttpStatus.OK));
			 }else {
				    map.put("timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date())); 
					map.put("status", "500");
					map.put("error", frmHdr.getReturnCode());
					map.put("message", "NF1107 return error");
					return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
			 }
		} catch (Exception e) {
			e.printStackTrace();
			map.put("timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date())); 
			map.put("message", e.getMessage());
			return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
		}
	}
}

