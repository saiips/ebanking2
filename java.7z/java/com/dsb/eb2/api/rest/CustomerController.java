package com.dsb.eb2.api.rest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;

import com.dsb.eb2.api.model.Customer;
import com.dsb.eb2.api.model.Customer2;
import com.dsb.eb2.api.services.CustomerProfile;
import com.dsb.eb2.framework.controller.BaseController;
import com.dsb.eb2.framework.controller.BaseObject;

//@RestController
//@RequestMapping(ApiController.API_PATH)
//@Loggable
public class CustomerController extends BaseController {
	
	private static Logger logger = LoggerFactory.getLogger(CustomerController.class);
	
	//@Autowired
	private CustomerProfile customerProfile;
	
	//@RequestMapping(value = "/v1/customer/{id}", method = RequestMethod.GET, produces="application/json")
	//@ResponseBody
	//@Loggable(result = false, value = LogLevel.INFO)
	//@Base(value=BaseObject.class)
	public Object getCustomerOld(@PathVariable("id") int id) throws Exception {
		
		BaseObject baseObject = this.getBaseObject();
		//BaseObject baseObject = this.getBaseObjectTest(id);
		
		Customer customer = baseObject.getCustomer();
		
		// Customer customer = customerProfile.getCustomerTest(id);
		
		return customer.getCustTab().getCustTabItem();
	}	
	
	//@RequestMapping(value = "/customer2/{id}", method = RequestMethod.GET, produces="application/json")
	//@ResponseBody
	//@Loggable(result = false, value = LogLevel.INFO)
	public Object getCustomer(@PathVariable("id") int id) throws Exception {
		//logger.info("getCustomer by id:" + id);
		
		Customer2 customer = customerProfile.getCustomer2(id);
		
		return customer;
	}
	
}
