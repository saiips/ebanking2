package com.dsb.eb2.common.sort;

import java.util.Comparator;

public abstract class BaseComparatoer 
implements Comparator<Object>
{
    private boolean desc = false;

    private ComparatorKeyInter ck = new DefaultComparatorKey();

    private boolean ignoreCase;

    public ComparatorKeyInter getCk()
    {
        return ck;
    }

    public void setCk(ComparatorKeyInter ck)
    {
        this.ck = ck;
    }

    public boolean isDesc()
    {
        return desc;
    }

    public void setDesc(boolean desc)
    {
        this.desc = desc;
    }

    public BaseComparatoer(boolean desc, ComparatorKeyInter ck,
        boolean ignoreCase)
    {
        this.desc = desc;
        this.ck = ck;
        this.ignoreCase = ignoreCase;
    }

    public BaseComparatoer()
    {

    }

    public boolean isIgnoreCase()
    {
        return ignoreCase;
    }

    public void setIgnoreCase(boolean ignoreCase)
    {
        this.ignoreCase = ignoreCase;
    }

}
