package com.dsb.eb2.common.sort;

public class UnicodeComparatoer
    extends BaseComparatoer
{

    public UnicodeComparatoer(boolean desc, ComparatorKeyInter ck,
        boolean ignoreCase)
    {
        super(desc, ck, ignoreCase);
    }

    public UnicodeComparatoer()
    {
        super();
    }

    @Override
    public int compare(Object o1, Object o2)
    {
        int back = doCompare(o1, o2);
        if (this.isDesc())
        {
            back = -back;
        }
        return back;
    }

    public int doCompare(Object para1, Object para2)
    {
        String o1 = this.getCk().getCompareKey(para1);
        String o2 = this.getCk().getCompareKey(para2);
        if (o1 == null && o2 == null)
        {
            return 0;
        } else if (o1 == null && o2 != null)
        {
            return -1;
        } else if (o1 != null && o2 == null)
        {
            return 1;
        }
        if (this.isIgnoreCase())
        {
            o1 = o1.toLowerCase();
            o2 = o2.toLowerCase();
        }
        return o1.compareTo(o2);
    }
}
