package com.dsb.eb2.common.sort;

public interface ComparatorKeyInter
{
    public String getCompareKey(Object obj);
}
