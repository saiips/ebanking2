package com.dsb.eb2.common.sort;

public class DefaultComparatorKey implements ComparatorKeyInter
{

    @Override
    public String getCompareKey(Object obj)
    {
        // TODO Auto-generated method stub
        if(obj==null)
        {
            return null;
        }
        return obj.toString();
    }

}
