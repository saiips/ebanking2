package com.dsb.eb2.common.commonFun.sendSMS;

import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dsb.eb2.backOffice.connect.webService.handle.HandleSmsSend;
import com.dsb.eb2.backOffice.connect.webService.soaobj.EmsHeaderType;
import com.dsb.eb2.backOffice.connect.webService.soaobj.EmsSOAService;
import com.dsb.eb2.backOffice.connect.webService.soaobj.ObjectFactory;
import com.dsb.eb2.backOffice.connect.webService.soaobj.SendSMSRequest;
import com.dsb.eb2.backOffice.connect.webService.soaobj.SendSMSResponse;
import com.dsb.eb2.bankApp.System.SystemConfig;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.System.exeption.SystemException;
import com.dsb.eb2.common.constant.EnvKey;
import com.dsb.eb2.util.Env;
@Component
public class SendSMSProcessor {
	@Autowired
	private HandleSmsSend handleSmsSend;
	
	private static Logger logger = LoggerFactory.getLogger(SendSMSProcessor.class);
	private static String loggerFunctionName = "SMSSendingAgent - ";
	
	private EmsSOAService service;
	private SendSMSResponse response;
	private boolean sendSMSFinish = false;
	
	private  int MAX_RETRY_COUNT = 3;
	private  int TIMEOUT = 1000 * 60;
	
	private final static int SMS  = 123;
	
	public SendSMSProcessor() {
		this.service = (EmsSOAService)service;
		try {
			MAX_RETRY_COUNT = Integer.parseInt(SystemConfig.getSystemParameter("ems_sms_retry"));
			TIMEOUT = Integer.parseInt(SystemConfig.getSystemParameter("ems_sms_timeout"));
			this.service = (EmsSOAService)((Future)service).get(TIMEOUT / 1000, TimeUnit.SECONDS);
		}
		catch (Exception e)
		{
			logger.error("Error e = " + e.getMessage());
		}
	}
	
	public Env handle(Env eIn) throws SystemException
	{
		String content = "";
		String key = "";
		String value = "";
		Env eOut = null;
		try { 
			content = "";
			
			for (Enumeration e = eIn.keys(); e.hasMoreElements(); )
			{
				key = (String)e.nextElement();
				value = (String)eIn.get(key);
				if (!EnvKey.PROGRAM_ID.equals(key) && !EnvKey.EMAIL.equals(key) && !EnvKey.SUBJECT.equals(key))
				{
					content = content.replaceAll("%" + key + "%", value);
				}
			}
			eOut = sendSMS(new String[]{(String)eIn.get(EnvKey.SUBJECT)}, content, (String)eIn.get(EnvKey.LANG), (String)eIn.get(EnvKey.REF_NO), eIn.getStr(EnvKey.CUST_ID));
		}catch (Exception e){
			e.printStackTrace(System.out);
			throw new SystemException(SystemStatusCode.SSC_UNEXPECTED);
		}
		return eOut;
	}
	
	public Env sendSMS(String[] recipient, String content, String lang, String ref_no, String cust_id) throws SystemException
	{
		return sendSMS(recipient,content,lang,ref_no,cust_id, 4);
	}
	
	public Env sendSMS(String[] recipient, String content, String lang, String ref_no, String cust_id, int messageType) throws SystemException
	{
		return sendSMS(recipient,content,lang,ref_no,cust_id, messageType,null,null);
	}
	
	public Env sendSMS(String[] recipient, String content, String lang, String ref_no, String cust_id, int messageType,String templateID,List<String> templateContent) throws SystemException
	{
		return sendSMS(recipient, content, lang, ref_no, cust_id, messageType,templateID,templateContent, null);
	}
	
	public Env sendSMS(String[] recipient, String content, String lang, String ref_no, String cust_id, int messageType,String templateID,List<String> templateContent, String retryProcessFlag) throws SystemException
	{
		return sendSMS(recipient,content,lang,ref_no,cust_id,messageType,templateID,templateContent,retryProcessFlag,null);
	}
	
	public Env sendSMS(String[] recipient, String content, String lang, String ref_no, String cust_id, int messageType,String templateID,List<String> templateContent, String retryProcessFlag, String accuntNum) throws SystemException
	{
		return sendSMS(recipient, content, lang, ref_no, cust_id, messageType, templateID, templateContent, retryProcessFlag, accuntNum, null);
	}
	
	public Env sendSMS(String[] recipient, String content, String lang, String ref_no, String cust_id, int messageType,String templateID,List<String> templateContent, String retryProcessFlag, String accuntNum, String emsHeaderType) throws SystemException
	{
		Env eOut = new Env();
		try {
			SendSMSRequest request = new SendSMSRequest();
			EmsHeaderType header = new EmsHeaderType();
			header.setBankCode("6");
			header.setChannelID("EB");
			header.setServiceVersion(1);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			header.setTxDateTime(sdf.format(new java.util.Date()));
			header.setSysTraceNum(ref_no);
			header.setLanguage(lang);
			header.setReturnCode("0");
			header.setCustID(cust_id);
			if (messageType == 54 || messageType == 74 || messageType == 76) {
				header.setServiceID("SendSMSFrPropTemplate");
			}
			if (retryProcessFlag != null) {
				header.setRetryProcessFlag(retryProcessFlag);
			}
			
			/*if(!SecurityUtils.isEmpty(emsHeaderType))
			{
				SecurityUtils.resetObject(header, emsHeaderType);
			}*/
			request.setEmsHeader(header);
			for (int i = 0; i < recipient.length; i++) {
				request.getRecipient().add(recipient[i]);
			}
			request.setContent(content);
			request.setMsgLen(content.length());
			request.setLanguage(lang);
			request.setMsgType(messageType);
			request.setPriority("H");
			request.setRefNum(ref_no);
			
			//For WeChat SMS
			if (accuntNum != null)
				request.setAcctNum(accuntNum);
				
			if(templateID!=null){//SV
				request.setTemplateID(templateID);
				}
			if(templateContent != null){//SV
				request.setTemplateContent(templateContent);
			}
			int retryCount = 0;
			eOut.put(EnvKey.DESCRIPTION, content);
			while (retryCount < MAX_RETRY_COUNT)
			{
				Thread smsThread = new Thread(this.new ThreadSendSMS(this, request));
				smsThread.start();

				logger.info("Before Wait = " + new Date() + "; retryCount = " + retryCount);
				synchronized(this)
				{
					this.wait(TIMEOUT);
				} 
				logger.info("After Wait = " + new Date() + ";" + sendSMSFinish);

				if (sendSMSFinish)
				{
					logger.info("Response = " + response.getRefNum());
					logger.info("Return Code = " + response.getEmsHeader().getReturnCode());
					if (response.getEmsHeader().getReturnCode() != null && "900000".equals(response.getEmsHeader().getReturnCode()))
						eOut.put(EnvKey.RESPSTATUS, "Y");
					else
						eOut.put(EnvKey.RESPSTATUS, "N");
					
					break;
				}
				else
				{
					smsThread.stop();
					retryCount++;
					sendSMSFinish = false;
				}
			}

			if (!sendSMSFinish)
			{
				eOut.put(EnvKey.RESPSTATUS, "N");
			}
		}
		catch (Exception e)
		{
			e.printStackTrace(System.out);
			//TODO ErrorLog(yusuwu)
			/*errLog = new ErrorLog(SystemStatusCode.SSC_UNEXPECTED,"SMS error.",e, cust_id);
			errLog.record();*/
			throw new SystemException(SystemStatusCode.SSC_UNEXPECTED);
		}
		
		return eOut;
	}
	
	private class ThreadSendSMS implements Runnable
	{
		SendSMSRequest request;
		SendSMSProcessor sendSMSProcessor;
		
		public ThreadSendSMS(SendSMSProcessor sendSMSProcessor, SendSMSRequest request)
		{
			this.sendSMSProcessor = sendSMSProcessor;
			this.request = request;
		}
		
		public void run()
		{
			/*stub = (BindingProvider)service.getEmsSOAPort();
			stub.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, SystemConfig.getSystemParameter("ems_sms_url"));
			port = (EmsSOAPortType)stub;*/
			
			if (request != null)
			{
				try 
				{
					ObjectFactory factory = new ObjectFactory();
					JAXBElement<SendSMSRequest> elementDown = factory.createMsgSendSMSRequest(request);
					getRequestXML(elementDown);
				}catch (Exception e)
				{
					logger.error(loggerFunctionName + "error:" + e.getMessage(), e);
				}
			}
			
	        try {
	        	/*
	        	 * response = handle_smsSending.invoke(SendSMSRequest request);
	        	 */
//	        	response = port.sendSMS(request);
	        	response = handleSmsSend.invoke(request);
	        }
			catch(Exception e)
			{
	        	e.printStackTrace(System.out);
	        }

	        if (response != null)
			{
				try 
				{
					ObjectFactory factory = new ObjectFactory();
					JAXBElement<SendSMSResponse> elementDown = factory.createMsgSendSMSResponse(response);
					getResponseXML(elementDown);
				}catch (Exception e)
				{
					logger.error(loggerFunctionName + "error:" + e.getMessage(), e);
				}
			}
	        
			sendSMSFinish = true;
			
			logger.info("Before notify = " + new Date());
			synchronized(sendSMSProcessor)
			{
				sendSMSProcessor.notifyAll();
			}
			logger.info("After notify = " + new Date());
		}
	}
	
	public String getRequestXML(JAXBElement<SendSMSRequest> element)
    {
		StringWriter sw = new StringWriter();
        try
        {
        	logger.info(loggerFunctionName + "getRequestXML");
            JAXBContext jc = JAXBContext.newInstance(SendSMSRequest.class);
            Marshaller m = jc.createMarshaller();
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            m.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
            m.marshal(element, sw);
            logger.info(loggerFunctionName + "getRequestXML : " + sw.toString());
        }catch (Exception e)
        {
        	logger.error(loggerFunctionName + "error:" + e.getMessage(), e);
        }
        return sw.toString();
    }
	
	public String getResponseXML(JAXBElement<SendSMSResponse> element)
    {
		StringWriter sw = new StringWriter();
        try
        {
        	logger.info(loggerFunctionName + "getResponseXML");
            JAXBContext jc = JAXBContext.newInstance(SendSMSResponse.class);
            Marshaller m = jc.createMarshaller();
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            m.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
            m.marshal(element, sw);
            logger.info(loggerFunctionName + "getResponseXML : " + sw.toString());
        }catch (Exception e)
        {
        	logger.error(loggerFunctionName + "error:" + e.getMessage(), e);
        }
        return sw.toString();
    }
}
