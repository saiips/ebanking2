package com.dsb.eb2.common.commonFun.smsOTP;

import java.util.LinkedList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dsb.eb2.api.common.smsOTP.model.SMSSecurityFrontEndBean;
import com.dsb.eb2.api.common.smsOTP.service.EBankKeyPariService;
import com.dsb.eb2.api.common.smsOTP.service.HandlerSmsOTPService;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.System.exeption.SystemException;
import com.dsb.eb2.bankApp.System.maintenance.ActivityLog;
import com.dsb.eb2.bankApp.dao.activityLog.ActivityLogBean;
import com.dsb.eb2.bankApp.dao.eBankKeyPair.EBankKeyPariBean;
import com.dsb.eb2.bankApp.massagedMobileNo.MassagedMobileNo;
import com.dsb.eb2.framework.log.Loggable;
import com.dsb.eb2.util.SecurityUtils;

@Service
@Loggable
public class SmsOtpCommonService {
	
	@Autowired
	private HandlerSmsOTPService handlerSmsOTPService;
	@Autowired
	private EBankKeyPariService eBankKeyPariService;
	@Autowired
    private ActivityLog activityLog;
	
	public SMSSecurityFrontEndBean smsAuthInput(SMSSecurityFrontEndBean bean) throws SystemException {
		String smsLang = "";
		String smsMobileNo = "";
		boolean validMobile = false;
		EBankKeyPariBean eBankKeyPariBean = null;
//		EBankKeyPariBean keyPairDesc = null;
		String smsotpRefno = "";
		try {
			smsLang = handlerSmsOTPService.getSmsLang(bean.getSmsLang(),bean.getCustId(),"LOGIN_PREF");
			bean.setSmsLang(smsLang);
			smsMobileNo = MassagedMobileNo.getMassagedMobileNo(bean.getCustId());
			if(!validMobile) {
				ActivityLogBean activityLogbean = new ActivityLogBean();
				activityLogbean.setCustId( bean.getCustId());
				activityLogbean.setMainType(bean.getMainType());
				activityLogbean.setSubType(bean.getSubType());
				activityLogbean.setReturnCode(SystemStatusCode.SCC_EMPTY_PHONENO);
		    	activityLog.setBean(activityLogbean);
				if(bean.getExtendedType() != -1)
				{
					activityLogbean.setExtendedType(bean.getExtendedType());
				}
				activityLog.record();
				throw new SystemException(SystemStatusCode.SCC_EMPTY_PHONENO);
			}
			bean.setSmsMobileNo(smsMobileNo);
			eBankKeyPariBean = eBankKeyPariService.findRecord();
//			keyPairDesc = SecurityUtils.getkeyPairDesc(eBankKeyPariBeanList);
			if(eBankKeyPariBean != null){
				bean.setPublicKey(eBankKeyPariBean.getPublicKey());
				bean.setPrivateKey(eBankKeyPariBean.getPrivateKey());
			}
			smsotpRefno = handlerSmsOTPService.sendSmsOTP(bean);
			bean.setSmsotpRefno(smsotpRefno);
		}catch(Exception e) {
			throw new SystemException(SystemStatusCode.SCC_SEND_SMS_OTP_ERROR);
		}
		return bean;
	}
}
