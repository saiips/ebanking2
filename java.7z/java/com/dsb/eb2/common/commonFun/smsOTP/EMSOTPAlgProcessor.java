package com.dsb.eb2.common.commonFun.smsOTP;

import java.text.SimpleDateFormat;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.logging.LogLevel;

import com.dsb.eb2.api.common.smsOTP.model.SmsOtpSecurityBean;
import com.dsb.eb2.backOffice.connect.webService.Constants.SecurityConstants;
import com.dsb.eb2.backOffice.connect.webService.emsOTPAlgorithm.EmsHeaderType;
import com.dsb.eb2.backOffice.connect.webService.emsOTPAlgorithm.ThalesGenActCodeRequest;
import com.dsb.eb2.backOffice.connect.webService.emsOTPAlgorithm.ThalesGenActCodeResponse;
import com.dsb.eb2.backOffice.connect.webService.handle.HandleSmsOTP;
import com.dsb.eb2.bankApp.System.BankCode;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.System.exeption.SystemException;
import com.dsb.eb2.framework.log.Loggable;
import com.dsb.eb2.sso.controller.LoginController;
import com.dsb.eb2.util.FormatUtils;

import lombok.Data;



@Data
public class EMSOTPAlgProcessor {
	
	private static Logger log = LoggerFactory.getLogger(LoginController.class);
	//common header
		private EmsHeaderType emsHeader;
		private String channelId;
		private String custId;
		private String PBID;
		private String reservedbyHost;
		
		//ThalesGenActCode request
		private int ActCodeFormat= -1;
		private int ActCodeLength= -1;
		private String AcctNum;
		private String Recipient;
		private int SmsMsgType= -1;
		private String SmsLang;
		private String SmsSupportOverseaFlag;
		private String SmsTemplateID;
		private List<String> SmsTemplateContent;
		private String RefNum;
		private String Key3Des;
		
		private String deptCode;
		private HandleSmsOTP handleSmsOTP;
		
		public EMSOTPAlgProcessor(SmsOtpSecurityBean bean)
		{
			this.custId=bean.getCustId();
			//暫時先送custId,具體待以後確定
			this.PBID=bean.getCustId();
			this.ActCodeFormat=bean.getActCodeFormat();
			this.ActCodeLength=bean.getActCodeLength();
			this.AcctNum=bean.getAcctNum();
			this.Recipient=bean.getRecipient();
			this.SmsMsgType=bean.getSmsMsgType();
			this.SmsLang=bean.getSmsLang();
			this.SmsSupportOverseaFlag=bean.getSmsSupportOverseaFlag();
			this.SmsTemplateID=bean.getSmsTemplateID();
			this.SmsTemplateContent=bean.getSmsTemplateContent();
			this.RefNum=bean.getRefNum();
			this.Key3Des=bean.getKey3Des();
			this.deptCode = bean.getDeptCode();
		}
		@Loggable(result = false, value = LogLevel.INFO)
		public synchronized ThalesGenActCodeResponse getResponse() throws Exception
		{	
			ThalesGenActCodeResponse thalesGenActCodeResponse = null;
			try {
					if(handleSmsOTP == null) {
						handleSmsOTP = new HandleSmsOTP();
					}
					ThalesGenActCodeRequest request = this.getRequest();
					thalesGenActCodeResponse = handleSmsOTP.invoke(request);
			}catch(Exception e){
				log.info(FormatUtils.getStackTrace(e));
				throw new SystemException(SystemStatusCode.SCC_SEND_SMS_OTP_ERROR);
			}
			return thalesGenActCodeResponse;
		}
		@Loggable(result = false, value = LogLevel.INFO)
		private ThalesGenActCodeRequest getRequest() throws SystemException
		{
			ThalesGenActCodeRequest request = new ThalesGenActCodeRequest();
			try 
			{
				request.setEmsHeader(prepareEmsHeaderTypeParam());
				prepareEmsBodyParam(request);
			}catch (Exception e)
			{
				throw new SystemException(SystemStatusCode.SCC_SEND_SMS_OTP_ERROR);
			}
			return request;
		}
		@Loggable(result = false, value = LogLevel.INFO)
		private EmsHeaderType prepareEmsHeaderTypeParam()
		{
			
			EmsHeaderType result = new EmsHeaderType();
			
			result.setBankCode(BankCode.BC_DSB);
			result.setCustID(this.getCustId());
			result.setLoginID(this.getPBID());
			String rq_channelId = this.getChannelId();
			if(rq_channelId == null || "".equals(rq_channelId.trim()))
			{
				rq_channelId = new String("EB");
			}
			result.setChannelID(rq_channelId);
			result.setServiceVersion(1);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			String formattedDate = sdf.format(new java.util.Date());
			result.setTxDateTime(formattedDate);
			if(this.getSmsMsgType() == SecurityConstants.INVEST_SRV_SMS_MSG_TYPE
				&& SecurityConstants.INVEST_SRV_SMS_TEMPLATE_ID.equals(this.getSmsTemplateID())
				)
			{
				result.setDeptCode("WMD");
			}else
			{
				result.setDeptCode(this.deptCode);
			}
			result.setSysTraceNum(this.getRefNum());
			String rq_reservedbyHost = this.getReservedbyHost();
			if(rq_reservedbyHost == null || "".equals(rq_reservedbyHost.trim()))
			{
				rq_reservedbyHost = "FI";
			}
			result.setReservedbyHost(rq_reservedbyHost);
			return result;
		}
		@Loggable(result = false, value = LogLevel.INFO)
		private ThalesGenActCodeRequest prepareEmsBodyParam(ThalesGenActCodeRequest requestBean)
		{
			ThalesGenActCodeRequest result = null;
			if(requestBean != null)
			{
				String rq_AcctNum = this.getAcctNum();
				int rq_ActCodeFormat= this.getActCodeFormat();
				int rq_ActCodeLength=this.getActCodeLength();
				String rq_Recipient= this.getRecipient();
				int rq_SmsMsgType=this.getSmsMsgType();
				String rq_SmsLang=this.getSmsLang();
				String rq_SmsSupportOverseaFlag=this.getSmsSupportOverseaFlag();
				String rq_SmsTemplateID=this.getSmsTemplateID();
				List<String> rq_SmsTemplateContent=this.getSmsTemplateContent();
				String rq_RefNum=this.getRefNum();
				String rq_Key3Des=this.getKey3Des();
				
				if(rq_AcctNum != null){requestBean.setAcctNum(rq_AcctNum);}
				if(rq_ActCodeFormat != -1){requestBean.setActCodeFormat(rq_ActCodeFormat);}
				if(rq_ActCodeLength != -1){requestBean.setActCodeLength(rq_ActCodeLength);}
				if(rq_Recipient != null){requestBean.setRecipient(rq_Recipient);}
				if(rq_SmsMsgType != -1){requestBean.setSmsMsgType(rq_SmsMsgType);}
				if(rq_SmsLang != null){requestBean.setSmsLang(rq_SmsLang);}
				if(rq_SmsSupportOverseaFlag != null){requestBean.setSmsSupportOverseaFlag(rq_SmsSupportOverseaFlag);}
				if(rq_SmsTemplateID != null){requestBean.setSmsTemplateID(rq_SmsTemplateID);}
				if(rq_SmsTemplateContent != null){requestBean.setSmsTemplateContent(rq_SmsTemplateContent);}
				if(rq_RefNum != null){requestBean.setRefNum(rq_RefNum);}
				if(rq_Key3Des != null){requestBean.setKey3Des(rq_Key3Des);}
			
				result = requestBean;
			}
			return result;
		}
		
		
}
