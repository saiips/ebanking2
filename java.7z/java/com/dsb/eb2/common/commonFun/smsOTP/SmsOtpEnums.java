package com.dsb.eb2.common.commonFun.smsOTP;

import com.dsb.eb2.api.common.smsOTP.model.SmsOtpParams;

public enum SmsOtpEnums {
	LOGIN("login",new SmsOtpParams("3","Y","WMD",58,1,1,1));
	
	private String type;
	private SmsOtpParams values;
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public SmsOtpParams getValues() {
		return values;
	}

	public void setValues(SmsOtpParams values) {
		this.values = values;
	}

	private SmsOtpEnums(String type,SmsOtpParams values) {
		this.type = type;
		this.values = values;
	}
	
	public static SmsOtpParams getValues(String type) {
		for(SmsOtpEnums o : SmsOtpEnums.values()) {
			if(o.getType().equals(type)) {
				return o.getValues();
			}
		}
		return null;
	}
	
	public static void main(String[] args) {
		SmsOtpParams params = SmsOtpEnums.getValues("login");
		System.out.println(params.getSmsTemplateId());
		System.out.println(params.getSmsSupportOverseaFlag());
		System.out.println(params.getDeptCode());
		System.out.println(params.getSmsMsgType());
		System.out.println(params.getMainType());
		System.out.println(params.getSubType());
		System.out.println(params.getExtendedType());
	}
}
