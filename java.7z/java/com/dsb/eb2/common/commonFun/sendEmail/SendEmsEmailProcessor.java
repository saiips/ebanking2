package com.dsb.eb2.common.commonFun.sendEmail;

import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dsb.eb2.backOffice.connect.webService.emsEmail.EmailAttachmentDetails;
import com.dsb.eb2.backOffice.connect.webService.emsEmail.EmsHeaderType;
import com.dsb.eb2.backOffice.connect.webService.emsEmail.ObjectFactory;
import com.dsb.eb2.backOffice.connect.webService.emsEmail.SendEmailRequest;
import com.dsb.eb2.backOffice.connect.webService.emsEmail.SendEmailResponse;
import com.dsb.eb2.bankApp.System.BankCode;
import com.dsb.eb2.util.JSONUtils;

public class SendEmsEmailProcessor {

	private static Logger logger = LoggerFactory.getLogger(SendEmsEmailProcessor.class);
	private static String loggerFunctionName = "SendEmsEmailProcessor - ";
	
	//common header
	private EmsHeaderType emsHeader;
	private String channelId;
	private String custId;
	private String reservedbyHost;
	
	//SendEmailRequest
	private String accNum;
	private String fromAddr;
	private List<String> toAddr;
	private List<String> cc;
	private List<String> bcc;
	private String subject;
	private String content;
	private String language;
	private int msgType = -1;
	private String refNum;
	private String templateID;
	private List<String> templateContent;
	private int numOfAttachment = -1;
	private List<EmailAttachmentDetails> emailAttachment;
	
	public SendEmsEmailProcessor(int emailMsgType, String emailTempid){
		this.msgType = emailMsgType;
		this.templateID = emailTempid;
		init();
	}
	
	public SendEmsEmailProcessor(  String custId
									, String accNum
									, String fromAddr
									, List<String> toAddr
									, List<String> cc
									, List<String> bcc
									, String subject
									, String content
									, String language
									, int msgType
									, String refNum
									, String templateID
									, List<String> templateContent
									, int numOfAttachment
									, List<EmailAttachmentDetails> emailAttachment)
	{
		this.custId = custId;
		this.accNum = accNum;
		this.fromAddr = fromAddr;
		this.toAddr = toAddr;
		this.cc = cc;
		this.bcc = bcc;
		this.subject = subject;
		this.content = content;
		this.language = language;
		this.msgType = msgType;
		this.refNum = refNum;
		this.templateID = templateID;
		this.templateContent = templateContent;
		this.numOfAttachment = numOfAttachment;
		this.emailAttachment = emailAttachment;
	}
	
	public SendEmsEmailProcessor( String custId
									, String accNum
									, String fromAddr
									, List<String> toAddr
									, String subject
									, String language
									, int msgType
									, String refNum
									, String templateID
									, List<String> templateContent)
	{
		this.custId = custId;
		this.accNum = accNum;
		this.fromAddr = fromAddr;
		this.toAddr = toAddr;
		this.subject = subject;
		this.language = language;
		this.msgType = msgType;
		this.refNum = refNum;
		this.templateID = templateID;
		this.templateContent = templateContent;
	}
	
	private void init(){
		this.channelId = "EB";
		this.reservedbyHost = "FI";
		this.subject = "";
		this.language = "C";
	}
	
	public synchronized SendEmailResponse getResponse() throws Exception
	{
		logger.info(loggerFunctionName + "beg.SendEmsEmailProcessor.getResponse");
		SendEmailResponse sendEmailResponse = null;
		SendEmailRequest  sendEmailRequest = null;

		sendEmailRequest = this.getRequest();
		
		String requetJsonStr = JSONUtils.objToJson(sendEmailRequest);
		
		//TODO Call OSB EMS send email Request
		String responseJsonStr = "";
		sendEmailResponse = (SendEmailResponse)JSONUtils.JsonToObj("", new SendEmailResponse());
		
		logger.info(loggerFunctionName + "end.SendEmsEmailProcessor.getResponse");
		return sendEmailResponse;
	}
	
	private SendEmailRequest getRequest()
	{
		logger.info(loggerFunctionName + "beg.SendEmsEmailProcessor.getRequest");
		SendEmailRequest rq = new SendEmailRequest();
		try 
		{
			ObjectFactory factory = new ObjectFactory();
			//refNum
			if(this.getRefNum() == null || "".equals(this.getRefNum().trim())){
				SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
				//TODO  Call DB get Seq Number
				String seq = "";
				String ref_no = df.format(Calendar.getInstance().getTime()) + seq;	//YYYYMMDDsssssss
				logger.info(loggerFunctionName + "ref_no:" + ref_no);
				this.setRefNum(ref_no);
			}
			
			
			rq.setEmsHeader(prepareEmsHeaderTypeParam());
			prepareEmsBodyParam(rq);
			
			JAXBElement<SendEmailRequest> elementUp = factory.createMsgSendEmailRequest(rq);
			getRequestXML(elementUp);
		}catch (Exception e)
		{
			logger.error(loggerFunctionName + "error:" + e.getMessage(), e);
		}
		
		logger.info(loggerFunctionName + "end.SendEmsEmailProcessor.getRequest");
		
		return rq;
	}
	
	private EmsHeaderType prepareEmsHeaderTypeParam()
	{
		
		EmsHeaderType result = new EmsHeaderType();
		String debugStr = "[Sending to EMS (EMS Header)] ";
		
		result.setBankCode(BankCode.BC_DSB);
		debugStr += " Bank Code:" + BankCode.BC_DSB;
		
		result.setCustID(this.getCustId());
		debugStr += " custId:" + this.getCustId();
		
		String rq_channelId = this.getChannelId();
		logger.info(loggerFunctionName + "rq_channelId=" + rq_channelId);
		if(rq_channelId == null || "".equals(rq_channelId.trim()))
		{
			//TODO get hub.agent.id from systemConfig FIle
			rq_channelId = "";
		}
		result.setChannelID(rq_channelId);
		debugStr += " Channel:" + rq_channelId;
		
		result.setServiceVersion(1);
		debugStr += " Service Version:1";
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		String formattedDate = sdf.format(new java.util.Date());
		result.setTxDateTime(formattedDate);
		debugStr += " Txn Date:" + formattedDate;
		
		//result.setSysTraceNum(sdf.format(new java.util.Date()));
		//debugStr += " System Trace no:" + sdf.format(new java.util.Date());
		
		result.setSysTraceNum(this.getRefNum());
		debugStr += " System Trace no:" + this.getRefNum();
		
		String rq_reservedbyHost = this.getReservedbyHost();
		logger.info(loggerFunctionName + "rq_reservedbyHost=" + rq_reservedbyHost);
		if(rq_reservedbyHost == null || "".equals(rq_reservedbyHost.trim()))
		{
			rq_reservedbyHost = "FI";
		}
		result.setReservedbyHost(rq_reservedbyHost);
		debugStr += " ReservedbyHOST:" + rq_reservedbyHost;
		
		logger.debug(loggerFunctionName + debugStr);
		
		return result;
	}
	
	private SendEmailRequest prepareEmsBodyParam(SendEmailRequest requestBean)
	{
		SendEmailRequest result = null;
		if(requestBean != null)
		{
			String rq_accNum = this.getAccNum();
			String rq_fromAddr = this.getFromAddr();
			List<String> rq_toAddr = this.getToAddr();
			List<String> rq_cc= this.getCc();
			List<String> rq_bcc = this.getBcc();
			String rq_subject = this.getSubject();
			String rq_content = this.getContent();
			String rq_language = this.getLanguage();
			int rq_msgType = this.getMsgType();
			String rq_refNum = this.getRefNum();
			String rq_templateID = this.getTemplateID();
			List<String> rq_templateContent = this.getTemplateContent();
			int rq_numOfAttachment = this.getNumOfAttachment();
			List<EmailAttachmentDetails> rq_emailAttachment = this.getEmailAttachment();
			
			logger.info(loggerFunctionName + "SendEmailRequest: rq_accNum=" + rq_accNum
																+ ", rq_fromAddr=" + rq_fromAddr
																+ ", rq_toAddr=" + rq_toAddr
																+ ", rq_cc=" + rq_cc
																+ ", rq_bcc=" + rq_bcc
																+ ", rq_subject=" + rq_subject
																+ ", rq_content=" + rq_content
																+ ", rq_language=" + rq_language
																+ ", rq_msgType=" + rq_msgType
																+ ", rq_refNum=" + rq_refNum
																+ ", rq_templateID=" + rq_templateID
																+ ", rq_templateContent=" + rq_templateContent
																+ ", rq_numOfAttachment=" + rq_numOfAttachment
																+ ", rq_emailAttachment=" + rq_emailAttachment);
			
			if(rq_accNum != null){requestBean.setAccNum(rq_accNum);}
			if(rq_fromAddr != null){requestBean.setFromAddr(rq_fromAddr);}
			if(rq_toAddr != null){requestBean.setToAddr(rq_toAddr);}
			if(rq_cc != null){requestBean.setCc(rq_cc);}
			if(rq_bcc != null){requestBean.setBcc(rq_bcc);}
			if(rq_subject != null){requestBean.setSubject(rq_subject);}
			if(rq_content != null){requestBean.setContent(rq_content);}
			if(rq_language != null){requestBean.setLanguage(rq_language);}
			if(rq_msgType != -1){requestBean.setMsgType(rq_msgType);}
			if(rq_refNum != null){requestBean.setRefNum(rq_refNum);}
			if(rq_templateID != null){requestBean.setTemplateID(rq_templateID);}
			if(rq_templateContent != null){requestBean.setTemplateContent(rq_templateContent);}
			if(rq_numOfAttachment != -1){requestBean.setNumOfAttachment(rq_numOfAttachment);}
			if(rq_emailAttachment != null){requestBean.setEmailAttachment(rq_emailAttachment);}
			
			result = requestBean;
		}
		return result;
	}
	
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public EmsHeaderType getEmsHeader() {
		return emsHeader;
	}
	public void setEmsHeader(EmsHeaderType emsHeader) {
		this.emsHeader = emsHeader;
	}
	public String getAccNum() {
		return accNum;
	}
	public void setAccNum(String accNum) {
		this.accNum = accNum;
	}
	public String getFromAddr() {
		return fromAddr;
	}
	public void setFromAddr(String fromAddr) {
		this.fromAddr = fromAddr;
	}
	public List<String> getToAddr() {
		return toAddr;
	}
	public void setToAddr(List<String> toAddr) {
		this.toAddr = toAddr;
	}
	public List<String> getCc() {
		return cc;
	}
	public void setCc(List<String> cc) {
		this.cc = cc;
	}
	public List<String> getBcc() {
		return bcc;
	}
	public void setBcc(List<String> bcc) {
		this.bcc = bcc;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public int getMsgType() {
		return msgType;
	}
	public void setMsgType(int msgType) {
		this.msgType = msgType;
	}
	public String getRefNum() {
		return refNum;
	}
	public void setRefNum(String refNum) {
		this.refNum = refNum;
	}
	public String getTemplateID() {
		return templateID;
	}
	public void setTemplateID(String templateID) {
		this.templateID = templateID;
	}
	public List<String> getTemplateContent() {
		return templateContent;
	}
	public void setTemplateContent(List<String> templateContent) {
		this.templateContent = templateContent;
	}
	public int getNumOfAttachment() {
		return numOfAttachment;
	}
	public void setNumOfAttachment(int numOfAttachment) {
		this.numOfAttachment = numOfAttachment;
	}
	public List<EmailAttachmentDetails> getEmailAttachment() {
		return emailAttachment;
	}
	public void setEmailAttachment(List<EmailAttachmentDetails> emailAttachment) {
		this.emailAttachment = emailAttachment;
	}
	
	public String getReservedbyHost() {
		return reservedbyHost;
	}

	public void setReservedbyHost(String reservedbyHost) {
		this.reservedbyHost = reservedbyHost;
	}

	public static String getRequestXML(JAXBElement<SendEmailRequest> element)
    {
		StringWriter sw = new StringWriter();
        try
        {
        	logger.info(loggerFunctionName + "SendEmsEmailProcessor.getRequestXML");
            JAXBContext jc = JAXBContext.newInstance(SendEmailRequest.class);
            Marshaller m = jc.createMarshaller();
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            m.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
            m.marshal(element, sw);
            logger.info(loggerFunctionName + "SendEmsEmailProcessor.getRequestXML : " + sw.toString());
        }catch (Exception e)
        {
        	logger.error(loggerFunctionName + "error:" + e.getMessage(), e);
        }
        return sw.toString();
    }
	
	public static String getResponseXML(JAXBElement<SendEmailResponse> element)
    {
		StringWriter sw = new StringWriter();
        try
        {
        	logger.info(loggerFunctionName + "SendEmsEmailProcessor.getResponseXML");
            JAXBContext jc = JAXBContext.newInstance(SendEmailResponse.class);
            Marshaller m = jc.createMarshaller();
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            m.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
            m.marshal(element, sw);
            logger.info(loggerFunctionName + "SendEmsEmailProcessor.getResponseXML : " + sw.toString());
        }catch (Exception e)
        {
        	logger.error(loggerFunctionName + "error:" + e.getMessage(), e);
        }
        return sw.toString();
    }
	
	public static void main(String[] args) throws Exception {
		List list = new ArrayList();
		list.add("dongzhiyong@formssi.com");
		SendEmsEmailProcessor processor = new SendEmsEmailProcessor(
				"IDK2369117",
				"dongzhiyong@formssi.com",
				"", list,
				null,
				null,
				"subject",
				"email content",
				"EN",
				5,
				"",
				"14",
				null,
				0, list
				);
		
		processor.getResponse();
	}
}
