package com.dsb.eb2.common.commonFun;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dsb.eb2.common.constant.HttpConstants;

/**
 * 
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class HttpConnector
{

	private static Logger logger = LoggerFactory.getLogger(HttpConnector.class);

    private String encoding;

    private String method;

    private String contentType;

    private int connectionTimout;

    private int readTimout;

    private String requestUri;

    private int responseCode;

    private String responseMessage;

    private Map<String, String> sendHeaderFields;

    private Map<String, List<String>> retHeaderFields;

    public HttpConnector(String url)
    {
        this.encoding = HttpConstants.ENCODING_UTF_8;
        this.method = HttpConstants.METHOD_POST;
        this.contentType = HttpConstants.CONTENT_TYPE_TEXT_XML;
        this.requestUri = url;
    }

    public HttpConnector(String url, String encoding, String method,
        String contentType, Map<String, String> headerFields)
    {
        this.encoding = encoding;
        this.method = method;
        this.contentType = contentType;
        this.requestUri = url;
        this.sendHeaderFields = headerFields;
    }

    public void getHttpsResources(String requestPage, String param,
        OutputStream resp) throws IOException
    {

        String connectURL = requestUri;

        if (requestPage != null) connectURL += requestPage;

        getResources(connectURL, param, resp);
    }

    public String getHttpsResources(String requestPage, String param)
        throws IOException
    {

        String connectURL = requestUri;

        if (requestPage != null) connectURL += requestPage;

        return getResources(connectURL, param);
    }

    public void getHttpsResources(String param, OutputStream resp)
        throws IOException
    {
        getHttpsResources(null, param, resp);
    }

    public String getHttpsResources(String param) throws IOException
    {
        return getHttpsResources(null, param);
    }

    private void getResources(String connectURL, String param, OutputStream resp)
        throws IOException
    {
        HttpURLConnection conn = connect(connectURL, param);

        responseCode = conn.getResponseCode();
        responseMessage = conn.getResponseMessage();

        BufferedReader in = null;
        try{
        	in = new BufferedReader(new InputStreamReader(
                    conn.getInputStream(), encoding));
            PrintWriter respWtr = new PrintWriter(resp);
            String line;
            while ((line = in.readLine()) != null)
            {
                respWtr.println(line);
            }
            respWtr.close();
        }
        finally
        {
        	if(in!=null)
        	{
        		safeClose(in);
        	}
        }
    }

    private String getResources(String connectURL, String param)
        throws IOException
    {
        HttpURLConnection conn = connect(connectURL, param);

        responseCode = conn.getResponseCode();
        responseMessage = conn.getResponseMessage();
        retHeaderFields = conn.getHeaderFields();

        StringBuffer result = new StringBuffer();
        if (hasInputStream(conn))
        {
            BufferedReader in = null;
            try
            {
            	in = new BufferedReader(new InputStreamReader(
                        conn.getInputStream(), encoding));

                String line;
                while ((line = in.readLine()) != null)
                {
                    result.append(line).append("\r\n");
                }
            }
            finally
            {
            	if(in!=null)
            	{
            		safeClose(in);
            	}
            }
        }

        return result.toString();
    }

    private boolean hasInputStream(HttpURLConnection conn)
    {
        try
        {
            conn.getInputStream();
        } catch (IOException e)
        {
            return false;
        }
        return true;
    }

    private HttpURLConnection connect(String connectURL, String param)
        throws IOException
    {
        logger.debug("Connect to [" + connectURL + "].");
        URL url = new URL(connectURL);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod(method);
        conn.setRequestProperty(HttpConstants.CONTENT_TYPE_KEY, contentType);

        if (sendHeaderFields != null)
        {
            for (String key : sendHeaderFields.keySet())
            {
                conn.addRequestProperty(key, sendHeaderFields.get(key));
            }
        }

        conn.setDoInput(true);
        conn.setConnectTimeout(connectionTimout);
        conn.setReadTimeout(readTimout);

        if (!HttpConstants.METHOD_GET.equals(this.method))
        {
            conn.setDoOutput(true);
            PrintWriter reqWtr = new PrintWriter(conn.getOutputStream());
            reqWtr.print(param);
            reqWtr.close();
        }
        return conn;
    }

    public void setConnectionTimout(int connectionTimout)
    {
        this.connectionTimout = connectionTimout;
    }

    public int getConnectionTimout()
    {
        return connectionTimout;
    }

    public void setReadTimout(int readTimout)
    {
        this.readTimout = readTimout;
    }

    public int getReadTimout()
    {
        return readTimout;
    }

    public String getRequestUri()
    {
        return requestUri;
    }

    public void setRequestUri(String uri)
    {
        this.requestUri = uri;
    }

    public String getEncoding()
    {
        return encoding;
    }

    public void setEncoding(String encoding)
    {
        this.encoding = encoding;
    }

    public String getMethod()
    {
        return method;
    }

    public void setMethod(String method)
    {
        this.method = method;
    }

    public String getContentType()
    {
        return contentType;
    }

    public void setContentType(String contentType)
    {
        this.contentType = contentType;
    }

    public int getResponseCode()
    {
        return responseCode;
    }

    public void setResponseCode(int responseCode)
    {
        this.responseCode = responseCode;
    }

    public String getResponseMessage()
    {
        return responseMessage;
    }

    public void setResponseMessage(String responseMessage)
    {
        this.responseMessage = responseMessage;
    }

    public Map<String, String> getSendHeaderFields()
    {
        return sendHeaderFields;
    }

    public void setSendHeaderFields(Map<String, String> sendHeaderFields)
    {
        this.sendHeaderFields = sendHeaderFields;
    }

    public Map<String, List<String>> getRetHeaderFields()
    {
        return retHeaderFields;
    }

    public void setRetHeaderFields(Map<String, List<String>> retHeaderFields)
    {
        this.retHeaderFields = retHeaderFields;
    }
    
    public static void safeClose(BufferedReader in) {
    	
    	try
    	{
    		if(in != null)
    		{
    			in.close();
    		}
    	}catch(IOException ioe)
    	{
    		logger.info("Unable to close InputStream", ioe);
    	}    	
    }

}
