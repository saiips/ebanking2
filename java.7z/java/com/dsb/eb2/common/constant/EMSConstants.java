package com.dsb.eb2.common.constant;

public class EMSConstants
{
    public static final String BANK_CODE_DSB = "6";

    public static final String BANK_CODE_MEV = "3";

    public static final String CHANNEL_ET = "ET";
    
    public static final String CHANNEL_ID = "EB";

    //Terminal ID
    public static final String TERMINAL_ID = "SITCCFSISRV01";

    //Agent ID
    public static final String AGENT_ID = "FAI06";

    //MessageSequence
    public static final int MSG_SEQ_CONFIRM = 0;

    public static final int MSG_SEQ_INITIAL = 1;

    public static final int MSG_SEQ_REBID = 2;

    //OverrideLevel
    public static final int OVRD_LVL_NO = 0;

    public static final int OVRD_LVL_TELLER = 1;

    public static final int OVRD_LVL_SUPERVISOR = 2;

    public static final int OVRD_LVL_OFFICER = 3;

    public static final int OVRD_LVL_MANAGER = 4;

}
