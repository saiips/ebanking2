/**

 * @author Franky Cheung

 * @version 0.0

 */

/*
 * Reference    Author      Date        Description
 * E2011004     Joe Leung   2011/04/01  PDM10453
 */



package com.dsb.eb2.common.constant;



public class EnvKey

{
	public static final String CHANNEL_ID = "CHANNEL_ID";
	
        public static final String EXP_DATE             ="EXP_DATE";

    //add by Ricky 27 Feb 2001
    public static final String ACCT_OPEN_DATE               ="ACCT_OPEN_DATE";

    //add by Franky 5 Feb 2001
    public static final String TX_DATETIME              ="TX_DATETIME";

    public static final String CUST_ID                  = "CUST_ID";

    public static final String CUST_TYPE                = "CUST_TYPE";

    public static final String CUST_NAME                = "CUST_NAME";

    public static final String TITLE                    = "TITLE";

    public static final String NAME                     = "NAME";

    public static final String SEX                      = "SEX";

    public static final String EMAIL_ADDR               = "EMAIL_ADDR";
	
    public static final String EMPLOYER                 = "EMPLOYER";

    public static final String ACCT_NUM                 = "ACCT_NUM";
    
    public static final String ACCT_TYPE_IND   			= "ACCT_TYPE_IND";

    public static final String ACCT_TYPE                = "ACCT_TYPE";

    public static final String PROD_SUB_CODE            = "PROD_SUB_CODE";

    public static final String ACCT_CCY                 = "ACCT_CCY";

    public static final String ACCT_BAL                 = "ACCT_BAL";

    public static final String STATUS                   = "STATUS";

    public static final String ACCT_NAME                = "ACCT_NAME";

    public static final String HOLD_CODE                = "HOLD_CODE";

    public static final String CCY                      = "CCY";

    public static final String CUR_BAL                  = "CUR_BAL";

    public static final String AVAIL_BAL                = "AVAIL_BAL";

    public static final String MIN_PAY                  = "MIN_PAY";

    public static final String ACCT_OWNER               = "ACCT_OWNER";

    public static final String ROLE                     = "ROLE";

    public static final String STMT_CYCLE_DATE          = "STMT_CYCLE_DATE";

    public static final String DEP_TERMS                = "DEP_TERMS";

    public static final String DEP_DUR_UNIT             = "DEP_DUR_UNIT";

    public static final String TOTAL_PCP_PLUS_INT       = "TOTAL_PXP_PLUS_INT";

    public static final String PCP_ON_MAT               = "PCP_ON_MAT";

    public static final String INT_ON_MAT               = "INT_ON_MAT";

    public static final String MAT_DATE                 = "MAT_DATE";

    public static final String MONTH_DEP                = "MONTH_DEP";

    public static final String NEXT_INSTALL_DATE        = "NEXT_INSTALL_DATE";

    public static final String REMAIN_NUM_INSTALL       = "REMAIN_NUM_INSTALL";

    public static final String PCP                      = "PCP";

    //add by Franky Cheung 24 Mar 04 BMD03117
    /* begin */
    public static final String PCP_ADJ                  = "PRINCIPAL ADJUSTMENT";
    /*end*/

    public static final String AUTO_RENEW_PERIOD        = "AUTO_RENEW_PERIOD";

    public static final String RENEW_TYPE               = "RENEW_TYPE";

    public static final String CREDIT_ACCT_NUM          = "CREDIT_ACCT_NUM";

    public static final String OUTSTAND_BAL             = "OUTSTAND_BAL";

    public static final String STMT_BAL                 = "STMT_BAL";

    public static final String AVAIL_LIMIT              = "AVAIL_LIMIT";

    public static final String CR_LIMIT                 = "CR_LIMIT";

    public static final String PAY_DUE_DATE             = "PAY_DUE_DATE";

    public static final String CASH_REW_CR              = "CASH_REW_CR";

    public static final String CASH_REW_EARN            = "CASH_REW_EARN";

    public static final String ORG_LOAN_AMT             = "ORG_LOAN_AMT";

    public static final String NEXT_REPAY_DATE          = "NEXT_REPAY_DATE";

    public static final String INSTALL_AMT              = "INSTALL_AMT";

    public static final String LOAN_OUTSTAND            = "LOAN_OUTSTAND";

    public static final String HOST_REF_1               = "HOST_REF_#1";

    public static final String HOST_REF_2               = "HOST_REF_#2";

    public static final String BANK_BUY_HKD             = "BANK_BUY_HKD";

    public static final String BANK_SELL_HKD            = "BANK_SELL_HKD";

    public static final String BANK_BUY_USD             = "BANK_BUY_USD";

    public static final String BANK_SELL_USD            = "BANK_SELL_USD";

    public static final String SAV_RATE                 = "SAV_RATE";

    public static final String CALL_RATE                = "CALL_RATE";

    public static final String RATE_7_DAYS              = "7_DAYS_RATE";

    public static final String RATE_14_DAYS             = "14_DAYS_RATE";

    public static final String RATE_1_MONTH             = "1_MONTH_RATE";

    public static final String RATE_2_MONTH             = "2_MONTH_RATE";

    public static final String RATE_3_MONTH             = "3_MONTH_RATE";

    public static final String RATE_6_MONTH             = "6_MONTH_RATE";

    public static final String RATE_9_MONTH             = "9_MONTH_RATE";

    public static final String RATE_12_MONTH            = "12_MONTH_RATE";

    public static final String BANK_CODE                = "BANK_CODE";

    public static final String DEBIT_ACCT_NUM           = "DEBIT_ACCT_NUM";

    public static final String DEBIT_ACCT_CCY           = "DEBIT_ACCT_CCY";

    public static final String CREDIT_ACCT_CCY          = "CREDIT_ACCT_CCY";

    public static final String DEBIT_ACCT_AMT           = "DEBIT_ACCT_AMT";

    public static final String CREDIT_ACCT_AMT          = "CREDIT_ACCT_AMT";

    public static final String DEPOSIT_BANK_CODE        = "DEPOSIT_BANK_CODE";

    public static final String DEPOSIT_BANK_NAME        = "DEPOSIT_BANK_NAME";

    public static final String DEPOSIT_ACCT_NUM         = "DEPOSTI_ACCT_NUM";

    public static final String BENEFICIAL_NAME          = "BENEFICIAL_NAME";

    public static final String BENEFICIAL_ACCT_NUM          = "BENEFICIAL_ACCT_NUM"; //20050312

    public static final String BENEFICIAL_DAILY_LIMIT           = "BENEFICIAL_DAILY_LIMIT"; //20050316

    public static final String PAYMENT_DETAILS          = "PAYMENT_DETAILS";

    public static final String MSG_TO_BANK              = "MSG_TO_BANK";

    public static final String TARGET_CCY               = "TARGET_CCY";

    public static final String METHOD                   = "METHOD";

    public static final String BRANCH                   = "BRANCH";

    public static final String NUM_OF_CHEQ_BK           = "NUM_OF_CHEQ_BK";

    public static final String CHEQ_BK_SIZE             = "CHEQ_BK_SIZE";

    public static final String CHEQ_NUM                 = "CHEQ_NUM";

    public static final String COUNT                    = "COUNT";

    public static final String CHEQ_DATE                = "CHEQ_DATE";

    public static final String CHEQ_AMT                 = "CHEQ_AMT";

    public static final String CHARGE                   = "CHARGE";

    public static final String CHARGE_CODE                  = "CHARGE_CODE";

    public static final String PAYEE                    = "PAYEE";

    public static final String TXNCODE                  = "TXNCODE";

    public static final String RESPSTATUS               = "RESPSTATUS";

    public static final String REASON                   = "REASON";

    public static final String DOB                      = "DOB";

    public static final String CARD_STATUS              = "CARD_STATUS";

    public static final String STMT_FLAG                = "STATEMENT FLAG";

    public static final String BLOCK_CODE               = "BLOCK_CODE";

    public static final String AMOUNT                   = "DEBIT_AMT";

    public static final String IS_FULL_AMT              = "IS_FULL_AMT";

    public static final String DAYTIME_TEL              = "DAYTIME_TEL";

    public static final String RENEW_DUR_UNIT           = "RENEW_DUR_UNIT";

    public static final String RENEW_TERMS              = "RENEW_TERMS";

    public static final String INT_RATE                 = "INT_RATE";

    public static final String REF_CODE_1               = "REF_CODE_1";

    public static final String REF_CODE_2               = "REF_CODE_2";

    public static final String TRANSFER_TYPE            = "TRANSFER_TYPE";

    public static final String DEBIT_AT_RATE            = "DEBIT_AT_RATE";

    public static final String CREDIT_AT_RATE           = "CREDIT_AT_RATE";

    public static final String CARD_ORG                 = "CARD_ORG";

    public static final String CARD_CUST_NUM            = "CARD_CUST_NUM";

    public static final String ACCT_TYPE_3P             = "ACCT_TYPE_3P";

    public static final String I_ACCT_IND               = "I_ACCT_IND";

    public static final String BALANCE                  = "BALANCE";

    public static final String ID_PASSPORT              = "ID_PASSPORT";

    public static final String FD_TYPE                  = "FD_TYPE";

    public static final String DEP_TERM                 = "DEP_TERM";

    public static final String DEP_UNIT                 = "DEP_UNIT";

    public static final String PCP_AMT                  = "PCP_AMT";

    public static final String PCP_CCY                  = "PCP_CCY";

    public static final String CCARD_ACCT_NUM           = "CCARD_ACCT_NUM";

    public static final String FROM_ACCT_NUM            = "FROM_ACCT_NUM";

    public static final String ONCE_OR_AUTO                             = "ONCE_OR_AUTO";

    public static final String FD_ACCT_NUM                             = "FD_ACCT_NUM";

    public static final String RENEWAL_TYPE                             = "RENEWAL_TYPE";

    public static final String INDICATOR                = "INDICATOR";

    public static final String PHBK_USER_ID             = "PHBK_USER_ID";

    public static final String NUM_OF_ACCT              = "NUM_OF_ACCT";

    public static final String CUST_ORG_NUM             = "CUST_ORG_NUM";

    public static final String CUST_NUM                 = "CUST_NUM";

    public static final String PAYMENT_DUE_DATE             = "PAYMENT_DUE_DATE";



   public static final String ERR_DESC                  = "ERR_DESC";

   public static final String MORE_IND                  = "MORE_IND";

   public static final String LAST_KEY                  = "LAST_KEY";

   public static final String ID_NUMBER                 = "ID_NUMBER";

   public static final String CARDHOLDER_NO             = "CARDHOLDER_NO";

   public static final String BRANCH_CODE               = "BRANCH_CODE";

   public static final String OVERRIDE_IND                              = "OVERRIDE_IND";

   public static final String NO_INST_OVERDUE                           = "NO_INST_OVERDUE";

   public static final String CATEGORY_CODE                             = "CATEGORY_CODE";

   public static final String OLD_BILL_NUM              = "OLD_BILL_NUM";
   public static final String OLD_BILL_TYPE                 = "OLD_BILL_TYPE";
   public static final String OLD_BILL_LABEL                    = "OLD_BILL_LABEL";
   public static final String OLD_MERCHANT_CODE             = "OLD_MERCHANT_CODE";

   public static final String BILL_NUM                  = "BILL_NUM";
   public static final String BILL_TYPE                     = "BILL_TYPE";
   public static final String BILL_LABEL                                = "BILL_LABEL";
   public static final String MERCHANT_NUM              = "MERCHANT_NUM";
   public static final String MERCHANT_CODE             = "MERCHANT_CODE";
   public static final String GL_BRANCH_CODE            = "GL_BRANCH_CODE";
   public static final String GL_NUMBER                 = "GL_NUMBER";

   public static final String PAYMENT_STATUS                = "PAYMENT_STATUS";
   public static final String PAY_REF_NUM               = "PAY_REF_NUM";

   public static final String TX_POST_DATE              = "TX_POST_DATE";
   public static final String TX_DATE                   = "TX_DATE";
   public static final String DESCRIPTION               = "DESCRIPTION";
   public static final String TX_CCY                    = "TX_CCY";
   public static final String TX_AMOUNT                 = "TX_AMOUNT";
   public static final String HKD_AMOUNT                = "HKD_AMOUNT";
   public static final String NUM_OF_RECORD             = "NUM_OF_RECORD";

   public static final String LAST_UPDATE_AT                = "LAST_UPDATE_AT";
   
   public static final String STAFF_IND                 = "STAFF_IND";

   // for enhancement to credit card bank bill payment
   public static final String HOLDER_ORG                            = "HOLDER_ORG";
   public static final String HOLDER_CARD_TYPE                       = "HOLDER_CARD_TYPE";
   public static final String XSTATUS                       = "XSTATUS";

   // for credit card online instalment by Szeto (Feb 23, 2001)
   public static final String SRC_OF_APP       = "SRC_OF_APP";
   public static final String INST_CODE        = "INST_CODE";
   public static final String HKID             = "HKID";
   public static final String EMAIL            = "EMAIL";
   public static final String PHONE_DAY        = "PHONE_DAY";
   public static final String PHONE_NIGHT      = "PHONE_NIGHT";
   public static final String DLVR_NAME        = "DLVR_NAME";
   public static final String DLVR_TITLE       = "DLVR_TITLE";
   public static final String DLVR_PH_DAY      = "DLVR_PH_DAY";
   public static final String DLVR_PH_NIG      = "DLVR_PH_NIG";
   public static final String DLVR_FLAT        = "DLVR_FLAT";
   public static final String DLVR_FLOOR       = "DLVR_FLOOR";
   public static final String DLVR_BLOCK       = "DLVR_BLOCK";
   public static final String DLVR_BLDG_EST    = "DLVR_BLDG_EST";
   public static final String DLVR_STREET      = "DLVR_STREET";
   public static final String DLVR_DISTRICT    = "DLVR_DISTRICT";
   public static final String DLVR_AREA        = "DLVR_AREA";
   public static final String PROD_CODE        = "PROD_CODE";
   public static final String QUANTITY         = "QUANTITY";
   public static final String NUM_OF_ITEMS     = "NUM_OF_ITEMS";
   public static final String RESP_MAIL_STATUS = "RESP_MAIL_STATUS";

   // eIPO by Lam Chi Kai
   public static final String APPLICATION_NUM  = "APPLICATION_NUM";
   public static final String STOCK_CODE       = "STOCK_CODE";

   // for eIPO appl creation, removal and enquiry (March 23, 2001)
        public static final String ACTION_CODE                   = "ACTION_CODE";
    public static final String RESPONSE_STATUS      = "RESPONSE_STATUS";
    public static final String APPLICATION_NUMBER       = "APPLICATION_NUMBER";
    public static final String APPLICANT_ID_NUMBER      = "APPLICANT_ID_NUMBER";

    public static final String APPLICANT_NAME_LINE1     = "APPLICANT_NAME_LINE1";
    public static final String APPLICANT_NAME_LINE2     = "APPLICANT_NAME_LINE2";
    public static final String OCCUPATION               = "OCCUPATION";
    public static final String APPLICANT_ADDRESS_LINE1  = "APPLICANT_ADDRESS_LINE1";
    public static final String APPLICANT_ADDRESS_LINE2  = "APPLICANT_ADDRESS_LINE2";
    public static final String APPLICANT_ADDRESS_LINE3  = "APPLICANT_ADDRESS_LINE3";
    public static final String PHONE_NUMBER             = "PHONE_NUMBER";
    public static final String EMAIL_ADDRESS1           = "EMAIL_ADDRESS1";
    public static final String EMAIL_ADDRESS2           = "EMAIL_ADDRESS2";

    public static final String FORM_TYPE                = "FORM_TYPE";
    public static final String BROKER_CODE              = "BROKER_CODE";
    public static final String NUMBER_OF_SHARES_APPLIED = "NUMBER_OF_SHARES_APPLIED";
    public static final String AMOUNT_OF_SHARES             = "AMOUNT_OF_SHARES";
    public static final String BROKERAGE                = "BROKERAGE";
    public static final String TRANSACTION_LEVY                     = "TRANSACTION_LEVY";
        public static final String TOTAL_AMOUNT_OF_APPLICATION_MONEY = "TOTAL_AMOUNT_OF_APPLICATION_MONEY";

    public static final String JOINT_APPLICANT1_NAME        = "JOINT_APPLICANT1_NAME";
    public static final String JOINT_APPLICANT1_ID_NUMBER   = "JOINT_APPLICANT1_ID_NUMBER";
    public static final String JOINT_APPLICANT2_NAME        = "JOINT_APPLICANT2_NAME";
    public static final String JOINT_APPLICANT2_ID_NUMBER   = "JOINT_APPLICANT2_ID_NUMBER";
    public static final String JOINT_APPLICANT3_NAME        = "JOINT_APPLICANT3_NAME";
    public static final String JOINT_APPLICANT3_ID_NUMBER   = "JOINT_APPLICANT3_ID_NUMBER";
    public static final String BENEFICIAL_OWNER_CODE        = "BENEFICIAL_OWNER_CODE";
    public static final String COLLECTION_INDICATOR         = "COLLECTION_INDICATOR";
    public static final String CCASS_PARTICIPANT_ID         = "CCASS_PARTICIPANT_ID";

    public static final String APPLICATION_STATUS           = "APPLICATION_STATUS";
    public static final String DATE_OF_APPLICATION          = "DATE_OF_APPLICATION";
    public static final String DATE_OF_LAST_AMENDMENT       = "DATE_OF_LAST_AMENDMENT";
    public static final String DATE_OF_CANCELLATION         = "DATE_OF_CANCELLATION";
    public static final String DATE_OF_SUBMISSION           = "DATE_OF_SUBMISSION";

    public static final String PAYMENT_DATE                 = "PAYMENT_DATE";
    public static final String PAYMENT_SOURCE               = "PAYMENT_SOURCE";
    public static final String PAYMENT_ACCOUNT              = "PAYMENT_ACCOUNT";
    public static final String PAYMENT_REFERENCE            = "PAYMENT_REFERENCE";

        //for Retail Transaction History Enquiry
        //add by Franky Cheung 17 Apr 2001
        public static final String LANG             = "LANG";
        public static final String TX_CODE         = "TX_CODE";
        public static final String TX_CODE_NATURE  = "TX_CODE_NATURE";
        public static final String TX_DESCRIPTION   = "TX_DESCRIPTION";
        public static final String TX_TIME          = "TX_TIME";
        public static final String START_DATE       = "START_DATE";
        public static final String END_DATE         = "END_DATE";
        public static final String REQUEST_OPTION   = "REQUEST_OPTION";

  // For autopay inter-bank transfer to other bank
  // by Szeto (May 29, 2001)
  public static final String DEBIT_ACCT_NAME  = "DEBIT_ACCT_NAME";
  public static final String CREDIT_ACCT_NAME = "CREDIT_ACCT_NAME";
  // For phone banking registered beneficiary enquiry
  // by Szeto (May 30, 2001)
  public static final String LAST_BENEFICIAL_NAME = "LAST_BENEFICIAL_NAME";
  public static final String LAST_BENEFICIAL_ACCT = "LAST_BENEFICIAL_ACCT"; //20050319

  // For scheduled inter-bank fund transfer to other bank (CHATS)
  // by Szeto (Jul 4, 2001)
  public static final String SUBMIT_DATE = "SUBMIT_DATE";

  //For Inter-Bank Fund Transfer From Other Bank (e-Deposit)
  public static final String DEBTOR_REF    = "DEBITOR_REF";
  public static final String PARTICULARS   = "PARTICULARS";

  //For Inter-Bank Fund Transfer From/To Other Bank
  public static final String CHARGE_IND = "CHARGE_IND";
  public static final String CHARGE_AMOUNT = "CHARGE_AMOUNT";
  public static final String BENEFICIARY_REG_IND = "BENEFICIARY_REG_IND";
  public static final String IS_REGISTERED = "IS_REGISTERED";
  public static final String INSTR_ID = "INSTR_ID";

  //new added by Franky (Aug 24, 2001)
  public static final String CYCLE_DATE = "CYCLE_DATE";

  // For credit card product nature. It is either credit or debit nature.
  // by Lam Chi Kai (Aug 20, 2001)
  public static final String CARD_NATURE = "CARD_NATURE";

  //For FD Schematic Promotion
  // by Franky Cheung 09 Jan 2002
  public static final String FD_BASIC_RATE = "FD_BASIC_RATE";
  public static final String FD_MARKUP_RATE = "FD_MARKUP_RATE";

  // For FD Joint Name Enhancement
  // by Cari Pang (13 Feb 2006)
  public static final String FD_JOINT_NAME1 = "FD_JOINT_NAME1";
  public static final String FD_JOINT_NAME2 = "FD_JOINT_NAME2";
  public static final String FD_JOINT_NAME_CIF_ID1 = "FD_JOINT_NAME_CIF_ID1"; //Primary
  public static final String FD_JOINT_NAME_CIF_ID2 = "FD_JOINT_NAME_CIF_ID2";
  public static final String FD_JOINT_NAME_CIF_ID3 = "FD_JOINT_NAME_CIF_ID3";
  public static final String FD_JOINT_NAME_CIF_ID4 = "FD_JOINT_NAME_CIF_ID4";
  public static final String FD_JOINT_NAME_CIF_ID5 = "FD_JOINT_NAME_CIF_ID5";
  public static final String FD_SINGLE_JOINT_IND = "FD_SINGLE_JOINT_IND";
  public static final String FD_JOINT_NAME_SHORT = "FD_JOINT_NAME_SHORT";

  //For Unit Trust
  //add by Franky Cheung 07 Jun 2002
  //for use of hub message NF1658
  public static final String FUND_CODE = "FUND_CODE";
  public static final String HOLDING_UNITS = "HOLDING_UNITS";
  public static final String VALUE_DATE = "VALUE_DATE";
  public static final String MARKET_PRICE = "MARKET_PRICE";
  public static final String MARKET_VALUE = "MARKET_VALUE";
  public static final String HKD_EQV = "HKD_EQV";
  public static final String LAST_UPDATED_AT = "LAST_UPDATED_AT";
  public static final String GRAND_TOTAL = "GRAND_TOTAL";

  //for use of Unit Trust Txn History
  public static final String UNIT_PRICE = "UNIT_PRICE";
  public static final String UNITS = "UNITS";
  public static final String TX_STATUS = "TX_STATUS";

  //For FD Automation
  //by Albert Chan 18 June 2002
  public static final String RENEW_TERM             = "RENEW_TERM";
  public static final String RENEW_UNIT             = "RENEW_UNIT";
  public static final String CREDIT_ACCT_NUM_2      = "CREDIT_ACCT_NUM_2";
  public static final String CREDIT_ACCT_CCY_2      = "CREDIT_ACCT_CCY_2";
  public static final String PAST_DUE_INT           = "PAST_DUE_INT";
  public static final String SEQ_NUM                = "SEQ_NUM";

  public static final String MAIL_REQ = "MAIL_REQ";

    // For Add_Mgmt_Request
    public static final String REF_NO = "REF_NO";
    public static final String REQUEST_DATE = "REQUEST_DATE";
    public static final String EFFECTIVE_DATE = "EFFECTIVE_DATE";
    public static final String FLAT = "FLAT";
    public static final String FLOOR = "FLOOR";
    public static final String BLOCK = "BLOCK";
    public static final String BUILDING = "BUILDING";
    public static final String STREET = "STREET";
    public static final String DISTRICT = "DISTRICT";
    public static final String AREA = "AREA";
    public static final String ADDRESS_TYPE = "ADDRESS_TYPE";
    public static final String HOME_TEL = "HOME_TEL";
    public static final String OFFICE_TEL = "OFFICE_TEL";
    public static final String MOBILE = "MOBILE";
    public static final String FAX_PAGER = "FAX_PAGER";
    public static final String PF_TEL = "PF_TEL";
    public static final String ACCOUNT_TYPE = "ACCOUNT_TYPE";
    public static final String ACCOUNT_1 = "ACCOUNT_1";
    public static final String ACCOUNT_2 = "ACCOUNT_2";
    public static final String ACCOUNT_3 = "ACCOUNT_3";
    public static final String SAFE_BOX_BRANCH = "SAFE_BOX_BRANCH";
    public static final String SAFE_BOX_NUMBER = "SAFE_BOX_NUMBER";

    // For CUST_EMAIL_ADD
    public static final String SENDER_NAME = "SENDER_NAME";


        //For Bonus Point Redemption

        public static final String REDEEM_CODE    = "REDEEM_CODE";
        public static final String ITEM_CODE      = "ITEM_CODE";
        public static final String ITEM_DESC_E    = "ITEM_DESC_E";
        public static final String ITEM_DESC_C    = "ITEM_DESC_C";
        public static final String DELIVERY_MEANS = "DELIVERY_MEANS";
        public static final String BONUS_PT       = "BONUS_PT";
        public static final String REWARD_TYPE    = "REWARD_TYPE";
        public static final String MAX_COUNT      = "MAX_COUNT";
        public static final String ITEM_QTY       = "ITEM_QTY";
        //YOU Bonus Point Redemption
        public static final String REBATE_DATE = "REBATE_DATE";
        public static final String REDEEM_POINT = "REDEEM_POINT";
        public static final String REBATE_ACCOUNT = "REBATE_ACCOUNT";
        //end
        //new added For Bonus Point Redemption Phase I
        public static final String TXN_STATUS     = "TXN_STATUS";
        public static final String REFILL_IND     = "REFILL_IND";
        public static final String PROGRAM_ID     = "PROGRAM_ID";
        public static final String BANKSIDE_USER_ID = "BANKSIDE_USER_ID";

    // Tax Campaign
    public static final String TAX_APP_DISBURSE_OPT   = "TAX_APP_DISBURSE_OPT";
    public static final String TAX_APP_REPAY_OPT = "TAX_APP_REPAY_OPT";
    public static final String CC_VALID_UNTIL_DATE = "CC_VALID_UNTIL_DATE";

        // Loyalty Program for Credit Card Phase I
        // Inserted on 06 Jan 2004 by Cari
        public static final String MEMBER_SINCE = "MEMBER_SINCE";
        public static final String NUM_OF_STAR = "NUM_OF_STAR";

        //Inter-Bank and Prime Rate Enquiry Service
        public static final String RATE_DESC = "RATE_DESC";
        public static final String FORMULA = "FORMULA";
        public static final String CURRENT_RATE = "CURRENT_RATE";
        public static final String EFFECTIVE_RATE = "EFFECTIVE_RATE";
        public static final String PREIVOUS_RATE = "PREVIOUS_RATE";

        //Securities a/c enquiry
        public static final String REAL_TIME_QUOTE_IND = "REAL_TIME_QUOTE_IND";
        public static final String INV_STOCKS = "INV_STOCKS";
        public static final String GAIN_LOSS_TOTAL = "GAIN_LOSS_TOTAL";
        public static final String TXNS_REC = "TXNS_REC";
        public static final String ALL_TXN_LOADED_IND = "ALL_TXN_LOADED_IND";
        public static final String AVG_PURCHASE_PRICE = "AVG_PURCHASE_PRICE";

        //Investment Product Enquiry
        public static final String BOND_CODE = "BOND_CODE";
        public static final String NOTIONAL_AMT = "NOTIONAL_AMT";
        public static final String TTL_SETTLEMENT_AMT = "TTL_SETTLEMENT_AMT";
        public static final String MATURITY_DATE = "MATURITY_DATE";
        public static final String ISSUE_DATE = "ISSUE_DATE";
        public static final String ISSUE_NUM = "ISSUE_NUM";
        public static final String ACCRUED_INT = "ACCRUED_INT";
        public static final String COMM_CHARGES = "COMM_CHARGES";

        //Lucky Draw
        public static final String ITEM_ID = "ITEM_ID";
        public static final String RETURN_CODE = "RETURN_CODE";
        public static final String ORDER_ID = "ORDER_ID";
        public static final String ORDER_PLACE_DATE = "ORDER_PLACE_DATE";
        public static final String ORDER_PLACE_TIME = "ORDER_PLACE_TIME";

        //Intra-bank fund transfer (changed for CUP Credit Card Project)
        public static final String REC_COMPANY_CODE = "REC_COMPANY_CODE";

        //Project Mark Lucky Draw
        public static final String APPROVAL_CODE = "APPROVAL_CODE";
        public static final String REF_NUM = "REF_NUM";
        public static final String DRAW_DATE = "DRAW_DATE";

        //Tax Loan Online Form
        public static final String LOAN_TYPE = "LOAN_TYPE";
        public static final String PROMO_ID = "PROMO_ID";

    //Discount Loan (OPD05007)
    public static final String LOAN_PREDISCOUNT = "LOAN_PREDISCOUNT";

        // Added by Anfernee for batch instruction enhancement @ 20081017
        public static final String IS_BATCH_INSTRUCTION = "IS_BATCH_INSTRUCTION";
        public static final String TXN_REF_NUM = "TXN_REF_NUM";
        
        //Hibor and Libor Rate Enquiry (DPS07001)
        public static final String HIBOR_CURRENT_RATE = "HIBOR_CURRENT_RATE";
        public static final String HIBOR_UPDATE_DATETIME = "HIBOR_UPDATE_DATETIME";
        public static final String LIBOR_CURRENT_RATE = "LIBOR_CURRENT_RATE";
        public static final String LIBOR_UPDATE_DATETIME = "LIBOR_UPDATE_DATETIME";
        
        //FD Online Creation and Enquiry (for Staff FD)
        public static final String STAFF_FD_FLAG = "STAFF_FD_FLAG";
        public static final String HIBOR_LIBOR_RATE = "HIBOR_LIBOR_RATE";
        public static final String BOARD_RATE = "BOARD_RATE";
        public static final String FD_PRIV_INT_FLAG = "FD_PRIV_INT_FLAG";
        
        public static final String MOBILE_NUMBER = "MOBILE_NUMBER";
        public static final String SUBJECT = "SUBJECT";
        
        public static final String CARD_LOGIN_CARD_NO = "CARD_LOGIN_CARD_NO";
        public static final String CARD_LOGIN_ID_NO = "CARD_LOGIN_ID_NO";
        public static final String CARD_LOGIN_CVV2 = "CARD_LOGIN_CVV2";

        // Added by Anfernee for Securities Acct Opening @ 20100510
        public static final String DATA_BLOCK = "DATA_BLOCK";
        public static final String FAX_NUM = "FAX_NUM";
        public static final String CONTACT_NUM = "CONTACT_NUM";
        public static final String NATIONALITY = "NATIONALITY";
        public static final String VIP_FLAG = "VIP_FLAG";
        public static final String GEN_LONG_DESC = "GEN_LONG_DESC";
        public static final String ADDRESS_LINE_1 = "ADDRESS_LINE_1";
        public static final String ADDRESS_LINE_2 = "ADDRESS_LINE_2";
        public static final String ADDRESS_LINE_3 = "ADDRESS_LINE_3";
        public static final String ADDRESS_LINE_4 = "ADDRESS_LINE_4";
        public static final String ADDRESS_CODE = "ADDRESS_CODE";
        public static final String ACCT_OFFICER = "ACCT_OFFICER";
        
        public static final String AVAILABLE_CREDIT_LINE = "ADDRESS_CODE";
        public static final String AVAILABLE_INSTALLMENT_LINE = "ADDRESS_CODE";
        public static final String TOTAL_INSTALLMENT_AVAIL = "ADDRESS_CODE";
        
        // Added by Michael Cheng for Online Risk Assessment @ 20101021
        public static final String RISK_ANS_01 = "RISK_ANS_01";
        public static final String RISK_ANS_02 = "RISK_ANS_02";
        public static final String RISK_ANS_03 = "RISK_ANS_03";
        public static final String RISK_ANS_04 = "RISK_ANS_04";
        public static final String RISK_ANS_05 = "RISK_ANS_05";
        public static final String RISK_ANS_06 = "RISK_ANS_06";
        public static final String RISK_ANS_07 = "RISK_ANS_07";
        public static final String RISK_ANS_08 = "RISK_ANS_08";
        public static final String RISK_ANS_09 = "RISK_ANS_09";
        public static final String RISK_ANS_10 = "RISK_ANS_10";
        public static final String COMPANY_IND = "COMPANY_IND";
        public static final String LANGUAGE = "LANGUAGE";
        public static final String VERSION_NO = "VERSION_NO";
        public static final String CHANNEL = "CHANNEL";
        public static final String DIVISION = "DIVISION";
        public static final String RISK_BANK_CODE = "RISK_BANK_CODE";
        public static final String EMS_CHANNEL = "EMS_CHANNEL";
        public static final String SERVICE_VERSION = "SERVICE_VERSION";
        public static final String SYS_TRACE_NUM = "SYS_TRACE_NUM";
        public static final String ENDPOINT_ADDRESS_PROPERTY = "ENDPOINT_ADDRESS_PROPERTY";
        public static final String RISK_RETURN_CODE = "RISK_RETURN_CODE";
        public static final String RISK_REF_NO = "RISK_REF_NO";
        public static final String RESULT_SCORE = "RESULT_SCORE";
        public static final String CUST_RTL = "CUST_RTL";
        public static final String RISK_ASSESS_DATE = "RISK_ASSESS_DATE";
        public static final String RISK_ASSESS_APPROVE_DATE = "RISK_ASSESS_APPROVE_DATE";
        public static final String RISK_ASSESS_OPERATION = "RISK_ASSESS_OPERATION";
        public static final String RTL_STATUS = "RTL_STATUS";
	public static final String RISK_DECLARATION_IND = "RISK_DECLARATION_IND";
	public static final String RISK_LAST_REF_NO = "RISK_LAST_REF_NO";	
        
        //E2011004 Start
        public static final String INT_RATE_HISORY_ENV = "INT_RATE_HISORY_ENV";
        public static final String PRIV_MON_INT_PAY_FLAG = "PRIV_MON_INT_PAY_FLAG";
        public static final String MON_INT_PAY_ACC_NUM = "MON_INT_PAY_ACC_NUM";
        public static final String INT_START_DATE = "INT_START_DATE";
        public static final String INT_END_DATE = "INT_END_DATE";
        public static final String INT_AMOUNT = "INT_AMOUNT";
        public static final String INT_PAID_FLAG = "INT_PAID_FLAG";
        //E2011004 End
		
		public static final String SYSTEM_CODE = "SYSTEM_CODE";
		public static final String CUST_ID2 = "CUST_ID2";
		public static final String CUST_ID3 = "CUST_ID3";
		public static final String CUST_ID4 = "CUST_ID4";
		public static final String CUST_ID5 = "CUST_ID5";
		public static final String SIGNATURE_NO = "SIGNATURE_NO";
		public static final String APPLY_MASTER_CSN = "APPLY_MASTER_CSN";

	public static final String CARD_REQUEST_TYPE = "CARD_REQUEST_TYPE";
	public static final String CARD_REQUEST_FIELD = "CARD_REQUEST_FIELD";
	public static final String CARD_PHONE_NUMBER = "CARD_PHONE_NUMBER";
	public static final String CARD_LAST_CVX = "CARD_LAST_CVX";
	public static final String CARD_INDICATOR = "CARD_INDICATOR";
	
	public static final String DERI_KNOWLEDGE_OPERATION = "DERI_KNOWLEDGE_OPERATION";
	public static final String DERI_KNOWLEDGE_CREATED_DATE = "DERI_KNOWLEDGE_CREATED_DATE";
	public static final String DERI_KNOWLEDGE_RTN_CODE = "DERI_KNOWLEDGE_RTN_CODE";
	public static final String DERI_KNOWLEDGE_FLAG = "DERI_KNOWLEDGE_FLAG";
	public static final String DERI_KNOWLEDGE_TRAIN_FLAG = "DERI_KNOWLEDGE_TRAIN_FLAG";
	public static final String DERI_KNOWLEDGE_WORK_EXP_FLAG = "DERI_KNOWLEDGE_WORK_EXP_FLAG";
	public static final String DERI_KNOWLEDGE_TRADE_EXP_FLAG = "DERI_KNOWLEDGE_TRADE_EXP_FLAG";
	public static final String DERI_KNOWLEDGE_CREATED_BY = "DERI_KNOWLEDGE_CREATED_BY";
	
	public static final String HOLD_RELEASE_FUND_REASON = "HOLD_RELEASE_FUND_REASON";
	public static final String HOLD_RELEASE_FUND_ENTITY = "HOLD_RELEASE_FUND_ENTITY";
	public static final String HOLD_RELEASE_FUND_ACTION = "HOLD_RELEASE_FUND_ACTION";
	public static final String HOLD_RELEASE_FUND_FLOAT_CODE = "HOLD_RELEASE_FUND_FLOAT_CODE";
	public static final String HOLD_RELEASE_FUND_HOST_SEQ = "HOLD_RELEASE_FUND_HOST_SEQ";
	public static final String HOLD_RELEASE_FUND_TX_DATE_TIME = "HOLD_RELEASE_FUND_TX_DATE_TIME";
	
	public static final String EMS_HEADER_REMARK = "EMS_HEADER_REMARK";
	
	public static final String CIPA_ID = "CIPA_ID";
        public static final String CIPA_ENCRYPTED_PASSWORD = "CIPA_ENCRYPTED_PASSWORD";
        public static final String CIPA_ACL = "CIPA_ACL";
        public static final String CIPA_CALLER_ID = "CIPA_CALLER_ID";
        public static final String CIPA_TERMINAL_ID = "CIPA_TERMINAL_ID";
        public static final String CIPA_CREDENTIAL = "CIPA_CREDENTIAL";
        public static final String CIPA_RET_CODE = "CIPA_RET_CODE";
        public static final String CIPA_RET_MSG = "CIPA_REG_MSG";
        public static final String CIPA_NUM_OF_ACL = "CIPA_NUM_OF_ACL";
        
        
        //WMD13100  start
        public static final String HITRUST_BOND_CODE = "HITRUST_BOND_CODE";
        public static final String HITRUST_BOND_NAMEENG = "HITRUST_BOND_NAMEENG";
        public static final String HITRUST_BOND_NAMECHI = "HITRUST_BOND_NAMECHI";
        public static final String HITRUST_BOND_CCY = "HITRUST_BOND_CCY";
        public static final String HITRUST_LOT_SIZE = "HITRUST_LOT_SIZE";
        public static final String HITRUST_HANDLING_FEE = "HITRUST_HANDLING_FEE";
        public static final String HITRUST_MATURITY_DATE = "HITRUST_MATURITY_DATE";
        public static final String HITRUST_INITIAL_PRICE = "HITRUST_INITIAL_PRICE";
        public static final String HITRUST_CUTOFF_TIME = "HITRUST_CUTOFF_TIME";
        public static final String HITRUST_RESULT = "HITRUST_RESULT";
        public static final String HITRUST_HANDLINGFEE_RATE = "HITRUST_HANDLINGFEE_RATE";
        public static final String HITRUST_HANDLINGFEE_AMT = "HITRUST_HANDLINGFEE_AMT";
        public static final String HITRUST_NOTIONAL_AMT = "HITRUST_NOTIONAL_AMT";
        public static final String HITRUST_SUCCESS = "SUCCESS";
        public static final String HITRUST_FAILURE = "FAILURE";
        
        
	
	public static final String HITRUST_BANK_CODE = "HITRUST_BANK_CODE";
	public static final String HITRUST_FUND_CODE = "HITRUST_FUND_CODE";
	public static final String HITRUST_FUND_NAME_ENG = "HITRUST_FUND_NAME_ENG";
	public static final String HITRUST_CLASS_CODE = "HITRUST_CLASS_CODE";
	public static final String HITRUST_CLASS_DESC = "HITRUST_CLASS_DESC";
	public static final String HITRUST_FUND_STATUS = "HITRUST_FUND_STATUS";
	public static final String HITRUST_FUND_CCY = "HITRUST_FUND_CCY";
	public static final String HITRUST_FUND_VALID_SUB = "HITRUST_FUND_VALID_SUB";
	public static final String HITRUST_FUND_VALID_RED = "HITRUST_FUND_VALID_RED";
	public static final String HITRUST_FUND_VALID_SWI = "HITRUST_FUND_VALID_SWI";
	public static final String HITRUST_FUND_VALID_SWO = "HITRUST_FUND_VALID_SWO";
	public static final String HITRUST_CUT_OFF_TIME = "HITRUST_CUT_OFF_TIME";
	public static final String HITRUST_FUND_SUB_DATE_FROM = "HITRUST_FUND_SUB_DATE_FROM";
	public static final String HITRUST_FUND_SUB_DATE_TO = "HITRUST_FUND_SUB_DATE_TO";
	public static final String HITRUST_FUND_SUB_AMT_MIN = "HITRUST_FUND_SUB_AMT_MIN";
	public static final String HITRUST_FUND_SUB_AMT_MAX = "HITRUST_FUND_SUB_AMT_MAX";
	public static final String HITRUST_FUND_SUB_AMT_DENOM = "HITRUST_FUND_SUB_AMT_DENOM";
	public static final String HITRUST_PROD_RISK_LEVEL = "HITRUST_PROD_RISK_LEVEL";
	public static final String HITRUST_PROD_RESTRICT = "HITRUST_PROD_RESTRICT";
	public static final String HITRUST_PROD_RESTRICT_MSG = "HITRUST_PROD_RESTRICT_MSG";
	public static final String HITRUST_INIT_COMM_RATE = "HITRUST_INIT_COMM_RATE";
	public static final String HITRUST_WMOD_SUB_ONLY = "HITRUST_WMOD_SUB_ONLY";
	public static final String HITRUST_FUND_RED_DATE_FROM = "HITRUST_FUND_RED_DATE_FROM";
	public static final String HITRUST_FUND_RED_DATE_TO = "HITRUST_FUND_RED_DATE_TO";
	public static final String HITRUST_FUND_RED_UNIT_MIN = "HITRUST_FUND_RED_UNIT_MIN";
	public static final String HITRUST_FUND_RED_UNIT_MAX = "HITRUST_FUND_RED_UNIT_MAX";
	public static final String HITRUST_FUND_RED_UNIT_DENOM = "HITRUST_FUND_RED_UNIT_DENOM";
	public static final String HITRUST_WMOD_RED_ONLY = "HITRUST_WMOD_RED_ONLY";
	public static final String HITRUST_DISTRIBUTION_TYPE = "HITRUST_DISTRIBUTION_TYPE";
	public static final String HITRUST_RET_CODE = "HITRUST_RET_CODE";
	public static final String HITRUST_RET_MSG = "HITRUST_RET_MSG";	
	public static final String HITRUST_CUST_ID = "HITRUST_CUST_ID";
	public static final String HITRUST_PORTFOLIO_NO = "HITRUST_PORTFOLIO_NO";
	public static final String HITRUST_PORTFOLIO_NAME = "HITRUST_PORTFOLIO_NAME";
	public static final String HITRUST_PORTFOLIO_STATUS = "HITRST_PORTFOLIO_STATUS";
	public static final String HITRUST_PORTFOLIO_TYPE = "HITRUST_PORTFOLIO_TYPE";
	public static final String HITRUST_SETTLE_AC = "HITRUST_SETTLE_AC";
	public static final String HITRUST_NUM_OF_CLIENTS = "HITRUST_NUM_OF_CLIENTS";
	public static final String HITRUST_CLIENT_NUM = "HITRUST_CLIENT_NUM";
	public static final String HITRUST_CLIENT_NAME = "HITRUST_CLIENT_NAME";
	public static final String HITRUST_CLIENT_ID = "HITRUST_CLIENT_ID";
	public static final String HITRUST_IS_PRIMARY = "HITRUST_IS_PRIMARY";
	public static final String HITRUST_PORTFOLIOS = "HITRUST_PORTFOLIO";
	public static final String HITRUST_MKT_PRICE = "HITRUST_MKT_PRICE";
	public static final String HITRUST_MKT_PRICE_DATE = "HITRUST_MKT_PRICE_DATE";
	public static final String HITRUST_CONFIRMED_UNITS = "HITRUST_CONFIRMED_UNITS";
	public static final String HITRUST_HOLDINGS = "HITRUST_HOLDINGS";
	public static final String HITRUST_CONTRACTS = "HITRUST_CONTRACTS";
	public static final String HITRUST_CTRACT_NO = "HITRUST_CTRACT_NO";
	public static final String HITRUST_REF_NUM = "HITRUST_REF_NUM";
	public static final String HITRUST_PROC_BRH = "HITRUST_PROC_BRH";
	public static final String HITRUST_ORDER_DATE = "HITRUST_ORDER_DATE";
	public static final String HITRUST_ORDER_TYPE = "HITRUST_ORDER_TYPE";
	public static final String HITRUST_ORDER_STATUS = "HITRUST_ORDER_STATUS";
	public static final String HITRUST_UNIT_CLASS_CODE = "HITRUST_UNIT_CLASS_CODE";
	public static final String HITRUST_UNIT_PRICE = "HITRUST_UNIT_PRICE";
	public static final String HITRUST_DEAL_CCY = "HITRUST_DEAL_CCY";
	public static final String HITRUST_SETTLE_AMT = "HITRUST_SETTLE_AMT";
	public static final String HITRUST_UNITS = "HITRUST_UNITS";
	public static final String HITRUST_PRICED_DATE = "HITRUST_PRICED_DATE";
	public static final String HITRUST_SETTLE_ACCOUNT = "HITRUST_SETTLE_ACCOUNT";
	public static final String HITRUST_COMM_DISC_RATE = "HITRUST_COMM_DISC_RATE";
	public static final String HITRUST_NET_COMM_RATE = "HITRUST_NET_COMM_RATE";
	public static final String HITRUST_AGENT_CODE = "HITRUST_AGENT_CODE";
	public static final String HITRUST_ORDER_DATE_TIME = "HITRUST_ORDER_DATE_TIME";
	public static final String HITRUST_TO_CUST_INDICATOR = "HITRUST_TO_CUST_INDICATOR";
	public static final String HITRUST_TO_UTQS_INDICATOR = "HITRUST_TO_UTQS_INDICATOR";
	public static final String HITRUST_DISCOUNT_RATE = "HITRUST_DISCOUNT_RATE";
	public static final String HITRUST_RED_UNITS = "HITRUST_RED_UNITS";
	public static final String HITRUST_MKT_VALUE = "HITRUST_MKT_VALUE";
	public static final String HITRUST_MKT_VALUE_HKD = "HITRUST_MKT_VALUE_HKD";
	public static final String HITRUST_IPO_FUNDS = "HITRUST_IPO_FUNDS";
	public static final String CSS_SEM_TYPE = "CSS_SEM_TYPE";
	public static final String CSS_SEM_ACCOUNT_NUMBER = "CSS_SEM_ACCOUNT_NUMBER";
	public static final String CSS_SEM_LANGUAGE = "CSS_SEM_LANGUAGE";
	public static final String CSS_SEM_IND_AGED = "CSS_SEM_IND_AGED";
	public static final String CSS_SEM_PRI_EDU = "CSS_SEM_PRI_EDU";
	public static final String CSS_SEM_IND_LTD_MEANS = "CSS_SEM_IND_LTD_MEANS";
	public static final String CSS_SEM_INVEST_OBJ = "CSS_SEM_INVEST_OBJ";
	public static final String CSS_SEM_INVEST_EXP = "CSS_SEM_INVEST_EXP";
	public static final String CSS_SEM_NO_RECENT_CHANGE = "CSS_SEM_NO_RECENT_CHANGE";
	public static final String CSS_SEM_UNDUE_CONCENTRATION = "CSS_SEM_UNDUE_CONCENTRATION";
	public static final String CSS_SEM_RISK_ASSESS_REF_NO_1 = "CSS_SEM_RISK_ASSESS_REF_NO_1";
	public static final String CSS_SEM_RISK_ASSESS_REF_NO_2 = "CSS_SEM_RISK_ASSESS_REF_NO_2";
	public static final String CSS_SEM_RISK_ASSESS_REF_NO_3 = "CSS_SEM_RISK_ASSESS_REF_NO_3";
	public static final String CSS_SEM_RISK_ASSESS_REF_NO_4 = "CSS_SEM_RISK_ASSESS_REF_NO_4";
	public static final String CSS_SEM_RISK_ASSESS_REF_NO_5 = "CSS_SEM_RISK_ASSESS_REF_NO_5";
	public static final String CSS_SEM_ANY_RISK_MISMATCH = "CSS_SEM_ANY_RISK_MISMATCH";
	public static final String CSS_SEM_MISMATCH_INVEST_OBJ = "CSS_SEM_MISMATCH_INVEST_OBJ";
	public static final String CSS_SEM_MISMATCH_PRODUCT_RISK = "CSS_SEM_MISMATCH_PRODUCT_RISK";
	public static final String CSS_SEM_MISMATCH_UNDUE_CON = "CSS_SEM_MISMATCH_UNDUE_CON";
	public static final String CSS_SEM_MISMATCH_INVEST_EXP = "CSS_SEM_MISMATCH_INVEST_EXP";
	public static final String CSS_SEM_MISMATCH_INVEST_HORIZON = "CSS_SEM_MISMATCH_INVEST_HORIZON";
	public static final String CSS_SEM_ALT_PRODUCT_CHOICE = "CSS_SEM_ALT_PRODUCT_CHOICE";
	public static final String CSS_SEM_JOIN_ACCT_INDICATOR = "CSS_SEM_JOIN_ACCT_INDICATOR";
	public static final String CSS_SEM_RISK_ASSESS_OWNER_RTL = "CSS_SEM_RISK_ASSESS_OWNER_RTL";
	public static final String CSS_SEM_RISK_ASSESS_OWNER_DATE = "CSS_SEM_RISK_ASSESS_OWNER_DATE";
	public static final String CSS_SEM_RISK_ASSESS_LOWEST_NAME = "CSS_SEM_RISK_ASSESS_LOWEST_NAME";
	public static final String CSS_SEM_RISK_ASSESS_LOWEST_RTL = "CSS_SEM_RISK_ASSESS_LOWEST_RTL";
	public static final String CSS_SEM_PRODUCT_CODE = "CSS_SEM_PRODUCT_CODE";
	public static final String CSS_SEM_ALT_PRODUCT = "CSS_SEM_ALT_PRODUCT";
	public static final String CSS_SEM_PRODUCT_NAME = "CSS_SEM_PRODUCT_NAME";
	public static final String CSS_SEM_TXN_INVEST_OBJ = "CSS_SEM_TXN_INVEST_OBJ";
	public static final String CSS_SEM_CT_RISK_PRL = "CSS_SEM_CT_RISK_PRL";
	public static final String CSS_SEM_SEQ_NO = "CSS_SEM_SEQ_NO";
	public static final String CSS_SEM_PRD_RISK_MISMATCH = "CSS_SEM_PRD_RISK_MISMATCH";
	public static final String CSS_SEM_DERIVATIVE_PRODUCT = "CSS_SEM_DERIVATIVE_PRODUCT";
	public static final String CSS_RETURN_CODE = "CSS_RETURN_CODE";
	public static final String CSS_SEM_REF_NO = "CSS_SEM_REF_NO";
	public static final String CSS_SEM_EBANK_REF_NO = "CSS_SEM_EBANK_REF_NO";
	public static final String CSS_SEM_STAFF_IND = "CSS_SEM_STAFF_IND";
	public static final String CSS_SEM_PICOP_TYPE = "CSS_SEM_PICOP_TYPE";
	public static final String CSS_SEM_PICOP_ARRANGEMENT = "CSS_SEM_PICOP_ARRANGEMENT";
	public static final String CSS_SEM_CLPD_FTB_PK = "CSS_SEM_CLPD_FTB_PK";
	public static final String CSS_SEM_INVEST_TENOR = "CSS_SEM_INVEST_TENOR";
	public static final String CSS_SEM_CHANNEL = "CSS_SEM_CHANNEL";
	public static final String CSS_SEM_ALT_PROD_CHOICE = "CSS_SEM_ALT_PROD_CHOICE";
	public static final String CSS_CCD_REF_NO = "CSS_CCD_REF_NO";
	public static final String HITRUST_TYPHOON_MODE = "HITRUST_TYPHOON_MODE";
        public static final String HITRUST_TYPHOON_DATE_TIME = "HITRUST_TYPHOON_DATE_TIME";
        public static final String HITRUST_TYPHOON_CREATED_BY = "HITRUST_TYPHOON_CREATED_BY";
	
	//20120119 Mobile Trading Start
	public static final String MOBILE_DEVICE_LIST = "MOBILE_DEVICE_LIST";
	public static final String MOBILE_NAME = "MOBILE_NAME";
	public static final String MOBILE_TOKEN = "MOBILE_TOKEN";
	public static final String MOBILE_CREATE_TIME = "MOBILE_CREATE_TIME";
	public static final String MOBILE_STATUS = "MOBILE_STATUS";
	public static final String MOBILE_UPDATE_BY = "MOBILE_UPDATE_BY";
	public static final String MOBILE_COMMAND = "MOBILE_COMMAND";
	public static final String MOBILE_REFNO = "MOBILE_REFNO";
	public static final String EBID = "EBID";
	public static final String MOBILE_RETURN_CODE = "MOBILE_RETURN_CODE";
    public static final String PBID = "PBID";	
    public static final String MOBILE_INIT_STATUS = "MOBILE_INIT_STATUS";
    public static final String MOBILE_PKI = "PKI";
    public static final String MOBILE_KEY_MESSAGE = "MOBILE_KEY_MESSAGE";
    public static final String MOBILE_TRADING_ERR = "MOBILE_TRADING_ERR"; 
       //20120119 Mobile Trading End
	   
	// PDM11365 start
	public static final String PDF_ESTMT_REQUEST = "PDF_ESTMT_REQUEST";
	public static final String PDF_ESTMT = "PDF_ESTMT";
	// PDM11365 end

	public static final String HITRUST_NODEC = "HITRUST_NODEC";

	public static final String CIF_EDU_LEVEL = "CIF_EDU_LEVEL";	
	
	//WMO12002 start
	public static final String PROD_TYPE = "PROD_TYPE";
	public static final String CN_NAME = "CN_NAME";
	public static final String LPI = "LPI";
	//WMO12002 end
	//20120618 Mobile Trading Start
	public static final String MOBILE_PIN_CHECKSUM = "MOBILE_PIN_CHECKSUM";
	//20120618 Mobile Trading End
	
	// WMD11067 start
	public static final String GET_TRADING_STATUS_RESPONSE = "GET_TRADING_STATUS_RESPONSE";
	public static final String FTB_FLAG = "FTB_FLAG";
	public static final String FTB_PK = "FTB_PK";
	public static final String EMS_HEADER_TYPE_PARAM = "EMS_HEADER_TYPE_PARAM";
	public static final String PICOP_TYPE = "PICOP_TYPE";
	public static final String GET_TRADING_STATUS_REQUEST = "GET_TRADING_STATUS_REQUEST";
	public static final String EMS_RETURN_CODE = "EMS_RETURN_CODE";
	public static final String PRODUCT_TYPE = "PRODUCT_TYPE";
	public static final String CREATE_DATE = "CREATE_DATE";
	public static final String GET_RATE_ENQUIRY_REQUEST = "GET_RATE_ENQUIRY_REQUEST";
	public static final String GET_RATE_ENQUIRY_RESPONSE = "GET_RATE_ENQUIRY_RESPONSE";
	public static final String GET_FIX_RATE_REQUEST = "GET_FIX_RATE_REQUEST";
	public static final String GET_FIX_RATE_RTN_CODE = "GET_FIX_RATE_RTN_CODE";
	public static final String GET_FIX_RATE_RESPONSE = "GET_FIX_RATE_RESPONSE";
	public static final String PLACE_ORDER_REQUEST = "PLACE_ORDER_REQUEST";
	public static final String PLACE_ORDER_RESPONSE = "PLACE_ORDER_RESPONSE";
	public static final String PLACE_ORDER_RTN_CODE = "PLACE_ORDER_RTN_CODE";
	public static final String GET_TXN_HISTORY_REQUEST = "GET_TXN_HISTORY_REQUEST";
	public static final String GET_TXN_HISTORY_RESPONSE = "GET_TXN_HISTORY_RESPONSE";
	public static final String GET_TXN_HISTORY_RTN_CODE = "GET_TXN_HISTORY_RTN_CODE";
	public static final String GET_TENOR_DETAIL_REQUEST = "GET_TENOR_DETAIL_REQUEST";
	public static final String GET_TENOR_DETAIL_RESPONSE = "GET_TENOR_DETAIL_RESPONSE";
	public static final String GET_TENOR_DETAIL_RTN_CODE = "GET_TENOR_DETAIL_RTN_CODE";
	public static final String CLPD_INFO_ENQUIRY_RESPONSE = "CLPD_INFO_ENQUIRY_RESPONSE";
	public static final String CLPD_INFO_ENQUIRY_REQUEST = "CLPD_INFO_ENQUIRY_REQUEST";
	public static final String FREE_TEXT = "FREE_TEXT";
	public static final String CSS_CLPD_DOC_LEAFLET = "CSS_CLPD_DOC_LEAFLET";
	public static final String CSS_CLPD_CONFIRM = "CSS_CLPD_CONFIRM";
	public static final String OTHER_INFO = "OTHER_INFO";
	
	
	// WMD11067 end

	// WMD12038 start
	public static final String CSS_SEM_CONCENTRATION_THRESHOLD = "CSS_SEM_CONCENTRATION_THRESHOLD";
	public static final String CSS_SEM_CONCENTRATION_VALUE = "CSS_SEM_CONCENTRATION_VALUE";
	// WMD12038 end
	
	//PDM12770
	 public static final String WEBPIN_PKI = "WEBPIN_PKI";
	 public static final String WEBPIN_KEY_MESSAGE = "WEBPIN_KEY_MESSAGE";
	 public static final String WEBPIN_OLD_CHECKSUM = "WEBPIN_OLD_CHECKSUM";
	 public static final String WEBPIN_NEW_CHECKSUM = "WEBPIN_NEW_CHECKSUM";
	 public static final String WEBPIN_RETURN_CODE = "WEBPIN_RETURN_CODE";  
     public static final String RESET_BY = "RESET_BY";
     public static final String WEBPIN_ASSIGN_DATE = "WEBPIN_ASSIGN_DATE";
	 
 	//SCR-PDM10588 Start
        public static final String ATM_ACTION = "ATM_ACTION";
        public static final String ATM_OVERSEA_LIMIT = "ATM_OVERSEA_LIMIT";
        public static final String ATM_START_DATE = "ATM_START_DATE";
        public static final String ATM_END_DATE = "ATM_END_DATE";
        //SCR_PDM10588 End
        
        
    //PDM12647 Start
   	public static final String FRAUD_MON_SMS_ACC_NUM = "FRAUD_MON_SMS_ACC_NUM";
   	public static final String FRAUD_MON_SMS_RECIPIENT_LIST = "FRAUD_MON_SMS_RECIPIENT_LIST";
   	public static final String FRAUD_MON_SMS_CONTENT = "FRAUD_MON_SMS_CONTENT";
   	public static final String FRAUD_MON_SMS_MSGLEN = "FRAUD_MON_SMS_MSGLEN";
   	public static final String FRAUD_MON_SMS_LANUAGE = "FRAUD_MON_SMS_LANUAGE";
   	public static final String FRAUD_MON_SMS_MSG_TYPE = "FRAUD_MON_SMS_MSG_TYPE";
   	public static final String FRAUD_MON_SMS_PRIORITY = "FRAUD_MON_SMS_PRIORITY";
   	public static final String FRAUD_MON_SMS_REFNUM = "FRAUD_MON_SMS_REFNUM";
   	public static final String FRAUD_MON_SMS_TEMPLATE_ID = "FRAUD_MON_SMS_TEMPLATE_ID";
   	public static final String FRAUD_MON_SMS_TEMPLATE_CONTENT_LIST = "FRAUD_MON_SMS_TEMPLATE_CONTENT_LIST";
   	public static final String FRAUD_MON_SMS_CUSTOMER_INFO = "FRAUD_MON_SMS_CUSTOMER_INFO";
   	public static final String FRAUD_MON_SMS_ALERT_LIST = "FRAUD_MON_SMS_ALERT_LIST";
   	public static final String FRAUD_MON_SMS_TXN_ID_LIST = "FRAUD_MON_SMS_TXN_ID_LIST";
    //PDM12647 End
	
	// WMD13023 start
	public static final String CSS_REASON_UNMATCHED_INV_EXP = "CSS_REASON_UNMATCHED_INV_EXP";
	// WMD13023 END
	//Ebpp Jack Wong 20130728 Begin
	
	public static final String SEL_PTY = "SEL_PTY";                
	public static final String EBI_ID = "EBI_ID"; 
	public static final String MRCH_CODE_EPS = "MRCH_CODE_EPS" ;  
	public static final String BILL_TYPE_EPS = "BILL_TYPE_EPS"; 
	public static final String MRCH_CODE_ICL = "MRCH_CODE_ICL";  
	public static final String BILL_TYPE_ICL = "BILL_TYPE_ICL"; 
	public static final String TX_CURR = "TX_CURR";  
	public static final String ICL_OUT_REFERENCE = "ICL_OUT_REFERENCE"; 
	public static final String ICL_OUT_PARTICULARS = "ICL_OUT_PARTICULARS"; 
	public static final String ICL_REJ_CODE = "ICL_REJ_CODE";  
	public static final String ICL_DSB_PAYT_REF_NUM = "ICL_DSB_PAYT_REF_NUM"; 
	public static final String ICL_EBPCR_PAYT_REF_NUM = "ICL_EBPCR_PAYT_REF_NUM"; 
	public static final String ICL_DONOR_ID = "ICL_DONOR_ID"; 
	public static final String ICL_DONOR_RCPT = "ICL_DONOR_RCPT";  
	public static final String ICL_ANON_DONATE = "ICL_ANON_DONATE";  
	public static final String ICL_DONOR_NAME = "ICl_DONOR_NAME"; 
	public static final String ICL_DONATE_RCPT_EMAIL = "ICL_DONATE_RCPT_EMAIL"; 
	public static final String ICL_IN_REFERENCE = "ICL_IN_REFERNCE"; 
	public static final String ICL_IN_PARTICULARS = "ICL_IN_PARTICULARS";
	public static final String ICL_RTN_CODE ="ICl_RTN_CODE";                   
	public static final String ICL_RTN_REASON = "ICL_RTN_REASON"; 
	public static final String EBPS_REF_NUM_BILL = "EBPS_REF_NUM_BILL"; 
	public static final String ICL_TXN_CODE = "ICL_TXN_CODE"; 
	public static final String ICL_DONATE_RCPT_REQ = "ICL_DONATE_RCPT_REQ"; 
	public static final String ICL_ENROLMENT_OBJ = "ENROL_OBJ";
	public static final String CUR_PAGE = "CUR_PAGE";
	public static final String IS_HIGH_RISK_BILL = "HIGH_RISK_BILL";
	public static final String ICL_BANK_CODE = "ICL_BANK_CODE";
	public static final String WAIVE_CHARGE_IND = "WAIVE_CHARGE_IND";
	public static final String EBPP_BANKSIDE_BILL_UNREG_REQ = "EBPP_BANKSIDE_BILL_UNREG_REQ";
    public static final String BANKSIDE_CHANNEL ="BANKSIDE_CHANNEL";
    public static final String BANK_SIDE_USER_ID = "BANK_SIDE_USER_ID";
    public static final String ENROL_SEQ_ID = "ENROL_SEQ_ID";
    public static final String MODIFY_LABEL_CHANNEL = "MODIFY_LABEL_CHANNEL";
	public static final String LAST_MODIFY_DATE = "LAST_MODIFY_DATE";
	public static final String CREATE_CHANNEL = "CREATE_CHANNEL";
	public static final String ENROL_ID = "ENROL_ID";
	public static final String CREDIT_CARD_PAYMENT_FLAG = "CREDIT_CARD_PAYMENT_FLAG";
    //bankside high risk bill unregister edit ends;
	//PDM13694 EBPP Phase 2.5 Begin
	//////
	public static final String ICL_PAYER_NAME = "ICL_PAYER_NAME";
	public static final String ICL_PAYER_RCPT_MAIL = "ICL_PAYER_RCPT_MAIL";
	//PDM13694 EBPP Phase 2.5 End
	//PDM13694 Ebpp Jack Wong 20130728 End
	// EBPP phase 3 Start
	public static final String ICL_DONOR_INFO = "ICL_DONOR_INFO";
	public static final String ICL_PRES_REF_NUM = "PRES_REF_NUM";
	public static final String INSTR_LAST_UPD_DATE = "INSTR_LAST_UPD_DATE";
	// EBPP phase 3 End
    
	//SCR-PDM12706 Start
	public static final String SUPPRESS_FLAG = "SUPPRESS_STATEMENT_FLAG";
	public static final String ZIP_CODE = "ZIP_CODE";
	public static final String POSITION = "POSITION";
	public static final String BILLING_CYCLE = "BILLING_CYCLE";
	public static final String MEMO_LINE_1 = "MEMO_LINE_1";
	public static final String MEMO_LINE_2 = "MEMO_LINE_2";
	//SCR-PDM12706 End
	
	// PDM12146 start               
	public static final String WEB_SERVICE_REQUEST = "WEB_SERVICE_REQUEST"; 
	public static final String MB_SERVICE_STATUS = "MB_SERVICE_STATUS"; 
	public static final String MB_SERVICE_UPDATE_DATE = "MB_SERVICE_UPDATE_DATE"; 
	// PDM12146 end
	
	//token replacement charge
	public static final String TOK_REPLACE_CHARGE_TYPE = "TOK_REPLACE_CHARGE_TYPE";
	public static final String TOK_REPLACE_TXN_CODE = "TOK_REPLACE_TXN_CODE";
	public static final String TOK_REPLACE_GL_BRANCH_CODE = "TOK_REPLACE_GL_BRANCH";
	public static final String TOK_REPLACE_GL_CODE = "TOK_REPLACE_GL_BRANCH_CODE";
	public static final String TOK_REPLACE_DECODED_AMT = "TOK_REPLACE_DECODED_AMT";

        public static final String BILL_TKN = "BILL_TOKEN";
        
        
    //SCR-DRD09002 Start
    public static final String EX_FOREIGN_CUR = "EX_FOREIGN_CURRENCY";
    public static final String EX_TRANS_CUR = "EX_TRANS_CUR";
    public static final String EX_TRANS_AMT = "EX_TRANS_AMT";
    public static final String EX_RATE_REQ_IND = "EX_RATE_REQ_IND";
    public static final String EX_RATE_ORD_TYPE = "EX_RATE_ORD_TYPE";
    public static final String EX_SUPER_ID = "EX_SUPER_ID";
    public static final String EX_OVER_FLAG = "EX_OVER_FLAG";
    public static final String EX_RATE_TYPE = "EX_RATE_TYPE";
    public static final String EX_CNY_CLASS = "EX_CNY_CLASS";
    public static final String EX_OFF_CODE = "EX_OFF_CODE";
    public static final String EX_OFF_SUBCODE = "EX_OFF_SUBCODE"; 
    public static final String EX_DIVISION = "EX_DIVISION";
    public static final String EX_REGION = "EX_REGION";
    public static final String EX_STAFF_IND = "EX_STAFF_IND";
    public static final String EX_VIP_FLAG = "EX_VIP_FLAG";
    public static final String EX_RATE_TIER = "EX_RATE_TIER";
    public static final String EX_DEB_T1_RATE_1 = "EX_DEB_T1_RATE_1";
    public static final String EX_DEB_T1_RATE_2 = "EX_DEB_T1_RATE_2";
    public static final String EX_DEB_T1_RATE_3 = "EX_DEB_T1_RATE_3";
    public static final String EX_DEB_T1_PROFIT = "EX_DEB_T1_PROFIT";
    public static final String EX_DEB_T1_COST = "EX_DEB_T1_COST";
    public static final String EX_CRE_T1_RATE_1 = "EX_CRE_T1_RATE_1";
    public static final String EX_CRE_T1_RATE_2 = "EX_CRE_T1_RATE_2";
    public static final String EX_CRE_T1_RATE_3 = "EX_CRE_T1_RATE_3";
    public static final String EX_CRE_T1_PROFIT = "EX_CRE_T1_PROFIT";
    public static final String EX_CRE_T1_COST = "EX_CRE_T1_COST";
    public static final String EX_DEB_T2_RATE_1 = "EX_DEB_T2_RATE_1";
    public static final String EX_DEB_T2_RATE_2 = "EX_DEB_T2_RATE_2";
    public static final String EX_DEB_T2_RATE_3 = "EX_DEB_T2_RATE_3";
    public static final String EX_DEB_T2_PROFIT = "EX_DEB_T2_PROFIT";
    public static final String EX_DEB_T2_COST = "EX_DEB_T2_COST";
    public static final String EX_CRE_T2_RATE_1 = "EX_CRE_T2_RATE_1";
    public static final String EX_CRE_T2_RATE_2 = "EX_CRE_T2_RATE_2";
    public static final String EX_CRE_T2_RATE_3 = "EX_CRE_T2_RATE_3";
    public static final String EX_CRE_T2_PROFIT = "EX_CRE_T2_PROFIT";
    public static final String EX_CRE_T2_COST = "EX_CRE_T2_COST";
    public static final String EX_SPOT_DATA = "EX_SPOT_DATA";
    public static final String EX_BRANCH = "EX_BRANCH";
    //SCR-DRD09002 End
    
    //SCR-PDM13729 Start
    public static final String WEB_SERVICE_RESPONSE = "WEB_SERVICE_RESPONSE";
    //SCR-PDM13729 End
    
    //Currency switching phase 1B
    public static final String ACCT_SUMMARY_ENQ_FILLER = "ACCT_SUMMARY_ENQ_FILLER";
    //Currency switching phase 1B ends
    
    public static final String VALUE = "VALUE";
    public static final String RE_ISSUE_FEE_INDICATOR = "RE_ISSUE_FEE_INDICATOR";
    public static final String CIF_NUMBER = "CIF_NUMBER";
    public static final String ATM_CARD_TYPE = "ATM_CARD_TYPE";
    public static final String TERMINATE_OCTOPUS_INDICATOR = "TERMINATE_OCTOPUS_INDICATOR";
    public static final String OCTOPUS_CARD_FLAG = "OCTOPUS_CARD_FLAG";
    
    public static final String STATEMENT_CYCLE = "STATEMENT_CYCLE";
    public static final String ACCT_STATUS_CODE = "ACCT_STATUS_CODE";
    public static final String STATEMENT_NAME_1 = "STATEMENT_NAME_1";
    public static final String STATEMENT_NAME_2 = "STATEMENT_NAME_2";
    public static final String TRUST_CLIENT_INDICATOR = "TRUST_CLIENT_INDICATOR";
    public static final String ACCOUNT_INDICATOR  = "ACCOUNT_INDICATOR";
    public static final String RENEW_STATUS  = "RENEW_STATUS";
    public static final String SOURCE_CODE  = "SOURCE_CODE";
    public static final String LIST_DAILY_FLAG  = "LIST_DAILY_FLAG";
    public static final String WAIVE_OD_INTEREST_INDICATOR = "WAIVE_OD_INTEREST_INDICATOR";
    public static final String WAIVE_UNAUTHORIZED_OD_CHARGE_INDICATOR = "WAIVE_UNAUTHORIZED_OD_CHARGE_INDICATOR";
    public static final String WAIVE_DORMANT_CHARGE_INDICATOR  = "WAIVE_DORMANT_CHARGE_INDICATOR";
    public static final String OFFICER_CODE = "OFFICER_CODE";
    public static final String SUPPRESS_PAPER_STATEMENT  = "SUPPRESS_PAPER_STATEMENT";
    public static final String E_ADVICE ="E_ADVICE";
    public static final String MAINTENANCE_FEE_WAIVER_END_DATE ="MAINTENANCE_FEE_WAIVER_END_DATE";
    public static final String CHARACTER_TYPE ="CHARACTER_TYPE";
    public static final String DIRECT_SALES_TEAM_INFORMATION = "DIRECT_SALES_TEAM_INFORMATION";
    public static final String PAYROLL_INFORMATION = "PAYROLL_INFORMATION";
    public static final String SUPPRESS_PAPER_STATEMENT_E_STATEMENT = "SUPPRESS_PAPER_STATEMENT_E_STATEMENT";
    public static final String E_ADVICE_E_STATEMENT = "E_ADVICE_E_STATEMENT";
     
    //SCR-PDM13729 Start
    public static final String SURNAME = "SURNAME";
    public static final String GIVEN_NAME = "GIVEN_NAME";
    public static final String ADDRESS_1 = "ADDRESS_1";
    public static final String ADDRESS_2 = "ADDRESS_2";
    public static final String ADDRESS_3 = "ADDRESS_3";
    public static final String ADDRESS_4 = "ADDRESS_4";
    //SCR-PDM13729 End
    public static final String DATE_OF_BIRTH = "DATE_OF_BIRTH";
    public static final String APPLY_ATM_SERVICE = "APPLY_ATM_SERVICE";
    public static final String APPLY_PAYROLL_SERVICE = "APPLY_PAYROLL_SERVICE";
    public static final String APPLY_E_RECEIPT_FLAG = "APPLY_E_RECEIPT_FLAG";
    public static final String UPLOADED_DOCUMENT_INDICATOR = "UPLOADED_DOCUMENT_INDICATOR";
    public static final String JOINT_ACCOUNT_REQUEST_INDICATOR = "JOINT_ACCOUNT_REQUEST_INDICATOR";
    
    //SCR-OPD14002 START
    public static final String BIRTH_COUNTRY_CODE_UPDATE_FLAG = "BIRTH_COUNTRY_CODE_UPDATE_FLAG";
    public static final String CUSTOMER_DETAILS = "CUSTOMER_DETAILS";
    public static final String EXISTING_FIXED_DEPOSIT_CUSTOMER_FLAG = "EXISTING_FIXED_DEPOSIT_CUSTOMER_FLAG";
    public static final String HOST_TRANSACTION_SEQUENCE_NUMBER = "HOST_TRANSACTION_SEQUENCE_NUMBER";
    //SCR-OPD14002 END
    
    //2FA phase 2b
    public static final String BYPASS_REGISTRATION_CHECK = "BYPASS_REGISTRATION_CHECK";
    //2FA phase 2b ends
    
    //SCR-DRD14058 START
    public static final String ADDRESS = "ADDRESS";
    public static final String CITY = "CITY";
    public static final String COUNTRY = "COUNTRY";
    public static final String PASSPORT = "PASSPORT";
    public static final String BUSINESS_NATURE = "BUSINESS_NATURE";
    public static final String JOB_POSITION = "JOB_POSITION";
    public static final String MONTHLY_INCOME = "MONTHLY_INCOME";
    public static final String DATE_OPEN = "DATE_OPEN";
    //SCR-DRD14058 End
    
    //SCR-CCD14022 START
    public static final String EXCHANGE_RATE = "EXCHANGE_RATE";
    //SCR-CCD14022 END
    
    //PDM15118 START
    public static final String DATE_CLOSE = "DATE_CLOSE";
    //PDM15118 END
    
    //WMD14204 begin
    public static final String CSS_SEM_AUM_EXCEED_THRESHOLD = "CSS_SEM_AUM_EXCEED_THRESHOLD";
    public static final String CSS_SEM_TXN_INVEST_OBJ2 = "CSS_SEM_TXN_INVEST_OBJ2";
    //WMD14204 end
    
    //PDM15219 START
    public static final String CIF_ESTMT_EADV_DETAILS = "CIF_ESTMT_EADV_DETAILS";
    public static final String CIF_ESTMT_EADV_SERVICE = "CIF_ESTMT_EADV_SERVICE";
    public static final String CIF_ESTMT_EADV_TYPE = "CIF_ESTMT_EADV_TYPE";
    public static final String CIF_ESTMT_EADV_OPTIN_FLAG = "CIF_ESTMT_EADV_OPTIN_FLAG";
    public static final String CIF_ESTMT_EADV_LAST_UPDATE_DATE = "CIF_ESTMT_EADV_LAST_UPDATE_DATE";
    public static final String CIF_ESTMT_EADV_LAST_UPDATE_TIME = "CIF_ESTMT_EADV_LAST_UPDATE_TIME";
    public static final String CIF_ESTMT_EADV_LAST_UPDATE_CHANNEL = "CIF_ESTMT_EADV_LAST_UPDATE_CHANNEL";
    //PDM15219 END
    
    //PDM15125 begin
    public static final String OPTION = "OPTION";
    public static final String HISTORY_INDICATOR = "HISTORY_INDICATOR";
    public static final String PUBLIC_SITE_INDICATOR = "PUBLIC_SITE_INDICATOR";
    public static final String LOG_NUMBER = "LOG_NUMBER";
    public static final String HOST_EMAIL_UPDATE_DATE = "HOST_EMAIL_UPDATE_DATE";
    public static final String EMAIL_UPDATE_STATUS = "EMAIL_UPDATE_STATUS";
    
    public static final String PERMANENT_EMAIL_ADDR = "PERMANENT_EMAIL_ADDR";
    public static final String PERMANENT_EMAIL_REMARK = "PERMANENT_EMAIL_REMARK";
    public static final String PERMANENT_UPDATE_CHANNEL = "PERMANENT_EMAIL_CHANNEL";
    public static final String PERMANENT_UPDATE_DATE = "PERMANENT_EMAIL_DATE";
    public static final String PERMANENT_UPDATE_TIME = "PERMANENT_UPDATE_TIME";
    public static final String PERMANENT_UPDATE_USER = "PERMANENT_UPDATE_USER";
    public static final String PERMANENT_REFERENCE_NUMBER = "PERMANENT_REFERENCE_NUMBER";
    
    public static final String PREFERED_EMAIL_ADDR = "PREFERED_EMAIL_ADDR";
    public static final String PREFERED_UPDATE_CHANNEL = "PREFERED_UPDATE_CHANNEL";
    public static final String PREFERED_UPDATE_DATE = "PREFERED_UPDATE_DATE";
    public static final String PREFERED_UPDATE_TIME = "PREFERED_UPDATE_TIME";
    public static final String PREFERED_UPDATE_USER = "PREFERED_UPDATE_USER";
    public static final String PREFERED_CONSENT_REQUIRED = "PREFERED_CONSENT_REQUIRED";
    public static final String PREFERED_CONSENT_OBTAINED = "PREFERED_CONSENT_OBTAINED";
    
    public static final String PENDING_EMAIL_ADDR = "PENDING_EMAIL_ADDR";
    public static final String PENDING_EMAIL_REMARK = "PENDING_EMAIL_REMARK";
    public static final String PENDING_UPDATE_CHANNEL = "PENDING_UPDATE_CHANNEL";
    public static final String PENDING_UPDATE_DATE = "PENDING_UPDATE_DATE";
    public static final String PENDING_UPDATE_TIME = "PENDING_UPDATE_TIME";
    public static final String PENDING_UPDATE_USER = "PENDING_UPDATE_USER";
    public static final String PENDING_REF_NO = "PENDING_REF_NO";
    public static final String PENDING_EXPIRY_DATE = "PENDING_EXPIRY_DATE";
    public static final String PENDING_STATUS = "PENDING_STATUS";
    
    public static final String TYPE = "TYPE";
    public static final String LAST_UPDATE_DATE = "LAST_UPDATE_DATE";
    public static final String LAST_UPDATE_TIME = "LAST_UPDATE_TIME";
    public static final String LAST_UPDATE_USER_ID = "LAST_UPDATE_USER_ID";
    public static final String LAST_UPDATE_CHANNEL = "LAST_UPDATE_CHANNEL";
    public static final String SUPPRESS_FLAG_DETAILS = "SUPPRESS_FLAG_DETAILS";
    public static final String HOST_TRANS_SEQ_NUMBER = "HOST_TRANS_SEQ_NUMBER";
    //PDM15125 end
   
    //NF1621,NF1622,NF1623 START
    public static final String PHONE_BANKING_ID="PHONE_BANKING_ID";
    
    public static final String AUTHENTICATION_ID="AUTHENTICATION_ID";
    public static final String SERVICE_STATUS="SERVICE_STATUS";
    public static final String REGISTRATION_DATE="REGISTRATION_DATE";
    public static final String REGISTRATION_TIME="REGISTRATION_TIME";
    public static final String P2P_ID="P2P_ID";
    public static final String REGISTERED_ACCOUNT_NUMBER="REGISTERED_ACCOUNT_NUMBER";
    public static final String REGISTERED_ACCOUNT_CURRENCY="REGISTERED_ACCOUNT_CURRENCY";
    public static final String PRE_SET_LIMIT="PRE_SET_LIMIT";
    public static final String REMAINING_LIMIT="REMAINING_LIMIT";
    public static final String MOBILE_PIN_RESTRY_COUNT="MOBILE_PIN_RESTRY_COUNT";
    public static final String LAST_TRANSACTION_DATE="LAST_TRANSACTION_DATE";
    public static final String LAST_TRANSACTION_TIME="LAST_TRANSATCION_TIME";
    public static final String TERMINATION_DATE="TERMINATION_DATE";
    public static final String HHOST_TRANSACTION_SEQUNCE_NUMBER="HOST_TRANSACTION_SEQUNCE_NUMBER";
    
    public static final String JETCO_TRANSACTION_SEQUENCE_NUMBER="JETCO_TRANSACTION_SEQUENCE_NUMBER";
    public static final String TRANSACTION_DATE="TRANSACTION_DATE";
    public static final String JETCO_TRANSACTION_DATE="JETCO_TRANSACTION_DATE";
    public static final String JETCO_TRANSACTION_TIME="JETCO_TRANSACTION_TIME";
    public static final String JETCO_TRANSACTION_TRANS_CODE="JETCO_TRANSACTION_TRANS_CODE";//transaction code
    public static final String JETCO_TRANSACTION_ACC_NUMBER="JETCO_TRANSACTION_ACC_NUMBER";//account number
    public static final String JETCO_TRANSACTION_AMOUNT="JETCO_TRANSACTION_AMOUNT";
    public static final String JETCO_TRANSACTION_CURRENCY="JETCO_TRANSACTION_CURRENCY";
    public static final String JETCO_TRANSACTION_TRANS_BANK_CODE="JETCO_TRANSACTION_TRANS_BANK_CODE";//transaction bank code
    public static final String JETCO_TRANSACTION_TRANSFERER_ACC_NUM="JETCO_TRANSACTION_TRANSFERER_ACC_NUM";//transferer account Number
    public static final String JETCO_TRANSACTION_TRANS_ACC_NUMBER="JETCO_TRANSACTION_TRANS_ACC_NUMBER";//transaction account number
    public static final String JETCO_TRANSACTION_P2P_TRANS_ID="JETCO_TRANSACTION_P2P_TRANS_ID";//p2p transaction ID
    public static final String JETCO_TRANSACTION_SYS_SEQ_NUMBER="JETCO_TRANSACTION_SYS_SEQ_NUMBER";//JETCO System Sequence Number
    public static final String JETCO_TRANSACTION_STATUS="JETCO_TRANSACTION_STATUS";
    public static final String JETCO_TRANSACTION_FILLER="JETCO_TRANSACTION_FILLER";
    public static final String JETCO_TRANSACTION_DETAILS="JETCO_TRANSACTION_DETAILS";
    
    public static final String ACTION="ACTION";
    public static final String AUTHENTICATION_ID_TAG="AUTHENTICATION_ID_TAG";
    public static final String PRE_SET_LIMIT_TAG="PRE_SET_LIMIT_TAG";
    public static final String SVT_SERVICE_STATUS="SVT_SERVICE_STATUS";
    
    public static final String P2P_EMAIL_SENT_DATE="P2P_EMAIL_SENT_DATE";
    public static final String SVT17_EMAIL_SENT_DATE="SVT17_EMAIL_SENT_DATE";
    public static final String SVT18_EMAIL_SENT_DATE="SVT18_EMAIL_SENT_DATE";
    public static final String SVT_ACT_UPD_DATE="SVT_ACT_UPD_DATE";
    public static final String SVT_STATUS_UPD_DATE="SVT_STATUS_UPD_DATE";
    public static final String SVT_STATUS_UPD_TYPE="SVT_STATUS_UPD_TYPE";
    public static final String SVT_LAST_ADJUSTED_LIMIT="SVT_LAST_ADJUSTED_LIMIT";
    public static final String P2PST_UPD_DATE="P2PST_UPD_DATE";
    public static final String P2PST_UPD_TYPE="P2PST_UPD_TYPE";
    public static final String BANKSIDE_INDICATOR="BANKSIDE_INDICATOR";
    public static final String TRANSACTION_TIME="TRANSACTION_TIME";
    //NF1621,NF1622,NF1623 end
    
    //BO0010 START
    public static final String SEA_LAND_AIR_ENQUIRY_PARMID ="SEA_LAND_AIR_ENQUIRY_PARMID";
    public static final String SEA_LAND_AIR_ENQUIRY_NUM ="SEA_LAND_AIR_ENQUIRY_NUM";
    public static final String SEA_LAND_AIR_ENQUIRY_HKID ="SEA_LAND_AIR_ENQUIRY_HKID";
    public static final String SEA_LAND_AIR_ENQUIRY_NO_OF_GIFT ="SEA_LAND_AIR_ENQUIRY_NO_OF_GIFT";
    public static final String SEA_LAND_AIR_ENQUIRY_REPE_DATE ="SEA_LAND_AIR_ENQUIRY_REPE_DATE";
    public static final String SEA_LAND_AIR_ENQUIRY_GIFT_LIST ="SEA_LAND_AIR_ENQUIRY_GIFT_LIST";
    public static final String SEA_LAND_AIR_ENQUIRY_QUANTITY ="SEA_LAND_AIR_ENQUIRY_QUANTITY";
    public static final String SEA_LAND_AIR_ENQUIRY_GIFT_ID ="SEA_LAND_AIR_ENQUIRY_GIFT_ID";
    public static final String SEA_LAND_AIR_ENQUIRY_ACC_SPENDING ="SEA_LAND_AIR_ENQUIRY_ACC_SPENDING";
    public static final String SEA_LAND_AIR_ENQUIRY_NO_OF_RECORD ="SEA_LAND_AIR_ENQUIRY_NO_OF_RECORD";
    public static final String SEA_LAND_AIR_ENQUIRY_SPEND_MONTH ="SEA_LAND_AIR_ENQUIRY_SPEND_MONTH";
    public static final String SEA_LAND_AIR_ENQUIRY_SPEND_AMOUNT ="SEA_LAND_AIR_ENQUIRY_SPEND_AMOUNT";
    public static final String SEA_LAND_AIR_ENQUIRY_SPEND_MONTH_END ="SEA_LAND_AIR_ENQUIRY_SPEND_MONTH_END";
    public static final String SEA_LAND_AIR_ENQUIRY_SPEND_TXN_COUNT ="SEA_LAND_AIR_ENQUIRY_SPEND_TXN_COUNT";
    public static final String SEA_LAND_AIR_ENQUIRY_REG_DATE ="SEA_LAND_AIR_ENQUIRY_REG_DATE";
    public static final String SEA_LAND_AIR_ENQUIRY_PREMIUM_STATUS ="SEA_LAND_AIR_ENQUIRY_PREMIUM_STATUS";
    public static final String SEA_LAND_AIR_ENQUIRY_CUST_PARAM_1 ="SEA_LAND_AIR_ENQUIRY_CUST_PARAM_1";
    public static final String SEA_LAND_AIR_ENQUIRY_CUST_PARAM_2 ="SEA_LAND_AIR_ENQUIRY_CUST_PARAM_2";
    public static final String SEA_LAND_AIR_ENQUIRY_CUST_PARAM_3 ="SEA_LAND_AIR_ENQUIRY_CUST_PARAM_3";
    //BO0010 END
    
    //PDM15434 START
    public static final String PAYMENT_OPTION = "PAYMENT_OPTION";
    public static final String PARTIAL_PRINCIPAL = "PARTIAL_PRINCIPAL";
    public static final String PAYMENT_OPTION_DESC = "PAYMENT_OPTION_DESC";
    public static final String MONTHLY_GAIN_INFO = "MONTHLY_GAIN_INFO";
    public static final String ORIGINAL_PRINCIPAL = "ORIGINAL_PRINCIPAL";
    public static final String PROMOTION_NUMBER_OF_MONTHS = "PROMOTION_NUMBER_OF_MONTHS";
    public static final String PREFERENTIAL_RATE = "PREFERENTIAL_RATE";
    public static final String MONTHLY_GAIN_INFO_FLAG = "MONTHLY_GAIN_INFO_FLAG";
    public static final String MONTHLY_GAIN_PAYMENT_PRINCIPAL = "MONTHLY_GAIN_PAYMENT_PRINCIPAL";
    public static final String MONTHLY_GAIN_MATURITY_INTEREST = "MONTHLY_GAIN_MATURITY_INTEREST";
    //PDM15434 END
    
  //BO0011 START
    public static final String GIFTCARD_NUM ="GIFTCARD_NUM";
    public static final String GIFTCARD_TRANS_START_DATE ="GIFTCARD_TRANS_START_DATE";
    public static final String GIFTCARD_TRANS_END_DATE ="GIFTCARD_TRANS_END_DATE";
    
  //RSD14013 START
    public static final String TRANSFER_CCY = "TRANSFER_CCY";
    public static final String TRANSFER_HKD_AMT = "TRANSFER_HKD_AMT";
    public static final String EXCEPTION_INDICATOR = "EXCEPTION_INDICATOR";
    public static final String REMITTANCE_REFERENCE_NUMBER =  "REMITTANCE_REFERENCE_NUMBER";
    public static final String IS_NEXT_DAY_RECORD = "IS_NEXT_DAY_RECORD";
    public static final String IS_CUT_OFF_TIME = "IS_CUT_OFF_TIME";
    
    public static final String MESSAGE_TYPE = "MESSAGE_TYPE";
    public static final String REMIT_CURRENCY = "REMIT_CURRENCY";
    public static final String REMIT_AMOUNT = "REMIT_AMOUNT";
    public static final String PURPOSE_OF_REMITTANCE = "PURPOSE_OF_REMITTANCE";
    public static final String REMARK_LINE_1 = "REMARK_LINE_1";
    public static final String REMARK_LINE_2 = "REMARK_LINE_2";
    public static final String COUNTRY_CODE = "COUNTRY_CODE";
    public static final String CHINESE_WORDS_CHARGE_INDICATOR  = "CHINESE_WORDS_CHARGE_INDICATOR";
    public static final String CHARGE_CURRENCY = "CHARGE_CURRENCY";
    public static final String BENE_ACCOUNT_INFO = "BENE_ACCOUNT_INFO";
    public static final String PAYMENT_INFO = "PAYMENT_INFO";
    // Beneficiary Account Information
    public static final String BENE_ACCOUNT_NO = "BENE_ACCOUNT_NO";
    public static final String BENE_ACCOUNT_NAME_LINE_1 = "BENE_ACCOUNT_NAME_LINE_1";
    public static final String BENE_ACCOUNT_NAME_LINE_2 = "BENE_ACCOUNT_NAME_LINE_2";
    public static final String BENE_ACCOUNT_NAME_LINE_3 = "BENE_ACCOUNT_NAME_LINE_3";
    public static final String BENE_COUNTRY = "BENE_COUNTRY";
    public static final String BENE_BANK_BIC = "BENE_BANK_BIC";
    public static final String BENE_BANK_BRANCH = "BENE_BANK_BRANCH";
    public static final String BENE_BANK_BIC_CODE = "BENE_BANK_BIC_CODE";
    // Payment Information
    public static final String PAYMENT_ONE_ACCOUNT_TYPE = "PAYMENT_ONE_ACCOUNT_TYPE";
    public static final String PAYMENT_ONE_ACCOUNT_NUMBER = "PAYMENT_ONE_ACCOUNT_NUMBER";
    public static final String PAYMENT_ONE_ACCOUNT_CURRENCY = "PAYMENT_ONE_ACCOUNT_CURRENCY";
    public static final String PAYMENT_ONE_SELL_EXCHANGE_RATE_TYPE = "PAYMENT_ONE_SELL_EXCHANGE_RATE_TYPE";
    public static final String PAYMENT_ONE_SELL_EXCHANGE_RATE = "PAYMENT_ONE_SELL_EXCHANGE_RATE";
    public static final String PAYMENT_ONE_BUY_EXCHANGE_RATE_TYPE = "PAYMENT_ONE_BUY_EXCHANGE_RATE_TYPE";
    public static final String PAYMENT_ONE_BUY_EXCHANGE_RATE = "PAYMENT_ONE_BUY_EXCHANGE_RATE";
    public static final String PAYMENT_TWO_ACCOUNT_TYPE = "PAYMENT_TWO_ACCOUNT_TYPE";
    public static final String PAYMENT_TWO_ACCOUNT_NUMBER = "PAYMENT_TWO_ACCOUNT_NUMBER";
    public static final String PAYMENT_TWO_ACCOUNT_CURRENCY = "PAYMENT_TWO_ACCOUNT_CURRENCY";
    
    //Other Information
    public static final String INTERMEDIARY_BANK_SWIFT_BIC = "INTERMEDIARY_BANK_SWIFT_BIC";
    public static final String INTERMEDIARY_BANK_SWIFT_BIC_BRANCH = "INTERMEDIARY_BANK_SWIFT_BIC_BRANCH";
    public static final String BANK_BUY_DEAL_NUMBER = "BANK_BUY_DEAL_NUMBER";
    public static final String BANK_SELL_DEAL_NUMBER = "BANK_SELL_DEAL_NUMBER";
    public static final String BATCH_NUMBER = "BATCH_NUMBER";
    public static final String MINIMUM_PROFIT_RATE_INDICATOR = "MINIMUM_PROFIT_RATE_INDICATOR";
    public static final String CIF_EXTRA_BUY_PIPS = "CIF_EXTRA_BUY_PIPS";
    public static final String CIF_EXTRA_SELL_PIPS = "CIF_EXTRA_SELL_PIPS";
    public static final String CHANNEL_EXTRA_BUY_PIPS = "CHANNEL_EXTRA_BUY_PIPS";
    public static final String CHANNEL_EXTRA_SELL_PIPS = "CHANNEL_EXTRA_SELL_PIPS";
    //RSD14013 END

    //WMD16067 START
    public static final String FX_ORDER_ENQUIRE_REQ_LAST_KEY = "FX_ORDER_ENQUIRE_REQ_LAST_KEY";
    public static final String FX_ORDER_ENQUIRE_REQ_ITEMS_REQUESTED = "FX_ORDER_ENQUIRE_REQ_ITEMS_REQUESTED";
    public static final String FX_ORDER_ENQUIRE_REQ_OPTION = "FX_ORDER_ENQUIRE_REQ_OPTION";
    
    public static final String FX_ORDER_TOTAL_NUM = "FX_ORDER_TOTAL_NUM";
    public static final String FX_ORDER_LAST_KEY = "FX_ORDER_LAST_KEY";
    public static final String FX_ORDER_MORE_ITEMS_INDICATOR = "FX_ORDER_MORE_ITEMS_INDICATOR";
    public static final String FX_ORDER_ORDER_TYPE = "FX_ORDER_ORDER_TYPE";
    public static final String FX_ORDER_CURRENCY = "FX_ORDER_CURRENCY";
    public static final String FX_ORDER_PRESET_EX_RATE = "FX_ORDER_PRESET_EX_RATE";
    public static final String FX_ORDER_ACTUAL_EX_RATE = "FX_ORDER_ACTUAL_EX_RATE";
    public static final String FX_ORDER_TRANSACTION_CURRENCY = "FX_ORDER_TRANSACTION_CURRENCY";
    public static final String FX_ORDER_TRANSACTION_AMOUNT = "FX_ORDER_TRANSACTION_AMOUNT";
    public static final String FX_ORDER_HKD_EQUIVALENT = "FX_ORDER_HKD_EQUIVALENT";
    public static final String FX_ORDER_DEBIT_ACCOUNT_NUMBER = "FX_ORDER_DEBIT_ACCOUNT_NUMBER";
    public static final String FX_ORDER_CREDIT_ACCOUNT_NUMBER = "FX_ORDER_CREDIT_ACCOUNT_NUMBER";
    public static final String FX_ORDER_PLACE_ORDER_TIME = "FX_ORDER_PLACE_ORDER_TIME";
    public static final String FX_ORDER_ORDER_NUMBER = "FX_ORDER_ORDER_NUMBER";
    public static final String FX_ORDER_USER_ID = "FX_ORDER_USER_ID";
    public static final String FX_ORDER_STATUS = "FX_ORDER_STATUS";
    public static final String FX_ORDER_SOURCE_ID = "FX_ORDER_SOURCE_ID";
    public static final String FX_ORDER_CANCEL_REF_NUMBER = "FX_ORDER_CANCEL_REF_NUMBER";
    public static final String FX_ORDER_DR_CURRENCY = "FX_ORDER_DR_CURRENCY";
    public static final String FX_ORDER_DR_AMOUNT = "FX_ORDER_DR_AMOUNT";
    public static final String FX_ORDER_CR_CURRENCY = "FX_ORDER_CR_CURRENCY";
    public static final String FX_ORDER_CR_AMOUNT = "FX_ORDER_CR_AMOUNT";
    public static final String FX_ORDER_EXPIRY_DATE = "FX_ORDER_EXPIRY_DATE";
    public static final String FX_ORDER_REJECT_CODE = "FX_ORDER_REJECT_CODE";
    public static final String FX_ORDER_PLACE_ORDER_DATE = "FX_ORDER_PLACE_ORDER_DATE";
    public static final String FX_ORDER_LAST_STATUS_DATE = "FX_ORDER_LAST_STATUS_DATE";
    public static final String FX_ORDER_LAST_STATUS_TIME = "FX_ORDER_LAST_STATUS_TIME";
    //WMD16067 END
    
    //WMD12103 START
    //request
    public static final String FUND_SWITCH_HOLD_STATUS = "FUND_SWITCH_HOLD_STATUS";
    public static final String FUND_SWITCH_BANK_CODE = "FUND_SWITCH_BANK_CODE";
    public static final String FUND_SWITCH_FUNDCODE_SWI = "FUND_SWITCH_FUNDCODE_SWI";
    public static final String FUND_SWITCH_FUNDCODE_SWO = "FUND_SWITCH_FUNDCODE_SWO";
	public static final String FUND_SWITCH_PORTFOLIONO = "FUND_SWITCH_PORTFOLIONO";
    public static final String FUND_SWITCH_ORDER_DATETIME = "FUND_SWITCH_ORDER_DATETIME";
    public static final String FUND_SWITCH_REFNUM = "FUND_SWITCH_REFNUM";
    public static final String FUND_SWITCH_CUTOFFTIME = "FUND_SWITCH_CUTOFFTIME";
    public static final String FUND_SWITCH_TOUTQS_INDICATOR = "FUND_SWITCH_TOUTQS_INDICATOR";
    public static final String FUND_SWITCH_TOCUST_INDICATOR = "FUND_SWITCH_TOCUST_INDICATOR";
    public static final String FUND_SWITCH_INITCOMM_RATE = "FUND_SWITCH_INITCOMM_RATE";
    public static final String FUND_SWITCH_DISCOUNT_RATE = "FUND_SWITCH_DISCOUNT_RATE";
    public static final String FUND_SWITCH_UNITS = "FUND_SWITCH_UNITS";
    //response
    public static final String FUND_SWITCH_REPSONSE_BANKCODE = "FUND_SWITCH_REPSONSE_BANKCODE";
    public static final String FUND_SWITCH_REPSONSE_REFNUM = "FUND_SWITCH_REPSONSE_REFNUM";
    public static final String FUND_SWITCH_REPSONSE_RETCODE = "FUND_SWITCH_REPSONSE_RETCODE";
    public static final String FUND_SWITCH_REPSONSE_RETMSG = "FUND_SWITCH_REPSONSE_RETMSG";
    //WMD12103 END
    
    //SCR-PDM18233 (Straight-through CASA Opening) Beg
    public static final String MARITAL_STATUS = "MARITAL_STATUS";
    public static final String PRIVACY_INDICATOR = "PRIVACY_INDICATOR";
    public static final String PAGER_NUMBER = "PAGER_NUMBER";
    public static final String FULL_EMAIL_ADDRESS = "FULL_EMAIL_ADDRESS";
    public static final String SPECIAL_STATUS = "SPECIAL_STATUS";
    public static final String YEAR_OF_BIRTH = "YEAR_OF_BIRTH";
    public static final String GENDER = "GENDER";
    public static final String APPLICATION_FEE_INDICATOR = "APPLICATION_FEE_INDICATOR";
    public static final String ANNUAL_FEE_INDICATOR = "ANNUAL_FEE_INDICATOR";
    public static final String CHARGING_ACCOUNT = "CHARGING_ACCOUNT";
    public static final String PIN_REFERENCE = "PIN_REFERENCE";
    public static final String CUST_RELATIONSHIP_END_DATE = "CUST_RELATIONSHIP_END_DATE";
    //SCR-PDM18233 (Straight-through CASA Opening) End
    
	//PDM18396 Payroll Features Enhancement in 1H 2019 Beg
    public static final String EDDA = "EDDA";
	//PDM18396 Payroll Features Enhancement in 1H 2019 End
    
}