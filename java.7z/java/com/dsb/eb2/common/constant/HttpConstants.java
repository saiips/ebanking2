package com.dsb.eb2.common.constant;

public class HttpConstants
{
    public static final String CONTENT_TYPE_KEY = "Content-Type";

    public static final String CONTENT_TYPE_TEXT_XML = "text/xml";

    public static final String CONTENT_TYPE_TEXT_HTML = "text/html";

    public static final String CONTENT_TYPE_APPLICATION = "application/x-www-form-urlencoded";

    public static final String METHOD_GET = "GET";

    public static final String METHOD_POST = "POST";

    public static final String METHOD_OPTION = "OPTION";

    public static final String CHARSET_KEY = "charset";

    public static final String ENCODING_UTF_8 = "UTF-8";

    public static final int RETURN_CODE_SUCCESS = 200;

    public static final int RETURN_CODE_ERROR_400 = 400;

    public static final int RETURN_CODE_ERROR_401 = 401;

    public static final int RETURN_CODE_ERROR_409 = 409;

    public static final String HEADER_FIELD_SET_COOKIE = "Set-Cookie";

    public static final String HEADER_FIELD_COOKIE = "Cookie";
}
