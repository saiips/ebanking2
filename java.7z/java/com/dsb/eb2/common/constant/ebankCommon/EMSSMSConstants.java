package com.dsb.eb2.common.constant.ebankCommon;

public class EMSSMSConstants {
		
	//WMD18047 SMS notification
	public static final int SFC_INTERNET_TRADING_MSGTYPE  = 76;
	public static final String SFC_CHANGE_OF_PASSWORD_TEMPID  	= "01";
	public static final String SFC_ONLINE_REGISTRATION_TEMPID  	= "02";
	
	/********************Batch SMS end********************/
}


