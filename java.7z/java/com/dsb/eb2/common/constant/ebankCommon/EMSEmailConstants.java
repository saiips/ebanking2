package com.dsb.eb2.common.constant.ebankCommon;

public class EMSEmailConstants {
	
	public static final String DSB_BANKCODE = "6";
	public static final String CHANNEL_EB = "EB";
	public static final String CHANNEL_MB = "MB";
	public static final String UNKNOWN_CUST_ID = "NaN";
	public static final String UNKNOWN_CUST_NAME = "Customer";
	public static final String MAP_PARAMETER_CATEGORY_PDM15126 = "PDM15126";
	public static final String MAP_PARAMETER_CATEGORY_CCY = "CCY";
	public static final String MAP_PARAMETER_CODE_HKD = "HKD";
	
	//ATM / Credit Card Overseas Withdrawal Service
	public static final int ATMCCCARD_EMAIL_MSGTYPE 		= 23;		//email message type
	public static final String ATM_ACTIVATE_EMAIL_TEMPID 	= "01";		//ATM Card Activate email template id
	public static final String ATM_DEACTIVATE_EMAIL_TEMPID 	= "02";		//ATM Card Deactivate email template id
	public static final String CC_ACTIVATE_EMAIL_TEMPID 	= "03";		//Credit Card Activate email template id
	public static final String CC_DEACTIVATE_EMAIL_TEMPID 	= "04";		//Credit Card Deactivate email template id
	
	//Inter-Bank Transfer (CHATS)
	public static final int INTER_CHATS_EMAIL_MSGTYPE 			= 24;			//email message type
	public static final String INTERCHATS_NOTIFY_EMAIL_TEMPID 	= "01";			//notify email template id
		
	//Online Payroll Service
	public static final int PAYROLL_EMAIL_MSGTYPE 		= 25;		//Payroll email message type
	public static final String PAYROLL_EMAIL_TEMPID 	= "01";		//Payroll email template id
	public static final String PAYROLL_EDDA_EMAIL_TEMPID 	= "02";	//Payroll Edda email template id
	
	//Mobile Banking Activation / Deactivation
	public static final int MB_ACTIVATE_EMAIL_MSGTYPE 		= 26;		//email message type
	public static final String MB_ACTIVATE_EMAIL_TEMPID 	= "01";		//Activation email template id
	public static final String MB_DEACTIVATE_EMAIL_TEMPID 	= "02";		//Deactivation email template id
	
	//Biometric Authentication
	public static final int MB_BIOMETRIC_EMAIL_MSGTYPE 		= 95;
	public static final String BIO_DEACTIVATE_PASSCODE_TEMPID 	= "13";	//deactivate passcode
	public static final String BIO_DEACTIVATE_FINGER_PASSCODE_TEMPID 	= "14";	//deactivate fingerprint and passcode
	public static final String BIO_DEACTIVATE_FACE_PASSCODE_TEMPID 	= "15";	//deactivate face and passcode
	public static final String BIO_DEACTIVATE_FINGER_PASSCODE_FACE_TEMPID 	= "16";	//deactivate fingerprint , passcode and face
	
	public static final String BIO_DEACTIVATE_MOBILETRADE_BY_SYSTEM_TEMPID 	= "18"; //deactivate mobileTrade by system
	
	/********************Batch email begin********************/
	//Scheduled PayEasy Bill Payment Instruction
	public static final int SCH_BP_EMAIL_MSGTYPE 		= 27;
	public static final String SCH_BP_REJECT_EMAIL_TEMPID 	= "01";		//Reject email template id	
	public static final String SCH_BP_SUCCESS_EMAIL_TEMPID 	= "02";		//Acknowledgment email template id
	
	//e-Deposit Service Set Up Acknowledgment
	public static final int ED_SETUP_EMAIL_MSGTYPE 		= 28;
	public static final String ED_SETUP_ACK_EMAIL_TEMPID 	= "01";
	
	//e-Donation Receipt Notification
	public static final int E_DONATION_EMAIL_MSGTYPE 	= 29;
	public static final String E_DONATION_EMAIL_TEMPID 	= "01";	
	
	//e-Bill Due Date Reminder
	public static final int BP_DUEDATE_REM_EMAIL_MSGTYPE 	= 30;
	public static final String BP_DUEDATE_REM_EMAIL_TEMPID 	= "01";
	
	//e-Payment Receipt Ready Reminder
	public static final int PAYT_REM_EMAIL_MSGTYPE 	= 31;
	public static final String PAYT_REM_DSB_EMAIL_TEMPID 	= "01";		//e-Payment Receipt Alert
	public static final String PAYT_REM_OTHBK_EMAIL_TEMPID 	= "02";		//e-Payment Receipt Alert (Payment via Other Bank)
	public static final String PAYT_REM_OTHPT_EMAIL_TEMPID 	= "03";		//e-Payment Receipt Alert (Payment from Other Party)
	
	//Scheduled e-Deposit - Success / Reject
	public static final int SCH_ED_EMAIL_MSGTYPE 		= 32;
	public static final String SCH_ED_REJECT_EMAIL_TEMPID 	= "01";		//Reject email
	public static final String SCH_ED_SUCCESS_EMAIL_TEMPID 	= "02";		//Acknowledgment email
	
	//e-Bill Enrolment Alert
	public static final int BILLENROL_EMAIL_MSGTYPE 	= 33;
	public static final String BILLENROL_REJECT_EMAIL_TEMPID 	= "02";		//Reject
	public static final String BILLENROL_ACCEPT_EMAIL_TEMPID 	= "01";		//Accept	
	
	//e-Bill Enrolment Deletion Notification
	public static final int BILLENROL_DEL_EMAIL_MSGTYPE 	= 34;
	public static final String BILLENROL_DEL_EMAIL_TEMPID 	= "01";
	
	//Fixed Deposit Creation - Success / Reject
	public static final int FD_CREATE_EMAIL_MSGTYPE 	= 35;
	public static final String FD_CREATE_REJECT_EMAIL_TEMPID 		= "01";		//Reject
	public static final String FD_CREATE_SUCCESS_EMAIL_TEMPID 		= "02";		//Acknowledgment
	public static final String FD_CREATE_REJECT_EMAIL_TEMPID_2 		= "03";		//Reject template 2
	public static final String FD_CREATE_SUCCESS_EMAIL_TEMPID_2 	= "04";		//Acknowledgment template 2
	
	//Scheduled Fixed Deposit Placement - Success / Reject
	public static final int FD_PLACE_EMAIL_MSGTYPE 	= 36;
	public static final String FD_PLACE_SUCCESS_EMAIL_TEMPID 	= "01";		//Acknowledgment
	public static final String FD_PLACE_SUCCESS_EMAIL_TEMPID_2 	= "02";		//Acknowledgment template 2
	
	//Fixed Deposit Creation (Monthly Gain) - Success / Reject
	public static final int FD_MG_EMAIL_MSGTYPE 	= 37;
	public static final String FD_MG_SUCCESS_EMAIL_TEMPID 	= "01";		//Acknowledgment
	
	//Foreign exchange Scheduled Instruction - Success / Reject
	public static final int SCH_FX_EMAIL_MSGTYPE 	= 38;
	public static final String SCH_FX_REJECT_EMAIL_TEMPID 	= "01";		//Reject
	public static final String SCH_FX_SUCCESS_EMAIL_TEMPID 	= "02";		//Acknowledgment
	
	//bankside : Inter-Bank Transfer Request Enquiry
	//Interbank fund transfer Scheduled Instruction - Success / Reject
	public static final int SCH_INTER_EMAIL_MSGTYPE 	= 39;
	public static final String SCH_INTER_REJECT_EMAIL_TEMPID 	= "01";		//Reject
	public static final String SCH_INTER_SUCCESS_EMAIL_TEMPID 	= "02";		//Acknowledgment
	
	//Intrabank fund transfer Scheduled Instruction - Success / Reject
	public static final int SCH_INTRA_EMAIL_MSGTYPE 	= 40;
	public static final String SCH_INTRA_REJECT_EMAIL_TEMPID 	= "01";		//Reject
	public static final String SCH_INTRA_SUCCESS_EMAIL_TEMPID 	= "02";		//Acknowledgment
	public static final String SCH_INTRA_REJECT_EMAIL_TEMPID_2 	= "03";		//Reject
	
	//Reminder for disabling the allow flag for bill payment (reminder email is sent 1 month before deactivation)
	public static final int BP_DEACT_REM_EMAIL_MSGTYPE 	= 41;
	public static final String BP_DEACT_REM_EMAIL_TEMPID 	= "01";
	
	//Suspension email for disabling the allow flag for bill payment
	public static final int BP_SUSP_EMAIL_MSGTYPE 	= 42;
	public static final String BP_SUSP_EMAIL_TEMPID = "01";
	
	//Reminder email for disabling the allow flag for fund transfer (reminder email is sent 1 month before deactivation)
	public static final int FT_DEACT_REM_EMAIL_MSGTYPE 	= 43;
	public static final String FT_DEACT_REM_EMAIL_TEMPID 	= "01";
	
	//Suspension email for disabling the allow flag for fund transfer
	public static final int FT_SUSP_EMAIL_MSGTYPE 	= 44;
	public static final String FT_SUSP_EMAIL_TEMPID = "01";
	
	//Payment Reversal Alert
	public static final int BP_REFUND_EMAIL_MSGTYPE 	= 45;
	public static final String REFUND_WITH_RFACCT_EMAIL_TEMPID 		= "01";		//with refund account
	public static final String REFUND_WITH_CRACCT_EMAIL_TEMPID 		= "02";		//without refund account
	
	//e-Bill Summary Alert
	public static final int BILL_SUMMARY_EMAIL_MSGTYPE 	= 46;
	public static final String BILL_SUMMARY_EMAIL_TEMPID = "01";
	
	//e-Banking Security Device Activation Reminder
	public static final int SD_ACT_EMAIL_MSGTYPE 	= 47;
	public static final String SD_ACT_EMAIL_TEMPID = "01";
	
	//Reminder for YOU Banking customers who did not first-time log into e-Banking for 30 days
	public static final int YB_1STLOGIN_EMAIL_MSGTYPE 	= 49;
	public static final String YB_1STLOGIN_EMAIL_TEMPID = "01";
	
	//Birthday Reminder for YOU Banking customers
	public static final int YB_BIRTH_REM_EMAIL_MSGTYPE 	= 51;
	public static final String YB_BIRTH_REM_EMAIL_TEMPID = "01";
	
	//Reminder email for Purge PBID Account (1 month before purge)
	public static final int PBID_PURGE_REM_EMAIL_MSGTYPE 	= 52;
	public static final String PBID_PURGE_REM_EMAIL_TEMPID = "01";
	
	//Dah Sing Credit Card eShopping Butler Registration Notice 
	
	public static final int CC_SHOP_EMAIL_MSGTYPE 	= 55;
	public static final String CC_SHOP_VALID_EMAIL_TEMPID = "01";
	public static final String CC_SHOP_INVALID_EMAIL_TEMPID = "02";
	
	//Dah Sing Bank Online Securities Account Application Acknowledgement
	public static final int OPEN_SECURITY_ACCOUNT_MSGTYPE  = 50;
	public static final String OPEN_SECURITY_ACCOUNT_SUCCESS_TMPID = "01";
	public static final String OPEN_SECURITY_ACCOUNT_FAIL_TMPID = "02";
	
	//WMD18047 email notification
	public static final int SFC_INTERNET_TRADING_MSGTYPE  = 103;
	public static final String SFC_LOGIN_INVESTMENT_SRV_TEMPID  = "01";
	public static final String SFC_FUND_SUBSCRIPTION_TEMPID  	= "02";
	public static final String SFC_FUND_REDEMPTION_TEMPID  		= "03";
	public static final String SFC_FUND_SWITCHING_TEMPID  		= "04";
	public static final String SFC_IBOUND_SUBSCRIPTION_TEMPID  	= "05";
	public static final String SFC_MOF_RMB_BOND_SUBSCRIPTION_TEMPID  = "06";
	public static final String SFC_CLPD_SUBSCRIPTION_TEMPID  	= "07";
	public static final String SFC_CHANGE_OF_PASSWORD_TEMPID  	= "08";
	public static final String SFC_ONLINE_REGISTRATION_TEMPID  	= "09";
	public static final String SFC_ISEC_LOGIN_TEMPID  	= "10";
	public static final String SFC_RESET_MOBILE_TRADING_PASSWORD_TEMPID  	= "11";
	
	/********************Batch email end********************/
}


