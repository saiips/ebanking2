package com.dsb.eb2.framework.util;

public abstract class JsonPattern {
	
	 public static final String DATE_FORMAT_DEFAULT = "yyyy-MM-dd";
	 public static final String DATE_FORMAT_SHORT = "yyyy-MM-dd";
	 public static final String DATE_FORMAT_LONG = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";
}
