package com.dsb.eb2.framework.config;

import java.util.Properties;

import javax.naming.NamingException;
import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jndi.JndiTemplate;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.dsb.eb2.framework.repository.BaseRepositoryImpl;

@Configuration
@Profile("production")
@EnableTransactionManagement
@PropertySource({ "classpath:persistence-jndi.properties" })
@ComponentScan({ "com.dsb.eb2.persistence" })
@EnableJpaRepositories(basePackages = "com.dsb.eb2.persistence.dao", repositoryBaseClass = BaseRepositoryImpl.class)
public class PersistenceJNDIConfig {
	
    @Autowired
    private Environment env;

    @Bean
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() throws NamingException {
        final LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(dataSource());
        em.setPackagesToScan(new String[] { "com.dsb.eb2.persistence.model" });
        em.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
        // em.setJpaProperties(additionalProperties());
        return em;
    }

    @Bean(destroyMethod = "")
    public DataSource dataSource() throws NamingException {
          return (DataSource) new JndiTemplate().lookup(env.getProperty("jdbc.url"));
    	
//    	  final JndiDataSourceLookup dsLookup = new JndiDataSourceLookup();
//        dsLookup.setResourceRef(true);
//        DataSource dataSource = dsLookup.getDataSource("jdbc/eb2DB");
//        return dataSource;    
    	
//        Context ctx = new InitialContext();
//        String jndiName = "java:comp/env/jdbc/eb2DB";
//        DataSource dataSource = (DataSource) ctx.lookup(jndiName);
//        return dataSource;
    	
    	
//        Context ctx;
//        DataSource dataSource;
//        Hashtable<String, String> ht;
//
//        ht = new Hashtable<>();
//        ht.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");
//        ht.put(Context.PROVIDER_URL, "t3://127.0.0.1:7001");
//        ht.put("weblogic.jndi.WLContext.ENABLE_SERVER_AFFINITY", "true");
//        ctx = new InitialContext(ht);
//
//        dataSource = (DataSource) ctx.lookup("jdbc/eb2DB");    	
//        return dataSource;
    }

    @Bean
    public PlatformTransactionManager transactionManager(final EntityManagerFactory emf) {
        final JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(emf);
        return transactionManager;
    }

    @Bean
    public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {
        return new PersistenceExceptionTranslationPostProcessor();
    }

    final Properties additionalProperties() {
        final Properties hibernateProperties = new Properties();
        hibernateProperties.setProperty("hibernate.hbm2ddl.auto", env.getProperty("hibernate.hbm2ddl.auto"));
        hibernateProperties.setProperty("hibernate.dialect", env.getProperty("hibernate.dialect"));
        hibernateProperties.setProperty("hibernate.cache.use_second_level_cache", "false");
        return hibernateProperties;
    }    
    

}
