package com.dsb.eb2.framework.sessions;

import java.io.Serializable;
import java.util.HashMap;

import javax.servlet.http.HttpSession;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter @Setter @NoArgsConstructor
public class UserSession implements Serializable {

	private static final long serialVersionUID = 4632952984541058406L;
	
	private String sessionID;
	private String custID;
	private HashMap<String, Object> sessionKeyValue = new HashMap<String, Object>();

	public UserSession(HttpSession httpSession) {
		if (httpSession != null)
			this.sessionID = httpSession.getId();
	}
	
	@Override
	public String toString() {
		return "{ SessionID:" + sessionID + ", custID:" + custID + "}";
	}

}
