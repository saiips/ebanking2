package com.dsb.eb2.framework.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.Version;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@MappedSuperclass
@Getter @Setter @NoArgsConstructor
public class Base implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
//    @Id
//    @GeneratedValue(strategy = GenerationType.AUTO)
//    @Column(name = "id", updatable = false, nullable = false)
//    private Long id = null;	

	@Version
	@Column(name="VERSION")	
	@JsonProperty("VERSION")
	private long version;
	
	/* if the field is timestamp map it into timestamp
	@Version
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "VERSION")
	private Date version;
	*/	
	

	protected void copy(final Base source)
    {
        this.version = source.version;
    }	
    
    @Override
    public boolean equals(final Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        if (obj == null)
        {
            return false;
        }
        if (!(obj instanceof Base))
        {
            return false;
        }
        final Base other = (Base) obj;
//        if (this.id != null && other.id != null)
//        {
//            if (this.id != other.id)
//            {
//                return false;
//            }
//        }
        return true;
    }
    
    protected static boolean getBooleanValue(final Boolean value)
    {
        return Boolean.valueOf(String.valueOf(value));
    }    
            
}
