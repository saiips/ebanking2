package com.dsb.eb2.framework.controller;

import com.dsb.eb2.api.model.Customer;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class BaseObject {
	
	private Customer customer;
	

}
