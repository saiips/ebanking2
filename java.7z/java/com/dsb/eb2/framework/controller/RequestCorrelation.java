package com.dsb.eb2.framework.controller;


public class RequestCorrelation {
	
    public static final String CORRELATION_ID_HEADER = "correlationId";

    private static final ThreadLocal<String> id = new ThreadLocal<String>();
    
    private static final ThreadLocal<String> clientID = new ThreadLocal<String>();
    
    private static final ThreadLocal<String> sessionUUID = new ThreadLocal<String>(); 
    

    public static String getId() {
        return id.get();
    }

    public static void setId(String correlationId) {
        id.set(correlationId);
    }

	public static String getClientID() {
		return clientID.get();
	}
    
	public static void setClientID(String ebid) {
		clientID.set(ebid);
	}

	public static String getSessionUUID() {
		return sessionUUID.get();
	}
	
	public static void setSessionUUID(String id) {
		sessionUUID.set(id);
	}	
	

}
