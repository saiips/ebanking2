package com.dsb.eb2.framework.controller;

public abstract class ApiController {
    // resource path 
	public static final String API_PATH = "/api";
    public static final String SSO_PATH = "/sso";
    public static final String PWS_PATH = "/pws";

    public static final String WEBPIN = "/webpin";
    public static final String DAO = "/dao";
    
    // response header
    public static final String X_AUTH_TOKEN = "X-AUTH-TOKEN";
    public static final String CONTENT_TYPE = "Content-Type";
    public static final String CONTENT_TYPE_APPL_JSON = "application/json; charset=UTF-8";
    public static final String AUTHORIZATION = "X-Authorization";
    public static final String REFRESH_AUTHORIZATION = "X-Refresh-Authorization";
    public static final String BEARER = "Bearer ";
    public static final String IS_REFRESH_TOKEN_REQUIRED = "isRefreshTokenRequired";
        
    // request fields on login EBID & Password
    public static final String USERNAME = "username";
    public static final String PASSWORD = "password";
    public static final String PINBLOCK = "pinblock";
    public static final String WEBPIN_CODE = "webpincode";
    public static final String RANDOM_NUMBER = "randomNum";
    public static final String CHECK_SUM = "checkSum";
    public static final String PUBLIC_KEY_INDEX = "publicKeyIndex";
    public static final String TGT = "TGT";
    public static final String JTI = "jti";
    public static final String UUID = "UUID";
    public static final String PBID = "pbid";
    public static final String ENCPIN = "encPin";
    public static final String ATMPIN = "atmPin";
    public static final String ATMNUM = "atmNum";
    public static final String EBID = "ebid";
    
    // hashmap key
    public static final String TOKEN_STATUS = "TOKEN_STATUS";
    public static final String CAS_PROFILE = "CAS_PROFILE";
    
    // token status
    public static final String TOKEN_EXPIRED = "E";
    public static final String TOKEN_INVALID = "I";
    public static final String TOKEN_VALID = "V";
    
    // Session Key
    public static final String USER_SESSION = "USER_SESSION";
    
    // OSB service endpoints
    public static final String GATEWAY_ENDPOINT = "/GatewayService/getData";
    public static final String NF1107_EMSERVICE_ENDPOINT = "/NF1107Service/emsService/emsService";
    
    public static final String AUTHENTICATE_URL = API_PATH + "/authenticate";
    public static final String STUFF_URL = API_PATH + "/stuff";

    // Spring Boot Actuator services
    public static final String AUTOCONFIG_ENDPOINT = "/autoconfig";
    public static final String BEANS_ENDPOINT = "/beans";
    public static final String CONFIGPROPS_ENDPOINT = "/configprops";
    public static final String ENV_ENDPOINT = "/env";
    public static final String MAPPINGS_ENDPOINT = "/mappings";
    public static final String METRICS_ENDPOINT = "/metrics";
    public static final String SHUTDOWN_ENDPOINT = "/shutdown";
    
    public static final String GATEWAY_URL = "http://eb2int01:7001";
    // public static final String GATEWAY_URL = "http://172.23.3.22:7101";
    
    public static final String LANG_PREF_ZH_TW = "zh_TW";
	public static final String LANG_PREF_EN_US = "en_US";
	
	public static final int LANG_PREF_ENGLISH = 0;
	public static final int LANG_PREF_CHINESE = 1;
    
}