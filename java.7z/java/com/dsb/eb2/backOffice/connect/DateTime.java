package com.dsb.eb2.backOffice.connect;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class DateTime {

  public Calendar C;

  public DateTime() {
   C=new GregorianCalendar();
  }

  public String getDay() {
    String si = new String(Integer.toString(C.get(Calendar.DAY_OF_MONTH)));
    String so = _Format.format(si,2,'0','L');
    return so;
  }

  public String getMonth() {
    String si = new String(Integer.toString(C.get(Calendar.MONTH)+1));
    String so = _Format.format(si,2,'0','L');
    return so;
  }


  public String getYear() {
    String si = new String(Integer.toString(C.get(Calendar.YEAR)));
    String so = _Format.format(si,4,'0','R');
    return so;
  }

  /**
    * @return DD-MMM-YYYY
   */
  public String getDateStr() {
    String dd,mm,yy;

    dd = getDay();
    mm = new String("???");
    yy = getYear();
    switch(C.get(Calendar.MONTH)+1) {
       case 1 : mm = new String("JAN"); break;
       case 2 : mm = new String("FEB"); break;
       case 3 : mm = new String("MAR"); break;
       case 4 : mm = new String("APR"); break;
       case 5 : mm = new String("MAY"); break;
       case 6 : mm = new String("JUN"); break;
       case 7 : mm = new String("JUL"); break;
       case 8 : mm = new String("AUG"); break;
       case 9 : mm = new String("SEP"); break;
       case 10: mm = new String("OCT"); break;
       case 11: mm = new String("NOV"); break;
       case 12: mm = new String("DEC"); break;
    }
mm = getMonth();
    return new String(dd+"-"+mm+"-"+yy);
  }

  /**
    * @return YYYYMMDD
   */
  public String getDateStrValue() {
    String dd,mm,yy;

    dd = getDay();
    mm = getMonth();
    yy = getYear();
    return new String(yy+mm+dd);
  }

  public long getTimeInMill() {
    long val=0;
    val += (C.get(Calendar.YEAR)*60*60*60*60*60*100);
    val += (C.get(Calendar.MONTH)*60*60*60*60*100);
    val += (C.get(Calendar.DAY_OF_MONTH)*60*60*60*100);
    val += (C.get(Calendar.HOUR)*60*60*100);
    val += (C.get(Calendar.MINUTE)*60*100);
    val += (C.get(Calendar.SECOND)*100);
    val += (C.get(Calendar.MILLISECOND));
    return val;
  }

  public String getDateTimeString() {
     String YY = _Format.format(Integer.toString(C.get(Calendar.YEAR)),4,'0','R');
     String MM = _Format.format(Integer.toString(C.get(Calendar.MONTH)+1),2,'0','L');
     String DD = _Format.format(Integer.toString(C.get(Calendar.DAY_OF_MONTH)),2,'0','L');
     String hh = _Format.format(Integer.toString(C.get(Calendar.HOUR_OF_DAY)),2,'0','L');
     String mm = _Format.format(Integer.toString(C.get(Calendar.MINUTE)),2,'0','L');
     String ss = _Format.format(Integer.toString(C.get(Calendar.SECOND)),2,'0','L');
     String str = new String(YY+MM+DD+hh+mm+ss);
     return str;
  }

  public static void main(String args[]) {
    DateTime t = new DateTime();

  }
}
