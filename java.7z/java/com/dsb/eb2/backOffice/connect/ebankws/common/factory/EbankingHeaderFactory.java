package com.dsb.eb2.backOffice.connect.ebankws.common.factory;

import com.dsb.eb2.backOffice.connect.ebankws.common.beans.EbankingHeader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class EbankingHeaderFactory {

	private static final DateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
	private EbankingHeader reqHeader = null;
	private String returnCode = "";
	private String returnMessage = "";
	private Date startTime = new Date();
	
	public EbankingHeader getReqHeader() {
		return reqHeader;
	}
	public void setReqHeader(EbankingHeader reqHeader) {
		this.reqHeader = reqHeader;
	}
	public String getReturnCode() {
		return returnCode;
	}
	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public EbankingHeader createInstance() {
		EbankingHeader respHeader = null;
		if(reqHeader == null) {
			respHeader = new EbankingHeader();
		} else {
			respHeader = reqHeader.clone();
		}
		respHeader.setReturnCode(returnCode);
		returnMessage = EbankwsRespCodeDesc.getRespDesc(returnCode);
		respHeader.setReturnMessage(returnMessage);
		Date endTime = new Date();
		respHeader.setElapsedTime(Long.toString(endTime.getTime() - startTime.getTime()));
		respHeader.setTxDateTime(sdf.format(endTime));
		return respHeader;
	}
}
