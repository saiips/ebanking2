package com.dsb.eb2.backOffice.connect.ebankws.updateCIFEmail.beans;

import javax.xml.bind.annotation.XmlRootElement;

import com.dsb.eb2.backOffice.connect.ebankws.common.beans.EbankingHeader;

@XmlRootElement
public class UpdateCIFEmailReq {

	private EbankingHeader ebankingHeader;	//Mandatory:Y	ebankingHeader
	
	private String custID;		//Mandatory:Y	Type:Char(20)	Customer ID Type (Char (2) )+ ID Number(Char (18) )
	private String custName;	//Mandatory:N 	Type:Char(100) 	For action=U
	private String action;		/*Mandatory:Y	Type:Char(1)	U=Update CIF temporary email at eBanking. All previous CIF temporary email at eBanking under the same Cust ID will be deleted. Verification email will be sent to the provided email.
																D=Delete CIF temporary and permanent email at eBanking. No verification email will be sent.*/
	private String eMail;		//Mandatory:N	Type:Char(50)
	private String refNo;		//Mandatory:Y	Type:Char(16) 	Format: XXXDDMMYYNNNNNNN, XXX is the source system name, DDMMYY is system date, and NNNNNNN is the random number.
	private String expiryDate;	//Mandatory:N	Type:Char(8) 	Format: YYYYMMDD For resend verification email, same refNo is used with new expiry date.
	
	public EbankingHeader getEbankingHeader() {
		return ebankingHeader;
	}
	public void setEbankingHeader(EbankingHeader ebankingHeader) {
		this.ebankingHeader = ebankingHeader;
	}
	public String getCustID() {
		return custID;
	}
	public void setCustID(String custID) {
		this.custID = custID;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String geteMail() {
		return eMail;
	}
	public void seteMail(String eMail) {
		this.eMail = eMail;
	}
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	
}
