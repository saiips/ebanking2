package com.dsb.eb2.backOffice.connect.ebankws.updateCIFEmail.services;

import javax.annotation.Resource;
import javax.jws.HandlerChain;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.xml.ws.WebServiceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dsb.eb2.backOffice.connect.ebankws.common.IpRestrictionMod;
import com.dsb.eb2.backOffice.connect.ebankws.common.WebServiceStatusCode;
import com.dsb.eb2.backOffice.connect.ebankws.common.factory.EbankingHeaderFactory;
import com.dsb.eb2.backOffice.connect.ebankws.updateCIFEmail.beans.UpdateCIFEmailReq;
import com.dsb.eb2.backOffice.connect.ebankws.updateCIFEmail.beans.UpdateCIFEmailResp;
import com.dsb.eb2.backOffice.connect.ebankws.updateCIFEmail.facade.UpdateCIFEmailFacade;
import com.dsb.eb2.bankApp.System.exeption.SystemException;

@WebService(serviceName="UpdateCIFEmailService", name="UpdateCIFEmailServicePortType", targetNamespace="http://www.dahsing.com/updateCIFEmail/")
@SOAPBinding(style=SOAPBinding.Style.DOCUMENT, use=SOAPBinding.Use.LITERAL, parameterStyle=SOAPBinding.ParameterStyle.WRAPPED)
@HandlerChain(file="handlers.xml")

public class UpdateCIFEmailService {

	private static Logger log = LoggerFactory.getLogger(UpdateCIFEmailService.class);
	
	@Resource
    private WebServiceContext wsContext;
	
	@WebMethod()
	
	@WebResult(name="updateCIFEmailResp", targetNamespace="http://www.dahsing.com/updateCIFEmail/")
	public UpdateCIFEmailResp updateCIFEmail(@WebParam(name="updateCIFEmailReq", targetNamespace="http://www.dahsing.com/updateCIFEmail/") UpdateCIFEmailReq request)
	{
		log.info("UpdateCIFEmailService.updateCIFEmail starts, request:" + request);
		
		String serversListKey = "ebws_update_cif_email_function_allow_server_list";
		//log.info("UpdateCIFEmailService.updateCIFEmail wsContext=" + wsContext + ", serversListKey=" + SystemConfig.getSystemParameter(serversListKey));
		IpRestrictionMod.checkServer(wsContext, serversListKey);
		
		// create a new factory instance at the start to mark start time
		EbankingHeaderFactory ebhFactory = new EbankingHeaderFactory();
		ebhFactory.setReqHeader(request.getEbankingHeader());
			
		UpdateCIFEmailResp response = new UpdateCIFEmailResp();
		
		String returnCode = null;
		
		try
		{
			response = new UpdateCIFEmailFacade().invoke(request);
			
			returnCode = WebServiceStatusCode.COMMON__SUCCESS;
		}catch(SystemException se)
		{
			returnCode = String.valueOf(se.getErrorCode());
			log.error("UpdateCIFEmailService.updateCIFEmail catch a SystemException:" + se.getMessage() + " | ", se);
		}catch(Exception e)
		{
			returnCode = WebServiceStatusCode.COMMON__SERVICE_ACCESS_DENIED;
			log.error("UpdateCIFEmailService.updateCIFEmail catch a Exception:" + e.getMessage() + " | ", e);
		}
		
		// populate returnCode
		ebhFactory.setReturnCode(returnCode);

		// populate respHeader
		response.setEbankingHeader(ebhFactory.createInstance());
		
		log.info("UpdateCIFEmailService.updateCIFEmail ends, Return Code:" + returnCode);
		
		return response;
	}
}
