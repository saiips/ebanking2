package com.dsb.eb2.backOffice.connect.ebankws.updateCIFEmail.facade;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dsb.eb2.backOffice.connect.ebankws.common.IpRestrictionMod;
import com.dsb.eb2.backOffice.connect.ebankws.common.WebServiceStatusCode;
import com.dsb.eb2.backOffice.connect.ebankws.common.beans.EbankingHeader;
import com.dsb.eb2.backOffice.connect.ebankws.updateCIFEmail.beans.UpdateCIFEmailReq;
import com.dsb.eb2.backOffice.connect.ebankws.updateCIFEmail.beans.UpdateCIFEmailResp;

public class UpdateCIFEmailFacade {

	private static final String UPDATE = "U";
	private static final String DELETE = "D";
	private static final String FUNCTIONNAME = "UpdateCIFEmailFacade";
	
	private static Logger log = LoggerFactory.getLogger(UpdateCIFEmailFacade.class);
	
	public UpdateCIFEmailResp invoke(UpdateCIFEmailReq request)throws Exception
	{
		logInfo("beg.UpdateCIFEmailFacade.invoke the request=[" + request + "]");
		
		try
		{
			EbankingHeader eBankingHeader = request.getEbankingHeader();

			//ebankingHeader
			String bankCode = eBankingHeader.getBankCode();
		    String channelId = eBankingHeader.getChannelId();
		    String serviceVersion = eBankingHeader.getServiceVersion();
		    String txDateTime = eBankingHeader.getTxDateTime();
		    String sysTraceNum = eBankingHeader.getSysTraceNum();
		    String asyncFlag = eBankingHeader.getAsyncFlag();
		    
		    logInfo("eBankingHeader: bankCode=" + bankCode
						    			+ ", channelId=" + channelId
						    			+ ", serviceVersion=" + serviceVersion
						    			+ ", txDateTime=" + txDateTime
						    			+ ", sysTraceNum=" + sysTraceNum
						    			+ ", asyncFlag=" + asyncFlag);
		    
		    //CIFEmailRequest
		    String custID = request.getCustID();
		    String custName = request.getCustName();
			String action = request.getAction();
			String eMail = request.geteMail();
			String refNo = request.getRefNo();
			String expiryDate = request.getExpiryDate();
			logInfo("CIFEmailRequest: custID=" + custID
										+ ", custName=" + custName
						    			+ ", action=" + action
						    			+ ", eMail=" + eMail
						    			+ ", refNo=" + refNo
						    			+ ", expiryDate=" + expiryDate);
			
//			//check Mandatory field
//			if(
//					//head
//					CustPerEmailUtil.isEmpty(bankCode)
//					|| CustPerEmailUtil.isEmpty(channelId)
//					|| CustPerEmailUtil.isEmpty(serviceVersion)
//					|| CustPerEmailUtil.isEmpty(txDateTime)
//					|| CustPerEmailUtil.isEmpty(sysTraceNum)
//					//body
//					|| CustPerEmailUtil.isEmpty(custID)
//					|| CustPerEmailUtil.isEmpty(action)
//					|| CustPerEmailUtil.isEmpty(refNo)
//			)
//			{
//				logInfo("Mandatory input");
//				throw new SystemException( Integer.parseInt(WebServiceStatusCode.INVALID_NUMBER_OF_PARAMETERS));
//			}
//			
//			if(DELETE.equals(action))
//			{
//				try
//				{
//					logInfo(channelId, custID, "## DELETE EBANK DB ##");
//					
//					//log#0003034
//					Date systemDate = Calendar.getInstance().getTime();
//					SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
//					String systemDateStr = sdf.format(systemDate);
//					
//					int count = EmailConsolidationUtil.updatePermanentEmail(custID, "", "", "", systemDateStr);
//					logInfo(channelId, custID, "count=" + count);
//					
//					logInfo(channelId, custID, "## DELETE INSTRUCTION DB ##");
//					CustEmailAddMtce.savePermanentEmailOneToInstr(custID, " ");
//					
//					logInfo(channelId, custID, "## DELETE SUCCESSFUL ##");
//					
//				}catch (Exception e)
//				{
//					throw new SystemException( Integer.parseInt(WebServiceStatusCode.COMMON__DBMS_GENERAL));
//				}
//			}else if(UPDATE.equals(action))
//			{
//				if(EmailConsolidationUtil.isEmpty(custName))
//				{
//					throw new SystemException( Integer.parseInt(WebServiceStatusCode.COMMON__DBMS_GENERAL));
//				}
//				//************ send EMS email ************
//				String returnCode = EmailConsolidationUtil.sendVerifyEmail(""
//																				, custID
//																				, custName
//																				, ""
//																				, eMail
//																				, refNo
//																				, expiryDate
//																				, "");
//				logInfo(channelId, custID, "returnCode=" + returnCode);
//				
//				//************ update E-bank DB ************
//				if(String.valueOf(SystemStatusCode.SSC_NORMAL_EMS_RESPONE).equals(returnCode) )
//				{
//					int count = 0;
//					try
//					{
//						CustEmailAdd custEmail = CustEmailAddMtce.findByCustId(custID);
//						if (custEmail != null)
//						{
//							logInfo(channelId, custID, "## UPDATE EBANK DB ##");
//							count = EmailConsolidationUtil.updateTempEmail(custID, eMail, refNo);
//						}else
//						{
//							logInfo(channelId, custID, "## INSERT EBANK DB ##");
//							CustEmailAdd cea = new CustEmailAdd();
//		                    cea.setCustId(custID);
//		                    cea.setCustName(custName);
//		                    cea.setTempEmail(eMail);
//		                    cea.setReferenceNumber(refNo);
//		                    count = CustEmailAddMtce.add(cea, false);
//						}
//						
//						logInfo(channelId, custID, "count=" + count);
//					}catch (Exception e)
//					{
//						throw new SystemException( Integer.parseInt(WebServiceStatusCode.COMMON__DBMS_GENERAL));
//					}
//				}else
//				{
//					throw new SystemException( Integer.parseInt(returnCode));
//				}
//			}else
//			{
//				throw new SystemException( SystemStatusCode.SSC_UNEXPECTED);
//			}
//			
		}catch (Exception e)
		{
			throw e;
		}
		
		UpdateCIFEmailResp response = new UpdateCIFEmailResp();
		
		return response;
	}
	
	private void logInfo(String logMessage)
	{
		log.info( "[" + FUNCTIONNAME + "]" + " Msg:\"" +  logMessage +"\"");
	}
	
	private void logInfo(String channelId, String custID, String logMessage)
	{
		log.info( "[" + FUNCTIONNAME + "]" + " channelId:\"" + channelId + "\" custID:\"" + custID + "\" Msg:\"" + logMessage+"\"");
	}
}
