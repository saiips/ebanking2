package com.dsb.eb2.backOffice.connect.ebankws.updateCIFEmail.beans;

import javax.xml.bind.annotation.XmlRootElement;

import com.dsb.eb2.backOffice.connect.ebankws.common.beans.EbankingHeader;

@XmlRootElement
public class UpdateCIFEmailResp {

	private EbankingHeader ebankingHeader;

	public EbankingHeader getEbankingHeader() {
		return ebankingHeader;
	}

	public void setEbankingHeader(EbankingHeader ebankingHeader) {
		this.ebankingHeader = ebankingHeader;
	}
	
	
}
