package com.dsb.eb2.backOffice.connect.ebankws.common.factory;

import com.dsb.eb2.backOffice.connect.ebankws.common.WebServiceStatusCode;
import java.util.Map;
import java.util.HashMap;

public class EbankwsRespCodeDesc {
	public static Map<String, String> respCodeDescMap = null;
	static {
		refresh();
	}
	
	public static synchronized void refresh() {
		Map<String, String> map = new HashMap<String, String>();
		map.put(WebServiceStatusCode.COMMON__SUCCESS, "Successful");
		map.put(WebServiceStatusCode.COMMON__UPDATE_SUCCESS, "Update successful");
		map.put(WebServiceStatusCode.COMMON__CUST_ACCT_NOT_FOUND, "Customer account not found");
		map.put(WebServiceStatusCode.COMMON__SERVICE_ACCESS_DENIED, "Service Access is Denied");
		map.put(WebServiceStatusCode.COMMON__DBMS_GENERAL, "Exception found when updating database");
		map.put(WebServiceStatusCode.REGBILLPAY__BILL_COUNT_NOT_MATCH, "Inputted Bill Count and Bill Information do not match");
		map.put(WebServiceStatusCode.REGBILLPAY__INSERT_FAIL_DUPLICATE_RECORD, "Cannot process insert action due to duplicated record");
		map.put(WebServiceStatusCode.REGBILLPAY__BILL_NUM_INVALID, "Invalid Bill Number");
		map.put(WebServiceStatusCode.REGBILLPAY__BP_BILL_TYPE_NOT_PAYABLE, "Bill Type Not Payable");
		map.put(WebServiceStatusCode.REGBILLPAY__BP_TX_LIMIT_EXCEEDED_L, "Bill payment amount is less than the merchant bill payment lowest transaction amount");
		map.put(WebServiceStatusCode.REGBILLPAY__BP_TX_LIMIT_EXCEEDED_U, "Bill payment amount is larger than the merchant bill payment highest transaction amount");
		//SCR-PDM12540 
		map.put(WebServiceStatusCode.REGBILLPAY__FT_TX_LIMIT_EXCEEDED, "Invalid daily transfer limit");
		//SCR-PDM12540-2
		map.put(WebServiceStatusCode.REGBILLPAY_BILL_HRISK_LIMIT_EXCEEDED, "Invalid bill payment high rish daily transfer limit");
		map.put(WebServiceStatusCode.REGBILLPAY_BILL_NHRISK_LIMIT_EXCEEDED, "Invalid bill payment non-high rish daily transfer limit");
		map.put(WebServiceStatusCode.REGBILLPAY_BILL_HRISK_LIMIT_ZERO, "bill payment high rish daily transfer limit cannot be zero");
		map.put(WebServiceStatusCode.REGBILLPAY_BILL_NHRISK_LIMIT_ZERO, "bill payment non-high rish daily transfer limit cannot be zero");
		map.put(WebServiceStatusCode.INBOX_MESSAGE_TEMPLATE_ID_NOT_FOUND, "Inbox Message Template ID not found");
		map.put(WebServiceStatusCode.INVALID_NUMBER_OF_PARAMETERS, "Invalid number of parameters");
		respCodeDescMap = map;
	}
	public static synchronized String getRespDesc(String respCode) {
		String s = respCodeDescMap.get(respCode);
		if(s == null) {
			s = "";
		}
		return s;
	}
}
