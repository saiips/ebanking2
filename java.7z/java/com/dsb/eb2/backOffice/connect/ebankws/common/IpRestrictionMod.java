package com.dsb.eb2.backOffice.connect.ebankws.common;

import javax.servlet.http.HttpServletRequest;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.http.HTTPException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class IpRestrictionMod {

	private static Logger log = LoggerFactory.getLogger(IpRestrictionMod.class);
	public static void checkServer(WebServiceContext wsContext, String serversListKey){
		log.info("IpRestrictionMod.checkServer starts");
		
//		// testing on ip restriction start
//		String servers_list = SystemConfig.getSystemParameter(serversListKey);
//		
//		if(servers_list != null){
//			String[] server_addr = servers_list.split(",");
//		    
//			MessageContext mc = wsContext.getMessageContext();
//			HttpServletRequest req = (HttpServletRequest)mc.get(MessageContext.SERVLET_REQUEST);
//			String sRemoteAddr = req.getRemoteAddr();
//			log.info("sRemoteAddr:"+sRemoteAddr);
//			
//			boolean inServerList = false;
//			for(int i=0; i<server_addr.length;i++){
//				log.info(server_addr[i]);
//				if( sRemoteAddr.startsWith(server_addr[i])) {
//					inServerList = true;
//					break;
//				}
//			}
//			if( !inServerList ) {
//				log.info("Not in List");
//				throw new HTTPException(403);
//			}
//		}else{
//			log.error(serversListKey+" Empty");
//			throw new HTTPException(403);
//		}
//		log.info("after ip restriction");
	}
	public static void main(String[] args){
		//For unit test only
		
	}
}
