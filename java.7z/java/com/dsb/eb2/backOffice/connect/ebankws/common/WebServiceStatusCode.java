package com.dsb.eb2.backOffice.connect.ebankws.common;

public class WebServiceStatusCode {
	public static final String COMMON__SUCCESS = "30000";
	public static final String COMMON__UPDATE_SUCCESS = "30001";
	public static final String COMMON__CUST_ACCT_NOT_FOUND = "31003";
	public static final String COMMON__SERVICE_ACCESS_DENIED = "39999";
	public static final String COMMON__DBMS_GENERAL = "31004";
	
	public static final String REGBILLPAY__BILL_COUNT_NOT_MATCH = "31000";
	public static final String REGBILLPAY__INSERT_FAIL_DUPLICATE_RECORD = "31001";
	public static final String REGBILLPAY__ACTION_VALUE_INVALID = "31002";
	public static final String REGBILLPAY__BILL_NUM_INVALID = "31005";
	public static final String REGBILLPAY__BP_BILL_TYPE_NOT_PAYABLE = "31006";
	public static final String REGBILLPAY__BP_TX_LIMIT_EXCEEDED_L = "31007";
	public static final String REGBILLPAY__BP_TX_LIMIT_EXCEEDED_U = "31008";

	//SCR-PDM12540 
	public static final String REGBILLPAY__FT_TX_LIMIT_EXCEEDED = "31009";
	
	//SCR-PDM12540-2
	public static final String REGBILLPAY_BILL_HRISK_LIMIT_EXCEEDED = "31010";
	public static final String REGBILLPAY_BILL_NHRISK_LIMIT_EXCEEDED = "31011";
	public static final String REGBILLPAY_BILL_HRISK_LIMIT_ZERO = "31012";
	public static final String REGBILLPAY_BILL_NHRISK_LIMIT_ZERO = "31013";
	
	
	public static final String INBOX_MESSAGE_TEMPLATE_ID_NOT_FOUND = "31014";
	public static final String INVALID_NUMBER_OF_PARAMETERS = "31015";
	
	//ITD15008
	public static final String HI_SERVER_COMMON_SUCCESS = "900000";
	
}
