package com.dsb.eb2.backOffice.connect.ebankws.common.beans;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class EbankingHeader implements Cloneable {
    private String bankCode;
    private String channelId;
    private String serviceVersion;
    private String serviceID;
    private String txDateTime;
    private String sysTraceNum;
    private String retriedCount;
    private String asyncFlag;
    private String elapsedTime;
    private String remarks;
    private String returnCode;
    private String returnMessage;
    
	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getServiceVersion() {
		return serviceVersion;
	}
	public void setServiceVersion(String serviceVersion) {
		this.serviceVersion = serviceVersion;
	}
	public String getServiceID() {
		return serviceID;
	}
	public void setServiceID(String serviceID) {
		this.serviceID = serviceID;
	}
	public String getTxDateTime() {
		return txDateTime;
	}
	public void setTxDateTime(String txDateTime) {
		this.txDateTime = txDateTime;
	}
	public String getSysTraceNum() {
		return sysTraceNum;
	}
	public void setSysTraceNum(String sysTraceNum) {
		this.sysTraceNum = sysTraceNum;
	}
	public String getRetriedCount() {
		return retriedCount;
	}
	public void setRetriedCount(String retriedCount) {
		this.retriedCount = retriedCount;
	}
	public String getAsyncFlag() {
		return asyncFlag;
	}
	public void setAsyncFlag(String asyncFlag) {
		this.asyncFlag = asyncFlag;
	}
	public String getElapsedTime() {
		return elapsedTime;
	}
	public void setElapsedTime(String elapsedTime) {
		this.elapsedTime = elapsedTime;
	}
    public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getReturnCode() {
		return returnCode;
	}
	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}
	public String getReturnMessage() {
		return returnMessage;
	}
	public void setReturnMessage(String returnMessage) {
		this.returnMessage = returnMessage;
	}
    public EbankingHeader clone() {
		EbankingHeader eh = new EbankingHeader();
		eh.bankCode=this.bankCode;
		eh.channelId=this.channelId;
		eh.serviceVersion=this.serviceVersion;
		eh.serviceID=this.serviceID;
    	eh.txDateTime=this.txDateTime;
    	eh.sysTraceNum=this.sysTraceNum;
    	eh.retriedCount=this.retriedCount;
    	eh.asyncFlag=this.asyncFlag;
    	eh.elapsedTime=this.elapsedTime;
    	eh.remarks=this.remarks;
    	eh.returnCode=this.returnCode;
    	eh.returnMessage=this.returnMessage;
		return eh;
	}
    
}