package com.dsb.eb2.backOffice.connect;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.logging.LogLevel;
import org.springframework.stereotype.Component;

import com.dsb.eb2.backOffice.connect.emsMsg.EmsMsgFactory;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsMsgUtils;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsRepMsg;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsReqMsg;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmHdr;
import com.dsb.eb2.framework.controller.ApiGateway;
import com.dsb.eb2.framework.log.Loggable;
import com.dsb.eb2.util.IOUtils;
import com.dsb.eb2.util.JSONUtils;

@Component
@Loggable
public class EMSQueueConnector extends ApiGateway
{
	
	private static Logger logger = LoggerFactory.getLogger(EMSQueueConnector.class);
	
	@Loggable(result = false, value = LogLevel.INFO)
    public EmsRepMsg invoke(EmsReqMsg emsReqMsg, FrmData obj) throws Exception
    {
    	return invoke(emsReqMsg, obj, false);
    }
	
	
	/*
	 * 
	 * type:SESSION/DATA
	 */
	
	public EmsRepMsg invoke(EmsReqMsg emsReqMsg, FrmData obj, Boolean fromCache) throws Exception
    {
		
    	EmsRepMsg emsRepMsg = new EmsRepMsg();
    	
    	String serviceID = emsReqMsg.getFrmData().getServiceID();
    	String serviceURL =null;
    	if(serviceID.equals("NF1110")||serviceID.equals("NF1109")) {
          serviceURL = super.getGatewayURL() + "/" + serviceID + "SBProject/emsService/emsService";
	
    	}else {
    		
    	serviceURL = super.getGatewayURL() + "/" + serviceID + "Service/emsService/emsService";
    	}
    	logger.info("Service URL = " + serviceURL);
    	String requestPayload =  JSONUtils.objToJson(emsReqMsg);
    	requestPayload = "{" + 
    			"\"XMLReqMsg\":" 
    			+ requestPayload
    			+ "}";
    	
    	String type = "DATA";
    	if(fromCache)
    	{
    		type = "SESSION";
    	}
		
    	logger.info("requestPayload = " + requestPayload);
    	System.out.println("----------------------------");
    	String responsePayload  = super.doRequest(type, "POST", "OTHERS", "N", null, serviceURL, "POST", requestPayload);
    	logger.info("responsePayload = " + responsePayload);
    	
    	System.out.println(responsePayload);
    	emsRepMsg = EmsMsgUtils.JSONToEmsRepMsg(responsePayload, obj);
    	
    	return emsRepMsg;
    }

	@Loggable(result = false, value = LogLevel.INFO)
    private void setHeader(EmsReqMsg emsReqMsg) throws Exception
    {
        FrmHdr frmHdr = emsReqMsg.getFrmHdr();
        FrmData data = emsReqMsg.getFrmData();
    }

    
    public static String getEmsErrorCode()
    {
        Properties properties = new Properties();
        InputStream in = EMSQueueConnector.class.getResourceAsStream("ems_error_code.properties");
        try
        {
            properties.load(in);
        } catch (IOException e)
        {
            throw new RuntimeException(e);
        } finally
        {
            IOUtils.close(in);
        }
        
        return properties.getProperty("ems.error.code").trim();
    }
    
	public EmsRepMsg getEmsRepMsg(FrmData ReqFrm,FrmData RespFrm) throws Exception {
		 EmsReqMsg emsReqMsg = EmsMsgFactory.createEmsReqMsg(ReqFrm);
		return invoke(emsReqMsg, RespFrm);
	}
}
