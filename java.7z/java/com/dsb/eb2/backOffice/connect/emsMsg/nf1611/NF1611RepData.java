package com.dsb.eb2.backOffice.connect.emsMsg.nf1611;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;


@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"cardNum","seqNum","status","startDate","endDate","priAcctCcy","overseasDailyWithdrawalLimit","atmDailyWithdrawalLimit","lastAction","lastUpdateDate","lastUpdateTime","lastUpdateSourceID","cardExpiryDate"})
public class NF1611RepData extends FrmData 
{
	
	public NF1611RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		
		return "NF1611";
	}

	@JSONField(name="CardNum") 
	private String  cardNum;
	
	@JSONField(name="SeqNum") 
	private String  seqNum;
	
	@JSONField(name="Status") 
	private String  status;
	
	@JSONField(name="StartDate") 
	private String  startDate;
	
	@JSONField(name="EndDate") 
	private String  endDate;
	
	@JSONField(name="PriAcctCcy")
	private String  priAcctCcy;
	
	@JSONField(name="OverseasDailyWithdrawalLimit")
	private String  overseasDailyWithdrawalLimit;
	
	@JSONField(name="AtmDailyWithdrawalLimit")
	private String  atmDailyWithdrawalLimit;
	
	@JSONField(name="LastAction") 
	private String  lastAction;
	
	@JSONField(name="LastUpdateDate")
	private String  lastUpdateDate;
	
	@JSONField(name="LastUpdateTime") 
	private String  lastUpdateTime;
	
	@JSONField(name="LastUpdateSourceID")
	private String  lastUpdateSourceID;
	
	@JSONField(name="CardExpiryDate")
	private String  cardExpiryDate;

	@XmlElement(name = "CardNum")
	public String getCardNum() {
		return cardNum;
	}

	@XmlElement(name = "SeqNum")
	public String getSeqNum() {
		return seqNum;
	}

	@XmlElement(name = "Status")
	public String getStatus() {
		return status;
	}

	@XmlElement(name = "StartDate")
	public String getStartDate() {
		return startDate;
	}

	@XmlElement(name = "EndDate")
	public String getEndDate() {
		return endDate;
	}

	@XmlElement(name = "PriAcctCcy")
	public String getPriAcctCcy() {
		return priAcctCcy;
	}

	@XmlElement(name = "OverseasDailyWithdrawalLimit")
	public String getOverseasDailyWithdrawalLimit() {
		return overseasDailyWithdrawalLimit;
	}

	@XmlElement(name = "AtmDailyWithdrawalLimit")
	public String getAtmDailyWithdrawalLimit() {
		return atmDailyWithdrawalLimit;
	}

	@XmlElement(name = "LastAction")
	public String getLastAction() {
		return lastAction;
	}

	@XmlElement(name = "LastUpdateDate")
	public String getLastUpdateDate() {
		return lastUpdateDate;
	}

	@XmlElement(name = "LastUpdateTime")
	public String getLastUpdateTime() {
		return lastUpdateTime;
	}

	@XmlElement(name = "LastUpdateSourceID")
	public String getLastUpdateSourceID() {
		return lastUpdateSourceID;
	}

	@XmlElement(name = "CardExpiryDate")
	public String getCardExpiryDate() {
		return cardExpiryDate;
	}

	public void setCardNum(String cardNum) {
		this.cardNum = cardNum;
	}

	public void setSeqNum(String seqNum) {
		this.seqNum = seqNum;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public void setPriAcctCcy(String priAcctCcy) {
		this.priAcctCcy = priAcctCcy;
	}

	public void setOverseasDailyWithdrawalLimit(String overseasDailyWithdrawalLimit) {
		this.overseasDailyWithdrawalLimit = overseasDailyWithdrawalLimit;
	}

	public void setAtmDailyWithdrawalLimit(String atmDailyWithdrawalLimit) {
		this.atmDailyWithdrawalLimit = atmDailyWithdrawalLimit;
	}

	public void setLastAction(String lastAction) {
		this.lastAction = lastAction;
	}

	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public void setLastUpdateTime(String lastUpdateTime) {
		this.lastUpdateTime = lastUpdateTime;
	}

	public void setLastUpdateSourceID(String lastUpdateSourceID) {
		this.lastUpdateSourceID = lastUpdateSourceID;
	}

	public void setCardExpiryDate(String cardExpiryDate) {
		this.cardExpiryDate = cardExpiryDate;
	}
	
	


}
