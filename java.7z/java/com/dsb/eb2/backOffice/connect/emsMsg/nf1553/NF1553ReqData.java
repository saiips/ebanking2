package com.dsb.eb2.backOffice.connect.emsMsg.nf1553;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"lastKey","itemsReq"})
public class NF1553ReqData extends FrmData{

	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1553";
	}
	
	public NF1553ReqData() {}

	@JSONField(name="LastKey")
	private String lastKey;
	
	@JSONField(name="ItemsReq")
	private String itemsReq;

    @XmlElement(name = "LastKey")
	public String getLastKey() {
		return lastKey;
	}

	public void setLastKey(String lastKey) {
		this.lastKey = lastKey;
	}

    @XmlElement(name = "ItemsReq")
	public String getItemsReq() {
		return itemsReq;
	}

	public void setItemsReq(String itemsReq) {
		this.itemsReq = itemsReq;
	}
	
	
	
}
