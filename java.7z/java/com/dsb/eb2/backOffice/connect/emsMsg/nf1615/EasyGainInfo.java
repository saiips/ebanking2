package com.dsb.eb2.backOffice.connect.emsMsg.nf1615;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"monthlyInterestPaid","totalInterestPaid","remInterest","paidACName"})
public class EasyGainInfo {

	@JSONField(name="MonthlyInterestPaid")
	private String monthlyInterestPaid;
	
	@JSONField(name="TotalInterestPaid")
	private String totalInterestPaid;
	
	@JSONField(name="RemInterest")
	private String remInterest;
	
	@JSONField(name="PaidACName")
	private String paidACName;

	public EasyGainInfo() {}

    @XmlElement(name = "MonthlyInterestPaid")
	public String getMonthlyInterestPaid() {
		return monthlyInterestPaid;
	}

	public void setMonthlyInterestPaid(String monthlyInterestPaid) {
		this.monthlyInterestPaid = monthlyInterestPaid;
	}

    @XmlElement(name = "TotalInterestPaid")
	public String getTotalInterestPaid() {
		return totalInterestPaid;
	}

	public void setTotalInterestPaid(String totalInterestPaid) {
		this.totalInterestPaid = totalInterestPaid;
	}

    @XmlElement(name = "RemInterest")
	public String getRemInterest() {
		return remInterest;
	}

	public void setRemInterest(String remInterest) {
		this.remInterest = remInterest;
	}

    @XmlElement(name = "PaidACName")
	public String getPaidACName() {
		return paidACName;
	}

	public void setPaidACName(String paidACName) {
		this.paidACName = paidACName;
	}
	
	


}
