package com.dsb.eb2.backOffice.connect.emsMsg.nf2089;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"id","name","nationality","addrCode","addrCountryCode","address","tIN","sharesPercentage"})
public class SubOwnerInfo {
	
	public SubOwnerInfo() {}
	
	
	@JSONField(name="ID") 
	private String id;
	
	@JSONField(name="Name") 
	private String name;
	
	@JSONField(name="Nationality") 
	private String nationality;
	
	@JSONField(name="AddrCode") 
	private String addrCode;
	
	@JSONField(name="AddrCountryCode") 
	private String addrCountryCode;
	
	@JSONField(name="Address") 
	private String address;
	
	@JSONField(name="TIN") 
	private String tIN;
	
	@JSONField(name="SharesPercentage") 
	private String sharesPercentage;

	@XmlElement(name = "ID")
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@XmlElement(name = "Name")
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@XmlElement(name = "Nationality")
	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	@XmlElement(name = "AddrCode")
	public String getAddrCode() {
		return addrCode;
	}

	public void setAddrCode(String addrCode) {
		this.addrCode = addrCode;
	}

	@XmlElement(name = "AddrCountryCode")
	public String getAddrCountryCode() {
		return addrCountryCode;
	}

	public void setAddrCountryCode(String addrCountryCode) {
		this.addrCountryCode = addrCountryCode;
	}

	@XmlElement(name = "Address")
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@XmlElement(name = "TIN")
	public String gettIN() {
		return tIN;
	}

	public void settIN(String tIN) {
		this.tIN = tIN;
	}

	@XmlElement(name = "SharesPercentage")
	public String getSharesPercentage() {
		return sharesPercentage;
	}

	public void setSharesPercentage(String sharesPercentage) {
		this.sharesPercentage = sharesPercentage;
	}
	

	
}



