package com.dsb.eb2.backOffice.connect.emsMsg.nf1653;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;


@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"method","bank","autopayAcc"})
public class AutopayInfo 
{

	public AutopayInfo(){}
	
	@JSONField(name="Method")
	private String method;
	
	@JSONField(name="Bank")
	private String bank;
	
	@JSONField(name="AutopayAcc")
	private String autopayAcc;

	
	@XmlElement(name = "Method")
	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	@XmlElement(name = "Bank")
	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	@XmlElement(name = "AutopayAcc")
	public String getAutopayAcc() {
		return autopayAcc;
	}

	public void setAutopayAcc(String autopayAcc) {
		this.autopayAcc = autopayAcc;
	}

	@Override
	public String toString() {
		return "AutopayInfo [method=" + method + ", bank=" + bank + ", autopayAcc=" + autopayAcc + "]";
	}
	
	
	
	
  
}
