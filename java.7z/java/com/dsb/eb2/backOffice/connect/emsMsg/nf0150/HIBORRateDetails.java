package com.dsb.eb2.backOffice.connect.emsMsg.nf0150;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class HIBORRateDetails
{
	public HIBORRateDetails(){}
	
	@JSONField(name="CurrentRate") 
	private String  currentRate;
	
	@JSONField(name="LastRate") 
	private String  lastRate;
}
