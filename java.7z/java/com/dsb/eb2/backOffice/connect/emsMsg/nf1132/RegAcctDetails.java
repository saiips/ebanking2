package com.dsb.eb2.backOffice.connect.emsMsg.nf1132;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"type","recPartyCode","recPartyAcctNum","payRef","recPartyName","acctName","ACNo","benAcctNum","benAcctNumBankType","benName","dailyLimit","creDate","userId"})
public class RegAcctDetails
{
	public RegAcctDetails(){}
	
	@JSONField(name="Type")
	private String  type;
	
	@JSONField(name="RecPartyCode")
    private String  recPartyCode;
	
	@JSONField(name="RecPartyAcctNum")
	private String  recPartyAcctNum;
	
	@JSONField(name="PayRef") 
	private String  payRef;
	
	@JSONField(name="RecPartyName")
	private String  recPartyName;
	
	@JSONField(name="AcctName") 
	private String  acctName;
	
	@JSONField(name="ACNo") 
	private String  ACNo;
	
	@JSONField(name="BenAcctNum") 
	private String  benAcctNum;
	
	@JSONField(name="BenAcctNumBankType") 
	private String  benAcctNumBankType;
	
	@JSONField(name="BenName") 
	private String  benName;
	
	@JSONField(name="DailyLimit") 
	private String  dailyLimit;
	
	@JSONField(name="CreDate") 
	private String  creDate;
	
	@JSONField(name="UserId") 
	private String  userId;

    @XmlElement(name = "Type")
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

    @XmlElement(name = "RecPartyCode")
	public String getRecPartyCode() {
		return recPartyCode;
	}

	public void setRecPartyCode(String recPartyCode) {
		this.recPartyCode = recPartyCode;
	}

    @XmlElement(name = "RecPartyAcctNum")
	public String getRecPartyAcctNum() {
		return recPartyAcctNum;
	}

	public void setRecPartyAcctNum(String recPartyAcctNum) {
		this.recPartyAcctNum = recPartyAcctNum;
	}

    @XmlElement(name = "PayRef")
	public String getPayRef() {
		return payRef;
	}

	public void setPayRef(String payRef) {
		this.payRef = payRef;
	}

    @XmlElement(name = "RecPartyName")
	public String getRecPartyName() {
		return recPartyName;
	}

	public void setRecPartyName(String recPartyName) {
		this.recPartyName = recPartyName;
	}

    @XmlElement(name = "AcctName")
	public String getAcctName() {
		return acctName;
	}

	public void setAcctName(String acctName) {
		this.acctName = acctName;
	}

    @XmlElement(name = "ACNo")
    public String getACNo() {
		return ACNo;
	}

	public void setACNo(String aCNo) {
		ACNo = aCNo;
	}

    @XmlElement(name = "BenAcctNum")
	public String getBenAcctNum() {
		return benAcctNum;
	}

	

	public void setBenAcctNum(String benAcctNum) {
		this.benAcctNum = benAcctNum;
	}

    @XmlElement(name = "BenAcctNumBankType")
	public String getBenAcctNumBankType() {
		return benAcctNumBankType;
	}

	public void setBenAcctNumBankType(String benAcctNumBankType) {
		this.benAcctNumBankType = benAcctNumBankType;
	}

    @XmlElement(name = "BenName")
	public String getBenName() {
		return benName;
	}

	public void setBenName(String benName) {
		this.benName = benName;
	}

    @XmlElement(name = "DailyLimit")
	public String getDailyLimit() {
		return dailyLimit;
	}

	public void setDailyLimit(String dailyLimit) {
		this.dailyLimit = dailyLimit;
	}

    @XmlElement(name = "CreDate")
	public String getCreDate() {
		return creDate;
	}

	public void setCreDate(String creDate) {
		this.creDate = creDate;
	}

    @XmlElement(name = "UserId")
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}


}
