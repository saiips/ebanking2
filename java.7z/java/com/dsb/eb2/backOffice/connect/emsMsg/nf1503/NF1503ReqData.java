package com.dsb.eb2.backOffice.connect.emsMsg.nf1503;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"acctNum","chqNum","chqCnt","stopChqDate","chqAmt","chgInd","gLBranchCode","gLNum","chgAmt","chqDate"})
public class NF1503ReqData  extends FrmData
{
    
	public NF1503ReqData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1503";
	}
	
	
	@JSONField(name="AcctNum")
	private String acctNum;
	
	@JSONField(name="ChqNum")
	private String chqNum;
	
	@JSONField(name="ChqCnt")
	private String chqCnt;
	
	@JSONField(name="StopChqDate")
	private String stopChqDate;
	
	@JSONField(name="ChqAmt")
	private String chqAmt;
	
	@JSONField(name="ChgInd")
	private String chgInd;
	
	@JSONField(name="GLBranchCode")
	private String gLBranchCode;
	
	@JSONField(name="GLNum")
	private String gLNum;
	
	@JSONField(name="ChgAmt")
	private String chgAmt;
	
	@JSONField(name="ChqDate")
	private String chqDate;

    @XmlElement(name = "AcctNum")
	public String getAcctNum() {
		return acctNum;
	}

	public void setAcctNum(String acctNum) {
		this.acctNum = acctNum;
	}

    @XmlElement(name = "ChqNum")
	public String getChqNum() {
		return chqNum;
	}

	public void setChqNum(String chqNum) {
		this.chqNum = chqNum;
	}

    @XmlElement(name = "ChqCnt")
	public String getChqCnt() {
		return chqCnt;
	}

	public void setChqCnt(String chqCnt) {
		this.chqCnt = chqCnt;
	}

    @XmlElement(name = "StopChqDate")
	public String getStopChqDate() {
		return stopChqDate;
	}

	public void setStopChqDate(String stopChqDate) {
		this.stopChqDate = stopChqDate;
	}

    @XmlElement(name = "ChqAmt")
	public String getChqAmt() {
		return chqAmt;
	}

	public void setChqAmt(String chqAmt) {
		this.chqAmt = chqAmt;
	}

    @XmlElement(name = "ChgInd")
	public String getChgInd() {
		return chgInd;
	}

	public void setChgInd(String chgInd) {
		this.chgInd = chgInd;
	}

    @XmlElement(name = "GLBranchCode")
	public String getgLBranchCode() {
		return gLBranchCode;
	}

	public void setgLBranchCode(String gLBranchCode) {
		this.gLBranchCode = gLBranchCode;
	}

    @XmlElement(name = "GLNum")
	public String getgLNum() {
		return gLNum;
	}

	public void setgLNum(String gLNum) {
		this.gLNum = gLNum;
	}

    @XmlElement(name = "ChgAmt")
	public String getChgAmt() {
		return chgAmt;
	}

	public void setChgAmt(String chgAmt) {
		this.chgAmt = chgAmt;
	}

    @XmlElement(name = "ChqDate")
	public String getChqDate() {
		return chqDate;
	}

	public void setChqDate(String chqDate) {
		this.chqDate = chqDate;
	}
	
}


