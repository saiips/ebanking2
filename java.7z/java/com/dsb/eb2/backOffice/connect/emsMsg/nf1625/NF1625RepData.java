package com.dsb.eb2.backOffice.connect.emsMsg.nf1625;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"hostSeqNum"})
public class NF1625RepData  extends FrmData
{
    
	public NF1625RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1625";
	}
	
	@JSONField(name="HostSeqNum")
	private String hostSeqNum;

    @XmlElement(name = "HostSeqNum")
	public String getHostSeqNum() {
		return hostSeqNum;
	}

	public void setHostSeqNum(String hostSeqNum) {
		this.hostSeqNum = hostSeqNum;
	}
	
	
	
}


