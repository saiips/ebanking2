package com.dsb.eb2.backOffice.connect.emsMsg.fn0005;

import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;
import com.dsb.eb2.backOffice.connect.emsMsg.fn0005.SpotPositionBookingData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class FN0005ReqData extends FrmData
{

	public FN0005ReqData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "FN0005";
	}

	@JSONField(name="TelUserID")
	private String telUserID;
	
	@JSONField(name="DebitAcctNum")
	private String debitAcctNum;
	
	@JSONField(name="DebitCurrency")
	private String debitCurrency;
	
	@JSONField(name="DebitAmt")
	private String debitAmt;
	
	@JSONField(name="DebitExchangeRate")
	private String debitExchangeRate;
	
	@JSONField(name="EntityCode")
	private String entityCode;
	
	@JSONField(name="CcyCode")
	private String ccyCode;
	
	@JSONField(name="PrinAmt")
	private String prinAmt;
	
	@JSONField(name="DepPeriodCode")
	private String depPeriodCode;
	
	@JSONField(name="DepPeriod")
	private String depPeriod;
	
	@JSONField(name="IntRate")
	private String intRate;
	
	@JSONField(name="IntRateMarkup")
	private String intRateMarkup;
	
	@JSONField(name="CreditExchangeRate")
	private String creditExchangeRate;
	
	@JSONField(name="JointName1")
	private String jointName1;
	
	@JSONField(name="JointName2")
	private String jointName2;
	
	@JSONField(name="JointShortName")
	private String jointShortName;
	
	@JSONField(name="JointNameCifId1")
	private String jointNameCifId1;
	
	@JSONField(name="JointNameCifId2")
	private String jointNameCifId2;
	
	@JSONField(name="JointNameCifId3")
	private String jointNameCifId3;
	
	@JSONField(name="JointNameCifId4")
	private String jointNameCifId4;
	
	@JSONField(name="JointNameCifId5")
	private String jointNameCifId5;
	
	@JSONField(name="StaffProcessFlag")
	private String staffProcessFlag;
	
	@JSONField(name="HiborLiborRate")
	private String hiborLiborRate;
	
	@JSONField(name="BoardRate")
	private String boardRate;
	
	@JSONField(name="AutoRenewalInstData")
	private List<AutoRenewalInstData> autoRenewalInstData;
	
	@JSONField(name="SpotPositionBookingData")
	private List <SpotPositionBookingData> spotPositionBookingData;
	
	@JSONField(name="DebitExRatesT1")
	private List <DebitExRatesT1> debitExRatesT1;
	
	@JSONField(name="CreditExRatesT1")
	private List <CreditExRatesT1> creditExRatesT1;
	
	@JSONField(name="DebitExRatesT2")
	private List <DebitExRatesT2> debitExRatesT2;
	
	@JSONField(name="CreditExRatesT2")
	private List <CreditExRatesT2> creditExRatesT2;

}
