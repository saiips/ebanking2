package com.dsb.eb2.backOffice.connect.emsMsg.nf1121;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"accountNumber","acctOwnerCount","acctOwners","emailFaxIndFlag",
				"acctOfficerCode","acctOfficerSubCode","acctOfficerName","acctOfficerBusinessUnit"})
public class  NF1121RepData extends FrmData
{
    
	public NF1121RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1121";
	}
	
	@JSONField(name="AccountNumber")
	private String accountNumber;
	
	@JSONField(name="AcctOwnerCount")
	private String acctOwnerCount;
	
	@JSONField(name="AcctOwners")
	private List <AcctOwners> acctOwners;
	
	@JSONField(name="EmailFaxIndFlag")
	private String emailFaxIndFlag;
	
	@JSONField(name="AcctOfficerCode")
	private String acctOfficerCode;
	
	@JSONField(name="AcctOfficerSubCode")
	private String acctOfficerSubCode;
	
	@JSONField(name="AcctOfficerName")
	private String acctOfficerName;
	
	@JSONField(name="AcctOfficerBusinessUnit")
	private String acctOfficerBusinessUnit;

	
	@XmlElement(name="AccountNumber")
	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	@XmlElement(name="AcctOwnerCount")
	public String getAcctOwnerCount() {
		return acctOwnerCount;
	}

	public void setAcctOwnerCount(String acctOwnerCount) {
		this.acctOwnerCount = acctOwnerCount;
	}

	@XmlElement(name="AcctOwners")
	public List<AcctOwners> getAcctOwners() {
		return acctOwners;
	}

	public void setAcctOwners(List<AcctOwners> acctOwners) {
		this.acctOwners = acctOwners;
	}

	@XmlElement(name="EmailFaxIndFlag")
	public String getEmailFaxIndFlag() {
		return emailFaxIndFlag;
	}

	public void setEmailFaxIndFlag(String emailFaxIndFlag) {
		this.emailFaxIndFlag = emailFaxIndFlag;
	}

	@XmlElement(name="AcctOfficerCode")
	public String getAcctOfficerCode() {
		return acctOfficerCode;
	}

	public void setAcctOfficerCode(String acctOfficerCode) {
		this.acctOfficerCode = acctOfficerCode;
	}

	@XmlElement(name="AcctOfficerSubCode")
	public String getAcctOfficerSubCode() {
		return acctOfficerSubCode;
	}

	public void setAcctOfficerSubCode(String acctOfficerSubCode) {
		this.acctOfficerSubCode = acctOfficerSubCode;
	}

	@XmlElement(name="AcctOfficerName")
	public String getAcctOfficerName() {
		return acctOfficerName;
	}

	public void setAcctOfficerName(String acctOfficerName) {
		this.acctOfficerName = acctOfficerName;
	}

	@XmlElement(name="AcctOfficerBusinessUnit")
	public String getAcctOfficerBusinessUnit() {
		return acctOfficerBusinessUnit;
	}

	public void setAcctOfficerBusinessUnit(String acctOfficerBusinessUnit) {
		this.acctOfficerBusinessUnit = acctOfficerBusinessUnit;
	}
	

	
}