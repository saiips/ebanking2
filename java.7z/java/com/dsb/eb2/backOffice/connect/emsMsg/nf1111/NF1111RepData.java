package com.dsb.eb2.backOffice.connect.emsMsg.nf1111;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1107.AcctDetails;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class NF1111RepData extends FrmData {

	public NF1111RepData() {
	}

	@JSONField(serialize = false)
	@Override
	public String getServiceID() {

		return "NF1111";
	}

	@JSONField(name = "AccountNumber")
	private String accountNumber;

	@JSONField(name = "LastKey")
	private String lastKey;

	@JSONField(name = "MoreItemsIndicator")
	private String moreItemsIndicator;

	@JSONField(name = "NumOfItems")
	private String numOfItems;

	@JSONField(name = "TxDetails")
	private List<TxDetail> txDetails;


	@Override
	public String toString() {
		return "NF1111RepData [accountNumber=" + accountNumber + ", lastKey=" + lastKey + ", moreItemsIndicator="
				+ moreItemsIndicator + ", numOfItems=" + numOfItems + ", txDetails=" + txDetails + "]";
	}
	

	
}
