package com.dsb.eb2.backOffice.connect.emsMsg.nf1615;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * AutoRenewalInformation
 *
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"autoRenewalPeriod","autoRenewalPeriodCode","typeName","interestRateMarkup","principalAmountToBeAdjusted","settlementAccountNumber"})
public class AutoRenewalInfo 
{
	public AutoRenewalInfo(){}

	@JSONField(name="AutoRenewalPeriod")
	private String autoRenewalPeriod;
	
	@JSONField(name="AutoRenewalPeriodCode")
	private String autoRenewalPeriodCode;
	
	@JSONField(name="TypeName")
	private String typeName;
	
	@JSONField(name="InterestRateMarkup")
	private String interestRateMarkup;
	
	@JSONField(name="PrincipalAmountToBeAdjusted")
	private String principalAmountToBeAdjusted;
	
	@JSONField(name="SettlementAccountNumber")
	private String settlementAccountNumber;

    @XmlElement(name = "AutoRenewalPeriod")
	public String getAutoRenewalPeriod() {
		return autoRenewalPeriod;
	}

	public void setAutoRenewalPeriod(String autoRenewalPeriod) {
		this.autoRenewalPeriod = autoRenewalPeriod;
	}

    @XmlElement(name = "AutoRenewalPeriodCode")
	public String getAutoRenewalPeriodCode() {
		return autoRenewalPeriodCode;
	}

	public void setAutoRenewalPeriodCode(String autoRenewalPeriodCode) {
		this.autoRenewalPeriodCode = autoRenewalPeriodCode;
	}

    @XmlElement(name = "TypeName")
	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

    @XmlElement(name = "InterestRateMarkup")
	public String getInterestRateMarkup() {
		return interestRateMarkup;
	}

	public void setInterestRateMarkup(String interestRateMarkup) {
		this.interestRateMarkup = interestRateMarkup;
	}

    @XmlElement(name = "PrincipalAmountToBeAdjusted")
	public String getPrincipalAmountToBeAdjusted() {
		return principalAmountToBeAdjusted;
	}

	public void setPrincipalAmountToBeAdjusted(String principalAmountToBeAdjusted) {
		this.principalAmountToBeAdjusted = principalAmountToBeAdjusted;
	}

    @XmlElement(name = "SettlementAccountNumber")
	public String getSettlementAccountNumber() {
		return settlementAccountNumber;
	}

	public void setSettlementAccountNumber(String settlementAccountNumber) {
		this.settlementAccountNumber = settlementAccountNumber;
	}
	
	


}
