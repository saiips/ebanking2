package com.dsb.eb2.backOffice.connect.emsMsg.nf1615;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"totalPrincipalPaid","totalInterestEarned","contractInterest","pastDueIntCallRate","pastDueIntContractRate","prematureIntCallRate","prematureIntContractRate","totalWithdrawal"})
public class WithdrawalInfo {

	public  WithdrawalInfo() {}
	
	@JSONField(name="TotalPrincipalPaid")
	private String totalPrincipalPaid;
	
	@JSONField(name="TotalInterestEarned")
	private String totalInterestEarned;
	
	@JSONField(name="ContractInterest")
	private String contractInterest;
	
	@JSONField(name="PastDueIntCallRate")
	private String pastDueIntCallRate;
	
	@JSONField(name="PastDueIntContractRate")
	private String pastDueIntContractRate;
	
	@JSONField(name="PrematureIntCallRate")
	private String prematureIntCallRate;
	
	@JSONField(name="PrematureIntContractRate")
	private String prematureIntContractRate;
	
	@JSONField(name="totalWithdrawal")
	private String totalWithdrawal;

    @XmlElement(name = "TotalPrincipalPaid")
	public String getTotalPrincipalPaid() {
		return totalPrincipalPaid;
	}

	public void setTotalPrincipalPaid(String totalPrincipalPaid) {
		this.totalPrincipalPaid = totalPrincipalPaid;
	}

    @XmlElement(name = "TotalInterestEarned")
	public String getTotalInterestEarned() {
		return totalInterestEarned;
	}

	public void setTotalInterestEarned(String totalInterestEarned) {
		this.totalInterestEarned = totalInterestEarned;
	}

    @XmlElement(name = "ContractInterest")
	public String getContractInterest() {
		return contractInterest;
	}

	public void setContractInterest(String contractInterest) {
		this.contractInterest = contractInterest;
	}

    @XmlElement(name = "PastDueIntCallRate")
	public String getPastDueIntCallRate() {
		return pastDueIntCallRate;
	}

	public void setPastDueIntCallRate(String pastDueIntCallRate) {
		this.pastDueIntCallRate = pastDueIntCallRate;
	}

    @XmlElement(name = "PastDueIntContractRate")
	public String getPastDueIntContractRate() {
		return pastDueIntContractRate;
	}

	public void setPastDueIntContractRate(String pastDueIntContractRate) {
		this.pastDueIntContractRate = pastDueIntContractRate;
	}

    @XmlElement(name = "PrematureIntCallRate")
	public String getPrematureIntCallRate() {
		return prematureIntCallRate;
	}

	public void setPrematureIntCallRate(String prematureIntCallRate) {
		this.prematureIntCallRate = prematureIntCallRate;
	}

    @XmlElement(name = "PrematureIntContractRate")
	public String getPrematureIntContractRate() {
		return prematureIntContractRate;
	}

	public void setPrematureIntContractRate(String prematureIntContractRate) {
		this.prematureIntContractRate = prematureIntContractRate;
	}

    @XmlElement(name = "TotalWithdrawal")
	public String getTotalWithdrawal() {
		return totalWithdrawal;
	}

	public void setTotalWithdrawal(String totalWithdrawal) {
		this.totalWithdrawal = totalWithdrawal;
	}
	
	


}
