package com.dsb.eb2.backOffice.connect.emsMsg.nf1112;
import javax.xml.bind.annotation.XmlElement;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class GuarantorInformation 
{

	public GuarantorInformation(){}
	
	@JSONField(name="CustomerName") 
	private String customerName;
	
	@JSONField(name="HomeAddressLine1") 
	private String homeAddressLine1;
	
	@JSONField(name="HomeAddressLine2") 
	private String homeAddressLine2;
	
	@JSONField(name="HomeAddressLine3") 
	private String homeAddressLine3;
	
	@JSONField(name="HomeAddressLine4") 
	private String homeAddressLine4;
	
	@JSONField(name="HomeTelephoneNumber") 
	private String homeTelephoneNumber;
	
	@JSONField(name="MobileNumber") 
	private String mobileNumber;
	
	@JSONField(name="EmployerName") 
	private String employerName;
	
	@JSONField(name="OfficeAddressLine1") 
	private String officeAddressLine1;
	
	@JSONField(name="OfficeAddressLine2") 
	private String officeAddressLine2;
	
	@JSONField(name="OfficeAddressLine3")
	private String officeAddressLine3;
	
	@JSONField(name="OfficeAddressLine4")
	private String officeAddressLine4;
	
	@JSONField(name="OfficeTelephoneNumber") 
	private String officeTelephoneNumber;
	
	@JSONField(name="GuarantorId") 
	private String guarantorId;
	
	@JSONField(name="Relation")
	private String relation;
	
	@JSONField(name="Sex")
	private String sex;
	
	@JSONField(name="DateOfBirth") 
	private String dateOfBirth;

}
