package com.dsb.eb2.backOffice.connect.emsMsg.nf1615;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"customerId","title","customerName","indicator"})
public class AccountOwnerInfo {
	
	private AccountOwnerInfo() {}
	
	@JSONField(name="CustomerId")
	private String customerId;
	
	@JSONField(name="Title")
	private String title;
	
	@JSONField(name="CustomerName")
	private String customerName;
	
	@JSONField(name="Indicator")
	private String indicator;

	@XmlElement(name = "CustomerId")
	public String getCustomerId() {
		return customerId;
	}

	@XmlElement(name = "Title")
	public String getTitle() {
		return title;
	}

	@XmlElement(name = "CustomerName")
	public String getCustomerName() {
		return customerName;
	}

	@XmlElement(name = "Indicator")
	public String getIndicator() {
		return indicator;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public void setIndicator(String indicator) {
		this.indicator = indicator;
	}
	
	
	

}
