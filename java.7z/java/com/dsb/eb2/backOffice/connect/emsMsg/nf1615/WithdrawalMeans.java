package com.dsb.eb2.backOffice.connect.emsMsg.nf1615;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"origCCY","origCashAmount","origTransferAmount","origTransferAccountNumber","origChequeAmount","origChequeNumber","origOtherAmount","origOtherRemark","hKDCashAmount","hKDCashExchangeRate","hKDTransferAmount","hKDTransferExchangeRate","hKDTransferAccount","hKDChequeAmount","hKDChequeExchangeRate","HKDChequeNumber","hKDOtherAmount","hKDOtherExchangeRate","hKDOtherRemarks"})
public class WithdrawalMeans {

	public  WithdrawalMeans() {}
	@JSONField(name="OrigCCY")
	private String origCCY;
	
	@JSONField(name="OrigCashAmount")
	private String origCashAmount;
	
	@JSONField(name="OrigTransferAmount")
	private String origTransferAmount;
	
	@JSONField(name="OrigTransferAccountNumber")
	private String origTransferAccountNumber;
	
	@JSONField(name="OrigChequeAmount")
	private String origChequeAmount;
	
	@JSONField(name="OrigChequeNumber")
	private String origChequeNumber;
	
	@JSONField(name="OrigOtherAmount")
	private String origOtherAmount;
	
	@JSONField(name="OrigOtherRemark")
	private String origOtherRemark;
	
	@JSONField(name="HKDCashAmount")
	private String hKDCashAmount;
	
	@JSONField(name="HKDCashExchangeRate")
	private String hKDCashExchangeRate;
	
	@JSONField(name="HKDTransferAmount")
	private String hKDTransferAmount;
	
	@JSONField(name="HKDTransferExchangeRate")
	private String hKDTransferExchangeRate;
	
	@JSONField(name="HKDTransferAccount")
	private String hKDTransferAccount;
	
	@JSONField(name="HKDChequeAmount")
	private String hKDChequeAmount;
	
	@JSONField(name="HKDChequeExchangeRate")
	private String hKDChequeExchangeRate;
	
	@JSONField(name="HKDChequeNumber")
	private String HKDChequeNumber;
	
	@JSONField(name="HKDOtherAmount")
	private String hKDOtherAmount;
	
	@JSONField(name="HKDOtherExchangeRate")
	private String hKDOtherExchangeRate;
	
	@JSONField(name="HKDOtherRemarks")
	private String hKDOtherRemarks;

    @XmlElement(name = "OrigCCY")
	public String getOrigCCY() {
		return origCCY;
	}

	public void setOrigCCY(String origCCY) {
		this.origCCY = origCCY;
	}

    @XmlElement(name = "OrigCashAmount")
	public String getOrigCashAmount() {
		return origCashAmount;
	}

	public void setOrigCashAmount(String origCashAmount) {
		this.origCashAmount = origCashAmount;
	}

    @XmlElement(name = "OrigTransferAmount")
	public String getOrigTransferAmount() {
		return origTransferAmount;
	}

	public void setOrigTransferAmount(String origTransferAmount) {
		this.origTransferAmount = origTransferAmount;
	}

    @XmlElement(name = "OrigTransferAccountNumber")
	public String getOrigTransferAccountNumber() {
		return origTransferAccountNumber;
	}

	public void setOrigTransferAccountNumber(String origTransferAccountNumber) {
		this.origTransferAccountNumber = origTransferAccountNumber;
	}

    @XmlElement(name = "OrigChequeAmount")
	public String getOrigChequeAmount() {
		return origChequeAmount;
	}

	public void setOrigChequeAmount(String origChequeAmount) {
		this.origChequeAmount = origChequeAmount;
	}

    @XmlElement(name = "OrigChequeNumber")
	public String getOrigChequeNumber() {
		return origChequeNumber;
	}

	public void setOrigChequeNumber(String origChequeNumber) {
		this.origChequeNumber = origChequeNumber;
	}

    @XmlElement(name = "OrigOtherAmount")
	public String getOrigOtherAmount() {
		return origOtherAmount;
	}

	public void setOrigOtherAmount(String origOtherAmount) {
		this.origOtherAmount = origOtherAmount;
	}

    @XmlElement(name = "OrigOtherRemark")
	public String getOrigOtherRemark() {
		return origOtherRemark;
	}

	public void setOrigOtherRemark(String origOtherRemark) {
		this.origOtherRemark = origOtherRemark;
	}

    @XmlElement(name = "HKDCashAmount")
	public String gethKDCashAmount() {
		return hKDCashAmount;
	}

	public void sethKDCashAmount(String hKDCashAmount) {
		this.hKDCashAmount = hKDCashAmount;
	}

    @XmlElement(name = "HKDCashExchangeRate")
	public String gethKDCashExchangeRate() {
		return hKDCashExchangeRate;
	}

	public void sethKDCashExchangeRate(String hKDCashExchangeRate) {
		this.hKDCashExchangeRate = hKDCashExchangeRate;
	}

    @XmlElement(name = "HKDTransferAmount")
	public String gethKDTransferAmount() {
		return hKDTransferAmount;
	}

	public void sethKDTransferAmount(String hKDTransferAmount) {
		this.hKDTransferAmount = hKDTransferAmount;
	}

    @XmlElement(name = "HKDTransferExchangeRate")
	public String gethKDTransferExchangeRate() {
		return hKDTransferExchangeRate;
	}

	public void sethKDTransferExchangeRate(String hKDTransferExchangeRate) {
		this.hKDTransferExchangeRate = hKDTransferExchangeRate;
	}

    @XmlElement(name = "HKDTransferAccount")
	public String gethKDTransferAccount() {
		return hKDTransferAccount;
	}

	public void sethKDTransferAccount(String hKDTransferAccount) {
		this.hKDTransferAccount = hKDTransferAccount;
	}

    @XmlElement(name = "HKDChequeAmount")
	public String gethKDChequeAmount() {
		return hKDChequeAmount;
	}

	public void sethKDChequeAmount(String hKDChequeAmount) {
		this.hKDChequeAmount = hKDChequeAmount;
	}

    @XmlElement(name = "HKDChequeExchangeRate")
	public String gethKDChequeExchangeRate() {
		return hKDChequeExchangeRate;
	}

	public void sethKDChequeExchangeRate(String hKDChequeExchangeRate) {
		this.hKDChequeExchangeRate = hKDChequeExchangeRate;
	}

    @XmlElement(name = "HKDChequeNumber")
	public String getHKDChequeNumber() {
		return HKDChequeNumber;
	}

	public void setHKDChequeNumber(String hKDChequeNumber) {
		HKDChequeNumber = hKDChequeNumber;
	}

    @XmlElement(name = "HKDOtherAmount")
	public String gethKDOtherAmount() {
		return hKDOtherAmount;
	}

	public void sethKDOtherAmount(String hKDOtherAmount) {
		this.hKDOtherAmount = hKDOtherAmount;
	}

    @XmlElement(name = "HKDOtherExchangeRate")
	public String gethKDOtherExchangeRate() {
		return hKDOtherExchangeRate;
	}

	public void sethKDOtherExchangeRate(String hKDOtherExchangeRate) {
		this.hKDOtherExchangeRate = hKDOtherExchangeRate;
	}

    @XmlElement(name = "HKDOtherRemarks")
	public String gethKDOtherRemarks() {
		return hKDOtherRemarks;
	}

	public void sethKDOtherRemarks(String hKDOtherRemarks) {
		this.hKDOtherRemarks = hKDOtherRemarks;
	}
	
	
	
	


}
