package com.dsb.eb2.backOffice.connect.emsMsg.fn0005;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class CreditExRatesT2 {
	private  CreditExRatesT2() {}

	@JSONField(name="PreferredRate")
	private String preferredRate;

	@JSONField(name="MinProfitRate")
	private String minProfitRate;

	@JSONField(name="CostRate")
	private String costRate;
}
