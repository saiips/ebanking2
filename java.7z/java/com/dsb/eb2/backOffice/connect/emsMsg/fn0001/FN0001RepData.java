package com.dsb.eb2.backOffice.connect.emsMsg.fn0001;


import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class FN0001RepData extends FrmData 
{

	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "FN0001";
	}

	public FN0001RepData(){}

	@JSONField(name="DebitAcctNum")
	private String debitAcctNum;
	
	@JSONField(name="CreditAcctNum")
	private String creditAcctNum;
	
	@JSONField(name="HostTxnSeqNum1")
	private String hostTxnSeqNum1;
	
	@JSONField(name="HostTxnSeqNum2")
	private String hostTxnSeqNum2;
	
	@JSONField(name="Deviation")
	private String deviation;
	
	@JSONField(name="DebitAmt")
	private String debitAmt;
	
	@JSONField(name="DebitExchangeRate")
	private String debitExchangeRate;
	
	@JSONField(name="CreditAmt")
	private String creditAmt;
	
	@JSONField(name="CreditExchangeRate")
	private String creditExchangeRate;
	
	@JSONField(name="DealNum1")
	private String dealNum1;
	
	@JSONField(name="DealNum2")
	private String dealNum2;
	
}
