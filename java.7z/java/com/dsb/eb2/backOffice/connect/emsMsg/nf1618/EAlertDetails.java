package com.dsb.eb2.backOffice.connect.emsMsg.nf1618;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Setter @Getter
public class EAlertDetails {

	@JSONField(name="Service")
	private String service;
	
	@JSONField(name="Type")
	private String type;
	
	@JSONField(name="OptInFlag")
	private String optInFlag;
}
