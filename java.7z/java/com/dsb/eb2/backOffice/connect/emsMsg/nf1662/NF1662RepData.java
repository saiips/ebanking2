package com.dsb.eb2.backOffice.connect.emsMsg.nf1662;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = { "accountNumber",  "lastKey","moreItemsIndicator","noOfItems","remittanceDetails"})
public class NF1662RepData
    extends FrmData
{
	
	@JSONField(name="AccountNumber")
    private String accountNumber ;

	@JSONField(name="LastKey")
    private String lastKey ;

	@JSONField(name="MoreItemsIndicator")
    private String moreItemsIndicator ;

	@JSONField(name="NoOfItems")
    private String noOfItems ;
    
	@JSONField(name="RemittanceDetails")
    private List<RemittanceDetails> remittanceDetails;

    @Override
    public String getServiceID()
    {
        return "NF1662";
    }

    @XmlElement(name = "AccountNumber")
	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	@XmlElement(name = "LastKey")
	public String getLastKey() {
		return lastKey;
	}

	public void setLastKey(String lastKey) {
		this.lastKey = lastKey;
	}

	@XmlElement(name = "MoreItemsIndicator")
	public String getMoreItemsIndicator() {
		return moreItemsIndicator;
	}

	public void setMoreItemsIndicator(String moreItemsIndicator) {
		this.moreItemsIndicator = moreItemsIndicator;
	}

   @XmlElement(name = "NoOfItems")
	public String getNoOfItems() {
		return noOfItems;
	}

	public void setNoOfItems(String noOfItems) {
		this.noOfItems = noOfItems;
	}

	
	@XmlElement(name = "RemittanceDetails")
	public List<RemittanceDetails> getRemittanceDetails() {
		return remittanceDetails;
	}

	public void setRemittanceDetails(List<RemittanceDetails> remittanceDetails) {
		this.remittanceDetails = remittanceDetails;
	}


  
    

}
