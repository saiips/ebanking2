package com.dsb.eb2.backOffice.connect.emsMsg.nf2089;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"systemCode","acctRef"})
public class AcctRefKey {
	
	public AcctRefKey() {}
	
	
	@JSONField(name="SystemCode")
	private String systemCode;
	
	@JSONField(name="AcctRef")
	private String acctRef;

	@XmlElement(name = "SystemCode")
	public String getSystemCode() {
		return systemCode;
	}

	public void setSystemCode(String systemCode) {
		this.systemCode = systemCode;
	}

	@XmlElement(name = "AcctRef")
	public String getAcctRef() {
		return acctRef;
	}

	public void setAcctRef(String acctRef) {
		this.acctRef = acctRef;
	}
	
	
}



