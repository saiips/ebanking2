package com.dsb.eb2.backOffice.connect.emsMsg.nf2089;

import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlAccessType;



@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"RefNum","UserCheck","StatusCode","Chapter4StatusCode","SpecialClosedReason",
		"CancelReason","OutstandingInd","FollowupLetterStatus","FirstFollowUpLetterIssueDate",
		"FirstFollowUpReminderLetterIssueDate","SecondFollowUpReminderLetterIssueDate",
		"FinalFollowUpLetterIssueDate","reasonCodeDetails","assoAcctDetails","indiciaDetails",
		"suppDocDetails","respPartyDetails","subOwnerDetails","CreationDate","UpdDate","CompDate",
		"CheckDate","CreateUserID","LastUpdUserID","Remark","Type","Chapter4StatusCode2"})
public class NF2089RepData  extends FrmData
{
    
	public NF2089RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF2089";
	}
	
	@JSONField(name="RefNum") 
	private String RefNum;
	
	@JSONField(name="UserCheck") 
	private String UserCheck;
	
	@JSONField(name="StatusCode") 
	private String StatusCode;
	
	@JSONField(name="Chapter4StatusCode") 
	private String Chapter4StatusCode;
	
	@JSONField(name="SpecialClosedReason") 
	private String SpecialClosedReason;
	
	@JSONField(name="CancelReason") 
	private String CancelReason;
	
	@JSONField(name="OutstandingInd") 
	private String OutstandingInd;
	
	@JSONField(name="FollowupLetterStatus") 
	private String FollowupLetterStatus;
	
	@JSONField(name="FirstFollowUpLetterIssueDate") 
	private String FirstFollowUpLetterIssueDate;
	
	@JSONField(name="FirstFollowUpReminderLetterIssueDate") 
	private String FirstFollowUpReminderLetterIssueDate;
	
	@JSONField(name="SecondFollowUpReminderLetterIssueDate") 
	private String SecondFollowUpReminderLetterIssueDate;
	
	@JSONField(name="FinalFollowUpLetterIssueDate") 
	private String FinalFollowUpLetterIssueDate;
	
	@JSONField(name="ReasonCodeDetails")
	private List<ReasonCodeDetails> reasonCodeDetails;
	
	@JSONField(name="AssoAcctDetails")
	private List<AssoAcctDetails> assoAcctDetails;
	
	@JSONField(name="IndiciaDetails")
	private List<IndiciaDetails> indiciaDetails;
	
	@JSONField(name="SuppDocDetails")
	private List<SuppDocDetails> suppDocDetails;
	
	@JSONField(name="RespPartyDetails")
	private List<RespPartyDetails> respPartyDetails;
	
	@JSONField(name="SubOwnerDetails")
	private List<SubOwnerDetails> subOwnerDetails;

	@JSONField(name="CreationDate") 
	private String CreationDate;
	
	@JSONField(name="UpdDate") 
	private String UpdDate;
	
	@JSONField(name="CompDate") 
	private String CompDate;
	
	@JSONField(name="CheckDate") 
	private String CheckDate;
	
	@JSONField(name="CreateUserID") 
	private String CreateUserID;
	
	@JSONField(name="LastUpdUserID") 
	private String LastUpdUserID;
	
	@JSONField(name="Remark") 
	private String Remark;
	
	@JSONField(name="Type") 
	private String Type;
	
	@JSONField(name="Chapter4StatusCode2") 
	private String Chapter4StatusCode2;

    @XmlElement(name = "RefNum")
	public String getRefNum() {
		return RefNum;
	}

	public void setRefNum(String refNum) {
		RefNum = refNum;
	}

    @XmlElement(name = "UserCheck")
	public String getUserCheck() {
		return UserCheck;
	}

	public void setUserCheck(String userCheck) {
		UserCheck = userCheck;
	}

    @XmlElement(name = "StatusCode")
	public String getStatusCode() {
		return StatusCode;
	}

	public void setStatusCode(String statusCode) {
		StatusCode = statusCode;
	}

    @XmlElement(name = "Chapter4StatusCode")
	public String getChapter4StatusCode() {
		return Chapter4StatusCode;
	}

	public void setChapter4StatusCode(String chapter4StatusCode) {
		Chapter4StatusCode = chapter4StatusCode;
	}

    @XmlElement(name = "SpecialClosedReason")
	public String getSpecialClosedReason() {
		return SpecialClosedReason;
	}

	public void setSpecialClosedReason(String specialClosedReason) {
		SpecialClosedReason = specialClosedReason;
	}

    @XmlElement(name = "CancelReason")
	public String getCancelReason() {
		return CancelReason;
	}

	public void setCancelReason(String cancelReason) {
		CancelReason = cancelReason;
	}

    @XmlElement(name = "OutstandingInd")
	public String getOutstandingInd() {
		return OutstandingInd;
	}

	public void setOutstandingInd(String outstandingInd) {
		OutstandingInd = outstandingInd;
	}

    @XmlElement(name = "FollowupLetterStatus")
	public String getFollowupLetterStatus() {
		return FollowupLetterStatus;
	}

	public void setFollowupLetterStatus(String followupLetterStatus) {
		FollowupLetterStatus = followupLetterStatus;
	}

    @XmlElement(name = "FirstFollowUpLetterIssueDate")
	public String getFirstFollowUpLetterIssueDate() {
		return FirstFollowUpLetterIssueDate;
	}

	public void setFirstFollowUpLetterIssueDate(String firstFollowUpLetterIssueDate) {
		FirstFollowUpLetterIssueDate = firstFollowUpLetterIssueDate;
	}

    @XmlElement(name = "FirstFollowUpReminderLetterIssueDate")
	public String getFirstFollowUpReminderLetterIssueDate() {
		return FirstFollowUpReminderLetterIssueDate;
	}

	public void setFirstFollowUpReminderLetterIssueDate(String firstFollowUpReminderLetterIssueDate) {
		FirstFollowUpReminderLetterIssueDate = firstFollowUpReminderLetterIssueDate;
	}

    @XmlElement(name = "SecondFollowUpReminderLetterIssueDate")
	public String getSecondFollowUpReminderLetterIssueDate() {
		return SecondFollowUpReminderLetterIssueDate;
	}

	public void setSecondFollowUpReminderLetterIssueDate(String secondFollowUpReminderLetterIssueDate) {
		SecondFollowUpReminderLetterIssueDate = secondFollowUpReminderLetterIssueDate;
	}

    @XmlElement(name = "FinalFollowUpLetterIssueDate")
	public String getFinalFollowUpLetterIssueDate() {
		return FinalFollowUpLetterIssueDate;
	}

	public void setFinalFollowUpLetterIssueDate(String finalFollowUpLetterIssueDate) {
		FinalFollowUpLetterIssueDate = finalFollowUpLetterIssueDate;
	}

    @XmlElement(name = "ReasonCodeDetails")
	public List<ReasonCodeDetails> getReasonCodeDetails() {
		return reasonCodeDetails;
	}

	public void setReasonCodeDetails(List<ReasonCodeDetails> reasonCodeDetails) {
		this.reasonCodeDetails = reasonCodeDetails;
	}

    @XmlElement(name = "AssoAcctDetails")
	public List<AssoAcctDetails> getAssoAcctDetails() {
		return assoAcctDetails;
	}

	public void setAssoAcctDetails(List<AssoAcctDetails> assoAcctDetails) {
		this.assoAcctDetails = assoAcctDetails;
	}

    @XmlElement(name = "IndiciaDetails")
	public List<IndiciaDetails> getIndiciaDetails() {
		return indiciaDetails;
	}

	public void setIndiciaDetails(List<IndiciaDetails> indiciaDetails) {
		this.indiciaDetails = indiciaDetails;
	}

    @XmlElement(name = "SuppDocDetails")
	public List<SuppDocDetails> getSuppDocDetails() {
		return suppDocDetails;
	}

	public void setSuppDocDetails(List<SuppDocDetails> suppDocDetails) {
		this.suppDocDetails = suppDocDetails;
	}

    @XmlElement(name = "RespPartyDetails")
	public List<RespPartyDetails> getRespPartyDetails() {
		return respPartyDetails;
	}

	public void setRespPartyDetails(List<RespPartyDetails> respPartyDetails) {
		this.respPartyDetails = respPartyDetails;
	}

    @XmlElement(name = "SubOwnerDetails")
	public List<SubOwnerDetails> getSubOwnerDetails() {
		return subOwnerDetails;
	}

	public void setSubOwnerDetails(List<SubOwnerDetails> subOwnerDetails) {
		this.subOwnerDetails = subOwnerDetails;
	}

    @XmlElement(name = "CreationDate")
	public String getCreationDate() {
		return CreationDate;
	}

	public void setCreationDate(String creationDate) {
		CreationDate = creationDate;
	}

    @XmlElement(name = "UpdDate")
	public String getUpdDate() {
		return UpdDate;
	}

	public void setUpdDate(String updDate) {
		UpdDate = updDate;
	}

    @XmlElement(name = "CompDate")
	public String getCompDate() {
		return CompDate;
	}

	public void setCompDate(String compDate) {
		CompDate = compDate;
	}

    @XmlElement(name = "CheckDate")
	public String getCheckDate() {
		return CheckDate;
	}

	public void setCheckDate(String checkDate) {
		CheckDate = checkDate;
	}

    @XmlElement(name = "CreateUserID")
	public String getCreateUserID() {
		return CreateUserID;
	}

	public void setCreateUserID(String createUserID) {
		CreateUserID = createUserID;
	}

    @XmlElement(name = "LastUpdUserID")
	public String getLastUpdUserID() {
		return LastUpdUserID;
	}

	public void setLastUpdUserID(String lastUpdUserID) {
		LastUpdUserID = lastUpdUserID;
	}

    @XmlElement(name = "Remark")
	public String getRemark() {
		return Remark;
	}

	public void setRemark(String remark) {
		Remark = remark;
	}

    @XmlElement(name = "Type")
	public String getType() {
		return Type;
	}

	public void setType(String type) {
		Type = type;
	}

    @XmlElement(name = "Chapter4StatusCode2")
	public String getChapter4StatusCode2() {
		return Chapter4StatusCode2;
	}

	public void setChapter4StatusCode2(String chapter4StatusCode2) {
		Chapter4StatusCode2 = chapter4StatusCode2;
	}
	
	
}



