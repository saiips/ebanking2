package com.dsb.eb2.backOffice.connect.emsMsg.FN2001;


import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class ExRatesT1 {
	
	@JSONField(name="PreferredRate")
    private List<String> PreferredRate;
	
	@JSONField(name="MinProfitRate")
    private String MinProfitRate;
	
	@JSONField(name="CostRate")
    private String CostRate;

}
