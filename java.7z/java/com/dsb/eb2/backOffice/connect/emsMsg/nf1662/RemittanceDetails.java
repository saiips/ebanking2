package com.dsb.eb2.backOffice.connect.emsMsg.nf1662;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = { "referenceNo", "creditCurrency","creditAmount","payerBankInformation" ,"remitter",
		"remittingCurrency","remittingAmount","status","transactionDate","messageDetails"})
public class RemittanceDetails
{
	@JSONField(name="ReferenceNo")
    private String referenceNo;

	@JSONField(name="CreditCurrency")
    private String creditCurrency;
    
	@JSONField(name="CreditAmount")
    private String creditAmount;
    
	@JSONField(name="PayerBankInformation")
    private List<PayerBankInformation> payerBankInformation;

	@JSONField(name="Remitter")
    private String remitter;
    
	@JSONField(name="RemittingCurrency")
    private String remittingCurrency;
    
	@JSONField(name="RemittingAmount")
    private String remittingAmount;
    
	@JSONField(name="Status")
    private String status;
    
	@JSONField(name="TransactionDate")
    private String transactionDate;
    
	@JSONField(name="MessageDetails")
    private List<MessageDetails> messageDetails;

	
	@XmlElement(name = "ReferenceNo")
	public String getReferenceNo() {
		return referenceNo;
	}

	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}
   
	@XmlElement(name = "CreditCurrency")
	public String getCreditCurrency() {
		return creditCurrency;
	}

	public void setCreditCurrency(String creditCurrency) {
		this.creditCurrency = creditCurrency;
	}

	
	@XmlElement(name = "CreditAmount")
	public String getCreditAmount() {
		return creditAmount;
	}

	public void setCreditAmount(String creditAmount) {
		this.creditAmount = creditAmount;
	}

	@XmlElement(name = "PayerBankInformation")
	public List<PayerBankInformation> getPayerBankInformation() {
		return payerBankInformation;
	}

	public void setPayerBankInformation(List<PayerBankInformation> payerBankInformation) {
		this.payerBankInformation = payerBankInformation;
	}

	
	@XmlElement(name = "Remitter")
	public String getRemitter() {
		return remitter;
	}

	public void setRemitter(String remitter) {
		this.remitter = remitter;
	}

	
	@XmlElement(name = "RemittingCurrency")
	public String getRemittingCurrency() {
		return remittingCurrency;
	}

	public void setRemittingCurrency(String remittingCurrency) {
		this.remittingCurrency = remittingCurrency;
	}
    
	
	@XmlElement(name = "RemittingAmount")
	public String getRemittingAmount() {
		return remittingAmount;
	}

	public void setRemittingAmount(String remittingAmount) {
		this.remittingAmount = remittingAmount;
	}

	
	@XmlElement(name = "Status")
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
	@XmlElement(name = "TransactionDate")
	public String getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}

	
	@XmlElement(name = "MessageDetails")
	public List<MessageDetails> getMessageDetails() {
		return messageDetails;
	}

	public void setMessageDetails(List<MessageDetails> messageDetails) {
		this.messageDetails = messageDetails;
	}
 
    
    
    
	
}
