package com.dsb.eb2.backOffice.connect.emsMsg.nf1110;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class AccountOwnerInfo {

	public AccountOwnerInfo(){}
	
	@JSONField(name="CustID")
	private String custID;
	
	@JSONField(name="Title")
	private String title;
	
	@JSONField(name="CustomerName1")
	private String customerName1;
	
	@JSONField(name="CustomerName2")
	private String customerName2;
	
	@JSONField(name="PrimaryOwnerInd")
	private String primaryOwnerInd;

}
