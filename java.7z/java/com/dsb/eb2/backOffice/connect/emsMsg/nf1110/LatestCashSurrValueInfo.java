package com.dsb.eb2.backOffice.connect.emsMsg.nf1110;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class LatestCashSurrValueInfo {

	public LatestCashSurrValueInfo() {
	}

	@JSONField(name="CCY")
	private String cCY;
	
	@JSONField(name="AmtInd")
	private String amtInd;
	
	@JSONField(name="Amt")
	private String amt;

}
