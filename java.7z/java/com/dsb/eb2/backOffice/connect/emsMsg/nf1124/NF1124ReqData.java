package com.dsb.eb2.backOffice.connect.emsMsg.nf1124;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"creditCardAccountNbr"})
public class  NF1124ReqData extends FrmData
{
    
	public NF1124ReqData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1124";
	}
	@JSONField(name="CreditCardAccountNbr")
	private String creditCardAccountNbr;
	
	
	
	@XmlElement(name="CreditCardAccountNbr")
	public String getCreditCardAccountNbr() {
		return creditCardAccountNbr;
	}

	public void setCreditCardAccountNbr(String creditCardAccountNbr) {
		this.creditCardAccountNbr = creditCardAccountNbr;
	}
	
}
