package com.dsb.eb2.backOffice.connect.emsMsg.fn1521;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class CredCrdAntiAttrData {
	
	public CredCrdAntiAttrData() {}
	

	@JSONField(name="CardFeeDate")
	private String cardFeeDate;
	
	@JSONField(name="SourceCode")
	private String sourceCode;
	
	@JSONField(name="TranAcct")
	private String tranAcct;
	
	@JSONField(name="DeliveryMethod")
	private String deliveryMethod;
	
	
}

