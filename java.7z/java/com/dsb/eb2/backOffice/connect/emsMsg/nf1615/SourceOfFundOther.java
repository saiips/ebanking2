package com.dsb.eb2.backOffice.connect.emsMsg.nf1615;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"gLBranchCode","gLNumber","otherCurrency","otherAmount","otherExchangeRate","otherFXDealNumber","otherHKDEquivalent","depositAmount","depositExchangeRate","depositFXDealNumber","crossExchangeRate"})
public class SourceOfFundOther {
	
	public SourceOfFundOther() {}

	@JSONField(name="GLBranchCode")
	private String gLBranchCode;
	
	@JSONField(name="GLNumber")
	private String gLNumber;
	
	@JSONField(name="OtherCurrency")
	private String otherCurrency;
	
	@JSONField(name="OtherAmount")
	private String otherAmount;
	
	@JSONField(name="OtherExchangeRate")
	private String otherExchangeRate;
	
	@JSONField(name="OtherFXDealNumber")
	private String otherFXDealNumber;
	
	@JSONField(name="OtherHKDEquivalent")
	private String otherHKDEquivalent;
	
	@JSONField(name="DepositAmount")
	private String depositAmount;
	
	@JSONField(name="DepositExchangeRate")
	private String depositExchangeRate;
	
	@JSONField(name="DepositFXDealNumber")
	private String depositFXDealNumber;
	
	@JSONField(name="CrossExchangeRate")
	private String crossExchangeRate;

    @XmlElement(name = "GLBranchCode")
	public String getgLBranchCode() {
		return gLBranchCode;
	}

	public void setgLBranchCode(String gLBranchCode) {
		this.gLBranchCode = gLBranchCode;
	}

    @XmlElement(name = "GLNumber")
	public String getgLNumber() {
		return gLNumber;
	}

	public void setgLNumber(String gLNumber) {
		this.gLNumber = gLNumber;
	}

    @XmlElement(name = "OtherCurrency")
	public String getOtherCurrency() {
		return otherCurrency;
	}

	public void setOtherCurrency(String otherCurrency) {
		this.otherCurrency = otherCurrency;
	}

    @XmlElement(name = "OtherAmount")
	public String getOtherAmount() {
		return otherAmount;
	}

	public void setOtherAmount(String otherAmount) {
		this.otherAmount = otherAmount;
	}

    @XmlElement(name = "OtherExchangeRate")
	public String getOtherExchangeRate() {
		return otherExchangeRate;
	}

	public void setOtherExchangeRate(String otherExchangeRate) {
		this.otherExchangeRate = otherExchangeRate;
	}

    @XmlElement(name = "OtherFXDealNumber")
	public String getOtherFXDealNumber() {
		return otherFXDealNumber;
	}

	public void setOtherFXDealNumber(String otherFXDealNumber) {
		this.otherFXDealNumber = otherFXDealNumber;
	}

    @XmlElement(name = "OtherHKDEquivalent")
	public String getOtherHKDEquivalent() {
		return otherHKDEquivalent;
	}

	public void setOtherHKDEquivalent(String otherHKDEquivalent) {
		this.otherHKDEquivalent = otherHKDEquivalent;
	}

    @XmlElement(name = "DepositAmount")
	public String getDepositAmount() {
		return depositAmount;
	}

	public void setDepositAmount(String depositAmount) {
		this.depositAmount = depositAmount;
	}

    @XmlElement(name = "DepositExchangeRate")
	public String getDepositExchangeRate() {
		return depositExchangeRate;
	}

	public void setDepositExchangeRate(String depositExchangeRate) {
		this.depositExchangeRate = depositExchangeRate;
	}

    @XmlElement(name = "DepositFXDealNumber")
	public String getDepositFXDealNumber() {
		return depositFXDealNumber;
	}

	public void setDepositFXDealNumber(String depositFXDealNumber) {
		this.depositFXDealNumber = depositFXDealNumber;
	}

    @XmlElement(name = "CrossExchangeRate")
	public String getCrossExchangeRate() {
		return crossExchangeRate;
	}

	public void setCrossExchangeRate(String crossExchangeRate) {
		this.crossExchangeRate = crossExchangeRate;
	}
	
	
	

	
}
