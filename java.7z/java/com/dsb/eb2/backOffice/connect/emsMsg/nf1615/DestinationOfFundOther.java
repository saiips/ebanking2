package com.dsb.eb2.backOffice.connect.emsMsg.nf1615;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"gLBranchCode","gLNumber","otherCurrency","otherAmount","otherExchangeRate","otherFXDealNumber","otherHKDEquivalent","withdrawalAmount","withdrawalExchangeRate","withdrawalFXDealNumber","crossExchangeRate"})
public class DestinationOfFundOther {

	public DestinationOfFundOther() {}

	@JSONField(name="GLBranchCode")
	private String gLBranchCode;
	
	@JSONField(name="GLNumber")
	private String gLNumber;
	
	@JSONField(name="OtherCurrency")
	private String otherCurrency;
	
	@JSONField(name="OtherAmount")
	private String otherAmount;
	
	@JSONField(name="OtherExchangeRate")
	private String otherExchangeRate;
	
	@JSONField(name="OtherFXDealNumber")
	private String otherFXDealNumber;
	
	@JSONField(name="OtherHKDEquivalent")
	private String otherHKDEquivalent;
	
	@JSONField(name="WithdrawalAmount")
	private String withdrawalAmount;
	
	@JSONField(name="WithdrawalExchangeRate")
	private String withdrawalExchangeRate;
	
	@JSONField(name="WithdrawalFXDealNumber")
	private String withdrawalFXDealNumber;
	
	@JSONField(name="CrossExchangeRate")
	private String crossExchangeRate;

    @XmlElement(name = "GLBranchCode")
	public String getgLBranchCode() {
		return gLBranchCode;
	}

	public void setgLBranchCode(String gLBranchCode) {
		this.gLBranchCode = gLBranchCode;
	}

    @XmlElement(name = "GLNumber")
	public String getgLNumber() {
		return gLNumber;
	}

	public void setgLNumber(String gLNumber) {
		this.gLNumber = gLNumber;
	}

    @XmlElement(name = "OtherCurrency")
	public String getOtherCurrency() {
		return otherCurrency;
	}

	public void setOtherCurrency(String otherCurrency) {
		this.otherCurrency = otherCurrency;
	}

    @XmlElement(name = "OtherAmount")
	public String getOtherAmount() {
		return otherAmount;
	}

	public void setOtherAmount(String otherAmount) {
		this.otherAmount = otherAmount;
	}

    @XmlElement(name = "OtherExchangeRate")
	public String getOtherExchangeRate() {
		return otherExchangeRate;
	}

	public void setOtherExchangeRate(String otherExchangeRate) {
		this.otherExchangeRate = otherExchangeRate;
	}

    @XmlElement(name = "OtherFXDealNumber")
	public String getOtherFXDealNumber() {
		return otherFXDealNumber;
	}

	public void setOtherFXDealNumber(String otherFXDealNumber) {
		this.otherFXDealNumber = otherFXDealNumber;
	}

    @XmlElement(name = "OtherHKDEquivalent")
	public String getOtherHKDEquivalent() {
		return otherHKDEquivalent;
	}

	public void setOtherHKDEquivalent(String otherHKDEquivalent) {
		this.otherHKDEquivalent = otherHKDEquivalent;
	}

    @XmlElement(name = "WithdrawalAmount")
	public String getWithdrawalAmount() {
		return withdrawalAmount;
	}

	public void setWithdrawalAmount(String withdrawalAmount) {
		this.withdrawalAmount = withdrawalAmount;
	}

    @XmlElement(name = "WithdrawalExchangeRate")
	public String getWithdrawalExchangeRate() {
		return withdrawalExchangeRate;
	}

	public void setWithdrawalExchangeRate(String withdrawalExchangeRate) {
		this.withdrawalExchangeRate = withdrawalExchangeRate;
	}

    @XmlElement(name = "WithdrawalFXDealNumber")
	public String getWithdrawalFXDealNumber() {
		return withdrawalFXDealNumber;
	}

	public void setWithdrawalFXDealNumber(String withdrawalFXDealNumber) {
		this.withdrawalFXDealNumber = withdrawalFXDealNumber;
	}

    @XmlElement(name = "CrossExchangeRate")
	public String getCrossExchangeRate() {
		return crossExchangeRate;
	}

	public void setCrossExchangeRate(String crossExchangeRate) {
		this.crossExchangeRate = crossExchangeRate;
	}
	
	


}
