package com.dsb.eb2.backOffice.connect.emsMsg.FN2001;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"sign","tranDate","eCFlag","tranAmt","ref1","ref2","bal","tellerID","nobookDate"})
public class SingleCcyPassbookData
{
    private String sign;
    
    private String tranDate;
    
    private String eCFlag;
    
    private String tranAmt;
    
    private String ref1;
    
    private String ref2;
    
    private String bal;
    
    private String tellerID;
    
    private String nobookDate;

    @XmlElement(name = "Sign")
    public String getSign()
    {
        return sign;
    }

    public void setSign(String sign)
    {
        this.sign = sign;
    }

    @XmlElement(name = "TranDate")
    public String getTranDate()
    {
        return tranDate;
    }

    public void setTranDate(String tranDate)
    {
        this.tranDate = tranDate;
    }

    @XmlElement(name = "ECFlag")
    public String geteCFlag()
    {
        return eCFlag;
    }

    public void seteCFlag(String eCFlag)
    {
        this.eCFlag = eCFlag;
    }

    @XmlElement(name = "TranAmt")
    public String getTranAmt()
    {
        return tranAmt;
    }

    public void setTranAmt(String tranAmt)
    {
        this.tranAmt = tranAmt;
    }

    @XmlElement(name = "Ref1")
    public String getRef1()
    {
        return ref1;
    }

    public void setRef1(String ref1)
    {
        this.ref1 = ref1;
    }

    @XmlElement(name = "Ref2")
    public String getRef2()
    {
        return ref2;
    }

    public void setRef2(String ref2)
    {
        this.ref2 = ref2;
    }

    @XmlElement(name = "Bal")
    public String getBal()
    {
        return bal;
    }

    public void setBal(String bal)
    {
        this.bal = bal;
    }

    @XmlElement(name = "TellerID")
    public String getTellerID()
    {
        return tellerID;
    }

    public void setTellerID(String tellerID)
    {
        this.tellerID = tellerID;
    }

    @XmlElement(name = "NobookDate")
    public String getNobookDate()
    {
        return nobookDate;
    }

    public void setNobookDate(String nobookDate)
    {
        this.nobookDate = nobookDate;
    }
    
    
}
