package com.dsb.eb2.backOffice.connect.emsMsg.nf1552;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"referenceNumber"})
public class NF1552RepData extends FrmData{
	
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1552";
	}
	
	public NF1552RepData() {}

	@JSONField(name="ReferenceNumber")
	private String referenceNumber;

	@XmlElement(name = "ReferenceNumber")
	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}
	
	
	
}
