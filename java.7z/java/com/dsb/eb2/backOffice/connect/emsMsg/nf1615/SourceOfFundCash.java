package com.dsb.eb2.backOffice.connect.emsMsg.nf1615;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"cashCurrency","cashAmount","cashExchangeRate","cashFXDealNumber","cashHKDEquivalent","depositAmount","depositExchangeRate","depositFXDealNumber","crossExchangeRate","transitAccount","transitAccountCurrency"})
public class SourceOfFundCash {
	
	public SourceOfFundCash() {}

	@JSONField(name="CashCurrency")
	private String cashCurrency;
	
	@JSONField(name="CashAmount")
	private String cashAmount;
	
	@JSONField(name="CashExchangeRate")
	private String cashExchangeRate;
	
	@JSONField(name="CashFXDealNumber")
	private String cashFXDealNumber;
	
	@JSONField(name="CashHKDEquivalent")
	private String cashHKDEquivalent;
	
	@JSONField(name="DepositAmount")
	private String depositAmount;
	
	@JSONField(name="DepositExchangeRate")
	private String depositExchangeRate;
	
	@JSONField(name="DepositFXDealNumber")
	private String depositFXDealNumber;
	
	@JSONField(name="CrossExchangeRate")
	private String crossExchangeRate;
	
	@JSONField(name="TransitAccount")
	private String transitAccount;
	
	@JSONField(name="TransitAccountCurrency")
	private String transitAccountCurrency;

    @XmlElement(name = "CashCurrency")
	public String getCashCurrency() {
		return cashCurrency;
	}

	public void setCashCurrency(String cashCurrency) {
		this.cashCurrency = cashCurrency;
	}

    @XmlElement(name = "CashAmount")
	public String getCashAmount() {
		return cashAmount;
	}

	public void setCashAmount(String cashAmount) {
		this.cashAmount = cashAmount;
	}

    @XmlElement(name = "CashExchangeRate")
	public String getCashExchangeRate() {
		return cashExchangeRate;
	}

	public void setCashExchangeRate(String cashExchangeRate) {
		this.cashExchangeRate = cashExchangeRate;
	}

    @XmlElement(name = "CashFXDealNumber")
	public String getCashFXDealNumber() {
		return cashFXDealNumber;
	}

	public void setCashFXDealNumber(String cashFXDealNumber) {
		this.cashFXDealNumber = cashFXDealNumber;
	}

    @XmlElement(name = "CashHKDEquivalent")
	public String getCashHKDEquivalent() {
		return cashHKDEquivalent;
	}

	public void setCashHKDEquivalent(String cashHKDEquivalent) {
		this.cashHKDEquivalent = cashHKDEquivalent;
	}

    @XmlElement(name = "DepositAmount")
	public String getDepositAmount() {
		return depositAmount;
	}

	public void setDepositAmount(String depositAmount) {
		this.depositAmount = depositAmount;
	}

    @XmlElement(name = "DepositExchangeRate")
	public String getDepositExchangeRate() {
		return depositExchangeRate;
	}

	public void setDepositExchangeRate(String depositExchangeRate) {
		this.depositExchangeRate = depositExchangeRate;
	}

    @XmlElement(name = "DepositFXDealNumber")
	public String getDepositFXDealNumber() {
		return depositFXDealNumber;
	}

	public void setDepositFXDealNumber(String depositFXDealNumber) {
		this.depositFXDealNumber = depositFXDealNumber;
	}

    @XmlElement(name = "CrossExchangeRate")
	public String getCrossExchangeRate() {
		return crossExchangeRate;
	}

	public void setCrossExchangeRate(String crossExchangeRate) {
		this.crossExchangeRate = crossExchangeRate;
	}

    @XmlElement(name = "TransitAccount")
	public String getTransitAccount() {
		return transitAccount;
	}

	public void setTransitAccount(String transitAccount) {
		this.transitAccount = transitAccount;
	}

    @XmlElement(name = "TransitAccountCurrency")
	public String getTransitAccountCurrency() {
		return transitAccountCurrency;
	}

	public void setTransitAccountCurrency(String transitAccountCurrency) {
		this.transitAccountCurrency = transitAccountCurrency;
	}
	
	
	

}
