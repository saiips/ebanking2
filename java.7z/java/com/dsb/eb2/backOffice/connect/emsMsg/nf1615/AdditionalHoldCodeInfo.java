package com.dsb.eb2.backOffice.connect.emsMsg.nf1615;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"borrowerName","pledgeAmount","accountOfficerCode","borrowerAccounts"})
public class AdditionalHoldCodeInfo{
	

	public AdditionalHoldCodeInfo() {}

	@JSONField(name="BorrowerName")
	private String borrowerName;
	
	@JSONField(name="PledgeAmount")
	private String pledgeAmount;
	
	@JSONField(name="AccountOfficerCode")
	private String accountOfficerCode;
	
	@JSONField(name="BorrowerAccounts")
	private String borrowerAccounts;

	@XmlElement(name = "BorrowerName")
	public String getBorrowerName() {
		return borrowerName;
	}

	@XmlElement(name = "PledgeAmount")
	public String getPledgeAmount() {
		return pledgeAmount;
	}

	@XmlElement(name = "AccountOfficerCode")
	public String getAccountOfficerCode() {
		return accountOfficerCode;
	}

	@XmlElement(name = "BorrowerAccounts")
	public String getBorrowerAccounts() {
		return borrowerAccounts;
	}

	public void setBorrowerName(String borrowerName) {
		this.borrowerName = borrowerName;
	}

	public void setPledgeAmount(String pledgeAmount) {
		this.pledgeAmount = pledgeAmount;
	}

	public void setAccountOfficerCode(String accountOfficerCode) {
		this.accountOfficerCode = accountOfficerCode;
	}

	public void setBorrowerAccounts(String borrowerAccounts) {
		this.borrowerAccounts = borrowerAccounts;
	}
	
	

}
