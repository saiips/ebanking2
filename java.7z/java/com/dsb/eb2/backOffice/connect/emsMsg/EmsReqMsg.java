package com.dsb.eb2.backOffice.connect.emsMsg;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlTransient;

import com.dsb.eb2.backOffice.connect.emsMsg.nf1107.NF1107ReqData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1108.NF1108ReqData;

/**
 * EMS请求消息，所有EMS请求消息必须继承此类
 * 
 * @author cxj
 * 
 */
@XmlSeeAlso( { 
    NF1107ReqData.class,NF1108ReqData.class})
@XmlRootElement(name = "XMLReqMsg")
@XmlAccessorType(XmlAccessType.PROPERTY)
public class EmsReqMsg
    extends EmsMsg
{
    private String jnlNo;

    public EmsReqMsg()
    {
        super();
    }

    public EmsReqMsg(FrmData frmData)
    {
        super(frmData);
    }

    public EmsReqMsg(FrmHdr frmHdr, FrmData frmData)
    {
        super(frmHdr, frmData);
    }

    @XmlElement(name = "Payload")
    public FrmData getFrmData()
    {
        return frmData;
    }

    public void setFrmData(FrmData frmData)
    {
        this.frmData = frmData;
    }

    @XmlTransient
    public String getJnlNo()
    {
        return jnlNo;
    }

    public void setJnlNo(String jnlNo)
    {
        this.jnlNo = jnlNo;
    }
}
