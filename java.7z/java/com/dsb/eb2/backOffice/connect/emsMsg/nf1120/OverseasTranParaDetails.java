package com.dsb.eb2.backOffice.connect.emsMsg.nf1120;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class OverseasTranParaDetails
{
	public OverseasTranParaDetails(){}
	
	@JSONField(name="StartDate")
	private String  startDate;
	
	@JSONField(name="EndDate") 
	private String  endDate;
	
	@JSONField(name="Limit") 
	private String  limit;
	
	@JSONField(name="LastChangeDate")
	private String  lastChangeDate;
	
	@JSONField(name="LastChangeTime") 
	private String  lastChangeTime;
	
	@JSONField(name="LastAction") 
	private String  lastAction;
	
	@JSONField(name="Source") 
	private String  source;
}
