package com.dsb.eb2.backOffice.connect.emsMsg.nf1566;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;


@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"acctType","acctNum","system","lastKey","itemsReq"})
public class NF1566ReqData extends FrmData{

	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1566";
	}
	
	public NF1566ReqData() {}

	@JSONField(name="AcctType")
	private String acctType;
	
	@JSONField(name="AcctNum")
	private String acctNum;
	
	@JSONField(name="System")
	private String system;
	
	@JSONField(name="LastKey")
	private String lastKey;
	
	@JSONField(name="ItemsReq")
	private String itemsReq;

	
	@XmlElement(name = "AcctType")
	public String getAcctType() {
		return acctType;
	}

	public void setAcctType(String acctType) {
		this.acctType = acctType;
	}

	@XmlElement(name = "AcctNum")
	public String getAcctNum() {
		return acctNum;
	}

	public void setAcctNum(String acctNum) {
		this.acctNum = acctNum;
	}

	@XmlElement(name = "System")
	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}

	@XmlElement(name = "LastKey")
	public String getLastKey() {
		return lastKey;
	}

	public void setLastKey(String lastKey) {
		this.lastKey = lastKey;
	}

	@XmlElement(name = "ItemsReq")
	public String getItemsReq() {
		return itemsReq;
	}

	public void setItemsReq(String itemsReq) {
		this.itemsReq = itemsReq;
	}
	


}
