package com.dsb.eb2.backOffice.connect.emsMsg.nf2008;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;


@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"acctNum", "acctType",  "acctName", "staffInd","statementCycle","iAcctMailingInd",
		"minimumPayment","acctStatusCode", "statementName1","statementName2", "trustClientInd","acctInd",
		"renewStatus","sourceCode", "listDailyFlag","waiveODInterestInd","waiveUnauthorizedODChargeInd",
		"waiveDormantChargeInd", "officerCode","signatureNo","applyMasterCSN","directSalesTeamInfo",
		"payrollInfo","suppPaperStatement","eAdvice","mainFeeWaiverEndDate","charType","dormChgFlag"})
public class NF2008ReqData  extends FrmData
{
    
	public NF2008ReqData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF2008";
	}
	
	@JSONField(name="AcctNum")
	private String acctNum;
	
	@JSONField(name="AcctType") 
	private String acctType;
	
	@JSONField(name="AcctName") 
	private String acctName;
	
	@JSONField(name="StaffInd") 
	private String staffInd;
	
	@JSONField(name="StatementCycle") 
	private String statementCycle;
	
	@JSONField(name="IAcctMailingInd") 
	private String iAcctMailingInd;
	
	@JSONField(name="MinimumPayment") 
	private String minimumPayment;
	
	@JSONField(name="AcctStatusCode") 
	private String acctStatusCode;
	
	@JSONField(name="StatementName1") 
	private String statementName1;
	
	@JSONField(name="StatementName2") 
	private String statementName2;
	
	
	
	@JSONField(name="TrustClientInd") 
	private String trustClientInd;
	
	@JSONField(name="AcctInd") 
	private String acctInd;
	
	@JSONField(name="RenewStatus") 
	private String renewStatus;
	
	@JSONField(name="SourceCode") 
	private String sourceCode;
	
	@JSONField(name="ListDailyFlag") 
	private String listDailyFlag;
	
	@JSONField(name="WaiveODInterestInd") 
	private String waiveODInterestInd;
	
	@JSONField(name="WaiveUnauthorizedODChargeInd") 
	private String waiveUnauthorizedODChargeInd;
	
	@JSONField(name="WaiveDormantChargeInd") 
	private String waiveDormantChargeInd;
	
	@JSONField(name="OfficerCode") 
	private String officerCode;
	
	@JSONField(name="SignatureNo") 
	private String signatureNo;
	
	
	
	@JSONField(name="ApplyMasterCSN") 
	private String applyMasterCSN;
	
	@JSONField(name="DirectSalesTeamInfo")
	private List<DirectSalesTeamInfo> directSalesTeamInfo;
	
	@JSONField(name="PayrollInfo")
	private List<PayrollInfo> payrollInfo;

	@JSONField(name="SuppPaperStatement") 
	private String suppPaperStatement;
	
	@JSONField(name="EAdvice") 
	private String eAdvice;
	
	@JSONField(name="MainFeeWaiverEndDate") 
	private String mainFeeWaiverEndDate;
	
	@JSONField(name="CharType") 
	private String charType;
	
	@JSONField(name="DormChgFlag") 
	private String dormChgFlag;

	
	
	@XmlElement(name = "AcctNum")
	public String getAcctNum() {
		return acctNum;
	}

	public void setAcctNum(String acctNum) {
		this.acctNum = acctNum;
	}

	@XmlElement(name = "AcctType")
	public String getAcctType() {
		return acctType;
	}

	public void setAcctType(String acctType) {
		this.acctType = acctType;
	}

	@XmlElement(name = "AcctName")
	public String getAcctName() {
		return acctName;
	}

	public void setAcctName(String acctName) {
		this.acctName = acctName;
	}

	@XmlElement(name = "StaffInd")
	public String getStaffInd() {
		return staffInd;
	}

	public void setStaffInd(String staffInd) {
		this.staffInd = staffInd;
	}

	@XmlElement(name = "StatementCycle")
	public String getStatementCycle() {
		return statementCycle;
	}

	public void setStatementCycle(String statementCycle) {
		this.statementCycle = statementCycle;
	}

	@XmlElement(name = "IAcctMailingInd")
	public String getiAcctMailingInd() {
		return iAcctMailingInd;
	}

	public void setiAcctMailingInd(String iAcctMailingInd) {
		this.iAcctMailingInd = iAcctMailingInd;
	}

	@XmlElement(name = "MinimumPayment")
	public String getMinimumPayment() {
		return minimumPayment;
	}

	public void setMinimumPayment(String minimumPayment) {
		this.minimumPayment = minimumPayment;
	}

	@XmlElement(name = "AcctStatusCode")
	public String getAcctStatusCode() {
		return acctStatusCode;
	}

	public void setAcctStatusCode(String acctStatusCode) {
		this.acctStatusCode = acctStatusCode;
	}

	@XmlElement(name = "StatementName1")
	public String getStatementName1() {
		return statementName1;
	}

	public void setStatementName1(String statementName1) {
		this.statementName1 = statementName1;
	}

	@XmlElement(name = "StatementName2")
	public String getStatementName2() {
		return statementName2;
	}

	public void setStatementName2(String statementName2) {
		this.statementName2 = statementName2;
	}

	@XmlElement(name = "TrustClientInd")
	public String getTrustClientInd() {
		return trustClientInd;
	}

	public void setTrustClientInd(String trustClientInd) {
		this.trustClientInd = trustClientInd;
	}

	@XmlElement(name = "AcctInd")
	public String getAcctInd() {
		return acctInd;
	}

	public void setAcctInd(String acctInd) {
		this.acctInd = acctInd;
	}

	@XmlElement(name = "RenewStatus")
	public String getRenewStatus() {
		return renewStatus;
	}

	public void setRenewStatus(String renewStatus) {
		this.renewStatus = renewStatus;
	}

	@XmlElement(name = "SourceCode")
	public String getSourceCode() {
		return sourceCode;
	}

	public void setSourceCode(String sourceCode) {
		this.sourceCode = sourceCode;
	}

	@XmlElement(name = "ListDailyFlag")
	public String getListDailyFlag() {
		return listDailyFlag;
	}

	public void setListDailyFlag(String listDailyFlag) {
		this.listDailyFlag = listDailyFlag;
	}

	@XmlElement(name = "WaiveODInterestInd")
	public String getWaiveODInterestInd() {
		return waiveODInterestInd;
	}

	public void setWaiveODInterestInd(String waiveODInterestInd) {
		this.waiveODInterestInd = waiveODInterestInd;
	}

	@XmlElement(name = "WaiveUnauthorizedODChargeInd")
	public String getWaiveUnauthorizedODChargeInd() {
		return waiveUnauthorizedODChargeInd;
	}

	public void setWaiveUnauthorizedODChargeInd(String waiveUnauthorizedODChargeInd) {
		this.waiveUnauthorizedODChargeInd = waiveUnauthorizedODChargeInd;
	}

	@XmlElement(name = "WaiveDormantChargeInd")
	public String getWaiveDormantChargeInd() {
		return waiveDormantChargeInd;
	}

	public void setWaiveDormantChargeInd(String waiveDormantChargeInd) {
		this.waiveDormantChargeInd = waiveDormantChargeInd;
	}

	@XmlElement(name = "OfficerCode")
	public String getOfficerCode() {
		return officerCode;
	}

	public void setOfficerCode(String officerCode) {
		this.officerCode = officerCode;
	}

	@XmlElement(name = "SignatureNo")
	public String getSignatureNo() {
		return signatureNo;
	}

	public void setSignatureNo(String signatureNo) {
		this.signatureNo = signatureNo;
	}

	@XmlElement(name = "ApplyMasterCSN")
	public String getApplyMasterCSN() {
		return applyMasterCSN;
	}

	public void setApplyMasterCSN(String applyMasterCSN) {
		this.applyMasterCSN = applyMasterCSN;
	}

	
	@XmlElement(name = "DirectSalesTeamInfo")
	public List<DirectSalesTeamInfo> getDirectSalesTeamInfo() {
		return directSalesTeamInfo;
	}

	public void setDirectSalesTeamInfo(List<DirectSalesTeamInfo> directSalesTeamInfo) {
		this.directSalesTeamInfo = directSalesTeamInfo;
	}

	@XmlElement(name = "PayrollInfo")
	public List<PayrollInfo> getPayrollInfo() {
		return payrollInfo;
	}

	public void setPayrollInfo(List<PayrollInfo> payrollInfo) {
		this.payrollInfo = payrollInfo;
	}

	@XmlElement(name = "SuppPaperStatement")
	public String getSuppPaperStatement() {
		return suppPaperStatement;
	}

	public void setSuppPaperStatement(String suppPaperStatement) {
		this.suppPaperStatement = suppPaperStatement;
	}

	@XmlElement(name = "EAdvice")
	public String geteAdvice() {
		return eAdvice;
	}

	public void seteAdvice(String eAdvice) {
		this.eAdvice = eAdvice;
	}

	@XmlElement(name = "MainFeeWaiverEndDate")
	public String getMainFeeWaiverEndDate() {
		return mainFeeWaiverEndDate;
	}

	public void setMainFeeWaiverEndDate(String mainFeeWaiverEndDate) {
		this.mainFeeWaiverEndDate = mainFeeWaiverEndDate;
	}

	@XmlElement(name = "CharType")
	public String getCharType() {
		return charType;
	}

	public void setCharType(String charType) {
		this.charType = charType;
	}

	@XmlElement(name = "DormChgFlag")
	public String getDormChgFlag() {
		return dormChgFlag;
	}

	public void setDormChgFlag(String dormChgFlag) {
		this.dormChgFlag = dormChgFlag;
	}
	
	
	
	
	
}



