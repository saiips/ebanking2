package com.dsb.eb2.backOffice.connect.emsMsg.nf1565;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"dealSource","dealNum","lastKey","itemsReq"})
public class NF1565ReqData extends FrmData {
    public NF1565ReqData() {}
	
	@Override
	public String getServiceID() {
		return "NF1565";
	}
	
    private String dealSource = "";
    
    private String dealNum = "";
    
    private String lastKey = "";
    
    private String itemsReq = "";

    @XmlElement(name = "Source")
    public String getDealSource() {
        return dealSource;
    }
    
    public void setDealSource(String dealSource) {
        this.dealSource = dealSource;
    }
    
    @XmlElement(name = "DealNum")
    public String getDealNum() {
        return dealNum;
    }
    
    public void setDealNum(String dealNum) {
        this.dealNum = dealNum;
    }
    
    @XmlElement(name = "LastKey")
    public String getLastKey() {
        return lastKey;
    }
    
    public void setLastKey(String lastKey) {
        this.lastKey = lastKey;
    }
        
    @XmlElement(name = "ItemsReq")
    public String getItemsReq() {
        return itemsReq;
    }
    
    public void setItemsReq(String itemsReq) {
        this.itemsReq = itemsReq;
    }
	
}
