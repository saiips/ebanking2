package com.dsb.eb2.backOffice.connect.emsMsg.mw0005;

import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class MW0005ReqData extends FrmData
{
	public MW0005ReqData(){}
	
	@Override
	public String getServiceID()
	{
		return "MW0005";
	}

}
