package com.dsb.eb2.backOffice.connect.emsMsg.nf1618;

import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Setter @Getter
public class NF1618ReqData extends FrmData{

	@Override
	public String getServiceID() {
		return "NF1618";
	}
	
	@JSONField(name="NumOfItems")
	private String numOfItems;
	
	@JSONField(name="EAlertDetails")
	private List<EAlertDetails> eAlertDetails = new ArrayList<EAlertDetails>();

}
