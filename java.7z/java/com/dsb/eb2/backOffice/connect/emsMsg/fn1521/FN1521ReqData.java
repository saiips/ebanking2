package com.dsb.eb2.backOffice.connect.emsMsg.fn1521;

import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class FN1521ReqData  extends FrmData
{
    
	public FN1521ReqData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "FN1521";
	}
	
	@JSONField(name="AcctNum")
	private String acctNum;
	
	@JSONField(name="ChargeInd")
	private String chargeInd;
	
	@JSONField(name="ChargeCcy")
	private String chargeCcy;
	
	@JSONField(name="TotalAmt")
	private String totalAmt;
	
	@JSONField(name="Remarks")
	private String remarks;
	
	@JSONField(name="ECInd")
	private String eCInd;
	
	@JSONField(name="OriHostTransSeqNum")
	private String oriHostTransSeqNum;
	
	@JSONField(name="CredCrdAntiAttrData")
	private List<CredCrdAntiAttrData> credCrdAntiAttrData;
	
	@JSONField(name="NumOfChrgDetailsItems")
	private String numOfChrgDetailsItems;
	
	@JSONField(name="ChargesDetails")
	private List<ChargesDetails> chargesDetails;
	
	
	
}


