package com.dsb.eb2.backOffice.connect.emsMsg.nf1624;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"type","productType","suppressFlag","lastUpdateDate","lastUpdateTime","lastUpdateUserID","lastUpdateChannel"})
public class SuppressFlagDetails {
	
	public SuppressFlagDetails() {}
	
	@JSONField(name="Type")
	private String type;
	
	@JSONField(name="ProductType")
	private String productType;
	
	@JSONField(name="SuppressFlag")
	private String suppressFlag;
	
	@JSONField(name="LastUpdateDate")
	private String lastUpdateDate;
	
	@JSONField(name="LastUpdateTime")
	private String lastUpdateTime;
	
	@JSONField(name="LastUpdateUserID")
	private String lastUpdateUserID;
	
	@JSONField(name="LastUpdateChannel")
	private String lastUpdateChannel;

    @XmlElement(name = "Type")
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

    @XmlElement(name = "ProductType")
	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

    @XmlElement(name = "SuppressFlag")
	public String getSuppressFlag() {
		return suppressFlag;
	}

	public void setSuppressFlag(String suppressFlag) {
		this.suppressFlag = suppressFlag;
	}

    @XmlElement(name = "LastUpdateDate")
	public String getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

    @XmlElement(name = "LastUpdateTime")
	public String getLastUpdateTime() {
		return lastUpdateTime;
	}

	public void setLastUpdateTime(String lastUpdateTime) {
		this.lastUpdateTime = lastUpdateTime;
	}

    @XmlElement(name = "LastUpdateUserID")
	public String getLastUpdateUserID() {
		return lastUpdateUserID;
	}

	public void setLastUpdateUserID(String lastUpdateUserID) {
		this.lastUpdateUserID = lastUpdateUserID;
	}

    @XmlElement(name = "LastUpdateChannel")
	public String getLastUpdateChannel() {
		return lastUpdateChannel;
	}

	public void setLastUpdateChannel(String lastUpdateChannel) {
		this.lastUpdateChannel = lastUpdateChannel;
	}
	
	

	
}


