package com.dsb.eb2.backOffice.connect.emsMsg.nf2089;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;


@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"moreItemsInd","lastKey","numOfItems","respPartyKey"})
public class RespPartyDetails {
	
	public RespPartyDetails() {}
	
	
	@JSONField(name="MoreItemsInd")
	private String moreItemsInd;
	
	@JSONField(name="LastKey")
	private String lastKey;
	
	@JSONField(name="NumOfItems")
	private String numOfItems;
	
	@JSONField(name="RespPartyKey")
	private List<RespPartyKey> respPartyKey;
	

	@XmlElement(name = "MoreItemsInd")
	public String getMoreItemsInd() {
		return moreItemsInd;
	}

	public void setMoreItemsInd(String moreItemsInd) {
		this.moreItemsInd = moreItemsInd;
	}

	@XmlElement(name = "LastKey")
	public String getLastKey() {
		return lastKey;
	}

	public void setLastKey(String lastKey) {
		this.lastKey = lastKey;
	}

	@XmlElement(name = "NumOfItems")
	public String getNumOfItems() {
		return numOfItems;
	}

	public void setNumOfItems(String numOfItems) {
		this.numOfItems = numOfItems;
	}

	@XmlElement(name = "RespPartyKey")
	public List<RespPartyKey> getRespPartyKey() {
		return respPartyKey;
	}

	
	public void setRespPartyKey(List<RespPartyKey> respPartyKey) {
		this.respPartyKey = respPartyKey;
	}
	

	
}



