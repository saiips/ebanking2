package com.dsb.eb2.backOffice.connect.emsMsg.FN2001;

import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class FN2001RepData extends FrmData
{
	@JSONField(name="AcctNum")
    private String acctNum;
    
	@JSONField(name="HostTranSeqNum")
    private String hostTranSeqNum;
    
	@JSONField(name="AcctName")
    private String acctName;
    
	@JSONField(name="RelatedAcctNum")
    private String relatedAcctNum;
    
	@JSONField(name="BuyDealNum")
    private String buyDealNum;
    
	@JSONField(name="SellDealNum")
    private String sellDealNum;
    
	@JSONField(name="PassbookItemCnt")
    private List<String> passbookItemCnt=new ArrayList<String>();
    
	@JSONField(name="MCYPassbookItems")
    private List<MCYPassbookItems> mCYPassbookItems;
    
	@JSONField(name="SingleCcyPassbookItems")
    private List<SingleCcyPassbookItems> singleCcyPassbookItems;
    
	@JSONField(name="MorePassbookItemInd")
    private String morePassbookItemInd;

	@Override
	public String getServiceID() {
		return "FN2001";
	}
}
