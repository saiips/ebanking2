package com.dsb.eb2.backOffice.connect.emsMsg.nf1615;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

/**
 * NF1615 respnse Data
 *
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"accountNumber","depositNumber","dateOpened","dateClosed","entityCode","statusCode","holdCode","noOfAcctOwner","accountOwnerInfo","cCY","principal","depositTerm","depositDurationType","effectiveDate","matureDate","signatureNumber","maturityInterest","totalPrincipalInterest","interestRate","spreadRate","spotDeal","easiGainInfo","swapInfo","autoRenewalInfo","additionalInterestInfo","maximumMarkupRate","floatingSpreadRate","noOfIntRateHistoryDetails","intRateHistoryDetails","withdrawalInfo","withdrawalMeans","renewalInfo","easyGainInfo","promotionIndicator","jointName1","jointName2","newSignatureNumber","addressCode","accountShortName","campaignCode","trustOrClientIndicator","printedIndicator","printStatus","confirmationPickUpBranch","narrative","additionalHoldCodeInfo","sourceOfFundCash","sourceOfFundTransfer","sourceOfFundCheque","sourceOfFundOther","destinationOfFundCash","destinationOfFundTransfer","destinationOfFundCheque","destinationOfFundOther","creationSoruceSystem","upliftSoruceSystem","mailingIndicator","swapSpecialInterest","privilegedInterestRateFlag","privilegedMonthlyInterestPaymentFlag","privilegedInterestPaymentEffectiveDate","privilegedNumberOfEarlyRedeemedInterest","existingFund","newFund","markupReason","hiborLiborRate","previousFDAccount","cLPGDInterestRateIndicator","mCBInterestFlag","mCBInterestRate","productType"})
public class NF1615RepData extends FrmData
{

	public NF1615RepData(){}

	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1615";
	}
	
	@JSONField(name="AccountNumber")
	private String accountNumber;

	@JSONField(name="DepositNumber")
	private String depositNumber;

	@JSONField(name="DateOpened")
	private String dateOpened;

	@JSONField(name="DateClosed")
	private String dateClosed;

	@JSONField(name="EntityCode")
	private String entityCode;

	@JSONField(name="StatusCode")
	private String statusCode;

	@JSONField(name="HoldCode")
	private String holdCode;

	@JSONField(name="NoOfAcctOwner")
	private String noOfAcctOwner;

	@JSONField(name="AccountOwnerInfo")
	private List <AccountOwnerInfo> accountOwnerInfo;

	@JSONField(name="CCY")
	private String cCY;

	@JSONField(name="Principal")
	private String principal;

	@JSONField(name="DepositTerm")
	private String depositTerm;

	@JSONField(name="DepositDurationType")
	private String depositDurationType;

	@JSONField(name="EffectiveDate")
	private String effectiveDate;

	@JSONField(name="MatureDate")
	private String matureDate;

	@JSONField(name="SignatureNumber")
	private String signatureNumber;

	@JSONField(name="MaturityInterest")
	private String maturityInterest;

	@JSONField(name="TotalPrincipalInterest")
	private String totalPrincipalInterest;

	@JSONField(name="InterestRate")
	private String interestRate;

	@JSONField(name="SpreadRate")
	private String spreadRate;

	@JSONField(name="SpotDeal")
	private String spotDeal;
	
	@JSONField(name="EasiGainInfo")
	private List <EasiGainInfo> easiGainInfo;

	@JSONField(name="SwapInfo")
	private List <SwapInfo> swapInfo;

	@JSONField(name="AutoRenewalInfo")
	private List <AutoRenewalInfo> autoRenewalInfo;

	@JSONField(name="AdditionalInterestInfo")
	private List <AdditionalInterestInfo> additionalInterestInfo;

	@JSONField(name="MaximumMarkupRate")
	private String maximumMarkupRate;

	@JSONField(name="FloatingSpreadRate")
	private String floatingSpreadRate;

	@JSONField(name="NoOfIntRateHistoryDetails")
	private String noOfIntRateHistoryDetails;

	@JSONField(name="IntRateHistoryDetails")
	private List <IntRateHistoryDetails> intRateHistoryDetails;

	@JSONField(name="WithdrawalInfo")
	private List <WithdrawalInfo> withdrawalInfo;

	@JSONField(name="WithdrawalMeans")
	private List <WithdrawalMeans> withdrawalMeans;

	@JSONField(name="RenewalInfo")
	private List <RenewalInfo> renewalInfo;

	@JSONField(name="")
	private List <EasyGainInfo> easyGainInfo;

	@JSONField(name="PromotionIndicator")
	private String promotionIndicator;

	@JSONField(name="JointName1")
	private String jointName1;

	@JSONField(name="JointName2")
	private String jointName2;

	@JSONField(name="NewSignatureNumber")
	private String newSignatureNumber;

	@JSONField(name="AddressCode")
	private String addressCode;
	
	@JSONField(name="AccountShortName")
	private String accountShortName;

	@JSONField(name="CampaignCode")
	private String campaignCode;

	@JSONField(name="TrustOrClientIndicator")
	private String trustOrClientIndicator;

	@JSONField(name="PrintedIndicator")
	private String printedIndicator;

	@JSONField(name="PrintStatus")
	private String printStatus;

	@JSONField(name="ConfirmationPickUpBranch")
	private String confirmationPickUpBranch;

	@JSONField(name="Narrative")
	private String narrative;

	@JSONField(name="AdditionalHoldCodeInfo")
	private List <AdditionalHoldCodeInfo> additionalHoldCodeInfo;

	@JSONField(name="SourceOfFundCash")
	private List <SourceOfFundCash> sourceOfFundCash;

	@JSONField(name="SourceOfFundTransfer")
	private List <SourceOfFundTransfer> sourceOfFundTransfer;

	@JSONField(name="SourceOfFundCheque")
	private List <SourceOfFundCheque> sourceOfFundCheque;

	@JSONField(name="SourceOfFundOther")
	private List <SourceOfFundOther> sourceOfFundOther;

	@JSONField(name="DestinationOfFundCash")
	private List <DestinationOfFundCash> destinationOfFundCash;

	@JSONField(name="DestinationOfFundTransfer")
	private List <DestinationOfFundTransfer> destinationOfFundTransfer;

	@JSONField(name="DestinationOfFundCheque")
	private List <DestinationOfFundCheque> destinationOfFundCheque;

	@JSONField(name="DestinationOfFundOther")
	private List <DestinationOfFundOther> destinationOfFundOther;

	@JSONField(name="CreationSoruceSystem")
	private String creationSoruceSystem;

	@JSONField(name="UpliftSoruceSystem")
	private String upliftSoruceSystem;

	@JSONField(name="MailingIndicator")
	private String mailingIndicator;

	@JSONField(name="SwapSpecialInterest")
	private String swapSpecialInterest;

	@JSONField(name="PrivilegedInterestRateFlag")
	private String privilegedInterestRateFlag;

	@JSONField(name="PrivilegedMonthlyInterestPaymentFlag")
	private String privilegedMonthlyInterestPaymentFlag;

	@JSONField(name="PrivilegedInterestPaymentEffectiveDate")
	private String privilegedInterestPaymentEffectiveDate;

	@JSONField(name="PrivilegedNumberOfEarlyRedeemedInterest")
	private String privilegedNumberOfEarlyRedeemedInterest;

	@JSONField(name="ExistingFund")
	private String existingFund;

	@JSONField(name="NewFund")
	private String newFund;

	@JSONField(name="MarkupReason")
	private String markupReason;

	@JSONField(name="HiborLiborRate")
	private String hiborLiborRate;

	@JSONField(name="PreviousFDAccount")
	private List <PreviousFDAccount> previousFDAccount;

	@JSONField(name="CLPGDInterestRateIndicator")
	private String cLPGDInterestRateIndicator;

	@JSONField(name="MCBInterestFlag")
	private String mCBInterestFlag;

	@JSONField(name="MCBInterestRate")
	private String mCBInterestRate;

	@JSONField(name="ProductType")
	private String productType;

    @XmlElement(name = "AccountNumber")
	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

    @XmlElement(name = "DepositNumber")
	public String getDepositNumber() {
		return depositNumber;
	}

	public void setDepositNumber(String depositNumber) {
		this.depositNumber = depositNumber;
	}

    @XmlElement(name = "DateOpened")
	public String getDateOpened() {
		return dateOpened;
	}

	public void setDateOpened(String dateOpened) {
		this.dateOpened = dateOpened;
	}

    @XmlElement(name = "DateClosed")
	public String getDateClosed() {
		return dateClosed;
	}

	public void setDateClosed(String dateClosed) {
		this.dateClosed = dateClosed;
	}

    @XmlElement(name = "EntityCode")
	public String getEntityCode() {
		return entityCode;
	}

	public void setEntityCode(String entityCode) {
		this.entityCode = entityCode;
	}

    @XmlElement(name = "StatusCode")
	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

    @XmlElement(name = "HoldCode")
	public String getHoldCode() {
		return holdCode;
	}

	public void setHoldCode(String holdCode) {
		this.holdCode = holdCode;
	}

    @XmlElement(name = "NoOfAcctOwner")
	public String getNoOfAcctOwner() {
		return noOfAcctOwner;
	}

	public void setNoOfAcctOwner(String noOfAcctOwner) {
		this.noOfAcctOwner = noOfAcctOwner;
	}

    @XmlElement(name = "AccountOwnerInfo")
	public List<AccountOwnerInfo> getAccountOwnerInfo() {
		return accountOwnerInfo;
	}

	public void setAccountOwnerInfo(List<AccountOwnerInfo> accountOwnerInfo) {
		this.accountOwnerInfo = accountOwnerInfo;
	}

    @XmlElement(name = "CCY")
	public String getcCY() {
		return cCY;
	}

	public void setcCY(String cCY) {
		this.cCY = cCY;
	}

    @XmlElement(name = "Principal")
	public String getPrincipal() {
		return principal;
	}

	public void setPrincipal(String principal) {
		this.principal = principal;
	}

    @XmlElement(name = "DepositTerm")
	public String getDepositTerm() {
		return depositTerm;
	}

	public void setDepositTerm(String depositTerm) {
		this.depositTerm = depositTerm;
	}

    @XmlElement(name = "DepositDurationType")
	public String getDepositDurationType() {
		return depositDurationType;
	}

	public void setDepositDurationType(String depositDurationType) {
		this.depositDurationType = depositDurationType;
	}

    @XmlElement(name = "EffectiveDate")
	public String getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

    @XmlElement(name = "MatureDate")
	public String getMatureDate() {
		return matureDate;
	}

	public void setMatureDate(String matureDate) {
		this.matureDate = matureDate;
	}

    @XmlElement(name = "SignatureNumber")
	public String getSignatureNumber() {
		return signatureNumber;
	}

	public void setSignatureNumber(String signatureNumber) {
		this.signatureNumber = signatureNumber;
	}

    @XmlElement(name = "MaturityInterest")
	public String getMaturityInterest() {
		return maturityInterest;
	}

	public void setMaturityInterest(String maturityInterest) {
		this.maturityInterest = maturityInterest;
	}

    @XmlElement(name = "TotalPrincipalInterest")
	public String getTotalPrincipalInterest() {
		return totalPrincipalInterest;
	}

	public void setTotalPrincipalInterest(String totalPrincipalInterest) {
		this.totalPrincipalInterest = totalPrincipalInterest;
	}

    @XmlElement(name = "InterestRate")
	public String getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(String interestRate) {
		this.interestRate = interestRate;
	}

    @XmlElement(name = "SpreadRate")
	public String getSpreadRate() {
		return spreadRate;
	}

	public void setSpreadRate(String spreadRate) {
		this.spreadRate = spreadRate;
	}

    @XmlElement(name = "SpotDeal")
	public String getSpotDeal() {
		return spotDeal;
	}

	public void setSpotDeal(String spotDeal) {
		this.spotDeal = spotDeal;
	}

    @XmlElement(name = "EasiGainInfo")
	public List<EasiGainInfo> getEasiGainInfo() {
		return easiGainInfo;
	}

	public void setEasiGainInfo(List<EasiGainInfo> easiGainInfo) {
		this.easiGainInfo = easiGainInfo;
	}

    @XmlElement(name = "SwapInfo")
	public List<SwapInfo> getSwapInfo() {
		return swapInfo;
	}

	public void setSwapInfo(List<SwapInfo> swapInfo) {
		this.swapInfo = swapInfo;
	}

    @XmlElement(name = "AutoRenewalInfo")
	public List<AutoRenewalInfo> getAutoRenewalInfo() {
		return autoRenewalInfo;
	}

	public void setAutoRenewalInfo(List<AutoRenewalInfo> autoRenewalInfo) {
		this.autoRenewalInfo = autoRenewalInfo;
	}

    @XmlElement(name = "AdditionalInterestInfo")
	public List<AdditionalInterestInfo> getAdditionalInterestInfo() {
		return additionalInterestInfo;
	}

	public void setAdditionalInterestInfo(List<AdditionalInterestInfo> additionalInterestInfo) {
		this.additionalInterestInfo = additionalInterestInfo;
	}

    @XmlElement(name = "MaximumMarkupRate")
	public String getMaximumMarkupRate() {
		return maximumMarkupRate;
	}

	public void setMaximumMarkupRate(String maximumMarkupRate) {
		this.maximumMarkupRate = maximumMarkupRate;
	}

    @XmlElement(name = "FloatingSpreadRate")
	public String getFloatingSpreadRate() {
		return floatingSpreadRate;
	}

	public void setFloatingSpreadRate(String floatingSpreadRate) {
		this.floatingSpreadRate = floatingSpreadRate;
	}

    @XmlElement(name = "NoOfIntRateHistoryDetails")
	public String getNoOfIntRateHistoryDetails() {
		return noOfIntRateHistoryDetails;
	}

	public void setNoOfIntRateHistoryDetails(String noOfIntRateHistoryDetails) {
		this.noOfIntRateHistoryDetails = noOfIntRateHistoryDetails;
	}

    @XmlElement(name = "IntRateHistoryDetails")
	public List<IntRateHistoryDetails> getIntRateHistoryDetails() {
		return intRateHistoryDetails;
	}

	public void setIntRateHistoryDetails(List<IntRateHistoryDetails> intRateHistoryDetails) {
		this.intRateHistoryDetails = intRateHistoryDetails;
	}

    @XmlElement(name = "WithdrawalInfo")
	public List<WithdrawalInfo> getWithdrawalInfo() {
		return withdrawalInfo;
	}

	public void setWithdrawalInfo(List<WithdrawalInfo> withdrawalInfo) {
		this.withdrawalInfo = withdrawalInfo;
	}

    @XmlElement(name = "WithdrawalMeans")
	public List<WithdrawalMeans> getWithdrawalMeans() {
		return withdrawalMeans;
	}

	public void setWithdrawalMeans(List<WithdrawalMeans> withdrawalMeans) {
		this.withdrawalMeans = withdrawalMeans;
	}

    @XmlElement(name = "RenewalInfo")
	public List<RenewalInfo> getRenewalInfo() {
		return renewalInfo;
	}

	public void setRenewalInfo(List<RenewalInfo> renewalInfo) {
		this.renewalInfo = renewalInfo;
	}

    @XmlElement(name = "EasyGainInfo")
	public List<EasyGainInfo> getEasyGainInfo() {
		return easyGainInfo;
	}

	public void setEasyGainInfo(List<EasyGainInfo> easyGainInfo) {
		this.easyGainInfo = easyGainInfo;
	}

    @XmlElement(name = "PromotionIndicator")
	public String getPromotionIndicator() {
		return promotionIndicator;
	}

	public void setPromotionIndicator(String promotionIndicator) {
		this.promotionIndicator = promotionIndicator;
	}

    @XmlElement(name = "JointName1")
	public String getJointName1() {
		return jointName1;
	}

	public void setJointName1(String jointName1) {
		this.jointName1 = jointName1;
	}

    @XmlElement(name = "JointName2")
	public String getJointName2() {
		return jointName2;
	}

	public void setJointName2(String jointName2) {
		this.jointName2 = jointName2;
	}

    @XmlElement(name = "NewSignatureNumber")
	public String getNewSignatureNumber() {
		return newSignatureNumber;
	}

	public void setNewSignatureNumber(String newSignatureNumber) {
		this.newSignatureNumber = newSignatureNumber;
	}

    @XmlElement(name = "AddressCode")
	public String getAddressCode() {
		return addressCode;
	}

	public void setAddressCode(String addressCode) {
		this.addressCode = addressCode;
	}

    @XmlElement(name = "AccountShortName")
	public String getAccountShortName() {
		return accountShortName;
	}

	public void setAccountShortName(String accountShortName) {
		this.accountShortName = accountShortName;
	}

    @XmlElement(name = "CampaignCode")
	public String getCampaignCode() {
		return campaignCode;
	}

	public void setCampaignCode(String campaignCode) {
		this.campaignCode = campaignCode;
	}

    @XmlElement(name = "TrustOrClientIndicator")
	public String getTrustOrClientIndicator() {
		return trustOrClientIndicator;
	}

	public void setTrustOrClientIndicator(String trustOrClientIndicator) {
		this.trustOrClientIndicator = trustOrClientIndicator;
	}

    @XmlElement(name = "PrintedIndicator")
	public String getPrintedIndicator() {
		return printedIndicator;
	}

	public void setPrintedIndicator(String printedIndicator) {
		this.printedIndicator = printedIndicator;
	}

    @XmlElement(name = "PrintStatus")
	public String getPrintStatus() {
		return printStatus;
	}

	public void setPrintStatus(String printStatus) {
		this.printStatus = printStatus;
	}

    @XmlElement(name = "ConfirmationPickUpBranch")
	public String getConfirmationPickUpBranch() {
		return confirmationPickUpBranch;
	}

	public void setConfirmationPickUpBranch(String confirmationPickUpBranch) {
		this.confirmationPickUpBranch = confirmationPickUpBranch;
	}

    @XmlElement(name = "Narrative")
	public String getNarrative() {
		return narrative;
	}

	public void setNarrative(String narrative) {
		this.narrative = narrative;
	}

    @XmlElement(name = "AdditionalHoldCodeInfo")
	public List<AdditionalHoldCodeInfo> getAdditionalHoldCodeInfo() {
		return additionalHoldCodeInfo;
	}

	public void setAdditionalHoldCodeInfo(List<AdditionalHoldCodeInfo> additionalHoldCodeInfo) {
		this.additionalHoldCodeInfo = additionalHoldCodeInfo;
	}

    @XmlElement(name = "SourceOfFundCash")
	public List<SourceOfFundCash> getSourceOfFundCash() {
		return sourceOfFundCash;
	}

	public void setSourceOfFundCash(List<SourceOfFundCash> sourceOfFundCash) {
		this.sourceOfFundCash = sourceOfFundCash;
	}

    @XmlElement(name = "SourceOfFundTransfer")
	public List<SourceOfFundTransfer> getSourceOfFundTransfer() {
		return sourceOfFundTransfer;
	}

	public void setSourceOfFundTransfer(List<SourceOfFundTransfer> sourceOfFundTransfer) {
		this.sourceOfFundTransfer = sourceOfFundTransfer;
	}

    @XmlElement(name = "SourceOfFundCheque")
	public List<SourceOfFundCheque> getSourceOfFundCheque() {
		return sourceOfFundCheque;
	}

	public void setSourceOfFundCheque(List<SourceOfFundCheque> sourceOfFundCheque) {
		this.sourceOfFundCheque = sourceOfFundCheque;
	}

    @XmlElement(name = "SourceOfFundOther")
	public List<SourceOfFundOther> getSourceOfFundOther() {
		return sourceOfFundOther;
	}

	public void setSourceOfFundOther(List<SourceOfFundOther> sourceOfFundOther) {
		this.sourceOfFundOther = sourceOfFundOther;
	}

    @XmlElement(name = "DestinationOfFundCash")
	public List<DestinationOfFundCash> getDestinationOfFundCash() {
		return destinationOfFundCash;
	}

	public void setDestinationOfFundCash(List<DestinationOfFundCash> destinationOfFundCash) {
		this.destinationOfFundCash = destinationOfFundCash;
	}

    @XmlElement(name = "DestinationOfFundTransfer")
	public List<DestinationOfFundTransfer> getDestinationOfFundTransfer() {
		return destinationOfFundTransfer;
	}

	public void setDestinationOfFundTransfer(List<DestinationOfFundTransfer> destinationOfFundTransfer) {
		this.destinationOfFundTransfer = destinationOfFundTransfer;
	}

    @XmlElement(name = "DestinationOfFundCheque")
	public List<DestinationOfFundCheque> getDestinationOfFundCheque() {
		return destinationOfFundCheque;
	}

	public void setDestinationOfFundCheque(List<DestinationOfFundCheque> destinationOfFundCheque) {
		this.destinationOfFundCheque = destinationOfFundCheque;
	}

    @XmlElement(name = "DestinationOfFundOther")
	public List<DestinationOfFundOther> getDestinationOfFundOther() {
		return destinationOfFundOther;
	}

	public void setDestinationOfFundOther(List<DestinationOfFundOther> destinationOfFundOther) {
		this.destinationOfFundOther = destinationOfFundOther;
	}

    @XmlElement(name = "CreationSoruceSystem")
	public String getCreationSoruceSystem() {
		return creationSoruceSystem;
	}

	public void setCreationSoruceSystem(String creationSoruceSystem) {
		this.creationSoruceSystem = creationSoruceSystem;
	}

    @XmlElement(name = "UpliftSoruceSystem")
	public String getUpliftSoruceSystem() {
		return upliftSoruceSystem;
	}

	public void setUpliftSoruceSystem(String upliftSoruceSystem) {
		this.upliftSoruceSystem = upliftSoruceSystem;
	}

    @XmlElement(name = "MailingIndicator")
	public String getMailingIndicator() {
		return mailingIndicator;
	}

	public void setMailingIndicator(String mailingIndicator) {
		this.mailingIndicator = mailingIndicator;
	}

    @XmlElement(name = "SwapSpecialInterest")
	public String getSwapSpecialInterest() {
		return swapSpecialInterest;
	}

	public void setSwapSpecialInterest(String swapSpecialInterest) {
		this.swapSpecialInterest = swapSpecialInterest;
	}

    @XmlElement(name = "PrivilegedInterestRateFlag")
	public String getPrivilegedInterestRateFlag() {
		return privilegedInterestRateFlag;
	}

	public void setPrivilegedInterestRateFlag(String privilegedInterestRateFlag) {
		this.privilegedInterestRateFlag = privilegedInterestRateFlag;
	}

    @XmlElement(name = "PrivilegedMonthlyInterestPaymentFlag")
	public String getPrivilegedMonthlyInterestPaymentFlag() {
		return privilegedMonthlyInterestPaymentFlag;
	}

	public void setPrivilegedMonthlyInterestPaymentFlag(String privilegedMonthlyInterestPaymentFlag) {
		this.privilegedMonthlyInterestPaymentFlag = privilegedMonthlyInterestPaymentFlag;
	}

    @XmlElement(name = "PrivilegedInterestPaymentEffectiveDate")
	public String getPrivilegedInterestPaymentEffectiveDate() {
		return privilegedInterestPaymentEffectiveDate;
	}

	public void setPrivilegedInterestPaymentEffectiveDate(String privilegedInterestPaymentEffectiveDate) {
		this.privilegedInterestPaymentEffectiveDate = privilegedInterestPaymentEffectiveDate;
	}

    @XmlElement(name = "PrivilegedNumberOfEarlyRedeemedInterest")
	public String getPrivilegedNumberOfEarlyRedeemedInterest() {
		return privilegedNumberOfEarlyRedeemedInterest;
	}

	public void setPrivilegedNumberOfEarlyRedeemedInterest(String privilegedNumberOfEarlyRedeemedInterest) {
		this.privilegedNumberOfEarlyRedeemedInterest = privilegedNumberOfEarlyRedeemedInterest;
	}

    @XmlElement(name = "ExistingFund")
	public String getExistingFund() {
		return existingFund;
	}

	public void setExistingFund(String existingFund) {
		this.existingFund = existingFund;
	}

    @XmlElement(name = "NewFund")
	public String getNewFund() {
		return newFund;
	}

	public void setNewFund(String newFund) {
		this.newFund = newFund;
	}

    @XmlElement(name = "MarkupReason")
	public String getMarkupReason() {
		return markupReason;
	}

	public void setMarkupReason(String markupReason) {
		this.markupReason = markupReason;
	}

    @XmlElement(name = "HiborLiborRate")
	public String getHiborLiborRate() {
		return hiborLiborRate;
	}

	public void setHiborLiborRate(String hiborLiborRate) {
		this.hiborLiborRate = hiborLiborRate;
	}

    @XmlElement(name = "PreviousFDAccount")
	public List<PreviousFDAccount> getPreviousFDAccount() {
		return previousFDAccount;
	}

	public void setPreviousFDAccount(List<PreviousFDAccount> previousFDAccount) {
		this.previousFDAccount = previousFDAccount;
	}

    @XmlElement(name = "CLPGDInterestRateIndicator")
	public String getcLPGDInterestRateIndicator() {
		return cLPGDInterestRateIndicator;
	}

	public void setcLPGDInterestRateIndicator(String cLPGDInterestRateIndicator) {
		this.cLPGDInterestRateIndicator = cLPGDInterestRateIndicator;
	}

    @XmlElement(name = "MCBInterestFlag")
	public String getmCBInterestFlag() {
		return mCBInterestFlag;
	}

	public void setmCBInterestFlag(String mCBInterestFlag) {
		this.mCBInterestFlag = mCBInterestFlag;
	}

    @XmlElement(name = "MCBInterestRate")
	public String getmCBInterestRate() {
		return mCBInterestRate;
	}

	public void setmCBInterestRate(String mCBInterestRate) {
		this.mCBInterestRate = mCBInterestRate;
	}

    @XmlElement(name = "ProductType")
	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}
	
	
	

}
