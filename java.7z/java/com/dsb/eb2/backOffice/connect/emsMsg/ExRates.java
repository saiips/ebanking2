package com.dsb.eb2.backOffice.connect.emsMsg;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"preferredRate","minProfitRate","costRate"})
public class ExRates
{
	public ExRates(){}
	
	private List<String> preferredRate;
	
	private String minProfitRate = "";
	
	private String costRate = "";
	
	@XmlElement(name = "PreferredRate")
	public List<String> getPreferredRate()
	{
		return preferredRate;
	}

	public void setPreferredRate(List<String> preferredRate)
	{
		this.preferredRate = preferredRate;
	}

	@XmlElement(name = "MinProfitRate")
	public String getMinProfitRate()
	{
		return minProfitRate;
	}

	public void setMinProfitRate(String minProfitRate)
	{
		this.minProfitRate = minProfitRate;
	}

	@XmlElement(name = "CostRate")
	public String getCostRate()
	{
		return costRate;
	}

	public void setCostRate(String costRate)
	{
		this.costRate = costRate;
	}
	
}
