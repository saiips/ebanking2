package com.dsb.eb2.backOffice.connect.emsMsg.nf1503;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"acctNum","acctShortName","hostTxnSeqNum"})
public class NF1503RepData  extends FrmData
{
    
	public NF1503RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1503";
	}
	
	@JSONField(name="AcctNum")
	private String acctNum;
	
	@JSONField(name="AcctShortName")
	private String acctShortName;
	
	@JSONField(name="HostTxnSeqNum")
	private String hostTxnSeqNum;

    @XmlElement(name = "AcctNum")
	public String getAcctNum() {
		return acctNum;
	}

	public void setAcctNum(String acctNum) {
		this.acctNum = acctNum;
	}

    @XmlElement(name = "AcctShortName")
	public String getAcctShortName() {
		return acctShortName;
	}

	public void setAcctShortName(String acctShortName) {
		this.acctShortName = acctShortName;
	}

    @XmlElement(name = "HostTxnSeqNum")
	public String getHostTxnSeqNum() {
		return hostTxnSeqNum;
	}

	public void setHostTxnSeqNum(String hostTxnSeqNum) {
		this.hostTxnSeqNum = hostTxnSeqNum;
	}
	
}


