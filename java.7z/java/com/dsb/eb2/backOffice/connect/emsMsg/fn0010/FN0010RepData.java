package com.dsb.eb2.backOffice.connect.emsMsg.fn0010;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

public class FN0010RepData
    extends FrmData
{

	public FN0010RepData() {}

	@Override
    public String getServiceID()
    {
        return "FN0010";
    }
	
	@JSONField(name="DebitAccountNumber")
	private String debitAccountNumber;
	
	@JSONField(name="HostTxSequenceNumber")
	private String hostTxSequenceNumber;


}
