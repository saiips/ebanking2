package com.dsb.eb2.backOffice.connect.emsMsg.nf1111;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class TxDetail {

	public TxDetail() {
	}

	@JSONField(name = "TxDate")
	private String txDate;

	@JSONField(name = "TxTime")
	private String txTime;

	@JSONField(name = "TxDesc1")
	private String txDesc1;

	@JSONField(name = "OverrideInd")
	private String overrideInd;

	@JSONField(name = "EcInd")
	private String ecInd;

	@JSONField(name = "ChequeNum")
	private String chequeNum;

	@JSONField(name = "CurrencyCode")
	private String currencyCode;

	@JSONField(name = "Amount")
	private String amount;

	@JSONField(name = "ExchangeRate")
	private String exchangeRate;

	@JSONField(name = "SystemCode")
	private String systemCode;

	@JSONField(name = "TxCodeNature")
	private String txCodeNature;

	@JSONField(name = "TxCode")
	private String txCode;

	@JSONField(name = "TxDesc2")
	private String txDesc2;

	@JSONField(name = "AmountType")
	private String amountType;

	@JSONField(name = "Narrative")
	private String narrative;

	@JSONField(name = "HostSeqNum")
	private String hostSeqNum;

	@JSONField(name = "Branch")
	private String branch;

	@JSONField(name = "TellerID")
	private String tellerID;

	@JSONField(name = "BalanceBoughtForward")
	private String balanceBoughtForward;

	@JSONField(name = "filler1")
	private String Filler1;

}
