package com.dsb.eb2.backOffice.connect.emsMsg.nf1615;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"aPSpecialInstructionLine"})
public class APSpecialInstruction{
	
	@JSONField(name="APSpecialInstructionLine")
	private String aPSpecialInstructionLine;

	public APSpecialInstruction() {}

    @XmlElement(name = "APSpecialInstructionLine")
	public String getaPSpecialInstructionLine() {
		return aPSpecialInstructionLine;
	}

	public void setaPSpecialInstructionLine(String aPSpecialInstructionLine) {
		this.aPSpecialInstructionLine = aPSpecialInstructionLine;
	}
	
	

}
