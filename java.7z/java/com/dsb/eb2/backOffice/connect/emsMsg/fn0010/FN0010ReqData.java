package com.dsb.eb2.backOffice.connect.emsMsg.fn0010;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class FN0010ReqData extends FrmData
{
	public FN0010ReqData() {}
	
	@JSONField(serialize=false)
    @Override
    public String getServiceID()
    {
        return "FN0010";
    }
	
	@JSONField(name="TelephoneUserID")
	private String telephoneUserID;
	
	@JSONField(name="DebitAccountNumber")
	private String  debitAccountNumber;
	
	@JSONField(name="TxAmount")
	private String txAmount;
	
	@JSONField(name="PaymentAccount")
	private String paymentAccount;
	
	@JSONField(name="PaymentType")
	private String paymentType;
	
	@JSONField(name="LogicalTerminalIdentity")
	private String logicalTerminalIdentity;
	
	@JSONField(name="GLBranchCode")
	private String gLBranchCode;
	
	@JSONField(name="GLNumber")
	private String  gLNumber;

    
}
