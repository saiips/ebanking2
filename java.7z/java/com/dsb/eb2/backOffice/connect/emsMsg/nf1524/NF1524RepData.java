package com.dsb.eb2.backOffice.connect.emsMsg.nf1524;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"customerNumber","addressLine1","addressLine2",
		"addressLine3","addressLine4","zipCode","employerName",
		"homePhoneNumber","workNumber","pos","mobilePhoneNumber","pagerNumber","emailAddress",
		"billingCycle","memoLine1","memoLine2","suppressStatementFlag","overlimitOptOutFlag","filler",
		"lastStmtFeeWaiverFlag","currentStmtFeeWaiverFlag","currentStmtFeeWaiverFlagMainDate"})
public class NF1524RepData  extends FrmData
{
	

	public NF1524RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1524";
	}
	
	@JSONField(name="CustomerNumber")
	private String customerNumber;
	
	@JSONField(name="AddressLine1")
	private String addressLine1;
	
	@JSONField(name="AddressLine2")
	private String addressLine2;
	
	@JSONField(name="AddressLine3")
	private String addressLine3;
	
	@JSONField(name="AddressLine4")
	private String addressLine4;
	
	@JSONField(name="ZipCode")
	private String zipCode;
	
	@JSONField(name="EmployerName")
	private String employerName;
	
	@JSONField(name="HomePhoneNumber")
	private String homePhoneNumber;
	
	@JSONField(name="WorkNumber")
	private String workNumber;
	
	@JSONField(name="Pos")
	private String pos;
	
	@JSONField(name="MobilePhoneNumber")
	private String mobilePhoneNumber;
	
	@JSONField(name="PagerNumber")
	private String pagerNumber;
	
	@JSONField(name="EmailAddress")
	private String emailAddress;
	
	@JSONField(name="BillingCycle")
	private String billingCycle;
	
	@JSONField(name="MemoLine1")
	private String memoLine1;
	
	@JSONField(name="MemoLine2")
	private String memoLine2;
	
	@JSONField(name="SuppressStatementFlag")
	private String suppressStatementFlag;
	
	@JSONField(name="OverlimitOptOutFlag")
	private String overlimitOptOutFlag;
	
	@JSONField(name="LastStmtFeeWaiverFlag")
	private String lastStmtFeeWaiverFlag;
	
	@JSONField(name="CurrentStmtFeeWaiverFlag")
	private String currentStmtFeeWaiverFlag;
	
	@JSONField(name="CurrentStmtFeeWaiverFlagMainDate")
	private String currentStmtFeeWaiverFlagMainDate;

	
	@JSONField(name="Filler")
	private String filler;

	@XmlElement(name = "CustomerNumber")
	public String getCustomerNumber() {
		return customerNumber;
	}

	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}

	@XmlElement(name = "AddressLine1")
	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	@XmlElement(name = "AddressLine2")
	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	@XmlElement(name = "AddressLine3")
	public String getAddressLine3() {
		return addressLine3;
	}

	public void setAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
	}

	@XmlElement(name = "AddressLine4")
	public String getAddressLine4() {
		return addressLine4;
	}

	public void setAddressLine4(String addressLine4) {
		this.addressLine4 = addressLine4;
	}

	@XmlElement(name = "ZipCode")
	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	@XmlElement(name = "EmployerName")
	public String getEmployerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	@XmlElement(name = "HomePhoneNumber")
	public String getHomePhoneNumber() {
		return homePhoneNumber;
	}

	public void setHomePhoneNumber(String homePhoneNumber) {
		this.homePhoneNumber = homePhoneNumber;
	}
	
	@XmlElement(name = "WorkNumber")
	public String getWorkNumber() {
		return workNumber;
	}

	public void setWorkNumber(String workNumber) {
		this.workNumber = workNumber;
	}

	@XmlElement(name = "Pos")
	public String getPos() {
		return pos;
	}

	public void setPos(String pos) {
		this.pos = pos;
	}

	@XmlElement(name = "MobilePhoneNumber")
	public String getMobilePhoneNumber() {
		return mobilePhoneNumber;
	}

	public void setMobilePhoneNumber(String mobilePhoneNumber) {
		this.mobilePhoneNumber = mobilePhoneNumber;
	}

	@XmlElement(name = "PagerNumber")
	public String getPagerNumber() {
		return pagerNumber;
	}

	public void setPagerNumber(String pagerNumber) {
		this.pagerNumber = pagerNumber;
	}

	@XmlElement(name = "EmailAddress")
	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	@XmlElement(name = "BillingCycle")
	public String getBillingCycle() {
		return billingCycle;
	}

	public void setBillingCycle(String billingCycle) {
		this.billingCycle = billingCycle;
	}

	@XmlElement(name = "MemoLine1")
	public String getMemoLine1() {
		return memoLine1;
	}

	public void setMemoLine1(String memoLine1) {
		this.memoLine1 = memoLine1;
	}

	@XmlElement(name = "MemoLine2")
	public String getMemoLine2() {
		return memoLine2;
	}

	public void setMemoLine2(String memoLine2) {
		this.memoLine2 = memoLine2;
	}

	@XmlElement(name = "SuppressStatementFlag")
	public String getSuppressStatementFlag() {
		return suppressStatementFlag;
	}

	public void setSuppressStatementFlag(String suppressStatementFlag) {
		this.suppressStatementFlag = suppressStatementFlag;
	}
	
	@XmlElement(name = "OverlimitOptOutFlag")
	public String getOverlimitOptOutFlag() {
		return overlimitOptOutFlag;
	}

	public void setOverlimitOptOutFlag(String overlimitOptOutFlag) {
		this.overlimitOptOutFlag = overlimitOptOutFlag;
	}

	@XmlElement(name = "Filler")
	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	@XmlElement(name = "LastStmtFeeWaiverFlag")
	public String getLastStmtFeeWaiverFlag() {
		return lastStmtFeeWaiverFlag;
	}

	public void setLastStmtFeeWaiverFlag(String lastStmtFeeWaiverFlag) {
		this.lastStmtFeeWaiverFlag = lastStmtFeeWaiverFlag;
	}
	
	@XmlElement(name = "CurrentStmtFeeWaiverFlag")
	public String getCurrentStmtFeeWaiverFlag() {
		return currentStmtFeeWaiverFlag;
	}

	public void setCurrentStmtFeeWaiverFlag(String currentStmtFeeWaiverFlag) {
		this.currentStmtFeeWaiverFlag = currentStmtFeeWaiverFlag;
	}
	
	@XmlElement(name = "CurrentStmtFeeWaiverFlagMainDate")
	public String getCurrentStmtFeeWaiverFlagMainDate() {
		return currentStmtFeeWaiverFlagMainDate;
	}

	public void setCurrentStmtFeeWaiverFlagMainDate(String currentStmtFeeWaiverFlagMainDate) {
		this.currentStmtFeeWaiverFlagMainDate = currentStmtFeeWaiverFlagMainDate;
	}
	
	
	
}
