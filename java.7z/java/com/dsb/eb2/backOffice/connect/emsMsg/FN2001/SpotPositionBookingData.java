package com.dsb.eb2.backOffice.connect.emsMsg.FN2001;

import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class SpotPositionBookingData {

	@JSONField(name="OverrideFlag")
    private String overrideFlag;
    
	@JSONField(name="Remarks")
    private String remarks;
    
	@JSONField(name="ExRateType")
    private String exRateType;
    
	@JSONField(name="CNYTransClass")
    private String cNYTransClass;
	
	@JSONField(name="AcctOfficerCode")
    private String acctOfficerCode;
    
	@JSONField(name="AcctOfficerSubCode")
    private String acctOfficerSubCode;
    
	@JSONField(name="Division")
    private String division;
    
	
	@JSONField(name="Region")
    private String region;
   
	
	@JSONField(name="StaffInd")
    private String staffInd;
   
	
	@JSONField(name="VIPFlag")
    private String vIPFlag;
   
	
	@JSONField(name="ExRateTier")
    private String exRateTier;
   
	
	@JSONField(name="ExRatesT1")
    private List<ExRatesT1> exRatesT1;
   
	
	@JSONField(name="ExRatesT2")
    private List<ExRatesT2> exRatesT2;
   
	
	   
	
}
