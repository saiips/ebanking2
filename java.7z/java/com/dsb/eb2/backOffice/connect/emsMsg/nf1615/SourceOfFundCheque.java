package com.dsb.eb2.backOffice.connect.emsMsg.nf1615;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"chequeIndicator","chequeNumber","issuingBank","chequeCurrency","chequeAmount","chequeExchangeRate","chequeFXDealNumber","chequeHKDEquivalent","depositamount","depositExchangeRate","depositFXDealNumber","crossExchangeRate"})
public class SourceOfFundCheque {

	public SourceOfFundCheque(){}
	
	@JSONField(name="ChequeIndicator")
	private String chequeIndicator;
	
	@JSONField(name="ChequeNumber")
	private String chequeNumber;
	
	@JSONField(name="IssuingBank")
	private String issuingBank;
	
	@JSONField(name="ChequeCurrency")
	private String chequeCurrency;
	
	@JSONField(name="ChequeAmount")
	private String chequeAmount;
	
	@JSONField(name="ChequeExchangeRate")
	private String chequeExchangeRate;
	
	@JSONField(name="ChequeFXDealNumber")
	private String chequeFXDealNumber;
	
	@JSONField(name="ChequeHKDEquivalent")
	private String chequeHKDEquivalent;
	
	@JSONField(name="Depositamount")
	private String depositamount;
	
	@JSONField(name="DepositExchangeRate")
	private String depositExchangeRate;
	
	@JSONField(name="DepositFXDealNumber")
	private String depositFXDealNumber;
	
	@JSONField(name="CrossExchangeRate")
	private String crossExchangeRate;

    @XmlElement(name = "ChequeIndicator")
	public String getChequeIndicator() {
		return chequeIndicator;
	}

	public void setChequeIndicator(String chequeIndicator) {
		this.chequeIndicator = chequeIndicator;
	}

    @XmlElement(name = "ChequeNumber")
	public String getChequeNumber() {
		return chequeNumber;
	}

	public void setChequeNumber(String chequeNumber) {
		this.chequeNumber = chequeNumber;
	}

    @XmlElement(name = "IssuingBank")
	public String getIssuingBank() {
		return issuingBank;
	}

	public void setIssuingBank(String issuingBank) {
		this.issuingBank = issuingBank;
	}

    @XmlElement(name = "ChequeCurrency")
	public String getChequeCurrency() {
		return chequeCurrency;
	}

	public void setChequeCurrency(String chequeCurrency) {
		this.chequeCurrency = chequeCurrency;
	}

    @XmlElement(name = "ChequeAmount")
	public String getChequeAmount() {
		return chequeAmount;
	}

	public void setChequeAmount(String chequeAmount) {
		this.chequeAmount = chequeAmount;
	}

    @XmlElement(name = "ChequeExchangeRate")
	public String getChequeExchangeRate() {
		return chequeExchangeRate;
	}

	public void setChequeExchangeRate(String chequeExchangeRate) {
		this.chequeExchangeRate = chequeExchangeRate;
	}

    @XmlElement(name = "ChequeFXDealNumber")
	public String getChequeFXDealNumber() {
		return chequeFXDealNumber;
	}

	public void setChequeFXDealNumber(String chequeFXDealNumber) {
		this.chequeFXDealNumber = chequeFXDealNumber;
	}

    @XmlElement(name = "ChequeHKDEquivalent")
	public String getChequeHKDEquivalent() {
		return chequeHKDEquivalent;
	}

	public void setChequeHKDEquivalent(String chequeHKDEquivalent) {
		this.chequeHKDEquivalent = chequeHKDEquivalent;
	}

    @XmlElement(name = "Depositamount")
	public String getDepositamount() {
		return depositamount;
	}

	public void setDepositamount(String depositamount) {
		this.depositamount = depositamount;
	}

    @XmlElement(name = "DepositExchangeRate")
	public String getDepositExchangeRate() {
		return depositExchangeRate;
	}

	public void setDepositExchangeRate(String depositExchangeRate) {
		this.depositExchangeRate = depositExchangeRate;
	}

    @XmlElement(name = "DepositFXDealNumber")
	public String getDepositFXDealNumber() {
		return depositFXDealNumber;
	}

	public void setDepositFXDealNumber(String depositFXDealNumber) {
		this.depositFXDealNumber = depositFXDealNumber;
	}

    @XmlElement(name = "CrossExchangeRate")
	public String getCrossExchangeRate() {
		return crossExchangeRate;
	}

	public void setCrossExchangeRate(String crossExchangeRate) {
		this.crossExchangeRate = crossExchangeRate;
	}
	
	


}
