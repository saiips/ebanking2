package com.dsb.eb2.backOffice.connect.emsMsg.nf1122;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"acctOwnerCode","custID","title","custName1","custName2","ind"})
public class AcctOwnerInfo {
	
	@JSONField(name="AcctOwnerCode")
	private String acctOwnerCode;
	
	@JSONField(name="CustID")
	private String custID;
	
	@JSONField(name="Title")
	private String title;
	
	@JSONField(name="CustName1")
	private String custName1;
	
	@JSONField(name="CustName2")
	private String custName2;
	
	@JSONField(name="Ind")
	private String ind;

	public String getAcctOwnerCode() {
		return acctOwnerCode;
	}

	public void setAcctOwnerCode(String acctOwnerCode) {
		this.acctOwnerCode = acctOwnerCode;
	}

	public String getCustID() {
		return custID;
	}

	public void setCustID(String custID) {
		this.custID = custID;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCustName1() {
		return custName1;
	}

	public void setCustName1(String custName1) {
		this.custName1 = custName1;
	}

	public String getCustName2() {
		return custName2;
	}

	public void setCustName2(String custName2) {
		this.custName2 = custName2;
	}

	public String getInd() {
		return ind;
	}

	public void setInd(String ind) {
		this.ind = ind;
	}
	
}
