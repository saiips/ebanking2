package com.dsb.eb2.backOffice.connect.emsMsg.nf0103;
import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class NF0103RepData extends FrmData 
{
	
	public NF0103RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		
		return "NF0103";
	}

	@JSONField(name="SystemCode") 
	private String  systemCode;
	
	@JSONField(name="LastKey")
	private String  lastKey;
	
	@JSONField(name="MoreItemsIndicator")
	private String  moreItemsIndicator;
	
	@JSONField(name="NoOfItems") 
	private String  noOfItems;
	
	@JSONField(name="RateDetails") 
	private List<RateDetails>  rateDetails;

	@Override
	public String toString() {
		return "NF0103RepData [systemCode=" + systemCode + ", lastKey=" + lastKey + ", moreItemsIndicator="
				+ moreItemsIndicator + ", noOfItems=" + noOfItems + ", rateDetails=" + rateDetails + "]";
	}

	
}
