package com.dsb.eb2.backOffice.connect.emsMsg;

import com.dsb.eb2.backOffice.connect.EMSQueueConnector;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1109.NF1109RepData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1109.NF1109ReqData;

public class TestReq {

	public static void main(String[] args) throws Exception {
		
		NF1109ReqData req = new NF1109ReqData();
		req.setAccountNumber("24646");
		EmsReqMsg emsReqMsg = EmsMsgFactory.createEmsReqMsg(req, "Cust ID");
		
		EMSQueueConnector connect = new EMSQueueConnector();
		
		EmsRepMsg emsRepMsg = connect.invoke(emsReqMsg, new NF1109RepData());
		
		NF1109RepData rep = (NF1109RepData)emsRepMsg.getFrmData();
		
		
		FrmHdr hdr = emsRepMsg.getFrmHdr();
		
		
		
		
	}
}
