package com.dsb.eb2.backOffice.connect.emsMsg.nf0150;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class HKDPrime
{
	public HKDPrime(){}
	
	@JSONField(name="CurrentRate") 
	private String  currentRate;
	
	@JSONField(name="LastRate") 
	private String  lastRate;
	
	@JSONField(name="UpdateDate") 
	private String  updateDate;
	
	@JSONField(name="UpdateTime") 
	private String  updateTime;
	
	@JSONField(name="UpdateBy") 
	private String  updateBy;

}
