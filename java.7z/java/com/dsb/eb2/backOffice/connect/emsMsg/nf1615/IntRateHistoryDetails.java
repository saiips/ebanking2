package com.dsb.eb2.backOffice.connect.emsMsg.nf1615;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"startDate","endDate","effectiveInterestRate","interestAmt","markupRate","paidFlag"})
public class IntRateHistoryDetails {

	public IntRateHistoryDetails () {}
	
	@JSONField(name="StartDate")
	private String startDate;
	
	@JSONField(name="EndDate")
	private String endDate;
	
	@JSONField(name="EffectiveInterestRate")
	private String effectiveInterestRate;
	
	@JSONField(name="InterestAmt")
	private String interestAmt;
	
	@JSONField(name="MarkupRate")
	private String markupRate;
	
	@JSONField(name="PaidFlag")
	private String paidFlag;

    @XmlElement(name = "StartDate")
	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

    @XmlElement(name = "EndDate")
	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

    @XmlElement(name = "EffectiveInterestRate")
	public String getEffectiveInterestRate() {
		return effectiveInterestRate;
	}

	public void setEffectiveInterestRate(String effectiveInterestRate) {
		this.effectiveInterestRate = effectiveInterestRate;
	}

    @XmlElement(name = "InterestAmt")
	public String getInterestAmt() {
		return interestAmt;
	}

	public void setInterestAmt(String interestAmt) {
		this.interestAmt = interestAmt;
	}

    @XmlElement(name = "MarkupRate")
	public String getMarkupRate() {
		return markupRate;
	}

	public void setMarkupRate(String markupRate) {
		this.markupRate = markupRate;
	}

    @XmlElement(name = "PaidFlag")
	public String getPaidFlag() {
		return paidFlag;
	}

	public void setPaidFlag(String paidFlag) {
		this.paidFlag = paidFlag;
	}
	
	

}
