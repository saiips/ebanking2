package com.dsb.eb2.backOffice.connect.emsMsg.nf1120;
import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class NF1120RepData extends FrmData
{
    public NF1120RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1120";
	}
	
	@JSONField(name="SearchStatus") 
	private String  searchStatus;
	
	@JSONField(name="CardNumber") 
	private String  cardNumber;
	
	@JSONField(name="SequenceNumber")
	private String  sequenceNumber;
	
	@JSONField(name="CardHolderName") 
	private String  cardHolderName;
	
	@JSONField(name="CardType") 
	private String  cardType;
	
	@JSONField(name="Status")
	private String  status;
	
	@JSONField(name="AcctOwnerCnt") 
	private String  acctOwnerCnt;
	
	@JSONField(name="AccountOwners") 
	private List<AccountOwners>  accountOwners;
	
	@JSONField(name="SecondaryAccount1") 
	private String  secondaryAccount1;
	
	@JSONField(name="DateAddedSecondaryAccount1") 
	private String  dateAddedSecondaryAccount1;
	
	@JSONField(name="SecondaryAccount2") 
	private String  secondaryAccount2;
	
	@JSONField(name="DateAddedSecondaryAccount2") 
	private String  dateAddedSecondaryAccount2;
	
	@JSONField(name="CardIssueDate") 
	private String  cardIssueDate;
	
	@JSONField(name="HotCardDate") 
	private String  hotCardDate;
	
	@JSONField(name="PinGeneratedDate") 
	private String  pinGeneratedDate;
	
	@JSONField(name="SuspensionDate")
	private String  suspensionDate;
	
	@JSONField(name="CardExpiryDate") 
	private String  cardExpiryDate;
	
	@JSONField(name="LanguageCode") 
	private String  languageCode;
	
	@JSONField(name="OldCardSequenceNumber") 
	private String  oldCardSequenceNumber;
	
	@JSONField(name="AppFeeInd") 
	private String  appFeeInd;
	
	@JSONField(name="AnnualFeeInd") 
	private String  annualFeeInd;
	
	@JSONField(name="OutstandingAppFeeCount") 
	private String  outstandingAppFeeCount;
	
	@JSONField(name="OutstandingReisFeeCount") 
	private String  outstandingReisFeeCount;
	
	@JSONField(name="OutstandingAnnualFeeCount")
	private String  outstandingAnnualFeeCount;
	
	@JSONField(name="AppFeeNextCollectionDate")
	private String  appFeeNextCollectionDate;
	
	@JSONField(name="ReisFeeNextCollectionDate") 
	private String  reisFeeNextCollectionDate;
	
	@JSONField(name="AnnualFeeNextCollectionDate") 
	private String  annualFeeNextCollectionDate;
	
	@JSONField(name="LastTransDate")
	private String  lastTransDate;
	
	@JSONField(name="LastTransTime")
	private String  lastTransTime;
	
	@JSONField(name="HKJCCashVoucherIndicator")
	private String  hKJCCashVoucherIndicator;
	
	@JSONField(name="OctopusCardId") 
	private String  octopusCardId;
	
	@JSONField(name="SubCardType")
	private String  subCardType;
	
	@JSONField(name="AnnualFeeDate")
	private String  annualFeeDate;
	
	@JSONField(name="CardActivationDetails") 
	private List<CardActivationDetails>  cardActivationDetails;
	
	@JSONField(name="OptInDetails") 
	private List<OptInDetails>  optInDetails;
	
	@JSONField(name="OverseasTranParaDetails") 
	private List<OverseasTranParaDetails>  overseasTranParaDetails;
	
	@JSONField(name="ChipCardInd") 
	private String  chipCardInd;
	
	@JSONField(name="PrimaryAccountCurrency")
	private String  primaryAccountCurrency;
	
	@JSONField(name="ChipCardSecAcctCnt")
	private String  chipCardSecAcctCnt;
	
	@JSONField(name="ChipCardSecondaryAcctInfo")
	private List<ChipCardSecondaryAcctInfo>  chipCardSecondaryAcctInfo;
	
	@JSONField(name="OctopusCardInd") 
	private String  octopusCardInd;
	
	@JSONField(name="EReceiptFlag")
	private String  eReceiptFlag;
}
