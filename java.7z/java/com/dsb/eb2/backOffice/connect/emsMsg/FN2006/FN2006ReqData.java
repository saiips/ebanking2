package com.dsb.eb2.backOffice.connect.emsMsg.FN2006;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class FN2006ReqData extends FrmData
{
	@JSONField(name="AcctNum")
    private String acctNum;
    
	@JSONField(name="CollectionType")
    private String collectionType;
    
	@JSONField(name="PaymentType")
    private String paymentType;
    
	@JSONField(name="Amt")
    private String amt;
    
	@JSONField(name="Ccy")
    private String ccy;
    
	@JSONField(name="Float")
    private String floats;
    
	@JSONField(name="Narrative")
    private String narrative;
    
	@JSONField(name="PaymentRef")
    private String paymentRef;
    
	@JSONField(name="DemandNoteNum")
    private String demandNoteNum;
    
	@JSONField(name="AsOfDate")
    private String asOfDate;

    @Override
    public String getServiceID()
    {
        return "FN2006";
    }
    
}
