package com.dsb.eb2.backOffice.connect.emsMsg.fn0005;


import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class SpotPositionBookingData 
{
	public SpotPositionBookingData(){}
	
	@JSONField(name="OverrideFlag")
	private String overrideFlag;
	
	@JSONField(name="ExRateType")
	private String exRateType;
	
	@JSONField(name="CNYTransClass")
	private String cNYTransClass;
	
	@JSONField(name="AcctOfficerCode")
	private String acctOfficerCode;
	
	@JSONField(name="AcctOfficerSubCode")
	private String acctOfficerSubCode;
	
	@JSONField(name="Division")
	private String division;
	
	@JSONField(name="Region")
	private String region;
	
	@JSONField(name="StaffInd")
	private String staffInd;
	
	@JSONField(name="VIPFlag")
	private String vIPFlag;
	
	@JSONField(name="ExRateTier")
	private String exRateTier;

}
