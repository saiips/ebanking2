package com.dsb.eb2.backOffice.connect.emsMsg.nf1135;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;


@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"startingPageNum","maxPageNum","custNumber",
		"totalEarnLS","openingLS","earnLS","redeemLS","closeLS",
		"earnCTD","redeemCTD","closing","numOfRow","totalList"})
public class  NF1135RepData extends FrmData
{
    
	public NF1135RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1135";
	}
	
	
	@JSONField(name="StartingPageNum")
	private String startingPageNum;
	
	@JSONField(name="MaxPageNum")
	private String maxPageNum;
	
	@JSONField(name="CustNumber")
	private String custNumber;
	
	@JSONField(name="TotalEarnLS")
	private String totalEarnLS;
	
	@JSONField(name="OpeningLS")
	private String openingLS;
	
	@JSONField(name="EarnLS")
	private String earnLS;
	
	@JSONField(name="RedeemLS")
	private String redeemLS;
	
	@JSONField(name="CloseLS")
	private String closeLS;
	
	@JSONField(name="EarnCTD")
	private String earnCTD;
	
	@JSONField(name="RedeemCTD")
	private String redeemCTD;
	
	@JSONField(name="Closing")
	private String closing;
	
	@JSONField(name="NumOfRow")
	private String numOfRow;
	
	@JSONField(name="TotalList")
	private List <TotalList>  totalList;

    @XmlElement(name = "StartingPageNum")
	public String getStartingPageNum() {
		return startingPageNum;
	}

	public void setStartingPageNum(String startingPageNum) {
		this.startingPageNum = startingPageNum;
	}

    @XmlElement(name = "MaxPageNum")
	public String getMaxPageNum() {
		return maxPageNum;
	}

	public void setMaxPageNum(String maxPageNum) {
		this.maxPageNum = maxPageNum;
	}

    @XmlElement(name = "CustNumber")
	public String getCustNumber() {
		return custNumber;
	}

	public void setCustNumber(String custNumber) {
		this.custNumber = custNumber;
	}

    @XmlElement(name = "TotalEarnLS")
	public String getTotalEarnLS() {
		return totalEarnLS;
	}

	public void setTotalEarnLS(String totalEarnLS) {
		this.totalEarnLS = totalEarnLS;
	}

    @XmlElement(name = "OpeningLS")
	public String getOpeningLS() {
		return openingLS;
	}

	public void setOpeningLS(String openingLS) {
		this.openingLS = openingLS;
	}

    @XmlElement(name = "EarnLS")
	public String getEarnLS() {
		return earnLS;
	}

	public void setEarnLS(String earnLS) {
		this.earnLS = earnLS;
	}

    @XmlElement(name = "RedeemLS")
	public String getRedeemLS() {
		return redeemLS;
	}

	public void setRedeemLS(String redeemLS) {
		this.redeemLS = redeemLS;
	}

    @XmlElement(name = "CloseLS")
	public String getCloseLS() {
		return closeLS;
	}

	public void setCloseLS(String closeLS) {
		this.closeLS = closeLS;
	}

    @XmlElement(name = "EarnCTD")
	public String getEarnCTD() {
		return earnCTD;
	}

	public void setEarnCTD(String earnCTD) {
		this.earnCTD = earnCTD;
	}

    @XmlElement(name = "RedeemCTD")
	public String getRedeemCTD() {
		return redeemCTD;
	}

	public void setRedeemCTD(String redeemCTD) {
		this.redeemCTD = redeemCTD;
	}

    @XmlElement(name = "Closing")
	public String getClosing() {
		return closing;
	}

	public void setClosing(String closing) {
		this.closing = closing;
	}

    @XmlElement(name = "NumOfRow")
	public String getNumOfRow() {
		return numOfRow;
	}

	public void setNumOfRow(String numOfRow) {
		this.numOfRow = numOfRow;
	}

    @XmlElement(name = "TotalList")
	public List<TotalList> getTotalList() {
		return totalList;
	}

	public void setTotalList(List<TotalList> totalList) {
		this.totalList = totalList;
	}
	
}
