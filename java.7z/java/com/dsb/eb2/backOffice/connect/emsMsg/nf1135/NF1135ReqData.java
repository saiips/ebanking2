package com.dsb.eb2.backOffice.connect.emsMsg.nf1135;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"creditCardAccountNbr","startingPageNum"})
public class  NF1135ReqData extends FrmData
{
    
	public NF1135ReqData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1135";
	}
	
	@JSONField(name="CreditCardAccountNbr")
	private String creditCardAccountNbr;
	
	@JSONField(name="StartingPageNum")
	private String startingPageNum;

    @XmlElement(name = "CreditCardAccountNbr")
	public String getCreditCardAccountNbr() {
		return creditCardAccountNbr;
	}

	public void setCreditCardAccountNbr(String creditCardAccountNbr) {
		this.creditCardAccountNbr = creditCardAccountNbr;
	}

    @XmlElement(name = "StartingPageNum")
	public String getStartingPageNum() {
		return startingPageNum;
	}

	public void setStartingPageNum(String startingPageNum) {
		this.startingPageNum = startingPageNum;
	}
	
}
