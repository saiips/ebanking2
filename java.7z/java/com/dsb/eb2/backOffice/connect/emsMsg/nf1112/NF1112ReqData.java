package com.dsb.eb2.backOffice.connect.emsMsg.nf1112;
import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class NF1112ReqData  extends FrmData
{

	public NF1112ReqData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1112";
	}
	
	@JSONField(name="AccountNumber")
	private String accountNumber;
	
	@JSONField(name="PenaltyOption")
	private String penaltyOption;
	
	@JSONField(name="SettlementDate")
	private String settlementDate;

}
