package com.dsb.eb2.backOffice.connect.emsMsg.nf0102;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class I110DepRates{

	private String ccy = "";
	private String call = "";
	private String sevDays = "";	
	private String fourtDays = "";	
	private String oneMonths = "";	
	private String twoMonths = "";	
	private String thrMonths = "";	
	private String sixMonths = "";	
	private String ninMonths = "";	
	private String twelMonths = "";

	public I110DepRates()
	{
		
	}
}
