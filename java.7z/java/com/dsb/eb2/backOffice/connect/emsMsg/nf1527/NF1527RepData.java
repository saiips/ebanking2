package com.dsb.eb2.backOffice.connect.emsMsg.nf1527;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"addrCode","addrLine1","addrLine2","addrLine3",
		"addrLine4","phoneNum","officeNum","mobileNum","pagerNum",
		"emailAddr","addressCountryCode","phoneCountryCode","mobileCountryCode" })
public class  NF1527RepData extends FrmData
{
    
	public NF1527RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1527";
	}
	

	@JSONField(name="NumOfItems")
	private String NumOfItems;
	
	@JSONField(name="AcctDetails")
	private List <AcctDetails> acctDetails =new ArrayList<AcctDetails>();
	
	@JSONField(name="AddrCode")
	private String AddrCode;
	
	@JSONField(name="AddrLine1")
	private String AddrLine1 ;
	
	@JSONField(name="AddrLine2")
	private String AddrLine2;
	
	@JSONField(name="AddrLine3")
	private String AddrLine3;
	
	@JSONField(name="AddrLine4")
	private String AddrLine4;
	
	@JSONField(name="PhoneNum")
	private String PhoneNum;
	
	@JSONField(name="OfficeNum")
	private String OfficeNum;
	
	@JSONField(name="MobileNum")
	private String MobileNum;
	
	@JSONField(name="PagerNum")
	private String PagerNum;
	
	@JSONField(name="EmailAddr")
	private String EmailAddr;
	
	@JSONField(name="AddressCountryCode")
	private String AddressCountryCode;
	
	@JSONField(name="PhoneCountryCode")
	private String PhoneCountryCode;
	
	@JSONField(name="MobileCountryCode")
	private String MobileCountryCode;

	@XmlElement(name = "NumOfItems")
	public String getNumOfItems() {
		return NumOfItems;
	}

	public void setNumOfItems(String numOfItems) {
		NumOfItems = numOfItems;
	}

	@XmlElement(name = "AcctDetails")
	public List<AcctDetails> getAcctDetails() {
		return acctDetails;
	}

	public void setAcctDetails(List<AcctDetails> acctDetails) {
		this.acctDetails = acctDetails;
	}

	@XmlElement(name = "AddrCode")
	public String getAddrCode() {
		return AddrCode;
	}

	public void setAddrCode(String addrCode) {
		AddrCode = addrCode;
	}

	@XmlElement(name = "AddrLine1")
	public String getAddrLine1() {
		return AddrLine1;
	}

	public void setAddrLine1(String addrLine1) {
		AddrLine1 = addrLine1;
	}

	@XmlElement(name = "AddrLine2")
	public String getAddrLine2() {
		return AddrLine2;
	}

	public void setAddrLine2(String addrLine2) {
		AddrLine2 = addrLine2;
	}

	@XmlElement(name = "AddrLine3")
	public String getAddrLine3() {
		return AddrLine3;
	}

	public void setAddrLine3(String addrLine3) {
		AddrLine3 = addrLine3;
	}

	@XmlElement(name = "AddrLine4")
	public String getAddrLine4() {
		return AddrLine4;
	}

	public void setAddrLine4(String addrLine4) {
		AddrLine4 = addrLine4;
	}

	@XmlElement(name = "PhoneNum")
	public String getPhoneNum() {
		return PhoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		PhoneNum = phoneNum;
	}
	
	@XmlElement(name = "OfficeNum")
	public String getOfficeNum() {
		return OfficeNum;
	}

	public void setOfficeNum(String officeNum) {
		OfficeNum = officeNum;
	}

	@XmlElement(name = "MobileNum")
	public String getMobileNum() {
		return MobileNum;
	}

	public void setMobileNum(String mobileNum) {
		MobileNum = mobileNum;
	}

	@XmlElement(name = "PagerNum")
	public String getPagerNum() {
		return PagerNum;
	}

	public void setPagerNum(String pagerNum) {
		PagerNum = pagerNum;
	}

	@XmlElement(name = "EmailAddr")
	public String getEmailAddr() {
		return EmailAddr;
	}

	public void setEmailAddr(String emailAddr) {
		EmailAddr = emailAddr;
	}

	@XmlElement(name = "AddressCountryCode")
	public String getAddressCountryCode() {
		return AddressCountryCode;
	}

	public void setAddressCountryCode(String addressCountryCode) {
		AddressCountryCode = addressCountryCode;
	}

	@XmlElement(name = "PhoneCountryCode")
	public String getPhoneCountryCode() {
		return PhoneCountryCode;
	}

	public void setPhoneCountryCode(String phoneCountryCode) {
		PhoneCountryCode = phoneCountryCode;
	}

	@XmlElement(name = "MobileCountryCode")
	public String getMobileCountryCode() {
		return MobileCountryCode;
	}

	public void setMobileCountryCode(String mobileCountryCode) {
		MobileCountryCode = mobileCountryCode;
	}
	
	

}
