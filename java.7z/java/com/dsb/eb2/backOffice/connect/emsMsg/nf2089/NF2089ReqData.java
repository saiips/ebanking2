package com.dsb.eb2.backOffice.connect.emsMsg.nf2089;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlAccessType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;


@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"countryCode","refNum","reasonCodeLastKey","acctRefLastKey","indiciaCodeLastKey",
		"suppDocCodeLastKey","respPartyLastKey","subOwnerIDLastKey","type"})
public class NF2089ReqData  extends FrmData
{
    
	public NF2089ReqData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF2089";
	}
	
	@JSONField(name="CountryCode") 
	private String countryCode;
	
	@JSONField(name="RefNum")
	private String refNum;
	
	@JSONField(name="ReasonCodeLastKey") 
	private String reasonCodeLastKey;
	
	@JSONField(name="AcctRefLastKey") 
	private String acctRefLastKey;
	
	@JSONField(name="IndiciaCodeLastKey") 
	private String indiciaCodeLastKey;
	
	@JSONField(name="SuppDocCodeLastKey") 
	private String suppDocCodeLastKey;
	
	@JSONField(name="RespPartyLastKey") 
	private String respPartyLastKey;
	
	@JSONField(name="SubOwnerIDLastKey") 
	private String subOwnerIDLastKey;
	
	@JSONField(name="Type") 
	private String type;

    @XmlElement(name = "CountryCode")
	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

    @XmlElement(name = "RefNum")
	public String getRefNum() {
		return refNum;
	}

	public void setRefNum(String refNum) {
		this.refNum = refNum;
	}

    @XmlElement(name = "ReasonCodeLastKey")
	public String getReasonCodeLastKey() {
		return reasonCodeLastKey;
	}

	public void setReasonCodeLastKey(String reasonCodeLastKey) {
		this.reasonCodeLastKey = reasonCodeLastKey;
	}

    @XmlElement(name = "AcctRefLastKey")
	public String getAcctRefLastKey() {
		return acctRefLastKey;
	}

	public void setAcctRefLastKey(String acctRefLastKey) {
		this.acctRefLastKey = acctRefLastKey;
	}

    @XmlElement(name = "IndiciaCodeLastKey")
	public String getIndiciaCodeLastKey() {
		return indiciaCodeLastKey;
	}

	public void setIndiciaCodeLastKey(String indiciaCodeLastKey) {
		this.indiciaCodeLastKey = indiciaCodeLastKey;
	}

    @XmlElement(name = "SuppDocCodeLastKey")
	public String getSuppDocCodeLastKey() {
		return suppDocCodeLastKey;
	}

	public void setSuppDocCodeLastKey(String suppDocCodeLastKey) {
		this.suppDocCodeLastKey = suppDocCodeLastKey;
	}

    @XmlElement(name = "RespPartyLastKey")
	public String getRespPartyLastKey() {
		return respPartyLastKey;
	}

	public void setRespPartyLastKey(String respPartyLastKey) {
		this.respPartyLastKey = respPartyLastKey;
	}

    @XmlElement(name = "SubOwnerIDLastKey")
	public String getSubOwnerIDLastKey() {
		return subOwnerIDLastKey;
	}

	public void setSubOwnerIDLastKey(String subOwnerIDLastKey) {
		this.subOwnerIDLastKey = subOwnerIDLastKey;
	}

    @XmlElement(name = "Type")
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}


}



