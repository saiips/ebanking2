package com.dsb.eb2.backOffice.connect.emsMsg.nf1108;

import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.Setter;


@Getter @Setter
public class NF1108RepData extends FrmData {
	
	@Override
	public String toString() {
		return "NF1108RepData [custNameLine1=" + custNameLine1 + ", custNameLine2=" + custNameLine2 + ", title=" + title
				+ ", sex=" + sex + ", custType=" + custType + ", acctOpenDate=" + acctOpenDate + ", addrCode="
				+ addrCode + ", acctOfficer=" + acctOfficer + ", dateOfBirth=" + dateOfBirth + ", nationality="
				+ nationality + ", maritalStatus=" + maritalStatus + ", specialStatus1=" + specialStatus1
				+ ", specialStatus2=" + specialStatus2 + ", specialStatus3=" + specialStatus3 + ", specialStatus4="
				+ specialStatus4 + ", homeNum=" + homeNum + ", officeNum=" + officeNum + ", mobileNum=" + mobileNum
				+ ", pagerNum=" + pagerNum + ", faxNum=" + faxNum + ", emailAddr=" + emailAddr + ", privacyInd="
				+ privacyInd + ", addrLine1=" + addrLine1 + ", addrLine2=" + addrLine2 + ", addrLine3=" + addrLine3
				+ ", addrLine4=" + addrLine4 + ", zipOrPostalCode=" + zipOrPostalCode + ", employerName=" + employerName
				+ ", position=" + position + ", pEPPosition=" + pEPPosition + ", vIPFlag=" + vIPFlag + ", staffInd="
				+ staffInd + ", masterTCAcceptanceInd=" + masterTCAcceptanceInd + ", acceptanceDateOfMasterTC="
				+ acceptanceDateOfMasterTC + ", masterTCIndLastUpdateUserID=" + masterTCIndLastUpdateUserID
				+ ", masterTCSystemCode=" + masterTCSystemCode + ", langPreferenceInd=" + langPreferenceInd
				+ ", custOrigin=" + custOrigin + ", filler1=" + filler1 + ", businessNature=" + businessNature + ", monthlyIncome="
				+ monthlyIncome + ", shortName=" + shortName + ", greetingName=" + greetingName + ", alias=" + alias
				+ ", docIssuedDate=" + docIssuedDate + ", docIssuedCountry=" + docIssuedCountry
				+ ", aDVClassificationCode=" + aDVClassificationCode + ", residencyCode=" + residencyCode
				+ ", residencyNatureCode=" + residencyNatureCode + ", yearsThere=" + yearsThere + ", statementCycle="
				+ statementCycle + ", statementPrintingFlag=" + statementPrintingFlag + ", suppressStatementDate="
				+ suppressStatementDate + ", pickupBranch=" + pickupBranch + ", faxInd=" + faxInd + ", openingBranch="
				+ openingBranch + ", domicileBranch=" + domicileBranch + ", educationCode=" + educationCode
				+ ", occupation=" + occupation + ", selfEmploymentInd=" + selfEmploymentInd + ", otherIncome="
				+ otherIncome + ", masterSignatureNum=" + masterSignatureNum + ", memberSince=" + memberSince
				+ ", relationToBankDirector=" + relationToBankDirector + ", relatedBankDirectorID="
				+ relatedBankDirectorID + ", lastUpdateDate=" + lastUpdateDate + ", lastUpdateUser=" + lastUpdateUser
				+ ", monthlyInstallmentOrRent=" + monthlyInstallmentOrRent + ", installmentOrRentCurrency="
				+ installmentOrRentCurrency + ", employmentStatus=" + employmentStatus + ", employmentOthers="
				+ employmentOthers + ", employmentServiceYear=" + employmentServiceYear + ", lastEmploymentDate="
				+ lastEmploymentDate + ", riskFlag=" + riskFlag + ", sCCDetails=" + sCCDetails + ", memorandum="
				+ memorandum + ", tempCustType=" + tempCustType + ", bankCustFlag=" + bankCustFlag + ", lastReviewDate="
				+ lastReviewDate + ", nextReviewDate=" + nextReviewDate + ", pEPCountryServed=" + pEPCountryServed
				+ ", domesticHelperValidContractFlag=" + domesticHelperValidContractFlag + ", consentIndicator="
				+ consentIndicator + ", consentIndicatorUpdateDate=" + consentIndicatorUpdateDate
				+ ", consentIndicatorUpdateUser=" + consentIndicatorUpdateUser + ", linkFlag=" + linkFlag + ", mtrFlag="
				+ mtrFlag + ", payrollFlag=" + payrollFlag + ", octopusAavsFlag=" + octopusAavsFlag
				+ ", octopusAavsFlagLastUpdDate=" + octopusAavsFlagLastUpdDate + ", exRateTier=" + exRateTier
				+ ", homeNumCountryCode=" + homeNumCountryCode + ", officeNumCountryCode=" + officeNumCountryCode
				+ ", mobileCountryCode=" + mobileCountryCode + ", addressCountryCode=" + addressCountryCode
				+ ", placeOfBirthCountryCode=" + placeOfBirthCountryCode + ", personCountryCode=" + personCountryCode
				+ ", permAddrCountryCode=" + permAddrCountryCode + ", tinNum=" + tinNum + ", appCreationDate="
				+ appCreationDate + ", lowBalFeeWaiverDetails=" + lowBalFeeWaiverDetails + ", exFDCustFlag="
				+ exFDCustFlag + ", custNonCreditProfileInfo=" + custNonCreditProfileInfo + ", guarantorFlag="
				+ guarantorFlag + ", custRelationshipEndDate=" + custRelationshipEndDate + ", retentionEndDate="
				+ retentionEndDate + ", reactivationDate=" + reactivationDate + ", updateTime=" + updateTime
				+ ", fullEmailAddr=" + fullEmailAddr +",filler1="+filler1+"]";
	}

	@JSONField(serialize=false)
	@Override
	@JsonIgnore
	public String getServiceID() {
		return "NF1108";
	}
	
	public NF1108RepData() {};
	
	@JSONField(name="CustNameLine1")
    private String custNameLine1;

	@JSONField(name="CustNameLine2")
    private String custNameLine2;

	@JSONField(name="Title")
    private String title;

	@JSONField(name="Sex")
    private String sex;

	@JSONField(name="CustType")
    private String custType;

	@JSONField(name="AcctOpenDate")
    private String acctOpenDate;

	@JSONField(name="AddrCode")
    private String addrCode;

	@JSONField(name="AcctOfficer")
    private String acctOfficer;

	@JSONField(name="DateOfBirth")
    private String dateOfBirth;

	@JSONField(name="Nationality")
    private String nationality;

	@JSONField(name="MaritalStatus")
    private String maritalStatus;

	@JSONField(name="SpecialStatus1")
    private String specialStatus1;

	@JSONField(name="SpecialStatus2")
    private String specialStatus2;

	@JSONField(name="SpecialStatus3")
    private String specialStatus3;

	@JSONField(name="SpecialStatus4")
    private String specialStatus4;

	@JSONField(name="HomeNum")
    private String homeNum;

	@JSONField(name="OfficeNum")
    private String officeNum;

	@JSONField(name="MobileNum")
    private String mobileNum;

	@JSONField(name="PagerNum")
    private String pagerNum;

	@JSONField(name="FaxNum")
    private String faxNum;

	@JSONField(name="EmailAddr")
    private String emailAddr;

	@JSONField(name="PrivacyInd")
    private String privacyInd;

	@JSONField(name="AddrLine1")
    private String addrLine1;

	@JSONField(name="AddrLine2")
    private String addrLine2;

	@JSONField(name="AddrLine3")
    private String addrLine3;
	
	@JSONField(name="AddrLine4")
    private String addrLine4;
	
	@JSONField(name="ZipOrPostalCode")
    private String zipOrPostalCode;

	@JSONField(name="EmployerName")
    private String employerName;
	
	@JSONField(name="Position")
    private String position;

	@JSONField(name="VIPFlag")
    private String vIPFlag;

	@JSONField(name="StaffInd")
    private String staffInd;

	@JSONField(name="MasterTCAcceptanceInd")
    private String masterTCAcceptanceInd;

	@JSONField(name="AcceptanceDateOfMasterTC")
    private String acceptanceDateOfMasterTC;

	@JSONField(name="MasterTCIndLastUpdateUserID")
    private String masterTCIndLastUpdateUserID;

	@JSONField(name="MasterTCSystemCode")
    private String masterTCSystemCode;

	@JSONField(name="LangPreferenceInd")
    private String langPreferenceInd;

	@JSONField(name="CustOrigin")
    private String custOrigin;
	
	@JSONField(name="Filler1")
    private String filler1;

	@JSONField(name="BusinessNature")
    private String businessNature;

	@JSONField(name="MonthlyIncome")
    private String monthlyIncome;

	@JSONField(name="ShortName")
    private String shortName;

	@JSONField(name="GreetingName")
    private String greetingName;

	@JSONField(name="Alias")
    private String alias;

	@JSONField(name="DocIssuedDate")
    private String docIssuedDate;

	@JSONField(name="DocIssuedCountry")
    private String docIssuedCountry;

	@JSONField(name="ADVClassificationCode")
    private String aDVClassificationCode;

	@JSONField(name="ResidencyCode")
    private String residencyCode;

	@JSONField(name="ResidencyNatureCode")
    private String residencyNatureCode;

	@JSONField(name="YearsThere")
    private String yearsThere;

	@JSONField(name="StatementCycle")
    private String statementCycle;

	@JSONField(name="StatementPrintingFlag")
    private String statementPrintingFlag;

	@JSONField(name="SuppressStatementDate")
    private String suppressStatementDate;
	
	@JSONField(name="PickupBranch")
    private String pickupBranch;

	@JSONField(name="FaxInd")
    private String faxInd;

	@JSONField(name="OpeningBranch")
    private String openingBranch;

	@JSONField(name="DomicileBranch")
    private String domicileBranch;

	@JSONField(name="EducationCode")
    private String educationCode;

	@JSONField(name="Occupation")
    private String occupation;

	@JSONField(name="SelfEmploymentInd")
    private String selfEmploymentInd;

	@JSONField(name="OtherIncome")
    private String otherIncome;

	@JSONField(name="MasterSignatureNum")
    private String masterSignatureNum;

	@JSONField(name="MemberSince")
    private String memberSince;

	@JSONField(name="RelationToBankDirector")
    private String relationToBankDirector;

	@JSONField(name="RelatedBankDirectorID")
    private String relatedBankDirectorID;

	@JSONField(name="LastUpdateDate")
    private String lastUpdateDate;
	
	@JSONField(name="LastUpdateUser")
    private String lastUpdateUser;

	@JSONField(name="MonthlyInstallmentOrRent")
    private String monthlyInstallmentOrRent;

	@JSONField(name="InstallmentOrRentCurrency")
    private String installmentOrRentCurrency;

	@JSONField(name="EmploymentStatus")
    private String employmentStatus;

	@JSONField(name="EmploymentOthers")
    private String employmentOthers;

	@JSONField(name="EmploymentServiceYear")
    private String employmentServiceYear;

	@JSONField(name="LastEmploymentDate")
    private String lastEmploymentDate;

	@JSONField(name="RiskFlag")
    private String riskFlag;

	@JSONField(name="SCCDetails")
    private List<SCCDetails> sCCDetails =new ArrayList<SCCDetails>();
	
	@JSONField(name="Memorandum")
    private List<String >memorandum;

	@JSONField(name="TempCustType")
    private String tempCustType;

	@JSONField(name="BankCustFlag")
    private String bankCustFlag;

	@JSONField(name="LastReviewDate")
    private String lastReviewDate;

	@JSONField(name="NextReviewDate")
    private String nextReviewDate;

	@JSONField(name="PEPCountryServed")
    private String pEPCountryServed;
	
	@JSONField(name="PEPPosition")
    private String pEPPosition;

	@JSONField(name="DomesticHelperValidContractFlag")
    private String domesticHelperValidContractFlag;
    
	@JSONField(name="ConsentIndicator")
    private String consentIndicator;
	
	@JSONField(name="ConsentIndicatorUpdateDate")
    private String consentIndicatorUpdateDate;
	
	@JSONField(name="ConsentIndicatorUpdateUser")
    private String consentIndicatorUpdateUser;
	
	@JSONField(name="LinkFlag")
    private String linkFlag;
	
	@JSONField(name="MtrFlag")
    private String mtrFlag;
	
	@JSONField(name="PayrollFlag")
    private String payrollFlag;
	
	@JSONField(name="OctopusAavsFlag")
    private String octopusAavsFlag;
	
	@JSONField(name="OctopusAavsFlagLastUpdDate")
    private String octopusAavsFlagLastUpdDate;
	
	@JSONField(name="ExRateTier")
    private String exRateTier;
	
	@JSONField(name="HomeNumCountryCode")
    private String homeNumCountryCode;
	
	@JSONField(name="OfficeNumCountryCode")
    private String officeNumCountryCode;
	
	@JSONField(name="MobileCountryCode")
    private String mobileCountryCode;
	
	@JSONField(name="AddressCountryCode")
    private String addressCountryCode;
	
	@JSONField(name="PlaceOfBirthCountryCode")
    private String placeOfBirthCountryCode;
	
	@JSONField(name="PersonCountryCode")
    private String personCountryCode;
	
	@JSONField(name="PermAddrCountryCode")
    private String permAddrCountryCode;
	
	@JSONField(name="TinNum")
    private String tinNum;
	
	@JSONField(name="AppCreationDate")
    private String appCreationDate;
	
	@JSONField(name="LowBalFeeWaiverDetails")
    private List<LowBalFeeWaiverDetails> lowBalFeeWaiverDetails=new ArrayList<LowBalFeeWaiverDetails>();
	
	@JSONField(name="ExFDCustFlag")
    private String exFDCustFlag;
	
	@JSONField(name="CustNonCreditProfileInfo")
    private List<CustNonCreditProfileInfo> custNonCreditProfileInfo=new ArrayList<CustNonCreditProfileInfo>();
	
	@JSONField(name="GuarantorFlag")
    private String guarantorFlag;
	
	@JSONField(name="CustRelationshipEndDate")
    private String custRelationshipEndDate;
	
	@JSONField(name="RetentionEndDate")
    private String retentionEndDate;
	
	@JSONField(name="ReactivationDate")
    private String reactivationDate;
	
	@JSONField(name="UpdateTime")
    private String updateTime;
	
	@JSONField(name="FullEmailAddr")
    private String fullEmailAddr;

}
