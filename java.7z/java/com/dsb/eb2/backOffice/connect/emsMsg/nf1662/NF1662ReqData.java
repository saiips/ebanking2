package com.dsb.eb2.backOffice.connect.emsMsg.nf1662;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;
@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = { "accountNumber","referenceNo", "fromTransactionDate", "toTransactionDate" ,"remittingCurrency",
		"fromRemitAmount","toRemitAmount","lastKey","itemsRequested"})
public class NF1662ReqData
    extends FrmData
{
	@JSONField(name="AccountNumber")
    private String accountNumber;
    
	@JSONField(name="ReferenceNo")
    private String referenceNo;
    
	@JSONField(name="FromTransactionDate")
    private String fromTransactionDate;
    
	@JSONField(name="ToTransactionDate")
    private String toTransactionDate;
    
	@JSONField(name="RemittingCurrency")
    private String remittingCurrency;
    
	@JSONField(name="FromRemitAmount")
    private String fromRemitAmount;
    
	@JSONField(name="ToRemitAmount")
    private String toRemitAmount;
    
	@JSONField(name="LastKey")
    private String lastKey;
    
	@JSONField(name="ItemsRequested")
    private String itemsRequested;

    public NF1662ReqData()
    {
    }
  
	@Override
    public String getServiceID()
    {
        return "NF1662";
    }
	
	@XmlElement(name = "AccountNumber")
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	
    @XmlElement(name = "ReferenceNo")
	public String getReferenceNo() {
		return referenceNo;
	}
	public void setReferenceNo(String referenceNo) {
		this.referenceNo = referenceNo;
	}
	
	@XmlElement(name = "FromTransactionDate")
	public String getFromTransactionDate() {
		return fromTransactionDate;
	}
	public void setFromTransactionDate(String fromTransactionDate) {
		this.fromTransactionDate = fromTransactionDate;
	}
	
	@XmlElement(name = "ToTransactionDate")
	public String getToTransactionDate() {
		return toTransactionDate;
	}
	public void setToTransactionDate(String toTransactionDate) {
		this.toTransactionDate = toTransactionDate;
	}
	
	@XmlElement(name = "RemittingCurrency")
	public String getRemittingCurrency() {
		return remittingCurrency;
	}
	public void setRemittingCurrency(String remittingCurrency) {
		this.remittingCurrency = remittingCurrency;
	}
	
	
	@XmlElement(name = "FromRemitAmount")
	public String getFromRemitAmount() {
		return fromRemitAmount;
	}
	public void setFromRemitAmount(String fromRemitAmount) {
		this.fromRemitAmount = fromRemitAmount;
	}
	
	@XmlElement(name = "ToRemitAmount")
	public String getToRemitAmount() {
		return toRemitAmount;
	}
	public void setToRemitAmount(String toRemitAmount) {
		this.toRemitAmount = toRemitAmount;
	}
	
	@XmlElement(name = "LastKey")
	public String getLastKey() {
		return lastKey;
	}
	public void setLastKey(String lastKey) {
		this.lastKey = lastKey;
	}
	
	@XmlElement(name = "ItemsRequested")
	public String getItemsRequested() {
		return itemsRequested;
	}
	public void setItemsRequested(String itemsRequested) {
		this.itemsRequested = itemsRequested;
	}
	

}
