package com.dsb.eb2.backOffice.connect.emsMsg.nf1135;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"cardholder","openingLS","earnLS","redeemLS","closeLS","earnCTD","redeemCTD","closingCTD"})
public class TotalList {
	
	public TotalList(){}
	
	@JSONField(name="Cardholder")
	private String cardholder;
	
	@JSONField(name="OpeningLS")
	private String openingLS;
	
	@JSONField(name="EarnLS")
	private String earnLS;
	
	@JSONField(name="RedeemLS")
	private String redeemLS;
	
	@JSONField(name="CloseLS")
	private String closeLS;
	
	@JSONField(name="EarnCTD")
	private String earnCTD;
	
	@JSONField(name="RedeemCTD")
	private String redeemCTD;
	
	@JSONField(name="ClosingCTD")
	private String closingCTD;

    @XmlElement(name = "Cardholder")
	public String getCardholder() {
		return cardholder;
	}

	public void setCardholder(String cardholder) {
		this.cardholder = cardholder;
	}

    @XmlElement(name = "OpeningLS")
	public String getOpeningLS() {
		return openingLS;
	}

	public void setOpeningLS(String openingLS) {
		this.openingLS = openingLS;
	}

    @XmlElement(name = "EarnLS")
	public String getEarnLS() {
		return earnLS;
	}

	public void setEarnLS(String earnLS) {
		this.earnLS = earnLS;
	}

    @XmlElement(name = "RedeemLS")
	public String getRedeemLS() {
		return redeemLS;
	}

	public void setRedeemLS(String redeemLS) {
		this.redeemLS = redeemLS;
	}

    @XmlElement(name = "CloseLS")
	public String getCloseLS() {
		return closeLS;
	}

	public void setCloseLS(String closeLS) {
		this.closeLS = closeLS;
	}

    @XmlElement(name = "EarnCTD")
	public String getEarnCTD() {
		return earnCTD;
	}

	public void setEarnCTD(String earnCTD) {
		this.earnCTD = earnCTD;
	}

    @XmlElement(name = "RedeemCTD")
	public String getRedeemCTD() {
		return redeemCTD;
	}

	public void setRedeemCTD(String redeemCTD) {
		this.redeemCTD = redeemCTD;
	}

    @XmlElement(name = "ClosingCTD")
	public String getClosingCTD() {
		return closingCTD;
	}

	public void setClosingCTD(String closingCTD) {
		this.closingCTD = closingCTD;
	}


}
