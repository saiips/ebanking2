package com.dsb.eb2.backOffice.connect.emsMsg.nf2089;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"moreItemsInd","lastKey","numOfItems","acctRefKey"})
public class AssoAcctDetails {
	
	public AssoAcctDetails() {}
	
	
	@JSONField(name="MoreItemsInd")
	private String moreItemsInd;
	
	@JSONField(name="LastKey")
	private String lastKey;
	
	@JSONField(name="NumOfItems")
	private String numOfItems;
	
	@JSONField(name="AcctRefKey")
	private List<AcctRefKey> acctRefKey;

	@XmlElement(name = "MoreItemsInd")
	public String getMoreItemsInd() {
		return moreItemsInd;
	}

	public void setMoreItemsInd(String moreItemsInd) {
		this.moreItemsInd = moreItemsInd;
	}

	@XmlElement(name = "LastKey")
	public String getLastKey() {
		return lastKey;
	}

	public void setLastKey(String lastKey) {
		this.lastKey = lastKey;
	}

	@XmlElement(name = "NumOfItems")
	public String getNumOfItems() {
		return numOfItems;
	}

	public void setNumOfItems(String numOfItems) {
		this.numOfItems = numOfItems;
	}

	@XmlElement(name = "AcctRefKey")
	public List<AcctRefKey> getAcctRefKey() {
		return acctRefKey;
	}

	public void setAcctRefKey(List<AcctRefKey> acctRefKey) {
		this.acctRefKey = acctRefKey;
	}

	
}



