package com.dsb.eb2.backOffice.connect.emsMsg.nf1108;

import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class NF1108ReqData extends FrmData {
	
	public NF1108ReqData() {}
	
    @Override
    @JSONField(serialize=false)
    public String getServiceID() {
        return "NF1108";
    }
	
    @JSONField(name="CardlinkInfo")
    private List<CardlinkInfo> cardlinkInfo;

    @JSONField(name="Filler")
    private List<Filler> filler;

    @JSONField(name="RetGuaInd")
    private String retGuaInd;
    
    @JSONField(name="AddrCode")
    private String addrCode;
    
    @JSONField(name="RetFDExCustInd")
    private String retFDExCustInd;

}
