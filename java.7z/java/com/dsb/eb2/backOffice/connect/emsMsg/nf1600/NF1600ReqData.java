package com.dsb.eb2.backOffice.connect.emsMsg.nf1600;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"acctNum","renewalInstruction","depPeriodCode","depPeriod",
		"setAcctNum","setAcctCcy","priAmtToBeAdj","intRateMarkup","action"})
public class NF1600ReqData extends FrmData
{
    public NF1600ReqData(){}
    
    @JSONField(serialize=false)
    @Override
    public String getServiceID()
    {
        return "NF1600";
    }

    @JSONField(name="AcctNum")
    private String acctNum ;

    @JSONField(name="RenewalInstruction")
    private String renewalInstruction ;

    @JSONField(name="DepPeriodCode")
    private String depPeriodCode ;

    @JSONField(name="DepPeriod")
    private String depPeriod ;

    @JSONField(name="SetAcctNum")
    private String setAcctNum ;

    @JSONField(name="SetAcctCcy")
    private String setAcctCcy ;

    @JSONField(name="PriAmtToBeAdj")
    private String priAmtToBeAdj ;

    @JSONField(name="IntRateMarkup")
    private String intRateMarkup ;

    @JSONField(name="Action")
    private String action;

    
	@XmlElement(name = "AcctNum")
	public String getAcctNum() {
		return acctNum;
	}

	public void setAcctNum(String acctNum) {
		this.acctNum = acctNum;
	}

	@XmlElement(name = "RenewalInstruction")
	public String getRenewalInstruction() {
		return renewalInstruction;
	}

	public void setRenewalInstruction(String renewalInstruction) {
		this.renewalInstruction = renewalInstruction;
	}

	@XmlElement(name = "DepPeriodCode")
	public String getDepPeriodCode() {
		return depPeriodCode;
	}

	public void setDepPeriodCode(String depPeriodCode) {
		this.depPeriodCode = depPeriodCode;
	}

	@XmlElement(name = "DepPeriod")
	public String getDepPeriod() {
		return depPeriod;
	}

	public void setDepPeriod(String depPeriod) {
		this.depPeriod = depPeriod;
	}

	@XmlElement(name = "SetAcctNum")
	public String getSetAcctNum() {
		return setAcctNum;
	}

	public void setSetAcctNum(String setAcctNum) {
		this.setAcctNum = setAcctNum;
	}

	@XmlElement(name = "SetAcctCcy")
	public String getSetAcctCcy() {
		return setAcctCcy;
	}

	public void setSetAcctCcy(String setAcctCcy) {
		this.setAcctCcy = setAcctCcy;
	}

	@XmlElement(name = "PriAmtToBeAdj")
	public String getPriAmtToBeAdj() {
		return priAmtToBeAdj;
	}

	public void setPriAmtToBeAdj(String priAmtToBeAdj) {
		this.priAmtToBeAdj = priAmtToBeAdj;
	}

	@XmlElement(name = "IntRateMarkup")
	public String getIntRateMarkup() {
		return intRateMarkup;
	}

	public void setIntRateMarkup(String intRateMarkup) {
		this.intRateMarkup = intRateMarkup;
	}

	@XmlElement(name = "Action")
	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}


}
