package com.dsb.eb2.backOffice.connect.emsMsg.nf1615;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

/**
 * NF1615 request Data
 *
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"accountNumber","depositNumber"})
public class NF1615ReqData 
	extends FrmData
{

	public NF1615ReqData (){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		
		return "NF1615";
	}

	@JSONField(name="AccountNumber")
	private String accountNumber;

	@JSONField(name="AccountNumber")
	private String depositNumber;

    @XmlElement(name = "AccountNumber")
	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

    @XmlElement(name = "DepositNumber")
	public String getDepositNumber() {
		return depositNumber;
	}

	public void setDepositNumber(String depositNumber) {
		this.depositNumber = depositNumber;
	}
	
	
	
}
