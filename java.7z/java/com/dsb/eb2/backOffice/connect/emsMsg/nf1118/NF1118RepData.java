package com.dsb.eb2.backOffice.connect.emsMsg.nf1118;

import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class NF1118RepData extends FrmData 
{
	
	public NF1118RepData(){}
	
	@Override
	public String getServiceID() {
		
		return "NF1118";
	}

	@JSONField(name="CustName")
	private String custName;
	
	@JSONField(name="First328AcctDate")
	private String first328AcctDate;
	
	@JSONField(name="LastUpdateDate")
	private String lastUpdateDate;
	
	@JSONField(name="PastMACSBBalInfo")
	private List<PastMACSBBalInfo> pastMACSBBalInfo;
}