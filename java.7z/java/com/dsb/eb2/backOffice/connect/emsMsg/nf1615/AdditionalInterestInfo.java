package com.dsb.eb2.backOffice.connect.emsMsg.nf1615;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"pastDueIntCallRate","pastDueIntContractRate","prematureIntCallRate","prematureIntContractRate"})
public class AdditionalInterestInfo {
	
	public AdditionalInterestInfo(){}
	
	@JSONField(name="PastDueIntCallRate")
	private String pastDueIntCallRate;
	
	@JSONField(name="PastDueIntContractRate")
	private String pastDueIntContractRate;
	
	@JSONField(name="PrematureIntCallRate")
	private String prematureIntCallRate;
	
	@JSONField(name="PrematureIntContractRate")
	private String prematureIntContractRate;

	@XmlElement(name = "PastDueIntCallRate")
	public String getPastDueIntCallRate() {
		return pastDueIntCallRate;
	}

	@XmlElement(name = "PastDueIntContractRate")
	public String getPastDueIntContractRate() {
		return pastDueIntContractRate;
	}

	@XmlElement(name = "PrematureIntCallRate")
	public String getPrematureIntCallRate() {
		return prematureIntCallRate;
	}

	@XmlElement(name = "PrematureIntContractRate")
	public String getPrematureIntContractRate() {
		return prematureIntContractRate;
	}

	public void setPastDueIntCallRate(String pastDueIntCallRate) {
		this.pastDueIntCallRate = pastDueIntCallRate;
	}

	public void setPastDueIntContractRate(String pastDueIntContractRate) {
		this.pastDueIntContractRate = pastDueIntContractRate;
	}

	public void setPrematureIntCallRate(String prematureIntCallRate) {
		this.prematureIntCallRate = prematureIntCallRate;
	}

	public void setPrematureIntContractRate(String prematureIntContractRate) {
		this.prematureIntContractRate = prematureIntContractRate;
	}
	
	

}
