package com.dsb.eb2.backOffice.connect.emsMsg;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSeeAlso;

import com.dsb.eb2.backOffice.connect.emsMsg.nf1107.NF1107RepData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1108.NF1108RepData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1612.NF1612RepData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1615.NF1615RepData;

/**
 * EMS响应消息，所有EMS响应消息必须继承此类
 * 
 * @author cxj
 * 
 */
@XmlSeeAlso( { 
    NF1107RepData.class,NF1108RepData.class,NF1612RepData.class,NF1615RepData.class})
@XmlRootElement(name = "XMLRepMsg")
@XmlAccessorType(XmlAccessType.PROPERTY)
public class EmsRepMsg
    extends EmsMsg
{
    public EmsRepMsg()
    {
        super();
    }

    public EmsRepMsg(FrmData frmData)
    {
        super(frmData);
    }

    public EmsRepMsg(FrmHdr frmHdr, FrmData frmData)
    {
        super(frmHdr, frmData);
    }

    @XmlElement(name = "Payload")
    public FrmData getFrmData()
    {
        return frmData;
    }

    public void setFrmData(FrmData frmData)
    {
        this.frmData = frmData;
    }

    public String getReturnCode()
    {
        FrmHdr frmHdr = getFrmHdr();
        if (null == frmHdr) return null;
        return frmHdr.getReturnCode();
    }
}
