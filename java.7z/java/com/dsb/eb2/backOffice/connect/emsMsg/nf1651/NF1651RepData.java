package com.dsb.eb2.backOffice.connect.emsMsg.nf1651;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"cardHolderNum","insLineInfoRetCode","availableInsAmt","reqField","cardInd","filler"})
public class NF1651RepData  extends FrmData
{
    
	public NF1651RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1651";
	}
	
	
	@JSONField(name="CardHolderNum")
	private String cardHolderNum;
	
	@JSONField(name="InsLineInfoRetCode")
	private String insLineInfoRetCode;
	
	@JSONField(name="AvailableInsAmt")
	private String availableInsAmt;
	
	@JSONField(name="ReqField")
	private String reqField;
	
	@JSONField(name="CardInd")
	private String cardInd;
	
	@JSONField(name="Filler")
	private String filler;

    @XmlElement(name = "CardHolderNum")
	public String getCardHolderNum() {
		return cardHolderNum;
	}

	public void setCardHolderNum(String cardHolderNum) {
		this.cardHolderNum = cardHolderNum;
	}

    @XmlElement(name = "InsLineInfoRetCode")
	public String getInsLineInfoRetCode() {
		return insLineInfoRetCode;
	}

	public void setInsLineInfoRetCode(String insLineInfoRetCode) {
		this.insLineInfoRetCode = insLineInfoRetCode;
	}

    @XmlElement(name = "AvailableInsAmt")
	public String getAvailableInsAmt() {
		return availableInsAmt;
	}

	public void setAvailableInsAmt(String availableInsAmt) {
		this.availableInsAmt = availableInsAmt;
	}

    @XmlElement(name = "ReqField")
	public String getReqField() {
		return reqField;
	}

	public void setReqField(String reqField) {
		this.reqField = reqField;
	}

    @XmlElement(name = "CardInd")
	public String getCardInd() {
		return cardInd;
	}

	public void setCardInd(String cardInd) {
		this.cardInd = cardInd;
	}

    @XmlElement(name = "Filler")
	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}
	
	
	
}
