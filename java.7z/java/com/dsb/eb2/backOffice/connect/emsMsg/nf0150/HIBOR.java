package com.dsb.eb2.backOffice.connect.emsMsg.nf0150;

import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class HIBOR
{
	public HIBOR(){}
	
	@JSONField(name="RateDetails") 
	private List<HIBORRateDetails>  rateDetails ;
}
