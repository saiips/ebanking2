package com.dsb.eb2.backOffice.connect.emsMsg.nf1118;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter		
public class PrivilegeStatus 
{

	public PrivilegeStatus(){}
	
	@JSONField(name="BankingRelFlag")
	private String bankingRelFlag;
	
	@JSONField(name="AcctInd")
	private String acctInd;
}

