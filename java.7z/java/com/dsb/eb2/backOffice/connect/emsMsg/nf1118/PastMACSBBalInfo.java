package com.dsb.eb2.backOffice.connect.emsMsg.nf1118;

import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class PastMACSBBalInfo {

	public PastMACSBBalInfo(){}
	
	@JSONField(name="BalMonth")
	private String balMonth;
	
	@JSONField(name="AverageBal")
	private String averageBal;
	
	@JSONField(name="PrivilegeStatus")
	private List<PrivilegeStatus> privilegeStatus;
}
