package com.dsb.eb2.backOffice.connect.emsMsg.nf1120;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class OptInDetails
{
	public OptInDetails(){}
	
	@JSONField(name="OptInFlag")
	private String  optInFlag;
	
	@JSONField(name="OptInDate") 
	private String  optInDate;
	
	@JSONField(name="OptInSource") 
	private String  optInSource;
}
