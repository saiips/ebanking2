package com.dsb.eb2.backOffice.connect.emsMsg.nf1565;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"lastKey","itemsInd","numItems","bookingDetails"})

public class NF1565RepData extends FrmData  {

	@Override
	public String getServiceID() {
		return "NF1565";
	}
	public NF1565RepData() {
	}

    private String lastKey = "";
    
    private String itemsInd = "";
    
    private String numItems = "";
    
    private List<BookingDetails> bookingDetails;
    
    @XmlElement(name = "LastKey")
    public String getLastKey()
    {
        return lastKey;
    }
    public void setLastKey(String lastKey)
    {
        this.lastKey = lastKey;
    }

    @XmlElement(name = "MoreItemsInd")
    public String getItemsInd()
    {
        return itemsInd;
    }
    public void setItemsInd(String itemsInd)
    {
        this.itemsInd = itemsInd;
    }

    @XmlElement(name = "NumOfItems")
    public String getNumItems()
    {
        return numItems;
    }
    public void setNumItems(String numItems)
    {
        this.numItems = numItems;
    }

    @XmlElement(name = "BookingDetails")
    public List<BookingDetails> getBookingDetails()
    {
        return bookingDetails;
    }
    public void setBookingDetails(List<BookingDetails> bookingDetails)
    {
        this.bookingDetails = bookingDetails;
    }

}
