package com.dsb.eb2.backOffice.connect.emsMsg.nf1124;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;


@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"userData","custOrgNumber","custNumber","corpOrgNumber","corpCustNumber",
		"officerCode","creditLimit","cashLimit","dailyCashLimit","walrnBulletin",
		"billingCycle","statementFreq","dateNextStatement","statementFlag",
		"dateLastMaint","specialStatus","shortName","jETCOChipFlag","paymentMethod",
		"aCHBank","account","faymentType","fixedPayment","opened","closed","user1AppRecv",
		"user2DateOfBirth","dateTransferEffective","transferNewAccountNbr","dateBlock",
		"blockCode","dateAltBlock","altBlock","userCode1CardFeeCode","userCode2","userCode3",
		"cardFee","ownershipFlag","collateral","altCustomerNumber","dateAltCustExpires",
		"duplicateStatement","expires","retailInterest","cashInterest","lateCharge",
		"lateNotices","annualFees","overLimitCharges","serviceCharges","prepayFlag",
		"joiningFee","tableOccurrence","expirationDate","pendingOccurrence","expiration",
		"multiple","epssPinRetries","displayRequest","bonusBucks","bucksUsed","collCardRequest",
		"hiBalance","tblHbl","prepay","posting","insuredDateOfBirth","coinsuredDateOfBirth",
		"numOfRow","insurList","OctopusCardNumber","AAVSStatus"})
public class  NF1124RepData extends FrmData
{
    
	public NF1124RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1124";
	}

	@JSONField(name="UserData")
	private String userData;
	
	@JSONField(name="CustOrgNumber")
	private String custOrgNumber;
	
	@JSONField(name="CustNumber")
	private String custNumber;
	
	@JSONField(name="CorpOrgNumber")
	private String corpOrgNumber;
	
	@JSONField(name="CorpCustNumber")
	private String corpCustNumber;
	
	@JSONField(name="OfficerCode")
	private String officerCode;
	
	@JSONField(name="CreditLimit")
	private String creditLimit;
	
	@JSONField(name="CashLimit")
	private String cashLimit;
	
	@JSONField(name="DailyCashLimit")
	private String dailyCashLimit;
	
	@JSONField(name="WarnBulletin")
	private String warnBulletin;
	
	@JSONField(name="BillingCycle")
	private String billingCycle;
	
	@JSONField(name="StatementFreq")
	private String statementFreq;
	
	@JSONField(name="DateNextStatement")
	private String dateNextStatement;
	
	@JSONField(name="StatementFlag")
	private String statementFlag;
	
	@JSONField(name="DateLastMaint")
	private String dateLastMaint;
	
	@JSONField(name="SpecialStatus")
	private String specialStatus;
	
	@JSONField(name="ShortName")
	private String shortName;
	
	@JSONField(name="JETCOChipFlag")
	private String jETCOChipFlag;
	
	@JSONField(name="PaymentMethod")
	private String paymentMethod;
	
	@JSONField(name="ACHBank")
	private String aCHBank;
	
	@JSONField(name="Account")
	private String account;
	
	@JSONField(name="PaymentType")
	private String faymentType;
	
	@JSONField(name="FixedPayment")
	private String fixedPayment;
	
	@JSONField(name="Opened")
	private String opened;
	
	@JSONField(name="Closed")
	private String closed;
	
	@JSONField(name="User1AppRecv")
	private String user1AppRecv;
	
	@JSONField(name="User2DateOfBirth")
	private String user2DateOfBirth;
	
	@JSONField(name="DateTransferEffective")
	private String dateTransferEffective;
	
	@JSONField(name="TransferNewAccountNbr")
	private String transferNewAccountNbr;
	
	@JSONField(name="DateBlock")
	private String dateBlock;
	
	@JSONField(name="BlockCode")
	private String blockCode;
	
	@JSONField(name="DateAltBlock")
	private String dateAltBlock;
	
	@JSONField(name="AltBlock")
	private String altBlock;
	
	@JSONField(name="UserCode1CardFeeCode")
	private String userCode1CardFeeCode;
	
	@JSONField(name="UserCode2")
	private String userCode2;
	
	@JSONField(name="UserCode3")
	private String userCode3;
	
	@JSONField(name="CardFee")
	private String cardFee;
	
	@JSONField(name="OwnershipFlag")
	private String ownershipFlag;
	
	@JSONField(name="Collateral")
	private String collateral;
	
	@JSONField(name="AltCustomerNumber")
	private String altCustomerNumber;
	
	@JSONField(name="DateAltCustExpires")
	private String dateAltCustExpires;
	
	@JSONField(name="DuplicateStatement")
	private String duplicateStatement;
	
	@JSONField(name="Expires")
	private String expires;
	
	@JSONField(name="RetailInterest")
	private String retailInterest;
	
	@JSONField(name="CashInterest")
	private String cashInterest;
	
	@JSONField(name="LateCharge")
	private String lateCharge;
	
	@JSONField(name="LateNotices")
	private String lateNotices;
	
	@JSONField(name="AnnualFees")
	private String annualFees;
	
	@JSONField(name="OverLimitCharges")
	private String overLimitCharges;
	
	@JSONField(name="ServiceCharges")
	private String serviceCharges;
	
	@JSONField(name="PrepayFlag")
	private String prepayFlag;
	
	@JSONField(name="JoiningFee")
	private String joiningFee;
	
	@JSONField(name="TableOccurrence")
	private String tableOccurrence;
	
	@JSONField(name="ExpirationDate")
	private String expirationDate;
	
	@JSONField(name="PendingOccurrence")
	private String pendingOccurrence;
	
	@JSONField(name="Expiration")
	private String expiration;
	
	@JSONField(name="Multiple")
	private String multiple;
	
	@JSONField(name="EpssPinRetries")
	private String epssPinRetries;
	
	@JSONField(name="DisplayRequest")
	private String displayRequest;
	
	@JSONField(name="BonusBucks")
	private String bonusBucks;
	
	@JSONField(name="BucksUsed")
	private String bucksUsed;
	
	@JSONField(name="CollCardRequest")
	private String collCardRequest;
	
	@JSONField(name="HiBalance")
	private String hiBalance;
	
	@JSONField(name="TblHbl")
	private String tblHbl;
	
	@JSONField(name="Prepay")
	private String prepay;
	
	@JSONField(name="Posting")
	private String posting;
	
	@JSONField(name="InsuredDateOfBirth")
	private String insuredDateOfBirth;
	
	@JSONField(name="CoinsuredDateOfBirth")
	private String coinsuredDateOfBirth;
	
	@JSONField(name="NumOfRow")
	private String numOfRow;
	
	@JSONField(name="InsurList")
	private List <InsurList> insurList;
	
	@JSONField(name="OctopusCardNumber")
	private String OctopusCardNumber;
	
	@JSONField(name="AAVSStatus")
	private String AAVSStatus;

	
	
	@XmlElement(name="UserData")
	public String getUserData() {
		return userData;
	}

	public void setUserData(String userData) {
		this.userData = userData;
	}

	@XmlElement(name="CustOrgNumber")
	public String getCustOrgNumber() {
		return custOrgNumber;
	}

	public void setCustOrgNumber(String custOrgNumber) {
		this.custOrgNumber = custOrgNumber;
	}

	@XmlElement(name="CustNumber")
	public String getCustNumber() {
		return custNumber;
	}

	public void setCustNumber(String custNumber) {
		this.custNumber = custNumber;
	}

	@XmlElement(name="CorpOrgNumber")
	public String getCorpOrgNumber() {
		return corpOrgNumber;
	}

	public void setCorpOrgNumber(String corpOrgNumber) {
		this.corpOrgNumber = corpOrgNumber;
	}

	@XmlElement(name="CorpCustNumber")
	public String getCorpCustNumber() {
		return corpCustNumber;
	}

	public void setCorpCustNumber(String corpCustNumber) {
		this.corpCustNumber = corpCustNumber;
	}

	@XmlElement(name="OfficerCode")
	public String getOfficerCode() {
		return officerCode;
	}

	public void setOfficerCode(String officerCode) {
		this.officerCode = officerCode;
	}

	@XmlElement(name="CreditLimit")
	public String getCreditLimit() {
		return creditLimit;
	}

	public void setCreditLimit(String creditLimit) {
		this.creditLimit = creditLimit;
	}

	@XmlElement(name="CashLimit")
	public String getCashLimit() {
		return cashLimit;
	}

	public void setCashLimit(String cashLimit) {
		this.cashLimit = cashLimit;
	}

	@XmlElement(name="DailyCashLimit")
	public String getDailyCashLimit() {
		return dailyCashLimit;
	}

	public void setDailyCashLimit(String dailyCashLimit) {
		this.dailyCashLimit = dailyCashLimit;
	}

	@XmlElement(name="WarnBulletin")
	public String getWarnBulletin() {
		return warnBulletin;
	}

	public void setWarnBulletin(String warnBulletin) {
		this.warnBulletin = warnBulletin;
	}

	@XmlElement(name="BillingCycle")
	public String getBillingCycle() {
		return billingCycle;
	}

	public void setBillingCycle(String billingCycle) {
		this.billingCycle = billingCycle;
	}

	@XmlElement(name="StatementFreq")
	public String getStatementFreq() {
		return statementFreq;
	}

	public void setStatementFreq(String statementFreq) {
		this.statementFreq = statementFreq;
	}

	@XmlElement(name="DateNextStatement")
	public String getDateNextStatement() {
		return dateNextStatement;
	}

	public void setDateNextStatement(String dateNextStatement) {
		this.dateNextStatement = dateNextStatement;
	}

	@XmlElement(name="StatementFlag")
	public String getStatementFlag() {
		return statementFlag;
	}

	public void setStatementFlag(String statementFlag) {
		this.statementFlag = statementFlag;
	}

	@XmlElement(name="DateLastMaint")
	public String getDateLastMaint() {
		return dateLastMaint;
	}

	public void setDateLastMaint(String dateLastMaint) {
		this.dateLastMaint = dateLastMaint;
	}

	@XmlElement(name="SpecialStatus")
	public String getSpecialStatus() {
		return specialStatus;
	}

	public void setSpecialStatus(String specialStatus) {
		this.specialStatus = specialStatus;
	}

	@XmlElement(name="ShortName")
	public String getShortName() {
		return shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	@XmlElement(name="JETCOChipFlag")
	public String getjETCOChipFlag() {
		return jETCOChipFlag;
	}

	public void setjETCOChipFlag(String jETCOChipFlag) {
		this.jETCOChipFlag = jETCOChipFlag;
	}

	@XmlElement(name="PaymentMethod")
	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	@XmlElement(name="ACHBank")
	public String getaCHBank() {
		return aCHBank;
	}

	public void setaCHBank(String aCHBank) {
		this.aCHBank = aCHBank;
	}

	@XmlElement(name="Account")
	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	@XmlElement(name="PaymentType")
	public String getFaymentType() {
		return faymentType;
	}

	public void setFaymentType(String faymentType) {
		this.faymentType = faymentType;
	}

	@XmlElement(name="FixedPayment")
	public String getFixedPayment() {
		return fixedPayment;
	}

	public void setFixedPayment(String fixedPayment) {
		this.fixedPayment = fixedPayment;
	}

	@XmlElement(name="Opened")
	public String getOpened() {
		return opened;
	}

	public void setOpened(String opened) {
		this.opened = opened;
	}

	@XmlElement(name="Closed")
	public String getClosed() {
		return closed;
	}

	public void setClosed(String closed) {
		this.closed = closed;
	}

	@XmlElement(name="User1AppRecv")
	public String getUser1AppRecv() {
		return user1AppRecv;
	}

	public void setUser1AppRecv(String user1AppRecv) {
		this.user1AppRecv = user1AppRecv;
	}

	@XmlElement(name="User2DateOfBirth")
	public String getUser2DateOfBirth() {
		return user2DateOfBirth;
	}

	public void setUser2DateOfBirth(String user2DateOfBirth) {
		this.user2DateOfBirth = user2DateOfBirth;
	}

	@XmlElement(name="DateTransferEffective")
	public String getDateTransferEffective() {
		return dateTransferEffective;
	}

	public void setDateTransferEffective(String dateTransferEffective) {
		this.dateTransferEffective = dateTransferEffective;
	}

	@XmlElement(name="TransferNewAccountNbr")
	public String getTransferNewAccountNbr() {
		return transferNewAccountNbr;
	}

	public void setTransferNewAccountNbr(String transferNewAccountNbr) {
		this.transferNewAccountNbr = transferNewAccountNbr;
	}

	@XmlElement(name="DateBlock")
	public String getDateBlock() {
		return dateBlock;
	}

	public void setDateBlock(String dateBlock) {
		this.dateBlock = dateBlock;
	}

	@XmlElement(name="BlockCode")
	public String getBlockCode() {
		return blockCode;
	}

	public void setBlockCode(String blockCode) {
		this.blockCode = blockCode;
	}

	
	@XmlElement(name="DateAltBlock")
	public String getDateAltBlock() {
		return dateAltBlock;
	}

	public void setDateAltBlock(String dateAltBlock) {
		this.dateAltBlock = dateAltBlock;
	}

	@XmlElement(name="AltBlock")
	public String getAltBlock() {
		return altBlock;
	}

	public void setAltBlock(String altBlock) {
		this.altBlock = altBlock;
	}

	@XmlElement(name="UserCode1CardFeeCode")
	public String getUserCode1CardFeeCode() {
		return userCode1CardFeeCode;
	}

	public void setUserCode1CardFeeCode(String userCode1CardFeeCode) {
		this.userCode1CardFeeCode = userCode1CardFeeCode;
	}

	@XmlElement(name="UserCode2")
	public String getUserCode2() {
		return userCode2;
	}

	public void setUserCode2(String userCode2) {
		this.userCode2 = userCode2;
	}

	@XmlElement(name="UserCode3")
	public String getUserCode3() {
		return userCode3;
	}

	public void setUserCode3(String userCode3) {
		this.userCode3 = userCode3;
	}

	@XmlElement(name="CardFee")
	public String getCardFee() {
		return cardFee;
	}

	public void setCardFee(String cardFee) {
		this.cardFee = cardFee;
	}

	@XmlElement(name="OwnershipFlag")
	public String getOwnershipFlag() {
		return ownershipFlag;
	}

	public void setOwnershipFlag(String ownershipFlag) {
		this.ownershipFlag = ownershipFlag;
	}

	@XmlElement(name="Collateral")
	public String getCollateral() {
		return collateral;
	}

	public void setCollateral(String collateral) {
		this.collateral = collateral;
	}

	@XmlElement(name="AltCustomerNumber")
	public String getAltCustomerNumber() {
		return altCustomerNumber;
	}

	public void setAltCustomerNumber(String altCustomerNumber) {
		this.altCustomerNumber = altCustomerNumber;
	}

	@XmlElement(name="DateAltCustExpires")
	public String getDateAltCustExpires() {
		return dateAltCustExpires;
	}

	public void setDateAltCustExpires(String dateAltCustExpires) {
		this.dateAltCustExpires = dateAltCustExpires;
	}

	@XmlElement(name="DuplicateStatement")
	public String getDuplicateStatement() {
		return duplicateStatement;
	}

	public void setDuplicateStatement(String duplicateStatement) {
		this.duplicateStatement = duplicateStatement;
	}

	@XmlElement(name="Expires")
	public String getExpires() {
		return expires;
	}

	public void setExpires(String expires) {
		this.expires = expires;
	}

	@XmlElement(name="RetailInterest")
	public String getRetailInterest() {
		return retailInterest;
	}

	public void setRetailInterest(String retailInterest) {
		this.retailInterest = retailInterest;
	}

	@XmlElement(name="CashInterest")
	public String getCashInterest() {
		return cashInterest;
	}

	public void setCashInterest(String cashInterest) {
		this.cashInterest = cashInterest;
	}

	@XmlElement(name="LateCharge")
	public String getLateCharge() {
		return lateCharge;
	}

	public void setLateCharge(String lateCharge) {
		this.lateCharge = lateCharge;
	}

	@XmlElement(name="LateNotices")
	public String getLateNotices() {
		return lateNotices;
	}

	public void setLateNotices(String lateNotices) {
		this.lateNotices = lateNotices;
	}

	@XmlElement(name="AnnualFees")
	public String getAnnualFees() {
		return annualFees;
	}

	public void setAnnualFees(String annualFees) {
		this.annualFees = annualFees;
	}

	@XmlElement(name="OverLimitCharges")
	public String getOverLimitCharges() {
		return overLimitCharges;
	}

	public void setOverLimitCharges(String overLimitCharges) {
		this.overLimitCharges = overLimitCharges;
	}

	@XmlElement(name="ServiceCharges")
	public String getServiceCharges() {
		return serviceCharges;
	}

	public void setServiceCharges(String serviceCharges) {
		this.serviceCharges = serviceCharges;
	}

	@XmlElement(name="PrepayFlag")
	public String getPrepayFlag() {
		return prepayFlag;
	}

	public void setPrepayFlag(String prepayFlag) {
		this.prepayFlag = prepayFlag;
	}

	@XmlElement(name="JoiningFee")
	public String getJoiningFee() {
		return joiningFee;
	}

	public void setJoiningFee(String joiningFee) {
		this.joiningFee = joiningFee;
	}

	@XmlElement(name="TableOccurrence")
	public String getTableOccurrence() {
		return tableOccurrence;
	}

	public void setTableOccurrence(String tableOccurrence) {
		this.tableOccurrence = tableOccurrence;
	}

	@XmlElement(name="ExpirationDate")
	public String getExpirationDate() {
		return expirationDate;
	}

	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}

	@XmlElement(name="PendingOccurrence")
	public String getPendingOccurrence() {
		return pendingOccurrence;
	}

	public void setPendingOccurrence(String pendingOccurrence) {
		this.pendingOccurrence = pendingOccurrence;
	}

	@XmlElement(name="Expiration")
	public String getExpiration() {
		return expiration;
	}

	public void setExpiration(String expiration) {
		this.expiration = expiration;
	}

	@XmlElement(name="Multiple")
	public String getMultiple() {
		return multiple;
	}

	public void setMultiple(String multiple) {
		this.multiple = multiple;
	}

	@XmlElement(name="EpssPinRetries")
	public String getEpssPinRetries() {
		return epssPinRetries;
	}

	public void setEpssPinRetries(String epssPinRetries) {
		this.epssPinRetries = epssPinRetries;
	}

	@XmlElement(name="DisplayRequest")
	public String getDisplayRequest() {
		return displayRequest;
	}

	public void setDisplayRequest(String displayRequest) {
		this.displayRequest = displayRequest;
	}

	@XmlElement(name="BonusBucks")
	public String getBonusBucks() {
		return bonusBucks;
	}

	public void setBonusBucks(String bonusBucks) {
		this.bonusBucks = bonusBucks;
	}

	@XmlElement(name="BucksUsed")
	public String getBucksUsed() {
		return bucksUsed;
	}

	public void setBucksUsed(String bucksUsed) {
		this.bucksUsed = bucksUsed;
	}

	@XmlElement(name="CollCardRequest")
	public String getCollCardRequest() {
		return collCardRequest;
	}

	public void setCollCardRequest(String collCardRequest) {
		this.collCardRequest = collCardRequest;
	}

	@XmlElement(name="HiBalance")
	public String getHiBalance() {
		return hiBalance;
	}

	public void setHiBalance(String hiBalance) {
		this.hiBalance = hiBalance;
	}

	@XmlElement(name="TblHbl")
	public String getTblHbl() {
		return tblHbl;
	}

	public void setTblHbl(String tblHbl) {
		this.tblHbl = tblHbl;
	}

	@XmlElement(name="Prepay")
	public String getPrepay() {
		return prepay;
	}

	public void setPrepay(String prepay) {
		this.prepay = prepay;
	}

	@XmlElement(name="Posting")
	public String getPosting() {
		return posting;
	}

	public void setPosting(String posting) {
		this.posting = posting;
	}

	@XmlElement(name="InsuredDateOfBirth")
	public String getInsuredDateOfBirth() {
		return insuredDateOfBirth;
	}

	public void setInsuredDateOfBirth(String insuredDateOfBirth) {
		this.insuredDateOfBirth = insuredDateOfBirth;
	}

	@XmlElement(name="CoinsuredDateOfBirth")
	public String getCoinsuredDateOfBirth() {
		return coinsuredDateOfBirth;
	}

	public void setCoinsuredDateOfBirth(String coinsuredDateOfBirth) {
		this.coinsuredDateOfBirth = coinsuredDateOfBirth;
	}

	@XmlElement(name="NumOfRow")
	public String getNumOfRow() {
		return numOfRow;
	}

	public void setNumOfRow(String numOfRow) {
		this.numOfRow = numOfRow;
	}

	@XmlElement(name="InsurList")
	public List<InsurList> getInsurList() {
		return insurList;
	}

	public void setInsurList(List<InsurList> insurList) {
		this.insurList = insurList;
	}

	@XmlElement(name="OctopusCardNumber")
	public String getOctopusCardNumber() {
		return OctopusCardNumber;
	}

	public void setOctopusCardNumber(String octopusCardNumber) {
		OctopusCardNumber = octopusCardNumber;
	}

	@XmlElement(name="AAVSStatus")
	public String getAAVSStatus() {
		return AAVSStatus;
	}

	public void setAAVSStatus(String aAVSStatus) {
		AAVSStatus = aAVSStatus;
	}

	
}
