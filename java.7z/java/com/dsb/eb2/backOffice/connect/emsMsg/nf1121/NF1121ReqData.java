package com.dsb.eb2.backOffice.connect.emsMsg.nf1121;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"AccountNumber","AccountType"})
public class  NF1121ReqData extends FrmData
{
    
	public NF1121ReqData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1121";
	}
	
	@JSONField(name="AccountNumber")
	private String AccountNumber;
	
	@JSONField(name="AccountType")
	private String   AccountType;

	
	@XmlElement(name="AccountNumber")
	public String getAccountNumber() {
		return AccountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		AccountNumber = accountNumber;
	}

	@XmlElement(name="AccountType")
	public String getAccountType() {
		return AccountType;
	}

	public void setAccountType(String accountType) {
		AccountType = accountType;
	}

	
}