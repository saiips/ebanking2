package com.dsb.eb2.backOffice.connect.emsMsg.nf1132;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;
@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"teleUserID","lastKey","itemsReq"})
public class NF1132ReqData  extends FrmData
{
    public NF1132ReqData(){}

	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1132";
	}
	
	@JSONField(name="TeleUserID") 
	private String teleUserID;
	
	@JSONField(name="LastKey") 
	private String lastKey;
	
	@JSONField(name="ItemsReq") 
	private String itemsReq;


    @XmlElement(name = "TeleUserID")    
	public String getTeleUserID() {
		return teleUserID;
	}

	public void setTeleUserID(String teleUserID) {
		this.teleUserID = teleUserID;
	}


    @XmlElement(name = "LastKey")    
	public String getLastKey() {
		return lastKey;
	}

	public void setLastKey(String lastKey) {
		this.lastKey = lastKey;
	}


    @XmlElement(name = "ItemsReq")    
	public String getItemsReq() {
		return itemsReq;
	}

	public void setItemsReq(String itemsReq) {
		this.itemsReq = itemsReq;
	}

	
}

