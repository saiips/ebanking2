package com.dsb.eb2.backOffice.connect.emsMsg.nf2089;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;
@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"type","moreItemsInd","lastKey","numOfItems","reasonCode"})
public class ReasonCodeDetails {
	
	public ReasonCodeDetails() {}
	
	@JSONField(name="Type")
	private String type;
	
	@JSONField(name="MoreItemsInd")
	private String moreItemsInd;
	
	@JSONField(name="LastKey")
	private String lastKey;
	
	@JSONField(name="NumOfItems")
	private String numOfItems;
	
	@JSONField(name="ReasonCode")
	private String reasonCode;

	@XmlElement(name = "Type")
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@XmlElement(name = "MoreItemsInd")
	public String getMoreItemsInd() {
		return moreItemsInd;
	}

	public void setMoreItemsInd(String moreItemsInd) {
		this.moreItemsInd = moreItemsInd;
	}

	@XmlElement(name = "LastKey")
	public String getLastKey() {
		return lastKey;
	}

	public void setLastKey(String lastKey) {
		this.lastKey = lastKey;
	}

	@XmlElement(name = "NumOfItems")
	public String getNumOfItems() {
		return numOfItems;
	}

	public void setNumOfItems(String numOfItems) {
		this.numOfItems = numOfItems;
	}

	@XmlElement(name = "ReasonCode")
	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}
	
	
}



