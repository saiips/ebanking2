package com.dsb.eb2.backOffice.connect.emsMsg.nf1652;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.util.StringUtils;


@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"txnDate", "postDate","txnDesc" ,"txnCur","txnAmt","hkdEqu","exRate"})

public class TransactionDetails implements Serializable{
	
	
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	@JSONField(name="TxnDate")
	private String txnDate;
	
	@JSONField(name="PostDate")
	private String postDate;
	
	@JSONField(name="TxnDesc")
	private String txnDesc;
	
	@JSONField(name="TxnCur")
	private String txnCur;
	
	@JSONField(name="TxnAmt")
	private String txnAmt;
	
	@JSONField(name="HkdEqu")
	private String hkdEqu;
	
	@JSONField(name="ExRate")
	private String exRate;

	/**
	 * @return the txnDate
	 */
	@XmlElement(name="TransDate")
	public String getTxnDate() {
		return txnDate;
	}

	/**
	 * @param txnDate the txnDate to set
	 */
	public void setTxnDate(String txnDate) {
		this.txnDate = txnDate;
	}

	/**
	 * @return the postDate
	 */
	@XmlElement(name="PostingDate")
	public String getPostDate() {
		return postDate;
	}

	/**
	 * @param postDate the postDate to set
	 */
	public void setPostDate(String postDate) {
		this.postDate = postDate;
	}

	/**
	 * @return the txnDesc
	 */
	@XmlElement(name="TransDesc")
	public String getTxnDesc() {
		return txnDesc;
	}

	/**
	 * @param txnDesc the txnDesc to set
	 */
	public void setTxnDesc(String txnDesc) {
		this.txnDesc = txnDesc;
	}

	/**
	 * @return the txnCur
	 */
	@XmlElement(name="TransCcy")
	public String getTxnCur() {
		return txnCur;
	}

	/**
	 * @param txnCur the txnCur to set
	 */
	public void setTxnCur(String txnCur) {
		this.txnCur = txnCur;
	}

	/**
	 * @return the txnAmt
	 */
	@XmlElement(name="TransAmt")
	public String getTxnAmt() {
		return txnAmt;
	}

	/**
	 * @param txnAmt the txnAmt to set
	 */
	public void setTxnAmt(String txnAmt) {
		this.txnAmt = txnAmt;
	}

	/**
	 * @return the hkdEqu
	 */
	@XmlElement(name="HKDEq")
	public String getHkdEqu() {
		return hkdEqu;
	}

	/**
	 * @param hkdEqu the hkdEqu to set
	 */
	public void setHkdEqu(String hkdEqu) {
		this.hkdEqu = hkdEqu;
	}
	
	@XmlElement(name = "ExRate")
	public String getExRate() {	
		 BigDecimal rate_1 = new BigDecimal("1");		 
	     if(!StringUtils.isBlank(this.exRate) && rate_1.compareTo(new BigDecimal(this.exRate))==0) this.exRate="1.000000";
		 return exRate;
	}

	public void setExRate(String exRate) {
		this.exRate = exRate;
	}
	
	
	

}
