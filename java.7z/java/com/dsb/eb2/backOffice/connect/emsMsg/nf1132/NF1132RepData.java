package com.dsb.eb2.backOffice.connect.emsMsg.nf1132;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;
@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"teleUserID","lastKey","moreItemsInd","numOfItems","regAcctDetails"})
public class NF1132RepData extends FrmData
{
    public NF1132RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1132";
	}
	
	@JSONField(name="TeleUserID")
	private String  teleUserID;
	
	@JSONField(name="LastKey") 
	private String  lastKey;
	
	@JSONField(name="MoreItemsInd") 
	private String  moreItemsInd;
	
	@JSONField(name="NumOfItems")
    private String  numOfItems;
	
	@JSONField(name="RegAcctDetails") 
	private List<RegAcctDetails>  regAcctDetails;

    @XmlElement(name = "TeleUserID")
	public String getTeleUserID() {
		return teleUserID;
	}

	public void setTeleUserID(String teleUserID) {
		this.teleUserID = teleUserID;
	}

    @XmlElement(name = "LastKey")
	public String getLastKey() {
		return lastKey;
	}

	public void setLastKey(String lastKey) {
		this.lastKey = lastKey;
	}

    @XmlElement(name = "MoreItemsInd")
	public String getMoreItemsInd() {
		return moreItemsInd;
	}

	public void setMoreItemsInd(String moreItemsInd) {
		this.moreItemsInd = moreItemsInd;
	}

    @XmlElement(name = "NumOfItems")
	public String getNumOfItems() {
		return numOfItems;
	}

	public void setNumOfItems(String numOfItems) {
		this.numOfItems = numOfItems;
	}

	@XmlElement(name = "RegAcctDetails")
	public List<RegAcctDetails> getRegAcctDetails() {
		return regAcctDetails;
	}

	public void setRegAcctDetails(List<RegAcctDetails> regAcctDetails) {
		this.regAcctDetails = regAcctDetails;
	}


}

