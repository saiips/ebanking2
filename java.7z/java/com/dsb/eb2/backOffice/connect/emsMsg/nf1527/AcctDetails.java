package com.dsb.eb2.backOffice.connect.emsMsg.nf1527;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"pdtType","acctNum"})
public class AcctDetails {
	
	public AcctDetails(){}
	
	@JSONField(name="PdtType")
	private String pdtType;
	
	@JSONField(name="AcctNum")
	private String acctNum;

	@XmlElement(name = "PdtType")
	public String getPdtType() {
		return pdtType;
	}

	public void setPdtType(String pdtType) {
		this.pdtType = pdtType;
	}
	
	@XmlElement(name = "AcctNum")
	public String getAcctNum() {
		return acctNum;
	}

	public void setAcctNum(String acctNum) {
		this.acctNum = acctNum;
	}


}
