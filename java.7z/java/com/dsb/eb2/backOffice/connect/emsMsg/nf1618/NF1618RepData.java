package com.dsb.eb2.backOffice.connect.emsMsg.nf1618;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;


public class NF1618RepData extends FrmData{

	@Override
	public String getServiceID() {
		return "NF1618";
	}
	
	@JSONField(name="NumOfItems")
	private String numOfItems;
	
	@JSONField(name="LogNum")
	private String logNum;

}
