package com.dsb.eb2.backOffice.connect.emsMsg.nf1560;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"maturityDate","filler1"})
public class FDInformaiton 
{
	
	public FDInformaiton(){}
	
	private String maturityDate = "";
	
	private String filler1 = "";

	@XmlElement(name = "MaturityDate")
	public String getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}

	@XmlElement(name = "Filler1")
	public String getFiller1() {
		return filler1;
	}

	public void setFiller1(String filler1) {
		this.filler1 = filler1;
	}
	
}
