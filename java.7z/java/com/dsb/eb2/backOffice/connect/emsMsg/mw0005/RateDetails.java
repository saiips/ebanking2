package com.dsb.eb2.backOffice.connect.emsMsg.mw0005;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class RateDetails
{
	public RateDetails(){}
	
	@JSONField(name="CCY")
	private String ccy;
	
	@JSONField(name="DDBuy")
	private String DDBuy;
	
	@JSONField(name="NotesBuy")
	private String notesBuy;
	
	@JSONField(name="NotesSell")
	private String notesSell;
	
	@JSONField(name="CostBuy")
	private String costBuy;
	
	@JSONField(name="CostSell")
	private String costSell;
	
	@JSONField(name="MinProfitBuy")
	private String minProfitBuy ;
	
	@JSONField(name="MinProfitSell")
	private String minProfitSell;
	
	@JSONField(name="NormalBuy")
	private String normalBuy ;
	
	@JSONField(name="NormalSell")
	private String normalSell ;
	
	@JSONField(name="VIPBuy")
	private String vipBuy ;
	
	@JSONField(name="VIPSell")
	private String vipSell ;
	
	@JSONField(name="SuperVIPBuy")
	private String superVIPBuy ;
	
	@JSONField(name="SuperVIPSell")
	private String superVIPSell ;
	
	@JSONField(name="UpdateTimestamp")
	private String updateTimestamp ;

}
