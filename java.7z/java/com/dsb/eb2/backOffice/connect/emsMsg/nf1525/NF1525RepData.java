package com.dsb.eb2.backOffice.connect.emsMsg.nf1525;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"customerNumber","hostTxSeqNumber"})
public class NF1525RepData  extends FrmData
{
    
	public NF1525RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1525";
	}
	
	@JSONField(name="CustomerNumber")
	private String customerNumber;
	
	@JSONField(name="HostTxSeqNumber")
	private String hostTxSeqNumber;

    @XmlElement(name = "CustomerNumber")
	public String getCustomerNumber() {
		return customerNumber;
	}

	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}

    @XmlElement(name = "HostTxSeqNumber")
	public String getHostTxSeqNumber() {
		return hostTxSeqNumber;
	}

	public void setHostTxSeqNumber(String hostTxSeqNumber) {
		this.hostTxSeqNumber = hostTxSeqNumber;
	}
	
	
	
}
