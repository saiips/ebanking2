package com.dsb.eb2.backOffice.connect.emsMsg.nf1620;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"option","action","emailAddr","logNum","newRefNum","hostEmailUpdDate","emailUpdStatus"})
public class NF1620RepData  extends FrmData
{
    
	public NF1620RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1620";
	}
	
	
	@JSONField(name="Option")
	private String option;
	
	@JSONField(name="Action")
	private String action;
	
	@JSONField(name="EmailAddr")
	private String emailAddr;
	
	@JSONField(name="LogNum") 
	private String logNum;
	
	@JSONField(name="NewRefNum")
	private String newRefNum;
	
	@JSONField(name="HostEmailUpdDate") 
	private String hostEmailUpdDate;
	
	@JSONField(name="EmailUpdStatus")
	private String emailUpdStatus;

    @XmlElement(name = "Option")
	public String getOption() {
		return option;
	}

	public void setOption(String option) {
		this.option = option;
	}

    @XmlElement(name = "Action")
	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

    @XmlElement(name = "EmailAddr")
	public String getEmailAddr() {
		return emailAddr;
	}

	public void setEmailAddr(String emailAddr) {
		this.emailAddr = emailAddr;
	}

    @XmlElement(name = "LogNum")
	public String getLogNum() {
		return logNum;
	}

	public void setLogNum(String logNum) {
		this.logNum = logNum;
	}

    @XmlElement(name = "NewRefNum")
	public String getNewRefNum() {
		return newRefNum;
	}

	public void setNewRefNum(String newRefNum) {
		this.newRefNum = newRefNum;
	}

    @XmlElement(name = "HostEmailUpdDate")
	public String getHostEmailUpdDate() {
		return hostEmailUpdDate;
	}

	public void setHostEmailUpdDate(String hostEmailUpdDate) {
		this.hostEmailUpdDate = hostEmailUpdDate;
	}

    @XmlElement(name = "EmailUpdStatus")
	public String getEmailUpdStatus() {
		return emailUpdStatus;
	}

	public void setEmailUpdStatus(String emailUpdStatus) {
		this.emailUpdStatus = emailUpdStatus;
	}
	
	
	
	
}



