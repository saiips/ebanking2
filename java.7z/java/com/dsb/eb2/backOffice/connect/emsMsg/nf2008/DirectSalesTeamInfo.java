package com.dsb.eb2.backOffice.connect.emsMsg.nf2008;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"teamInd","staffNum"})
public class DirectSalesTeamInfo {

	public DirectSalesTeamInfo() {}
	
	
	@JSONField(name="TeamInd")
	private String teamInd;
	
	@JSONField(name="StaffNum")
	private String staffNum;

	
	@XmlElement(name = "TeamInd")
	public String getTeamInd() {
		return teamInd;
	}

	public void setTeamInd(String teamInd) {
		this.teamInd = teamInd;
	}

	@XmlElement(name = "StaffNum")
	public String getStaffNum() {
		return staffNum;
	}

	public void setStaffNum(String staffNum) {
		this.staffNum = staffNum;
	}
	
	
}


