package com.dsb.eb2.backOffice.connect.emsMsg;


import com.dsb.eb2.common.constant.EMSConstants;
import com.dsb.eb2.util.StringUtils;

/**
 * EMS消息工厂 用于创建EMS请求消息和EMS响应消息
 * 
 * @author
 * 
 */
public class EmsMsgFactory
{
    /**
     * 根据提供的FrmData创建EmsRepMsg
     * 
     * @param data
     * @return
     */
    public static EmsRepMsg createEmsRepMsg(FrmData data) throws Exception
    {
        return createEmsRepMsg(data, "");
    }

    public static EmsRepMsg createEmsRepMsg(FrmData data, String custID)
        throws Exception
    {
        EmsRepMsg emsRepMsg = new EmsRepMsg(data);
        FrmHdr frmHdr = emsRepMsg.getFrmHdr();
        frmHdr.setBankCode(EMSConstants.BANK_CODE_DSB);
        frmHdr.setCustID(custID);
        frmHdr.setChannelID(EMSConstants.CHANNEL_ID);
        frmHdr.setTerminalID(EMSConstants.TERMINAL_ID);
        frmHdr.setAgentID(EMSConstants.AGENT_ID);
        frmHdr.setServiceID(data.getServiceID());
        frmHdr.setTxDateTime(com.dsb.eb2.bankApp.System.DateUtils.getCurrentEmsTsStr());
        frmHdr.setTxRefNo(com.dsb.eb2.bankApp.System.DateUtils.getCurrentEmsTimeStr());
        return emsRepMsg;
    }

    /**
     * 根据提供的FrmData创建EmsReqMsg
     * 
     * @param data
     * @param custID
     * @param jnlNo
     * @return
     */
    public static EmsReqMsg createEmsReqMsg(FrmData data, String custID,
        String jnlNo) throws Exception
    {
    	EmsReqMsg emsReqMsg = new EmsReqMsg(data);
        FrmHdr frmHdr = emsReqMsg.getFrmHdr();
        frmHdr.setBankCode(EMSConstants.BANK_CODE_DSB);
        if(!StringUtils.isBlank(custID))
        {
        	frmHdr.setCustID(custID);
        }
        frmHdr.setChannelID(EMSConstants.CHANNEL_ID);
        frmHdr.setTerminalID(EMSConstants.TERMINAL_ID);
        frmHdr.setServiceID(data.getServiceID());
        frmHdr.setTxDateTime(com.dsb.eb2.bankApp.System.DateUtils.getCurrentEmsTsStr());
        frmHdr.setAgentID(EMSConstants.AGENT_ID);
        frmHdr.setTxRefNo(com.dsb.eb2.bankApp.System.DateUtils.getCurrentEmsTimeStr());
        return emsReqMsg;
    }

    public static EmsReqMsg createEmsReqMsg(FrmData data, String custID)
        throws Exception
    {
        return createEmsReqMsg(data, custID, null);
    }

    public static EmsReqMsg createEmsReqMsg(FrmData data) throws Exception
    {
        return createEmsReqMsg(data, null, null);
    }
    
    /**
     * 根据提供的FrmData创建EmsReqMsg
     * 
     * @param data
     * @param custID
     * @param jnlNo
     * @return
     */
    public static EmsReqMsg createEmsReqMsg(FrmData data, String custID,String deptCode,
        String jnlNo) throws Exception
    {
        EmsReqMsg emsReqMsg = new EmsReqMsg(data);
        emsReqMsg.setJnlNo(jnlNo);
        FrmHdr frmHdr = emsReqMsg.getFrmHdr();
        frmHdr.setBankCode(EMSConstants.BANK_CODE_DSB);
        frmHdr.setCustID(custID);
        frmHdr.setChannelID(EMSConstants.CHANNEL_ID);
        frmHdr.setTerminalID(EMSConstants.TERMINAL_ID);
        frmHdr.setServiceID(data.getServiceID());
        frmHdr.setTxDateTime(com.dsb.eb2.bankApp.System.DateUtils.getCurrentEmsTsStr());
        frmHdr.setAgentID(EMSConstants.AGENT_ID);
        frmHdr.setDeptCode(deptCode);
        frmHdr.setTxRefNo(com.dsb.eb2.bankApp.System.DateUtils.getCurrentEmsTimeStr());
        return emsReqMsg;
    }    
}
