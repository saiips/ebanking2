package com.dsb.eb2.backOffice.connect.emsMsg.nf0150;
import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class NF0150ReqData  extends FrmData
{
    public NF0150ReqData(){}

	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF0150";
	}
	
	
	
}
