package com.dsb.eb2.backOffice.connect.emsMsg;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * EMS消息基累，所有EMS消息必须继承此类
 * 
 *
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
public class EmsMsg
{
	@JSONField(name = "Header")
    private FrmHdr frmHdr;

	@JSONField(name = "Payload")
    protected FrmData frmData;

    public EmsMsg()
    {
        this.frmHdr = new FrmHdr();
    }

    public EmsMsg(FrmData frmData)
    {
        this.frmHdr = new FrmHdr();
        this.frmData = frmData;
    }

    public EmsMsg(FrmHdr frmHdr, FrmData frmData)
    {
        this.frmHdr = frmHdr;
        this.frmData = frmData;
    }

    @XmlElement(name = "Header")
    public FrmHdr getFrmHdr()
    {
        return frmHdr;
    }

    public void setFrmHdr(FrmHdr frmHdr)
    {
        this.frmHdr = frmHdr;
    }
}
