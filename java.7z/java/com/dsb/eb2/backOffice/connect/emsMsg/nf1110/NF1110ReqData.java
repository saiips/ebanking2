package com.dsb.eb2.backOffice.connect.emsMsg.nf1110;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class NF1110ReqData  extends FrmData
{

	public NF1110ReqData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1110";
	}
	
	@JSONField(name="AccountNumber")
	private String accountNumber;
	
	@JSONField(name="ClosureIndicator")
	private String closureIndicator;
	
	@JSONField(name="Filler1")
	private String filler1;

}
