package com.dsb.eb2.backOffice.connect.emsMsg.nf2089;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;


@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"moreItemsInd","lastKey","numOfItems","subOwnerInfo"})
public class SubOwnerDetails {
	
	public SubOwnerDetails() {}
	
	
	@JSONField(name="MoreItemsInd")
	private String moreItemsInd;
	
	@JSONField(name="LastKey")
	private String lastKey;
	
	@JSONField(name="NumOfItems")
	private String numOfItems;
	
	@JSONField(name="SubOwnerInfo")
	private List<SubOwnerInfo> subOwnerInfo;
	
	@XmlElement(name = "MoreItemsInd")
	public String getMoreItemsInd() {
		return moreItemsInd;
	}

	public void setMoreItemsInd(String moreItemsInd) {
		this.moreItemsInd = moreItemsInd;
	}

	@XmlElement(name = "LastKey")
	public String getLastKey() {
		return lastKey;
	}

	public void setLastKey(String lastKey) {
		this.lastKey = lastKey;
	}

	@XmlElement(name = "NumOfItems")
	public String getNumOfItems() {
		return numOfItems;
	}

	public void setNumOfItems(String numOfItems) {
		this.numOfItems = numOfItems;
	}

	@XmlElement(name = "SubOwnerInfo")
	public List<SubOwnerInfo> getSubOwnerInfo() {
		return subOwnerInfo;
	}

	public void setSubOwnerInfo(List<SubOwnerInfo> subOwnerInfo) {
		this.subOwnerInfo = subOwnerInfo;
	}

	
}



