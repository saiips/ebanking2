package com.dsb.eb2.backOffice.connect.emsMsg.nf0106;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class  NF0106RepData extends FrmData
{
    
	public NF0106RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF0106";
	}
	
	@JSONField(name="CCY")
	private String cCY;
	
	@JSONField(name="HKDBuyTT")
	private String hKDBuyTT;
	
	@JSONField(name="HKDBuyDD")
	private String hKDBuyDD;
	
	@JSONField(name="HKDSellTT")
	private String hKDSellTT;
	
	@JSONField(name="USDBuyTT")
	private String uSDBuyTT;
	
	@JSONField(name="USDSellTT")
	private String uSDSellTT;
	
	@JSONField(name="HKDBuyNotes")
	private String hKDBuyNotes;
	
	@JSONField(name="HKDSellNotes")
	private String hKDSellNotes;
	
	@JSONField(name="UpdateTimestamp")
	private String updateTimestamp;
}