package com.dsb.eb2.backOffice.connect.emsMsg.fn0005;


import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class AutoRenewalInstData 
{
    public AutoRenewalInstData(){}

    @JSONField(name="RenewalInstruction")
    private String renewalInstruction;
    
    @JSONField(name="DepPeriodCode")
    private String depPeriodCode;
    
    @JSONField(name="DepPeriod")
    private String depPeriod;
    
    @JSONField(name="SetAcctNum")
    private String setAcctNum;
    
    @JSONField(name="SetAcctCcy")
    private String setAcctCcy;
    
    @JSONField(name="PrinAmtToBeAdj")
    private String prinAmtToBeAdj;
    
    @JSONField(name="RenewalIntRateMarkup")
    private String renewalIntRateMarkup;
   
    
}
