package com.dsb.eb2.backOffice.connect.emsMsg.nf1120;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class CardActivationDetails
{
	public CardActivationDetails(){}
	
	@JSONField(name="Date")
	private String  date;
	
	@JSONField(name="Time") 
	private String  time;
	
	@JSONField(name="Source") 
	private String  source;
		
	@JSONField(name="FailedCnt")
	private String  failedCnt;
}
