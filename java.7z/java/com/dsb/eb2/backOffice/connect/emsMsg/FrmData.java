package com.dsb.eb2.backOffice.connect.emsMsg;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * 
 */
@XmlRootElement(name = "Payload")
@XmlAccessorType(XmlAccessType.PROPERTY)
public abstract class FrmData
{
    /**
     * 返回消息对应的ServiceID，用于在创建消息时自动指定ServiceID
     * 
     * @return
     */
    public abstract String getServiceID();
}
