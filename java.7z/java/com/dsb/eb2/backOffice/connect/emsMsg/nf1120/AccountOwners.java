package com.dsb.eb2.backOffice.connect.emsMsg.nf1120;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1113.AccountOwnerInformation;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1113.Last3MonthsRepaymentDetail;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1113.Next12MonthsRepaymentSchedule;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class AccountOwners
{
	public AccountOwners(){}
	
	@JSONField(name="CustId")
	private String  custId;
	
	@JSONField(name="Title") 
	private String  title;
	
	@JSONField(name="CustName") 
	private String  custName;
	
	@JSONField(name="JointInd")
	private String  jointInd;
	
	@JSONField(name="SeqNumOfActiveCard")
	private String  seqNumOfActiveCard;
}
