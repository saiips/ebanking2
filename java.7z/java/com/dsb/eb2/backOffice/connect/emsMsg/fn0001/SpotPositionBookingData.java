package com.dsb.eb2.backOffice.connect.emsMsg.fn0001;

import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class SpotPositionBookingData {

	public SpotPositionBookingData() {}
	
	
	@JSONField(name="TxDateTime")
	private String SuperviSupervisorID;
	
	@JSONField(name="TxDateTime") 
	private String OverrideFlag;
	
	@JSONField(name="TxDateTime") 
	private String ExRateType;
	
	@JSONField(name="TxDateTime") 
	private String CNYTransClass;
	
	@JSONField(name="TxDateTime")
	private String AcctOfficerCode;
	
	@JSONField(name="TxDateTime")
	private String AcctOfficerSubCode;
	
	@JSONField(name="TxDateTime") 
	private String Division;
	
	@JSONField(name="TxDateTime") 
	private String Region;
	
	@JSONField(name="TxDateTime")
	private String StaffInd;
	
	@JSONField(name="TxDateTime") 
	private String VIPFlag;
	
	@JSONField(name="TxDateTime") 
	private String ExRateTier;
	
	@JSONField(name="DebitExRatesT1") 
	private List<DebitExRatesT1> DebitExRatesT1;
	
	@JSONField(name="CreditExRatesT1") 
	private List<CreditExRatesT1> CreditExRatesT1;
	
	@JSONField(name="DebitExRatesT2") 
	private List<DebitExRatesT2> DebitExRatesT2;
	
	@JSONField(name="CreditExRatesT2") 
	private List<CreditExRatesT2> CreditExRatesT2;

	@JSONField(name="Nature")
	private String nature;
	
	@JSONField(name="CancelDealNum1") 
	private String cancelDealNum1;
	
	@JSONField(name="CancelDealNum2") 
	private String cancelDealNum2;
	
	@JSONField(name="DealNum1") 
	private String dealNum1;
	
	@JSONField(name="DealNum2")
	private String dealNum2;
	
}

