package com.dsb.eb2.backOffice.connect.emsMsg.nf1300;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;
@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"pBID"})
public class NF1300ReqData  extends FrmData
{
    public NF1300ReqData(){}

	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1300";
	}
	
	@JSONField(name="PBID") 
	private String pBID;

    @XmlElement(name = "PBID")
	public String getpBID() {
		return pBID;
	}

	public void setpBID(String pBID) {
		this.pBID = pBID;
	}
	
	
}
