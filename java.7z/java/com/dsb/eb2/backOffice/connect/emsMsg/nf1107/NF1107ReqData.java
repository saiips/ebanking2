package com.dsb.eb2.backOffice.connect.emsMsg.nf1107;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class NF1107ReqData  extends FrmData
{
    
	public NF1107ReqData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1107";
	}
	
}

