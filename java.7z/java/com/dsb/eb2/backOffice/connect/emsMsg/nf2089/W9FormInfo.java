package com.dsb.eb2.backOffice.connect.emsMsg.nf2089;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"docSignDate","tIN"})
public class W9FormInfo {
	
	public W9FormInfo() {}
	
	
	@JSONField(name="DocSignDate")
	private String docSignDate;
	
	@JSONField(name="TIN")
	private String tIN;

	@XmlElement(name = "DocSignDate")
	public String getDocSignDate() {
		return docSignDate;
	}

	public void setDocSignDate(String docSignDate) {
		this.docSignDate = docSignDate;
	}

	@XmlElement(name = "TIN")
	public String gettIN() {
		return tIN;
	}

	public void settIN(String tIN) {
		this.tIN = tIN;
	}
	

	
}



