package com.dsb.eb2.backOffice.connect.emsMsg.nf1551;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"orderNum"})
public class NF1551ReqData extends FrmData{

	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1551";
	}

	
	
	public NF1551ReqData() {}



	@JSONField(name="OrderNum")
	private String orderNum;


	@XmlElement(name = "OrderNum")
	public String getOrderNum() {
		return orderNum;
	}



	public void setOrderNum(String orderNum) {
		this.orderNum = orderNum;
	}
	
	
}
