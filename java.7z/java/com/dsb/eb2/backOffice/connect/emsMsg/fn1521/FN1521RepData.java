package com.dsb.eb2.backOffice.connect.emsMsg.fn1521;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class FN1521RepData  extends FrmData
{
    
	public FN1521RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "FN1521";
	}
	
	@JSONField(name="AcctNum")
	private String acctNum;
	
	@JSONField(name="HostTxnSeqNum")
	private String hostTxnSeqNum;
	
	
	
	
	
}


