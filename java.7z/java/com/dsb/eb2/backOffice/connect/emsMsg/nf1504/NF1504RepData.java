package com.dsb.eb2.backOffice.connect.emsMsg.nf1504;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"acctNum","hostTxnSeqNum"})
public class NF1504RepData  extends FrmData
{
    
	public NF1504RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1504";
	}
	
	@JSONField(name="AcctNum")
	private String acctNum;
	
	@JSONField(name="HostTxnSeqNum")
	private String hostTxnSeqNum;

    @XmlElement(name = "AcctNum")
	public String getAcctNum() {
		return acctNum;
	}

	public void setAcctNum(String acctNum) {
		this.acctNum = acctNum;
	}

    @XmlElement(name = "HostTxnSeqNum")
	public String getHostTxnSeqNum() {
		return hostTxnSeqNum;
	}

	public void setHostTxnSeqNum(String hostTxnSeqNum) {
		this.hostTxnSeqNum = hostTxnSeqNum;
	}
	
}

