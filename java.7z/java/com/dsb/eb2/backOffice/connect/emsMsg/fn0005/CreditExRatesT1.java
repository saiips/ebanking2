package com.dsb.eb2.backOffice.connect.emsMsg.fn0005;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class CreditExRatesT1 {
	
	public  CreditExRatesT1() {}
	@JSONField(name="StringPreferredRate")
	private String preferredRate;

	@JSONField(name="StringMinProfitRate")
	private String minProfitRate;

	@JSONField(name="StringCostRate")
	private String costRate;
}
