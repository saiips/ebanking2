package com.dsb.eb2.backOffice.connect.emsMsg.nf1615;


import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"renewalOption","aPSpecialInstruction","aRLastSource","aRSettlementACCurrency"})
public class RenewalInfo {
	
	public RenewalInfo() {}
	
	@JSONField(name="RenewalOption")
	private String renewalOption;
	
	@JSONField(name="APSpecialInstruction")
	private List<APSpecialInstruction> aPSpecialInstruction;

	@JSONField(name="ARLastSource")
	private String aRLastSource;
	
	@JSONField(name="ARSettlementACCurrency")
	private String aRSettlementACCurrency;

    @XmlElement(name = "RenewalOption")
	public String getRenewalOption() {
		return renewalOption;
	}

	public void setRenewalOption(String renewalOption) {
		this.renewalOption = renewalOption;
	}

    @XmlElement(name = "APSpecialInstruction")
	public List<APSpecialInstruction> getaPSpecialInstruction() {
		return aPSpecialInstruction;
	}

	public void setaPSpecialInstruction(List<APSpecialInstruction> aPSpecialInstruction) {
		this.aPSpecialInstruction = aPSpecialInstruction;
	}

    @XmlElement(name = "ARLastSource")
	public String getaRLastSource() {
		return aRLastSource;
	}

	public void setaRLastSource(String aRLastSource) {
		this.aRLastSource = aRLastSource;
	}

    @XmlElement(name = "ARSettlementACCurrency")
	public String getaRSettlementACCurrency() {
		return aRSettlementACCurrency;
	}

	public void setaRSettlementACCurrency(String aRSettlementACCurrency) {
		this.aRSettlementACCurrency = aRSettlementACCurrency;
	}

	
	
	


}
