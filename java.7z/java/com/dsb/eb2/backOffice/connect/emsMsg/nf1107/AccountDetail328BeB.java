package com.dsb.eb2.backOffice.connect.emsMsg.nf1107;


public class AccountDetail328BeB
{
    private String securedFlag;
    
    private String financingCode;
    
    private String projectCode;
    
    private String filler;

	/**
	 * @return the securedFlag
	 */
	public String getSecuredFlag() {
		return securedFlag;
	}

	/**
	 * @param securedFlag the securedFlag to set
	 */
	public void setSecuredFlag(String securedFlag) {
		this.securedFlag = securedFlag;
	}

	/**
	 * @return the financingCode
	 */
	public String getFinancingCode() {
		return financingCode;
	}

	/**
	 * @param financingCode the financingCode to set
	 */
	public void setFinancingCode(String financingCode) {
		this.financingCode = financingCode;
	}

	/**
	 * @return the projectCode
	 */
	public String getProjectCode() {
		return projectCode;
	}

	/**
	 * @param projectCode the projectCode to set
	 */
	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
	}

	/**
	 * @return the filler
	 */
	public String getFiller() {
		return filler;
	}

	/**
	 * @param filler the filler to set
	 */
	public void setFiller(String filler) {
		this.filler = filler;
	}
}
