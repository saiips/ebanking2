package com.dsb.eb2.backOffice.connect.emsMsg.nf1652;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"acctNum","lastKey","moreItemsInd","numOfItems","transDetails"})
public class NF1652RepData  extends FrmData
{
    
	public NF1652RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1652";
	}
	
	
	@JSONField(name="AcctNum")
	private String acctNum;
	
	@JSONField(name="LastKey")
	private String lastKey;
	
	@JSONField(name="MoreItemsInd")
	private String moreItemsInd;
	
	@JSONField(name="NumOfItems")
	private String numOfItems;
	
	@JSONField(name="TransDetails")
	private List<TransDetails> transDetails;

    @XmlElement(name = "AcctNum")
	public String getAcctNum() {
		return acctNum;
	}

	public void setAcctNum(String acctNum) {
		this.acctNum = acctNum;
	}

    @XmlElement(name = "LastKey")
	public String getLastKey() {
		return lastKey;
	}

	public void setLastKey(String lastKey) {
		this.lastKey = lastKey;
	}

    @XmlElement(name = "MoreItemsInd")
	public String getMoreItemsInd() {
		return moreItemsInd;
	}

	public void setMoreItemsInd(String moreItemsInd) {
		this.moreItemsInd = moreItemsInd;
	}

    @XmlElement(name = "NumOfItems")
	public String getNumOfItems() {
		return numOfItems;
	}

	public void setNumOfItems(String numOfItems) {
		this.numOfItems = numOfItems;
	}

    @XmlElement(name = "TransDetails")
	public List<TransDetails> getTransDetails() {
		return transDetails;
	}

	public void setTransDetails(List<TransDetails> transDetails) {
		this.transDetails = transDetails;
	}
	
	
	
	
}
