package com.dsb.eb2.backOffice.connect.emsMsg.nf1615;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"debitAccountNumber","debitCurrency","debitAmount","debitExchangeRate","debitFXDealNumber","debitHKDEquivalent","depositAmount","depositExchangeRate","depositFXDealNumber","crossExchangeRate"})
public class SourceOfFundTransfer {
	
	public SourceOfFundTransfer() {}

	@JSONField(name="DebitAccountNumber")
	private String debitAccountNumber;
	
	@JSONField(name="DebitCurrency")
	private String debitCurrency;
	
	@JSONField(name="DebitAmount")
	private String debitAmount;
	
	@JSONField(name="DebitExchangeRate")
	private String debitExchangeRate;
	
	@JSONField(name="DebitFXDealNumber")
	private String debitFXDealNumber;
	
	@JSONField(name="DebitHKDEquivalent")
	private String debitHKDEquivalent;
	
	@JSONField(name="DepositAmount")
	private String depositAmount;
	
	@JSONField(name="DepositExchangeRate")
	private String depositExchangeRate;
	
	@JSONField(name="DepositFXDealNumber")
	private String depositFXDealNumber;
	
	@JSONField(name="CrossExchangeRate")
	private String crossExchangeRate;

    @XmlElement(name = "DebitAccountNumber")
	public String getDebitAccountNumber() {
		return debitAccountNumber;
	}

	public void setDebitAccountNumber(String debitAccountNumber) {
		this.debitAccountNumber = debitAccountNumber;
	}

    @XmlElement(name = "DebitCurrency")
	public String getDebitCurrency() {
		return debitCurrency;
	}

	public void setDebitCurrency(String debitCurrency) {
		this.debitCurrency = debitCurrency;
	}

    @XmlElement(name = "DebitAmount")
	public String getDebitAmount() {
		return debitAmount;
	}

	public void setDebitAmount(String debitAmount) {
		this.debitAmount = debitAmount;
	}

    @XmlElement(name = "DebitExchangeRate")
	public String getDebitExchangeRate() {
		return debitExchangeRate;
	}

	public void setDebitExchangeRate(String debitExchangeRate) {
		this.debitExchangeRate = debitExchangeRate;
	}

    @XmlElement(name = "DebitFXDealNumber")
	public String getDebitFXDealNumber() {
		return debitFXDealNumber;
	}

	public void setDebitFXDealNumber(String debitFXDealNumber) {
		this.debitFXDealNumber = debitFXDealNumber;
	}

    @XmlElement(name = "DebitHKDEquivalent")
	public String getDebitHKDEquivalent() {
		return debitHKDEquivalent;
	}

	public void setDebitHKDEquivalent(String debitHKDEquivalent) {
		this.debitHKDEquivalent = debitHKDEquivalent;
	}

    @XmlElement(name = "DepositAmount")
	public String getDepositAmount() {
		return depositAmount;
	}

	public void setDepositAmount(String depositAmount) {
		this.depositAmount = depositAmount;
	}

    @XmlElement(name = "DepositExchangeRate")
	public String getDepositExchangeRate() {
		return depositExchangeRate;
	}

	public void setDepositExchangeRate(String depositExchangeRate) {
		this.depositExchangeRate = depositExchangeRate;
	}

    @XmlElement(name = "DepositFXDealNumber")
	public String getDepositFXDealNumber() {
		return depositFXDealNumber;
	}

	public void setDepositFXDealNumber(String depositFXDealNumber) {
		this.depositFXDealNumber = depositFXDealNumber;
	}

    @XmlElement(name = "CrossExchangeRate")
	public String getCrossExchangeRate() {
		return crossExchangeRate;
	}

	public void setCrossExchangeRate(String crossExchangeRate) {
		this.crossExchangeRate = crossExchangeRate;
	}
	
	

}
