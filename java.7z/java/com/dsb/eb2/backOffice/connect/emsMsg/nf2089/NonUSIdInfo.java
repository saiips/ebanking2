package com.dsb.eb2.backOffice.connect.emsMsg.nf2089;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"docType","docNum","docExpDate"})
public class NonUSIdInfo {
	
	public NonUSIdInfo() {}
	
	
	@JSONField(name="DocType")
	private String docType;
	
	@JSONField(name="DocNum")
	private String docNum;
	
	@JSONField(name="DocExpDate")
	private String docExpDate;

	@XmlElement(name = "DocType")
	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	@XmlElement(name = "DocNum")
	public String getDocNum() {
		return docNum;
	}

	public void setDocNum(String docNum) {
		this.docNum = docNum;
	}

	@XmlElement(name = "DocExpDate")
	public String getDocExpDate() {
		return docExpDate;
	}

	public void setDocExpDate(String docExpDate) {
		this.docExpDate = docExpDate;
	}
	

	
}



