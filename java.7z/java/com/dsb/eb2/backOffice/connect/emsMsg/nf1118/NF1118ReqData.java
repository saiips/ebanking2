package com.dsb.eb2.backOffice.connect.emsMsg.nf1118;

import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class NF1118ReqData  extends FrmData
{

	public NF1118ReqData(){}
	
	@Override
	public String getServiceID() {
		return "NF1118";
	}

	
}
