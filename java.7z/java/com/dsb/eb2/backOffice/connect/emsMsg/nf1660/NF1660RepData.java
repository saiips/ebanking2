package com.dsb.eb2.backOffice.connect.emsMsg.nf1660;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"cardNum","availCreditLine","availInstallmentLine","totalInstallmentAvail"})
public class NF1660RepData  extends FrmData
{
    
	public NF1660RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1660";
	}
	
	
	@JSONField(name="CardNum")
	private String cardNum;
		
	@JSONField(name="AvailCreditLine")
	private String availCreditLine;
	
	@JSONField(name="AvailInstallmentLine")
	private String availInstallmentLine;
	
	@JSONField(name="TotalInstallmentAvail")
	private String totalInstallmentAvail;
	
	
	@XmlElement(name = "CardNum")
	public String getCardNum() {
		return cardNum;
	}

	public void setCardNum(String cardNum) {
		this.cardNum = cardNum;
	}

	@XmlElement(name = "AvailCreditLine")
	public String getAvailCreditLine() {
		return availCreditLine;
	}

	public void setAvailCreditLine(String availCreditLine) {
		this.availCreditLine = availCreditLine;
	}

	@XmlElement(name = "AvailInstallmentLine")
	public String getAvailInstallmentLine() {
		return availInstallmentLine;
	}

	public void setAvailInstallmentLine(String availInstallmentLine) {
		this.availInstallmentLine = availInstallmentLine;
	}

	@XmlElement(name = "TotalInstallmentAvail")
	public String getTotalInstallmentAvail() {
		return totalInstallmentAvail;
	}

	public void setTotalInstallmentAvail(String totalInstallmentAvail) {
		this.totalInstallmentAvail = totalInstallmentAvail;
	}


	
	
}
