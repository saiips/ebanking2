package com.dsb.eb2.backOffice.connect.emsMsg.nf1108;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class CardlinkInfo {
	
	@Override
	public String toString() {
		return "CardlinkInfo [cardlinkCustNum=" + cardlinkCustNum + ", org=" + org + "]";
	}

	public CardlinkInfo() {}
	
	@JSONField(name="CardlinkCustNum")
    private String cardlinkCustNum;
	
	@JSONField(name="Org")
    private String org;
}
