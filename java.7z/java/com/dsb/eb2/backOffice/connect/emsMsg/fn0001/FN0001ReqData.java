package com.dsb.eb2.backOffice.connect.emsMsg.fn0001;

import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class FN0001ReqData extends FrmData
{

	public FN0001ReqData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "FN0001";
	}
	
	
	@JSONField(name="TelUserID") 
	private String telUserID;
	
	@JSONField(name="DebitAcctNum") 
	private String debitAcctNum;
	
	@JSONField(name="DebitCurrency") 
	private String debitCurrency;
	
	@JSONField(name="DebitAmt") 
	private String debitAmt;
	
	@JSONField(name="DebitExchangeRate") 
	private String debitExchangeRate;
	
	@JSONField(name="CreditAcctNum") 
	private String creditAcctNum;
	
	@JSONField(name="CreditCurrency") 
	private String creditCurrency;
	
	@JSONField(name="CreditAmt") 
	private String creditAmt;
	
	@JSONField(name="CreditExchangeRate") 
	private String creditExchangeRate;
	
	@JSONField(name="TxnType") 
	private String txnType;
	
	@JSONField(name="TransferType") 
	private String transferType;
	
	@JSONField(name="Remarks") 
	private String remarks;
	
	@JSONField(name="CompanyCodeOrCreditCardBalTransferECRefNum") 
	private String companyCodeOrCreditCardBalTransferECRefNum;

	@JSONField(name="SpotPositionBookingData")
	private List<SpotPositionBookingData> spotPositionBookingData;

	@JSONField(name="BypassRegCheck") 
	private String bypassRegCheck;
	
	@JSONField(name="ChanExtraBuyPips") 
	private String chanExtraBuyPips;
	
	@JSONField(name="ChanExtraSellPips") 
	private String chanExtraSellPips;
	
	@JSONField(name="BypassCostRateChgCheck") 
	private String bypassCostRateChgCheck;
	
	@JSONField(name="BypassBelowCostRateCheck") 
	private String bypassBelowCostRateCheck;
	
	@JSONField(name="BypassMinProfitRateCheck") 
	private String bypassMinProfitRateCheck;
	
	@JSONField(name="BypassCrossTierRateCheck") 
	private String bypassCrossTierRateCheck;

}
