package com.dsb.eb2.backOffice.connect.emsMsg.nf2089;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;


@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"suppDocCode","w9FormInfo","waiverInfo","w8FormInfo","nonUSIdInfo",
		"lostOfNationalityCertInfo","selfDeclForm1Info","selfDeclForm2Info"})
public class SuppDocInfo {
	
	public SuppDocInfo() {}
	
	
	@JSONField(name="SuppDocCode")
	private String suppDocCode;
	
	@JSONField(name="W9FormInfo")
	private List<W9FormInfo> w9FormInfo;
	
	@JSONField(name="WaiverInfo")
	private List<WaiverInfo> waiverInfo;
	
	@JSONField(name="W8FormInfo")
	private List<W8FormInfo> w8FormInfo;
	
	@JSONField(name="NonUSIdInfo")
	private List<NonUSIdInfo> nonUSIdInfo;
	
	@JSONField(name="LostOfNationalityCertInfo")
	private List<LostOfNationalityCertInfo> lostOfNationalityCertInfo;
	
	@JSONField(name="SelfDeclForm1Info")
	private List<SelfDeclForm1Info> selfDeclForm1Info;
	
	@JSONField(name="SelfDeclForm2Info")
	private List<SelfDeclForm2Info> selfDeclForm2Info;

	
	@XmlElement(name = "SuppDocCode")
	public String getSuppDocCode() {
		return suppDocCode;
	}

	public void setSuppDocCode(String suppDocCode) {
		this.suppDocCode = suppDocCode;
	}

	@XmlElement(name = "W9FormInfo")
	public List<W9FormInfo> getW9FormInfo() {
		return w9FormInfo;
	}

	public void setW9FormInfo(List<W9FormInfo> w9FormInfo) {
		this.w9FormInfo = w9FormInfo;
	}

	@XmlElement(name = "WaiverInfo")
	public List<WaiverInfo> getWaiverInfo() {
		return waiverInfo;
	}

	public void setWaiverInfo(List<WaiverInfo> waiverInfo) {
		this.waiverInfo = waiverInfo;
	}

	@XmlElement(name = "W8FormInfo")
	public List<W8FormInfo> getW8FormInfo() {
		return w8FormInfo;
	}

	public void setW8FormInfo(List<W8FormInfo> w8FormInfo) {
		this.w8FormInfo = w8FormInfo;
	}

	@XmlElement(name = "NonUSIdInfo")
	public List<NonUSIdInfo> getNonUSIdInfo() {
		return nonUSIdInfo;
	}

	public void setNonUSIdInfo(List<NonUSIdInfo> nonUSIdInfo) {
		this.nonUSIdInfo = nonUSIdInfo;
	}

	@XmlElement(name = "LostOfNationalityCertInfo")
	public List<LostOfNationalityCertInfo> getLostOfNationalityCertInfo() {
		return lostOfNationalityCertInfo;
	}

	public void setLostOfNationalityCertInfo(List<LostOfNationalityCertInfo> lostOfNationalityCertInfo) {
		this.lostOfNationalityCertInfo = lostOfNationalityCertInfo;
	}

	@XmlElement(name = "SelfDeclForm1Info")
	public List<SelfDeclForm1Info> getSelfDeclForm1Info() {
		return selfDeclForm1Info;
	}

	public void setSelfDeclForm1Info(List<SelfDeclForm1Info> selfDeclForm1Info) {
		this.selfDeclForm1Info = selfDeclForm1Info;
	}

	@XmlElement(name = "SelfDeclForm2Info")
	public List<SelfDeclForm2Info> getSelfDeclForm2Info() {
		return selfDeclForm2Info;
	}

	public void setSelfDeclForm2Info(List<SelfDeclForm2Info> selfDeclForm2Info) {
		this.selfDeclForm2Info = selfDeclForm2Info;
	}
	

	
}



