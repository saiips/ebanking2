package com.dsb.eb2.backOffice.connect.emsMsg.nf2089;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;


@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"docSignDate","docExpDate"})
public class W8FormInfo {
	
	public W8FormInfo() {}
	
	
	@JSONField(name="DocSignDate")
	private String docSignDate;
	
	@JSONField(name="DocExpDate")
	private String docExpDate;

	@XmlElement(name = "DocSignDate")
	public String getDocSignDate() {
		return docSignDate;
	}

	public void setDocSignDate(String docSignDate) {
		this.docSignDate = docSignDate;
	}

	@XmlElement(name = "DocExpDate")
	public String getDocExpDate() {
		return docExpDate;
	}

	public void setDocExpDate(String docExpDate) {
		this.docExpDate = docExpDate;
	}
	

	
}



