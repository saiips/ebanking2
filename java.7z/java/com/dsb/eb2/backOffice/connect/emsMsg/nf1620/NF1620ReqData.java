package com.dsb.eb2.backOffice.connect.emsMsg.nf1620;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"option","action","emailAddr","remark","refNum","publicSiteInd"})
public class NF1620ReqData  extends FrmData
{
    
	public NF1620ReqData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1620";
	}
	
	@JSONField(name="Option")
	private String option;
	
	@JSONField(name="Action")
	private String action;
	
	@JSONField(name="EmailAddr") 
	private String emailAddr;
	
	@JSONField(name="Remark") 
	private String remark;
	
	@JSONField(name="RefNum")
	private String refNum;
	
	@JSONField(name="PublicSiteInd")
	private String publicSiteInd;

    @XmlElement(name = "Option")
	public String getOption() {
		return option;
	}

	public void setOption(String option) {
		this.option = option;
	}

    @XmlElement(name = "Action")
	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

    @XmlElement(name = "EmailAddr")
	public String getEmailAddr() {
		return emailAddr;
	}

	public void setEmailAddr(String emailAddr) {
		this.emailAddr = emailAddr;
	}

    @XmlElement(name = "Remark")
	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

    @XmlElement(name = "RefNum")
	public String getRefNum() {
		return refNum;
	}

	public void setRefNum(String refNum) {
		this.refNum = refNum;
	}

    @XmlElement(name = "PublicSiteInd")
	public String getPublicSiteInd() {
		return publicSiteInd;
	}

	public void setPublicSiteInd(String publicSiteInd) {
		this.publicSiteInd = publicSiteInd;
	}
	
	
	
}



