package com.dsb.eb2.backOffice.connect.emsMsg.nf1553;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"orderType","cCY","preExRate","actExRate","amt","hKDEq","debitAcctNum","creditAcctNum","transTime","orderNum","userId","status","sourceID","cancelRefNum"})
public class OrderDetails {

	
	public OrderDetails() {}

	@JSONField(name="OrderType")
	private String orderType;
	
	@JSONField(name="CCY")
	private String cCY;
	
	@JSONField(name="PreExRate")
	private String preExRate;
	
	@JSONField(name="ActExRate")
	private String actExRate;
	
	@JSONField(name="Amt")
	private String amt;
	
	@JSONField(name="HKDEq")
	private String hKDEq;
	
	@JSONField(name="DebitAcctNum")
	private String debitAcctNum;
	
	@JSONField(name="CreditAcctNum")
	private String creditAcctNum;
	
	@JSONField(name="TransTime")
	private String transTime;
	
	@JSONField(name="OrderNum")
	private String orderNum;
	
	@JSONField(name="UserId")
	private String userId;
	
	@JSONField(name="Status")
	private String status;
	
	@JSONField(name="SourceID")
	private String sourceID;
	
	@JSONField(name="CancelRefNum")
	private String cancelRefNum;

    @XmlElement(name = "OrderType")
	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

    @XmlElement(name = "CCY")
	public String getcCY() {
		return cCY;
	}

	public void setcCY(String cCY) {
		this.cCY = cCY;
	}

    @XmlElement(name = "PreExRate")
	public String getPreExRate() {
		return preExRate;
	}

	public void setPreExRate(String preExRate) {
		this.preExRate = preExRate;
	}

    @XmlElement(name = "ActExRate")
	public String getActExRate() {
		return actExRate;
	}

	public void setActExRate(String actExRate) {
		this.actExRate = actExRate;
	}

    @XmlElement(name = "Amt")
	public String getAmt() {
		return amt;
	}

	public void setAmt(String amt) {
		this.amt = amt;
	}

    @XmlElement(name = "HKDEq")
	public String gethKDEq() {
		return hKDEq;
	}

	public void sethKDEq(String hKDEq) {
		this.hKDEq = hKDEq;
	}

    @XmlElement(name = "DebitAcctNum")
	public String getDebitAcctNum() {
		return debitAcctNum;
	}

	public void setDebitAcctNum(String debitAcctNum) {
		this.debitAcctNum = debitAcctNum;
	}

    @XmlElement(name = "CreditAcctNum")
	public String getCreditAcctNum() {
		return creditAcctNum;
	}

	public void setCreditAcctNum(String creditAcctNum) {
		this.creditAcctNum = creditAcctNum;
	}

    @XmlElement(name = "TransTime")
	public String getTransTime() {
		return transTime;
	}

	public void setTransTime(String transTime) {
		this.transTime = transTime;
	}

    @XmlElement(name = "OrderNum")
	public String getOrderNum() {
		return orderNum;
	}

	public void setOrderNum(String orderNum) {
		this.orderNum = orderNum;
	}

    @XmlElement(name = "UserId")
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

    @XmlElement(name = "Status")
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

    @XmlElement(name = "SourceID")
	public String getSourceID() {
		return sourceID;
	}

	public void setSourceID(String sourceID) {
		this.sourceID = sourceID;
	}

    @XmlElement(name = "CancelRefNum")
	public String getCancelRefNum() {
		return cancelRefNum;
	}

	public void setCancelRefNum(String cancelRefNum) {
		this.cancelRefNum = cancelRefNum;
	}

	
	
}
