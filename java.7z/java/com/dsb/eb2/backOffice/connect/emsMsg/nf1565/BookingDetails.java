package com.dsb.eb2.backOffice.connect.emsMsg.nf1565;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = { "time","bookRef","buySellInd","status","currency","amount","exchangeRate",
    "hkdEqu","dealNum","createId","cancelId","cancelReason","debitAcc","creditAcc","utilInd"})
public class BookingDetails
{
    private String time = "";
    
    private String bookRef = "";
    
    private String buySellInd = "";
    
    private String status = "";
    
    private String currency = "";
    
    private BigDecimal amount;
    
    private String exchangeRate = "";
    
    private BigDecimal hkdEqu;
    
    private String dealNum = "";
    
    private String createId = "";
    
    private String cancelId = "";
    
    private String cancelReason = "";
    
    private String debitAcc = "";
    
    private String creditAcc = "";
    
    private String utilInd = "";
    
    @XmlElement(name = "Time")
    public String getTime()
    {
        return time;
    }
    public void setTime(String time)
    {
        this.time = time;
    }

    @XmlElement(name = "BookingRef")
    public String getBookRef()
    {
        return bookRef;
    }
    public void setBookRef(String bookRef)
    {
        this.bookRef = bookRef;
    }

    @XmlElement(name = "BuySellInd")
    public String getBuySellInd()
    {
        return buySellInd;
    }
    public void setBuySellInd(String buySellInd)
    {
        this.buySellInd = buySellInd;
    }
    
    @XmlElement(name = "Status")
    public String getStatus()
    {
        return status;
    }
    public void setStatus(String status)
    {
        this.status = status;
    }

    @XmlElement(name = "CCY")
    public String getCurrency()
    {
        return currency;
    }
    public void setCurrency(String currency)
    {
        this.currency = currency;
    }

    @XmlElement(name = "Amt")
    public BigDecimal getAmount()
    {
        return amount;
    }
    public void setAmount(BigDecimal amount)
    {
        this.amount = amount;
    }

    @XmlElement(name = "ExRate")
    public String getExchangeRate()
    {
        return exchangeRate;
    }
    public void setExchangeRate(String exchangeRate)
    {
        this.exchangeRate = exchangeRate;
    }

    @XmlElement(name = "HKDEqt")
    public BigDecimal getHkdEqu()
    {
        return hkdEqu;
    }
    public void setHkdEqu(BigDecimal hkdEqu)
    {
        this.hkdEqu = hkdEqu;
    }

    @XmlElement(name = "DealNum")
    public String getDealNum()
    {
        return dealNum;
    }
    public void setDealNum(String dealNum)
    {
        this.dealNum = dealNum;
    }

    @XmlElement(name = "CreUsrID")
    public String getCreateId()
    {
        return createId;
    }
    public void setCreateId(String createId)
    {
        this.createId = createId;
    }

    @XmlElement(name = "CancelUsrID")
    public String getCancelId()
    {
        return cancelId;
    }
    public void setCancelId(String cancelId)
    {
        this.cancelId = cancelId;
    }

    @XmlElement(name = "CancelReason")
    public String getCancelReason()
    {
        return cancelReason;
    }
    public void setCancelReason(String cancelReason)
    {
        this.cancelReason = cancelReason;
    }

    @XmlElement(name = "DebitAcct")
    public String getDebitAcc()
    {
        return debitAcc;
    }
    public void setDebitAcc(String debitAcc)
    {
        this.debitAcc = debitAcc;
    }

    @XmlElement(name = "CreditAcct")
    public String getCreditAcc()
    {
        return creditAcc;
    }
    public void setCreditAcc(String creditAcc)
    {
        this.creditAcc = creditAcc;
    }

    @XmlElement(name = "UtilisedInd")
    public String getUtilInd()
    {
        return utilInd;
    }
    public void setUtilInd(String utilInd)
    {
        this.utilInd = utilInd;
    }

}
