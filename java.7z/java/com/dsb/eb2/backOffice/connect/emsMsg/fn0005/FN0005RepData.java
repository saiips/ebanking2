package com.dsb.eb2.backOffice.connect.emsMsg.fn0005;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class FN0005RepData extends FrmData 
{
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "FN0005";
	}

	public FN0005RepData(){}

	@JSONField(name="DebitAcctNum")
	private String debitAcctNum;

	@JSONField(name="FixedDepAcctNum")
	private String fixedDepAcctNum;

	@JSONField(name="MatureDate")
	private String matureDate;

	@JSONField(name="MatureIntAmt")
	private String matureIntAmt;

	@JSONField(name="HostTxnSeqNum")
	private String hostTxnSeqNum;

	@JSONField(name="Deviation")
	private String deviation;

	@JSONField(name="StaffProcFlag")
	private String staffProcFlag;


}
