package com.dsb.eb2.backOffice.connect.emsMsg.fn1521;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class ChargesDetails {
	
	public ChargesDetails() {}
	

	@JSONField(name="ChrgType")
	private String chrgType;
	
	@JSONField(name="ChrgCode")
	private String chrgCode;
	
	@JSONField(name="TransCode")
	private String transCode;
	
	@JSONField(name="ChrgAmt")
	private String chrgAmt;
	
	@JSONField(name="GLBranchCode")
	private String gLBranchCode;
	
	@JSONField(name="GLCode")
	private String gLCode;
	
}

