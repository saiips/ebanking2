package com.dsb.eb2.backOffice.connect.emsMsg.nf1107;

import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class AcctDetails {

	@Override
	public String toString() {
		return "AcctDetails [acctTypeInd=" + acctTypeInd + ", acctType=" + acctType + ", prodSubCode=" + prodSubCode
				+ ", org=" + org + ", acctNum=" + acctNum + ", iacctInd=" + iacctInd + ", jointAcctInd=" + jointAcctInd
				+ ", statusCode=" + statusCode + ", currencyCode=" + currencyCode + ", balance=" + balance
				+ ", creditLimit=" + creditLimit + ", cardLinkCustNum=" + cardLinkCustNum + ", acctOwnerInd="
				+ acctOwnerInd + ", acctName=" + acctName + ", cardSuspInd=" + cardSuspInd + ", cSSAAcctInd="
				+ cSSAAcctInd + ", trustClientInd=" + trustClientInd + ", ccySwitchingInd=" + ccySwitchingInd
				+ ", jointSignInd=" + jointSignInd + ", filler1=" + filler1 + ", addressCode=" + addressCode
				+ ", holdCode=" + holdCode + ", biaLinkedInd=" + biaLinkedInd + "]";
	}

	public AcctDetails() {}
	
	
	@JSONField(name="AcctTypeInd") 
	private String acctTypeInd;
	
	
	@JSONField(name="AcctType")
	private String acctType;
	
	
	@JSONField(name="ProdSubCode") 
	private String prodSubCode;
	
	
	@JSONField(name="Org") 
	private String org;
	
	
	@JSONField(name="AcctNum") 
	private String acctNum;
	
	
	@JSONField(name="IAcctInd") 
	private String iacctInd;
	
	
	@JSONField(name="JointAcctInd") 
	private String jointAcctInd;
	
	
	@JSONField(name="StatusCode") 
	private String statusCode;
	
	
	@JSONField(name="CurrencyCode") 
	private String currencyCode;
	
	
	@JSONField(name="Balance") 
	private String balance;
	
	
	@JSONField(name="CreditLimit")
	private String creditLimit;
	
	
	
	@JSONField(name="CardLinkCustNum") 
	private String cardLinkCustNum;
	
	
	@JSONField(name="AcctOwnerInd") 
	private String acctOwnerInd;
	
	
	@JSONField(name="AcctName") 
	private String acctName;
	
	
	
	@JSONField(name="CardSuspInd") 
	private String cardSuspInd;
	
	
	@JSONField(name="CSSAAcctInd") 
	private String cSSAAcctInd;
	
	
	@JSONField(name="TrustClientInd") 
	private String trustClientInd;
	
	
	@JSONField(name="CcySwitchingInd") 
	private String ccySwitchingInd;
	
	
	@JSONField(name="JointSignInd") 
	private String jointSignInd;
	
	
	@JSONField(name="Filler1") 
	private String filler1;
	
	
	@JSONField(name="AddressCode") 
	private String addressCode;
	
	
	@JSONField(name="HoldCode") 
	private List<String> holdCode=new ArrayList<String>();


	@JSONField(name="BIALinkedInd") 
	private String biaLinkedInd;
	
}

