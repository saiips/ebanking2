package com.dsb.eb2.backOffice.connect.emsMsg;

import com.dsb.eb2.backOffice.connect.emsMsg.nf1108.NF1108RepData;
import com.dsb.eb2.backOffice.connect.webService.emsEmail.T;
import com.fasterxml.jackson.databind.ObjectMapper;

public class TestResp {

	public static void main(String[] args) throws Exception {
		String jsonStr = "{" + 
				"\"XMLRepMsg\" : {" + 
				"\"Header\" : {" + 
				"\"ServiceID\" : \"NF1107\"," + 
				"\"TxRefNo\" : \"2334448\"," + 
				"\"TxDateTime\" : \"20181227094542\"," + 
				"\"ChannelID\" : \"EB\"," + 
				"\"MessageSequence\" : \"0\"," + 
				"\"BankCode\" : \"6\"," + 
				"\"CustID\" : \"IDR8601517\"," + 
				"\"AgentID\" : \"FAI06\"," + 
				"\"TerminalID\" : \"EBHUB5\"," + 
				"\"ErrorCorrectionFlag\" : \"N\"," + 
				"\"ReturnCode\" : \"900000\"," + 
				"\"OverrideLevel\" : \"0\"," + 
				"\"Detail\" : {" + 
				"\"Code\" : \"\"," + 
				"\"Level\" : \"\"" + 
				"}," + 
				"\"Detail\" : {" + 
				"\"Code\" : \"\"," + 
				"\"Level\" : \"\"" + 
				"}," + 
				"\"Detail\" : {" + 
				"\"Code\" : \"\"," + 
				"\"Level\" : \"\"" + 
				"}," + 
				"\"Detail\" : {" + 
				"\"Code\" : \"\"," + 
				"\"Level\" : \"\"" + 
				"}," + 
				"\"Detail\" : {" + 
				"\"Code\" : \"\"," + 
				"\"Level\" : \"\"" + 
				"}," + 
				"\"Detail\" : {" + 
				"\"Code\" : \"\"," + 
				"\"Level\" : \"\"" + 
				"}," + 
				"\"Detail\" : {" + 
				"\"Code\" : \"\"," + 
				"\"Level\" : \"\"" + 
				"}," + 
				"\"Detail\" : {" + 
				"\"Code\" : \"\"," + 
				"\"Level\" : \"\"" + 
				"}," + 
				"\"CycleDate\" : \"20140903\"," + 
				"\"Remarks\" : \"\"," + 
				"\"SysTraceNum\" : \"0059313\"," + 
				"\"SpotDealOverrideFlag\" : \"\"" + 
				"}," + 
				"\"Payload\" : {" + 
				"\"NumOfAccts\" : \"9\"," + 
				"\"AcctDetails\" : {" + 
				"\"AcctTypeInd\" : \"O\"," + 
				"\"AcctType\" : \"AP\"," + 
				"\"ProdSubCode\" : \" \"," + 
				"\"Org\" : \"000\"," + 
				"\"AcctNum\" : \"7438500133 \"," + 
				"\"IAcctInd\" : \"N\"," + 
				"\"JointAcctInd\" : \"J\"," + 
				"\"StatusCode\" : \" \"," + 
				"\"CurrencyCode\" : \" \"," + 
				"\"Balance\" : \"0\"," + 
				"\"CreditLimit\" : \"0\"," + 
				"\"CardLinkCustNum\" : \" \"," + 
				"\"AcctOwnerInd\" : \"S\"," + 
				"\"AcctName\" : \" \"," + 
				"\"CSSAAcctInd\" : \" \"," + 
				"\"TrustClientInd\" : \" \"," + 
				"\"JointSignInd\" : \" \"," + 
				"\"Filler1\" : \" \"," + 
				"\"AddressCode\" : \"1\"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"BIALinkedInd\" : \" \"" + 
				"}," + 
				"\"AcctDetails\" : {" + 
				"\"AcctTypeInd\" : \"O\"," + 
				"\"AcctType\" : \"AP\"," + 
				"\"ProdSubCode\" : \" \"," + 
				"\"Org\" : \"000\"," + 
				"\"AcctNum\" : \"7488500133 \"," + 
				"\"IAcctInd\" : \"N\"," + 
				"\"JointAcctInd\" : \"J\"," + 
				"\"StatusCode\" : \" \"," + 
				"\"CurrencyCode\" : \" \"," + 
				"\"Balance\" : \"0\"," + 
				"\"CreditLimit\" : \"0\"," + 
				"\"CardLinkCustNum\" : \" \"," + 
				"\"AcctOwnerInd\" : \"S\"," + 
				"\"AcctName\" : \" \"," + 
				"\"CSSAAcctInd\" : \" \"," + 
				"\"TrustClientInd\" : \" \"," + 
				"\"JointSignInd\" : \" \"," + 
				"\"Filler1\" : \" \"," + 
				"\"AddressCode\" : \"1\"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"BIALinkedInd\" : \" \"" + 
				"}," + 
				"\"AcctDetails\" : {" + 
				"\"AcctTypeInd\" : \"D\"," + 
				"\"AcctType\" : \"CA\"," + 
				"\"ProdSubCode\" : \"VIA\"," + 
				"\"Org\" : \"000\"," + 
				"\"AcctNum\" : \"7438500133 \"," + 
				"\"IAcctInd\" : \"Y\"," + 
				"\"JointAcctInd\" : \"J\"," + 
				"\"StatusCode\" : \" \"," + 
				"\"CurrencyCode\" : \"HKD\"," + 
				"\"Balance\" : \"-1004.2\"," + 
				"\"CreditLimit\" : \"300000\"," + 
				"\"CardLinkCustNum\" : \" \"," + 
				"\"AcctOwnerInd\" : \"S\"," + 
				"\"AcctName\" : \"XX \"," + 
				"\"CSSAAcctInd\" : \" \"," + 
				"\"TrustClientInd\" : \" \"," + 
				"\"JointSignInd\" : \" \"," + 
				"\"Filler1\" : \" \"," + 
				"\"AddressCode\" : \"1\"," + 
				"\"HoldCode\" : \"00\"," + 
				"\"HoldCode\" : \"00\"," + 
				"\"HoldCode\" : \"00\"," + 
				"\"HoldCode\" : \"00\"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"BIALinkedInd\" : \" \"" + 
				"}," + 
				"\"AcctDetails\" : {" + 
				"\"AcctTypeInd\" : \"D\"," + 
				"\"AcctType\" : \"SA\"," + 
				"\"ProdSubCode\" : \"VIA\"," + 
				"\"Org\" : \"000\"," + 
				"\"AcctNum\" : \"7488500133 \"," + 
				"\"IAcctInd\" : \"Y\"," + 
				"\"JointAcctInd\" : \"J\"," + 
				"\"StatusCode\" : \" \"," + 
				"\"CurrencyCode\" : \"CNY\"," + 
				"\"Balance\" : \"37256.05\"," + 
				"\"CreditLimit\" : \"0\"," + 
				"\"CardLinkCustNum\" : \" \"," + 
				"\"AcctOwnerInd\" : \"S\"," + 
				"\"AcctName\" : \"XX \"," + 
				"\"CSSAAcctInd\" : \" \"," + 
				"\"TrustClientInd\" : \" \"," + 
				"\"JointSignInd\" : \" \"," + 
				"\"Filler1\" : \" \"," + 
				"\"AddressCode\" : \"1\"," + 
				"\"HoldCode\" : \"00\"," + 
				"\"HoldCode\" : \"00\"," + 
				"\"HoldCode\" : \"00\"," + 
				"\"HoldCode\" : \"00\"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"BIALinkedInd\" : \" \"" + 
				"}," + 
				"\"AcctDetails\" : {" + 
				"\"AcctTypeInd\" : \"D\"," + 
				"\"AcctType\" : \"SA\"," + 
				"\"ProdSubCode\" : \"VIA\"," + 
				"\"Org\" : \"000\"," + 
				"\"AcctNum\" : \"7488500133 \"," + 
				"\"IAcctInd\" : \"Y\"," + 
				"\"JointAcctInd\" : \"J\"," + 
				"\"StatusCode\" : \" \"," + 
				"\"CurrencyCode\" : \"EUR\"," + 
				"\"Balance\" : \"20004.97\"," + 
				"\"CreditLimit\" : \"0\"," + 
				"\"CardLinkCustNum\" : \" \"," + 
				"\"AcctOwnerInd\" : \"S\"," + 
				"\"AcctName\" : \"XX \"," + 
				"\"CSSAAcctInd\" : \" \"," + 
				"\"TrustClientInd\" : \" \"," + 
				"\"JointSignInd\" : \" \"," + 
				"\"Filler1\" : \" \"," + 
				"\"AddressCode\" : \"1\"," + 
				"\"HoldCode\" : \"00\"," + 
				"\"HoldCode\" : \"00\"," + 
				"\"HoldCode\" : \"00\"," + 
				"\"HoldCode\" : \"00\"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"BIALinkedInd\" : \" \"" + 
				"}," + 
				"\"AcctDetails\" : {" + 
				"\"AcctTypeInd\" : \"D\"," + 
				"\"AcctType\" : \"SA\"," + 
				"\"ProdSubCode\" : \"VIA\"," + 
				"\"Org\" : \"000\"," + 
				"\"AcctNum\" : \"7488500133 \"," + 
				"\"IAcctInd\" : \"Y\"," + 
				"\"JointAcctInd\" : \"J\"," + 
				"\"StatusCode\" : \" \"," + 
				"\"CurrencyCode\" : \"GBP\"," + 
				"\"Balance\" : \"17007.19\"," + 
				"\"CreditLimit\" : \"0\"," + 
				"\"CardLinkCustNum\" : \" \"," + 
				"\"AcctOwnerInd\" : \"S\"," + 
				"\"AcctName\" : \"XX \"," + 
				"\"CSSAAcctInd\" : \" \"," + 
				"\"TrustClientInd\" : \" \"," + 
				"\"JointSignInd\" : \" \"," + 
				"\"Filler1\" : \" \"," + 
				"\"AddressCode\" : \"1\"," + 
				"\"HoldCode\" : \"00\"," + 
				"\"HoldCode\" : \"00\"," + 
				"\"HoldCode\" : \"00\"," + 
				"\"HoldCode\" : \"00\"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"BIALinkedInd\" : \" \"" + 
				"}," + 
				"\"AcctDetails\" : {" + 
				"\"AcctTypeInd\" : \"D\"," + 
				"\"AcctType\" : \"SA\"," + 
				"\"ProdSubCode\" : \"VIA\"," + 
				"\"Org\" : \"000\"," + 
				"\"AcctNum\" : \"7488500133 \"," + 
				"\"IAcctInd\" : \"Y\"," + 
				"\"JointAcctInd\" : \"J\"," + 
				"\"StatusCode\" : \" \"," + 
				"\"CurrencyCode\" : \"HKD\"," + 
				"\"Balance\" : \"729435.08\"," + 
				"\"CreditLimit\" : \"0\"," + 
				"\"CardLinkCustNum\" : \" \"," + 
				"\"AcctOwnerInd\" : \"S\"," + 
				"\"AcctName\" : \"XX \"," + 
				"\"CSSAAcctInd\" : \" \"," + 
				"\"TrustClientInd\" : \" \"," + 
				"\"JointSignInd\" : \" \"," + 
				"\"Filler1\" : \" \"," + 
				"\"AddressCode\" : \"1\"," + 
				"\"HoldCode\" : \"00\"," + 
				"\"HoldCode\" : \"00\"," + 
				"\"HoldCode\" : \"00\"," + 
				"\"HoldCode\" : \"00\"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"BIALinkedInd\" : \" \"" + 
				"}," + 
				"\"AcctDetails\" : {" + 
				"\"AcctTypeInd\" : \"D\"," + 
				"\"AcctType\" : \"SA\"," + 
				"\"ProdSubCode\" : \"VIA\"," + 
				"\"Org\" : \"000\"," + 
				"\"AcctNum\" : \"7488500133 \"," + 
				"\"IAcctInd\" : \"Y\"," + 
				"\"JointAcctInd\" : \"J\"," + 
				"\"StatusCode\" : \" \"," + 
				"\"CurrencyCode\" : \"NZD\"," + 
				"\"Balance\" : \"32343.8\"," + 
				"\"CreditLimit\" : \"0\"," + 
				"\"CardLinkCustNum\" : \" \"," + 
				"\"AcctOwnerInd\" : \"S\"," + 
				"\"AcctName\" : \"XX \"," + 
				"\"CSSAAcctInd\" : \" \"," + 
				"\"TrustClientInd\" : \" \"," + 
				"\"JointSignInd\" : \" \"," + 
				"\"Filler1\" : \" \"," + 
				"\"AddressCode\" : \"1\"," + 
				"\"HoldCode\" : \"00\"," + 
				"\"HoldCode\" : \"00\"," + 
				"\"HoldCode\" : \"00\"," + 
				"\"HoldCode\" : \"00\"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"BIALinkedInd\" : \" \"" + 
				"}," + 
				"\"AcctDetails\" : {" + 
				"\"AcctTypeInd\" : \"D\"," + 
				"\"AcctType\" : \"SA\"," + 
				"\"ProdSubCode\" : \"VIA\"," + 
				"\"Org\" : \"000\"," + 
				"\"AcctNum\" : \"7488500133 \"," + 
				"\"IAcctInd\" : \"Y\"," + 
				"\"JointAcctInd\" : \"J\"," + 
				"\"StatusCode\" : \" \"," + 
				"\"CurrencyCode\" : \"USD\"," + 
				"\"Balance\" : \"37028.67\"," + 
				"\"CreditLimit\" : \"0\"," + 
				"\"CardLinkCustNum\" : \" \"," + 
				"\"AcctOwnerInd\" : \"S\"," + 
				"\"AcctName\" : \"XX \"," + 
				"\"CSSAAcctInd\" : \" \"," + 
				"\"TrustClientInd\" : \" \"," + 
				"\"JointSignInd\" : \" \"," + 
				"\"Filler1\" : \" \"," + 
				"\"AddressCode\" : \"1\"," + 
				"\"HoldCode\" : \"00\"," + 
				"\"HoldCode\" : \"00\"," + 
				"\"HoldCode\" : \"00\"," + 
				"\"HoldCode\" : \"00\"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"HoldCode\" : \" \"," + 
				"\"BIALinkedInd\" : \" \"" + 
				"}" + 
				"}" + 
				"}" + 
				"}";
		
		 //EmsRepMsg emsRepMsg = (EmsRepMsg)EmsMsgUtils.jsonToRepMsg(jsonStr);
//		EmsRepMsg EmsRepMsgTemp = new EmsRepMsg();
//		EmsRepMsgTemp.setFrmData(new NF1111RepData());
//		
//		JSONObject jsonObj = JSON.parseObject(jsonStr);
//		String xMLRepMsg = jsonObj.getString("XMLRepMsg");
//		
//		JSONObject xmlRepMsgJson = JSON.parseObject(xMLRepMsg);
//		
//		String body = xmlRepMsgJson.getString("Payload");
//		EmsRepMsgTemp = (EmsRepMsg)JsonUtils.JsonToObj(jsonStr, new EmsRepMsg());
//		
//		NF1111RepData nF1111RepData = (NF1111RepData) JsonUtils.JsonToObj(body,new NF1111RepData());
//		EmsRepMsgTemp.setFrmData(nF1111RepData);
//		// NF1111RepData repData = (NF1111RepData) emsRepMsg.getFrmData();
//		EmsRepMsgTemp = EmsMsgUtils.JSONToEmsRepMsg(jsonStr, new NF1108RepData());
		
		
//		ObjectMapper objectMapper = new ObjectMapper();
//		NF1108RepData object = objectMapper.readValue(jsonStr, NF1108RepData.class);
		
		EmsRepMsg emsRepMsg = EmsMsgUtils.JSONToEmsRepMsg(jsonStr);
	
	}
}
