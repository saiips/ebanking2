package com.dsb.eb2.backOffice.connect.emsMsg.nf1524;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"CustomerNumber","OrgNumber"})
public class NF1524ReqData  extends FrmData
{
    
	public NF1524ReqData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1524";
	}
	
	@JSONField(name="CustomerNumber")
	private String customerNumber;
	
	@JSONField(name="OrgNumber")
	private String orgNumber;

	@XmlElement(name = "CustomerNumber")
	public String getCustomerNumber() {
		return customerNumber;
	}

	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}

	@XmlElement(name = "OrgNumber")
	public String getOrgNumber() {
		return orgNumber;
	}

	public void setOrgNumber(String orgNumber) {
		this.orgNumber = orgNumber;
	}
	
	
}
