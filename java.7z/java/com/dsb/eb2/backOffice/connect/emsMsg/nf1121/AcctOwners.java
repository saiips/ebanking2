package com.dsb.eb2.backOffice.connect.emsMsg.nf1121;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"customerID","titleName","customerName1","customerName2","indicator",
					"custShortName","custType","tempCustType","staffInd","vIPInd"})
public class AcctOwners {

	public AcctOwners(){}
	
	@JSONField(name="CustomerID")
	private String customerID;
	
	@JSONField(name="TitleName")
	private String titleName;
	
	@JSONField(name="CustomerName1")
	private String customerName1;
	
	@JSONField(name="CustomerName2")
	private String customerName2;
	
	@JSONField(name="Indicator")
	private String indicator;
	
	@JSONField(name="CustShortName")
	private String custShortName;
	
	@JSONField(name="CustType")
	private String custType;
	
	@JSONField(name="TempCustType")
	private String tempCustType;
	
	@JSONField(name="StaffInd")
	private String staffInd;
	
	@JSONField(name="VIPInd")
	private String vIPInd;

	
	
	@XmlElement(name="CustomerID")
	public String getCustomerID() {
		return customerID;
	}

	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}

	@XmlElement(name="TitleName")
	public String getTitleName() {
		return titleName;
	}

	public void setTitleName(String titleName) {
		this.titleName = titleName;
	}

	@XmlElement(name="CustomerName1")
	public String getCustomerName1() {
		return customerName1;
	}

	public void setCustomerName1(String customerName1) {
		this.customerName1 = customerName1;
	}

	@XmlElement(name="CustomerName2")
	public String getCustomerName2() {
		return customerName2;
	}

	public void setCustomerName2(String customerName2) {
		this.customerName2 = customerName2;
	}

	@XmlElement(name="Indicator")
	public String getIndicator() {
		return indicator;
	}

	public void setIndicator(String indicator) {
		this.indicator = indicator;
	}

	@XmlElement(name="CustShortName")
	public String getCustShortName() {
		return custShortName;
	}

	public void setCustShortName(String custShortName) {
		this.custShortName = custShortName;
	}

	@XmlElement(name="CustType")
	public String getCustType() {
		return custType;
	}

	public void setCustType(String custType) {
		this.custType = custType;
	}

	@XmlElement(name="TempCustType")
	public String getTempCustType() {
		return tempCustType;
	}

	public void setTempCustType(String tempCustType) {
		this.tempCustType = tempCustType;
	}

	@XmlElement(name="StaffInd")
	public String getStaffInd() {
		return staffInd;
	}

	public void setStaffInd(String staffInd) {
		this.staffInd = staffInd;
	}

	@XmlElement(name="VIPInd")
	public String getvIPInd() {
		return vIPInd;
	}

	public void setvIPInd(String vIPInd) {
		this.vIPInd = vIPInd;
	}
	

}
