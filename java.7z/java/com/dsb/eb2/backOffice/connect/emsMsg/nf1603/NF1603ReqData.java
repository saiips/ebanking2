package com.dsb.eb2.backOffice.connect.emsMsg.nf1603;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"actionCode","systemCode","acctNum","custID1","custID2","custID3","custID4","custID5","addrCode","signatureNum","applyMasterCSN","branchNum"})
public class  NF1603ReqData extends FrmData
{
    
	public NF1603ReqData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1603";
	}
	 
	@JSONField(name="ActionCode")
	private String actionCode;
	
	@JSONField(name="SystemCode")
	private String systemCode;
	
	@JSONField(name="AcctNum")
	private String acctNum;
	
	@JSONField(name="CustID1")
	private String custID1;
	
	@JSONField(name="CustID2")
	private String custID2;
	
	@JSONField(name="CustID3")
	private String custID3;
	
	@JSONField(name="CustID4")
	private String custID4;
	
	@JSONField(name="CustID5")
	private String custID5;
	
	@JSONField(name="AddrCode")
	private String addrCode;
	
	@JSONField(name="SignatureNum")
	private String signatureNum;
	
	@JSONField(name="ApplyMasterCSN")
	private String applyMasterCSN;
	
	@JSONField(name="BranchNum")
	private String branchNum;
	
	
	
	@XmlElement(name = "ActionCode")
	public String getActionCode() {
		return actionCode;
	}

	@XmlElement(name = "SystemCode")
	public String getSystemCode() {
		return systemCode;
	}

	@XmlElement(name = "AcctNum")
	public String getAcctNum() {
		return acctNum;
	}

	@XmlElement(name = "CustID1")
	public String getCustID1() {
		return custID1;
	}

	@XmlElement(name = "CustID2")
	public String getCustID2() {
		return custID2;
	}

	@XmlElement(name = "CustID3")
	public String getCustID3() {
		return custID3;
	}

	@XmlElement(name = "CustID4")
	public String getCustID4() {
		return custID4;
	}

	@XmlElement(name = "CustID5")
	public String getCustID5() {
		return custID5;
	}

	@XmlElement(name = "AddrCode")
	public String getAddrCode() {
		return addrCode;
	}

	@XmlElement(name = "SignatureNum")
	public String getSignatureNum() {
		return signatureNum;
	}

	@XmlElement(name = "ApplyMasterCSN")
	public String getApplyMasterCSN() {
		return applyMasterCSN;
	}

	@XmlElement(name = "BranchNum")
	public String getBranchNum() {
		return branchNum;
	}

	
	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}

	public void setSystemCode(String systemCode) {
		this.systemCode = systemCode;
	}

	public void setAcctNum(String acctNum) {
		this.acctNum = acctNum;
	}

	public void setCustID1(String custID1) {
		this.custID1 = custID1;
	}

	public void setCustID2(String custID2) {
		this.custID2 = custID2;
	}

	public void setCustID3(String custID3) {
		this.custID3 = custID3;
	}

	public void setCustID4(String custID4) {
		this.custID4 = custID4;
	}

	public void setCustID5(String custID5) {
		this.custID5 = custID5;
	}

	public void setAddrCode(String addrCode) {
		this.addrCode = addrCode;
	}

	public void setSignatureNum(String signatureNum) {
		this.signatureNum = signatureNum;
	}

	public void setApplyMasterCSN(String applyMasterCSN) {
		this.applyMasterCSN = applyMasterCSN;
	}

	public void setBranchNum(String branchNum) {
		this.branchNum = branchNum;
	}

	
	
	
	
	


	
}
