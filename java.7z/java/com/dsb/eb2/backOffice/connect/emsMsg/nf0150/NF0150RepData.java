package com.dsb.eb2.backOffice.connect.emsMsg.nf0150;
import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class NF0150RepData extends FrmData
{
    public NF0150RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF0150";
	}
	
	@JSONField(name="HKDTODRate") 
	private String  hKDTODRate;
	
	@JSONField(name="HKDPrime") 
	private List<HKDPrime>  hKDPrime;
	
	@JSONField(name="USDPrime") 
	private List<USDPrime>  uSDPrime;
	
	@JSONField(name="HIBOR") 
	private List<HIBOR>  hIBOR;
	
	@JSONField(name="LIBOR")
	private  List<LIBOR> lIBOR;
	
	@JSONField(name="Message") 
	private String  message;
	
	@JSONField(name="HSBCPrimeRate")
	private String  hSBCPrimeRate;

}
