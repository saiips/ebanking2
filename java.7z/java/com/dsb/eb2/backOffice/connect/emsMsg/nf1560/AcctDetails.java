package com.dsb.eb2.backOffice.connect.emsMsg.nf1560;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"acctNum","availableBalance","currentBalance","accruedInterest",
				"upperLimit","holdCode1","holdCode2","holdCode3","holdCode4",
				"retrivalReturnCode","currencyCode","holdFundDetails"})
public class AcctDetails
{
	public AcctDetails (){}
	
	private String acctNum = "";
	
	private String availableBalance = "";
	
	private String currentBalance = "";
	
	private String accruedInterest = "";
	
	private String upperLimit = "";
	
	private String holdCode1 = "";
	
	private String holdCode2 = "";
	
	private String holdCode3 = "";
	
	private String holdCode4 = "";
	
	private String retrivalReturnCode = "";
	
	private String currencyCode = "";
	
	private List<HoldFundDetails> holdFundDetails;

	@XmlElement(name = "AcctNum")
	public String getAcctNum() {
		return acctNum;
	}

	public void setAcctNum(String acctNum) {
		this.acctNum = acctNum;
	}

	@XmlElement(name = "AvailableBalance")
	public String getAvailableBalance() {
		return availableBalance;
	}

	public void setAvailableBalance(String availableBalance) {
		this.availableBalance = availableBalance;
	}

	@XmlElement(name = "CurrentBalance")
	public String getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(String currentBalance) {
		this.currentBalance = currentBalance;
	}

	@XmlElement(name = "AccruedInterest")
	public String getAccruedInterest() {
		return accruedInterest;
	}

	public void setAccruedInterest(String accruedInterest) {
		this.accruedInterest = accruedInterest;
	}

	@XmlElement(name = "UpperLimit")
	public String getUpperLimit() {
		return upperLimit;
	}

	public void setUpperLimit(String upperLimit) {
		this.upperLimit = upperLimit;
	}

	@XmlElement(name = "HoldCode1")
	public String getHoldCode1() {
		return holdCode1;
	}

	public void setHoldCode1(String holdCode1) {
		this.holdCode1 = holdCode1;
	}

	@XmlElement(name = "HoldCode2")
	public String getHoldCode2() {
		return holdCode2;
	}

	public void setHoldCode2(String holdCode2) {
		this.holdCode2 = holdCode2;
	}

	@XmlElement(name = "HoldCode3")
	public String getHoldCode3() {
		return holdCode3;
	}

	public void setHoldCode3(String holdCode3) {
		this.holdCode3 = holdCode3;
	}

	@XmlElement(name = "HoldCode4")
	public String getHoldCode4() {
		return holdCode4;
	}

	public void setHoldCode4(String holdCode4) {
		this.holdCode4 = holdCode4;
	}

	@XmlElement(name = "RetrivalReturnCode")
	public String getRetrivalReturnCode() {
		return retrivalReturnCode;
	}

	public void setRetrivalReturnCode(String retrivalReturnCode) {
		this.retrivalReturnCode = retrivalReturnCode;
	}

	@XmlElement(name = "CurrencyCode")
	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	@XmlElement(name = "HoldFundDetails")
	public List<HoldFundDetails> getHoldFundDetails() {
		return holdFundDetails;
	}

	public void setHoldFundDetails(List<HoldFundDetails> holdFundDetails) {
		this.holdFundDetails = holdFundDetails;
	}
}
