package com.dsb.eb2.backOffice.connect.emsMsg.fn0006;

import java.util.List;


import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;
@Getter @Setter
public class FN0006ReqData extends FrmData
{
    public FN0006ReqData(){}
    
    @JSONField(serialize=false)
    @Override
    public String getServiceID()
    {
        return "FN0006";
    }

    @JSONField(name="AcctNum")
    private String acctNum;

    @JSONField(name="CcyCode")
    private String ccyCode;

    @JSONField(name="CreditAcctNum")
    private String creditAcctNum;

    @JSONField(name="CreditAcctCcy")
    private String creditAcctCcy;

    @JSONField(name="ExchangeRate")
    private String exchangeRate;

    @JSONField(name="HKDAmt")
    private String hKDAmt;

    @JSONField(name="SpotPositionBookingData")
    private List<SpotPositionBookingData> spotPositionBookingData ;
}
