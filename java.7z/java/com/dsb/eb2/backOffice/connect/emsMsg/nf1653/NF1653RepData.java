package com.dsb.eb2.backOffice.connect.emsMsg.nf1653;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"acctNum","title","custName","blockCode","cardStatus","availLimit","creditLimit","outstandingBalance",
		"paymentDueDate","statementFlag","cardExpiryDate","giftCardAvailBalance","currentOutstandingBalance","lastStatementDate",
		"lastStatementBalance","outstandingStatementBalance","minPayment", "minPaymentDue","cardEmbossingName","autopayInfo"})
public class NF1653RepData extends FrmData 
{
	
	public NF1653RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		
		return "NF1653";
	}

	@JSONField(name="AcctNum")
    private String  acctNum;
	
	@JSONField(name="Title") 
	private String  title;
	
	@JSONField(name="CustName") 
	private String  custName;
	
	@JSONField(name="BlockCode") 
	private String  blockCode;
	
	@JSONField(name="CardStatus") 
	private String  cardStatus;
	
	@JSONField(name="AvailLimit")
	private String  availLimit;
	
	@JSONField(name="CreditLimit")
	private String  creditLimit;
	
	@JSONField(name="OutstandingBalance")
    private String  outstandingBalance;
	
	@JSONField(name="PaymentDueDate")
    private String  paymentDueDate;
	
	@JSONField(name="StatementFlag")
	private String  statementFlag;
	
	
	
	@JSONField(name="CardExpiryDate")
	private String  cardExpiryDate;
	
	@JSONField(name="GiftCardAvailBalance")
	private String  giftCardAvailBalance;
	
	@JSONField(name="CurrentOutstandingBalance") 
	private String  currentOutstandingBalance;
	
	@JSONField(name="LastStatementDate")
	private String  lastStatementDate;
	
	@JSONField(name="LastStatementBalance") 
	private String  lastStatementBalance;
	
	@JSONField(name="OutstandingStatementBalance") 
	private String  outstandingStatementBalance;
	
	@JSONField(name="MinPayment")
	private String  minPayment;
	
	@JSONField(name="MinPaymentDue") 
	private String  minPaymentDue;
	
	@JSONField(name="CardEmbossingName") 
	private String  cardEmbossingName;
	
	@JSONField(name="AutopayInfo")
	private List<AutopayInfo>  autopayInfo;

	
	
	@XmlElement(name = "AcctNum")
	public String getAcctNum() {
		return acctNum;
	}

	public void setAcctNum(String acctNum) {
		this.acctNum = acctNum;
	}
	
	@XmlElement(name = "Title")
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@XmlElement(name = "CustName")
	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	@XmlElement(name = "BlockCode")
	public String getBlockCode() {
		return blockCode;
	}

	public void setBlockCode(String blockCode) {
		this.blockCode = blockCode;
	}

	@XmlElement(name = "CardStatus")
	public String getCardStatus() {
		return cardStatus;
	}

	public void setCardStatus(String cardStatus) {
		this.cardStatus = cardStatus;
	}

	@XmlElement(name = "AvailLimit")
	public String getAvailLimit() {
		return availLimit;
	}

	public void setAvailLimit(String availLimit) {
		this.availLimit = availLimit;
	}

	@XmlElement(name = "CreditLimit")
	public String getCreditLimit() {
		return creditLimit;
	}

	public void setCreditLimit(String creditLimit) {
		this.creditLimit = creditLimit;
	}

	@XmlElement(name = "OutstandingBalance")
	public String getOutstandingBalance() {
		return outstandingBalance;
	}

	public void setOutstandingBalance(String outstandingBalance) {
		this.outstandingBalance = outstandingBalance;
	}

	@XmlElement(name = "PaymentDueDate")
	public String getPaymentDueDate() {
		return paymentDueDate;
	}

	public void setPaymentDueDate(String paymentDueDate) {
		this.paymentDueDate = paymentDueDate;
	}

	@XmlElement(name = "StatementFlag")
	public String getStatementFlag() {
		return statementFlag;
	}

	public void setStatementFlag(String statementFlag) {
		this.statementFlag = statementFlag;
	}

	@XmlElement(name = "CardExpiryDate")
	public String getCardExpiryDate() {
		return cardExpiryDate;
	}

	public void setCardExpiryDate(String cardExpiryDate) {
		this.cardExpiryDate = cardExpiryDate;
	}

	@XmlElement(name = "GiftCardAvailBalance")
	public String getGiftCardAvailBalance() {
		return giftCardAvailBalance;
	}

	public void setGiftCardAvailBalance(String giftCardAvailBalance) {
		this.giftCardAvailBalance = giftCardAvailBalance;
	}

	@XmlElement(name = "CurrentOutstandingBalance")
	public String getCurrentOutstandingBalance() {
		return currentOutstandingBalance;
	}

	public void setCurrentOutstandingBalance(String currentOutstandingBalance) {
		this.currentOutstandingBalance = currentOutstandingBalance;
	}

	@XmlElement(name = "LastStatementDate")
	public String getLastStatementDate() {
		return lastStatementDate;
	}

	public void setLastStatementDate(String lastStatementDate) {
		this.lastStatementDate = lastStatementDate;
	}

	@XmlElement(name = "LastStatementBalance")
	public String getLastStatementBalance() {
		return lastStatementBalance;
	}

	public void setLastStatementBalance(String lastStatementBalance) {
		this.lastStatementBalance = lastStatementBalance;
	}

	@XmlElement(name = "OutstandingStatementBalance")
	public String getOutstandingStatementBalance() {
		return outstandingStatementBalance;
	}

	public void setOutstandingStatementBalance(String outstandingStatementBalance) {
		this.outstandingStatementBalance = outstandingStatementBalance;
	}

	@XmlElement(name = "MinPayment")
	public String getMinPayment() {
		return minPayment;
	}

	public void setMinPayment(String minPayment) {
		this.minPayment = minPayment;
	}

	@XmlElement(name = "MinPaymentDue")
	public String getMinPaymentDue() {
		return minPaymentDue;
	}

	public void setMinPaymentDue(String minPaymentDue) {
		this.minPaymentDue = minPaymentDue;
	}

	@XmlElement(name = "CardEmbossingName")
	public String getCardEmbossingName() {
		return cardEmbossingName;
	}

	public void setCardEmbossingName(String cardEmbossingName) {
		this.cardEmbossingName = cardEmbossingName;
	}

	@XmlElement(name = "AutopayInfo")
	public List<AutopayInfo> getAutopayInfo() {
		return autopayInfo;
	}

	public void setAutopayInfo(List<AutopayInfo> autopayInfo) {
		this.autopayInfo = autopayInfo;
	}

	@Override
	public String toString() {
		return "NF1653RepData [acctNum=" + acctNum + ", title=" + title + ", custName=" + custName + ", blockCode="
				+ blockCode + ", cardStatus=" + cardStatus + ", availLimit=" + availLimit + ", creditLimit="
				+ creditLimit + ", outstandingBalance=" + outstandingBalance + ", paymentDueDate=" + paymentDueDate
				+ ", statementFlag=" + statementFlag + ", cardExpiryDate=" + cardExpiryDate + ", giftCardAvailBalance="
				+ giftCardAvailBalance + ", currentOutstandingBalance=" + currentOutstandingBalance
				+ ", lastStatementDate=" + lastStatementDate + ", lastStatementBalance=" + lastStatementBalance
				+ ", outstandingStatementBalance=" + outstandingStatementBalance + ", minPayment=" + minPayment
				+ ", minPaymentDue=" + minPaymentDue + ", cardEmbossingName=" + cardEmbossingName + ", autopayInfo="
				+ autopayInfo + "]";
	}

	


}
