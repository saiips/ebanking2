package com.dsb.eb2.backOffice.connect.emsMsg.nf1108;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class Filler {

	public Filler() {}
	
	@JSONField(name="BankCustCheck")
	public String bankCustCheck;

	@Override
	public String toString() {
		return "Filler [bankCustCheck=" + bankCustCheck + "]";
	}

}
