package com.dsb.eb2.backOffice.connect.emsMsg.nf1504;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"chqType"})
public class Filler {
	
	public Filler() {}
	
	@JSONField(name="ChqType")
	private String chqType;

	@XmlElement(name="ChqType")
	public String getChqType() {
		return chqType;
	}

	public void setChqType(String chqType) {
		this.chqType = chqType;
	}

	
}
