package com.dsb.eb2.backOffice.connect.emsMsg.fn0006;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;
@Getter @Setter
public class FN0006RepData
    extends FrmData
{
	
	
    public FN0006RepData() {}
    @JSONField(serialize=false)
	@Override
    public String getServiceID()
    {
        return "FN0006";
    }

    @JSONField(name="AcctNum")
    private String acctNum;

    @JSONField(name="HostTxnSeqNum")
    private String hostTxnSeqNum;

}
