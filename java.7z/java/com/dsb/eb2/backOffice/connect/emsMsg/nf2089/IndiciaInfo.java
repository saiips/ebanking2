package com.dsb.eb2.backOffice.connect.emsMsg.nf2089;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"indiciaCode","indiciaFlag"})
public class IndiciaInfo {
	
	public IndiciaInfo() {}
	
	@JSONField(name="IndiciaCode")
	private String indiciaCode;
	
	@JSONField(name="IndiciaFlag")
	private String indiciaFlag;

	
	@XmlElement(name = "IndiciaCode")
	public String getIndiciaCode() {
		return indiciaCode;
	}

	public void setIndiciaCode(String indiciaCode) {
		this.indiciaCode = indiciaCode;
	}

	@XmlElement(name = "IndiciaFlag")
	public String getIndiciaFlag() {
		return indiciaFlag;
	}

	public void setIndiciaFlag(String indiciaFlag) {
		this.indiciaFlag = indiciaFlag;
	}
	
}



