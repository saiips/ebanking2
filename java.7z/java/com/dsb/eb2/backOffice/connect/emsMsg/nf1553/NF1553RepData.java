package com.dsb.eb2.backOffice.connect.emsMsg.nf1553;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"lastKey","moreItemsInd","numOfItems","orderDetails"})
public class NF1553RepData extends FrmData{

	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1553";
	}
	
	public NF1553RepData() {}

	@JSONField(name="LastKey")
	private String lastKey;
	
	@JSONField(name="MoreItemsInd")
	private String moreItemsInd;
	
	@JSONField(name="NumOfItems")
	private String numOfItems;
	
	@JSONField(name="OrderDetails")
	private List <OrderDetails> orderDetails;

    @XmlElement(name = "LastKey")
	public String getLastKey() {
		return lastKey;
	}

	public void setLastKey(String lastKey) {
		this.lastKey = lastKey;
	}

    @XmlElement(name = "MoreItemsInd")
	public String getMoreItemsInd() {
		return moreItemsInd;
	}

	public void setMoreItemsInd(String moreItemsInd) {
		this.moreItemsInd = moreItemsInd;
	}

    @XmlElement(name = "NumOfItems")
	public String getNumOfItems() {
		return numOfItems;
	}

	public void setNumOfItems(String numOfItems) {
		this.numOfItems = numOfItems;
	}

    @XmlElement(name = "OrderDetails")
	public List<OrderDetails> getOrderDetails() {
		return orderDetails;
	}

	public void setOrderDetails(List<OrderDetails> orderDetails) {
		this.orderDetails = orderDetails;
	}



}
