package com.dsb.eb2.backOffice.connect.emsMsg.fn0006;

import com.dsb.eb2.backOffice.connect.emsMsg.ExRates;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class SpotPositData
{
	public SpotPositData(){}
	
	private String cnyTransClass = "";
	
	private String acctOfficerCode = "";
	
	private String acctOfficerSubCode = "";
	
	private String division = "";
	
	private String region = "";
	
	private String staffInd = "";
	
	private String vipFlag = "";
	
	private String exRateTier = "";
	
	private ExRates exRatesT1;
	
	private ExRates exRatesT2;
}
