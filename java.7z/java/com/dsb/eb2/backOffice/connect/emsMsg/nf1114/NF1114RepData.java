package com.dsb.eb2.backOffice.connect.emsMsg.nf1114;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class NF1114RepData  extends FrmData
{
    
	public NF1114RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1114";
	}
	
	@JSONField(name="LastUnsuccessScreenId")
	private String lastUnsuccessScreenId;
	
	@JSONField(name="AccountNumber")
	private String accountNumber;
	
	@JSONField(name="BlockCode")
	private String blockCode;
	
	@JSONField(name="AltBlockCode")
	private String altBlockCode;
	
	@JSONField(name="Status")
	private String status;
	
	@JSONField(name="Type")
	private String type;
	
	@JSONField(name="SpStatus1")
	private String spStatus1;
	
	@JSONField(name="SpStatus2")
	private String spStatus2;
	
	@JSONField(name="CustomerId")
	private String customerId;
	
	@JSONField(name="Title")
	private String title;
	
	@JSONField(name="CustomerName")
	private String customerName;
	
	@JSONField(name="JointIndicator")
	private String jointIndicator;
	
	@JSONField(name="CurrentBalance")
	private String currentBalance;
	
	@JSONField(name="CreditLimit")
	private String creditLimit;
	
	@JSONField(name="AvLimit")
	private String avLimit;
	
	@JSONField(name="CashLimit")
	private String cashLimit;
	
	@JSONField(name="AvCash")
	private String avCash;
	
	@JSONField(name="AggAvailable")
	private String aggAvailable;
	
	@JSONField(name="TotalAuthCount")
	private String totalAuthCount;
	
	@JSONField(name="TotalAuthAmount")
	private String totalAuthAmount;
	
	@JSONField(name="AuthTodayCount")
	private String authTodayCount;
	
	@JSONField(name="AuthTodayAmount")
	private String authTodayAmount;
	
	@JSONField(name="CashBalance")
	private String cashBalance;
	
	@JSONField(name="RetailBalance")
	private String retailBalance;
	
	@JSONField(name="DisputedAmount")
	private String disputedAmount;
	
	@JSONField(name="AmountLstPymt")
	private String amountLstPymt;
	
	@JSONField(name="PrepayAmount")
	private String prepayAmount;
	
	@JSONField(name="LastActivity")
	private String lastActivity;
	
	@JSONField(name="CardFeeDate")
	private String cardFeeDate;
	
	@JSONField(name="ExpireDate")
	private String expireDate;
	
	@JSONField(name="LastPayment")
	private String lastPayment;
	
	@JSONField(name="Collector")
	private String collector;
	
	@JSONField(name="CycleToDatePymt")
	private String cycleToDatePymt;
	
	@JSONField(name="CashDebitCount")
	private String cashDebitCount;
	
	@JSONField(name="CashDebitAmount")
	private String cashDebitAmount;
	
	@JSONField(name="CashCreditCount")
	private String cashCreditCount;
	
	@JSONField(name="CashCreditAmount")
	private String cashCreditAmount;
	
	@JSONField(name="CashBegBalance")
	private String cashBegBalance;
	
	@JSONField(name="RetailDebitCount")
	private String retailDebitCount;
	
	@JSONField(name="RetailDebitAmount")
	private String retailDebitAmount;
	
	@JSONField(name="RetailCreditCount")
	private String retailCreditCount;
	
	@JSONField(name="RetailCreditAmount")
	private String retailCreditAmount;
	
	@JSONField(name="RetailBegBalance")
	private String retailBegBalance;
	
	@JSONField(name="Payments")
	private String payments;
	
	@JSONField(name="LastStmtDate")
	private String lastStmtDate;
	
	@JSONField(name="PymtDueDate")
	private String pymtDueDate;
	
	@JSONField(name="StmtBalance")
	private String stmtBalance;
	
	@JSONField(name="CurrentDue")
	private String currentDue;
	
	@JSONField(name="PastDue")
	private String pastDue;
	
	@JSONField(name="TotalDue")
	private String totalDue;
	
	@JSONField(name="BillCycleDate")
	private String billCycleDate;
	
	@JSONField(name="CycleDue")
	private String cycleDue;
	
	@JSONField(name="C1IntRate")
	private String c1IntRate;
	
	@JSONField(name="C1Limit")
	private String c1Limit;
	
	@JSONField(name="C2IntRate")
	private String c2IntRate;
	
	@JSONField(name="C2Limit")
	private String c2Limit;
	
	@JSONField(name="C3IntRate")
	private String c3IntRate;
	
	@JSONField(name="R1IntRate")
	private String r1IntRate;
	
	@JSONField(name="R1Limit")
	private String r1Limit;
	
	@JSONField(name="R2IntRate")
	private String r2IntRate;
	
	@JSONField(name="R2Limit")
	private String r2Limit;
	
	@JSONField(name="R3IntRate")
	private String a3IntRate;
	
	@JSONField(name="AccruedCash")
	private String accruedCash;
	
	@JSONField(name="AccruedRetail")
	private String accruedRetail;
	
	@JSONField(name="PerDiem")
	private String perDiem;
	
	@JSONField(name="YTDInt")
	private String yTDInt;
	
	@JSONField(name="PriorYear")
	private String priorYear;
	
	@JSONField(name="Ccy")
	private String ccy;
	
	@JSONField(name="PAccount")
	private String pAccount;
	
	@JSONField(name="Agent")
	private String agent;
	
	@JSONField(name="Branch")
	private String branch;
	
	@JSONField(name="YTDEarn")
	private String yTDEarn;
	
	@JSONField(name="AccruedEarn")
	private String accruedEarn;
	
	@JSONField(name="Census")
	private String census;
	
	@JSONField(name="CrdLine")
	private String crdLine;
	
	@JSONField(name="CashLine")
	private String cashLine;
	
	@JSONField(name="AvailCash")
	private String availCash;
	
	@JSONField(name="AvailCrd")
	private String availCrd;
	
	@JSONField(name="MemoLine1")
	private String memoLine1;
	
	@JSONField(name="MemoLine2")
	private String memoLine2;
	
	@JSONField(name="CustClass")
	private String custClass;
	
	@JSONField(name="Statement")
	private String statement;
	
	@JSONField(name="CardMailer")
	private String cardMailer;
	
	@JSONField(name="PINMailer")
	private String cINMailer;
	
	@JSONField(name="Collection")
	private String collection;
	
	@JSONField(name="DirectMail")
	private String directMail;
	
	@JSONField(name="Usage6")
	private String psage6;
	
	@JSONField(name="Usage7")
	private String usage7;
	
	@JSONField(name="Usage8")
	private String usage8;
	
	@JSONField(name="Usage9")
	private String usage9;
	
	@JSONField(name="Usage10")
	private String usage10;
	
	@JSONField(name="Usage11")
	private String usage11;
	
	@JSONField(name="Usage12")
	private String usage12;

}
