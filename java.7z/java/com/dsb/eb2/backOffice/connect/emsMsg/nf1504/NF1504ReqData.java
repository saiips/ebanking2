package com.dsb.eb2.backOffice.connect.emsMsg.nf1504;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"acctNum","numOfChqBk","chqBkSize","mailingInd","collBranch","remarks","filler"})
public class NF1504ReqData  extends FrmData
{
    
	public NF1504ReqData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1504";
	}
	
	@JSONField(name="AcctNum")
	private String acctNum;
	
	@JSONField(name="NumOfChqBk")
	private String numOfChqBk;
	
	@JSONField(name="ChqBkSize")
	private String chqBkSize;
	
	@JSONField(name="MailingInd")
	private String mailingInd;
	
	@JSONField(name="CollBranch")
	private String collBranch;
	
	@JSONField(name="Remarks")
	private String remarks;
	
	@JSONField(name="Filler")
	private List<Filler> filler;

    @XmlElement(name = "AcctNum")
	public String getAcctNum() {
		return acctNum;
	}

	public void setAcctNum(String acctNum) {
		this.acctNum = acctNum;
	}

    @XmlElement(name = "NumOfChqBk")
	public String getNumOfChqBk() {
		return numOfChqBk;
	}

	public void setNumOfChqBk(String numOfChqBk) {
		this.numOfChqBk = numOfChqBk;
	}

    @XmlElement(name = "ChqBkSize")
	public String getChqBkSize() {
		return chqBkSize;
	}

	public void setChqBkSize(String chqBkSize) {
		this.chqBkSize = chqBkSize;
	}

    @XmlElement(name = "MailingInd")
	public String getMailingInd() {
		return mailingInd;
	}

	public void setMailingInd(String mailingInd) {
		this.mailingInd = mailingInd;
	}

    @XmlElement(name = "CollBranch")
	public String getCollBranch() {
		return collBranch;
	}

	public void setCollBranch(String collBranch) {
		this.collBranch = collBranch;
	}

    @XmlElement(name = "Remarks")
	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

    @XmlElement(name = "Filler")
	public List<Filler> getFiller() {
		return filler;
	}

	public void setFiller(List<Filler> filler) {
		this.filler = filler;
	}
	
}

