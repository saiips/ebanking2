package com.dsb.eb2.backOffice.connect.emsMsg.nf0104;
import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class NF0104RepData extends FrmData
{
    public NF0104RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF0104";
	}
	
	@JSONField(name="NoOfRows") 
	private String noOfRows;
	
	@JSONField(name="InterestRateDetails") 
	private List<InterestRateDetails> interestRateDetails;
}
