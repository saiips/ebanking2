package com.dsb.eb2.backOffice.connect.emsMsg.nf1609;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"cardNum","filler"})
public class NF1609RepData extends FrmData 
{
	
	public NF1609RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		
		return "NF1609";
	}

	@JSONField(name="CardNum") 
	private String  cardNum;
	
	@JSONField(name="Filler")
	private String  filler;

	@XmlElement(name = "CardNum") 
	public String getCardNum() {
		return cardNum;
	}

	@XmlElement(name = "Filler") 
	public String getFiller() {
		return filler;
	}

	public void setCardNum(String cardNum) {
		this.cardNum = cardNum;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}
	
	
	

}
