package com.dsb.eb2.backOffice.connect.emsMsg.nf1612;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;


@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"cardNum","seqNum","action","overseasDailyWithdrawalLimit","startDate","endDate"})
public class NF1612ReqData  extends FrmData
{

	public NF1612ReqData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1612";
	}
	
	@JSONField(name="CardNum")
	private String  cardNum;
	
	@JSONField(name="SeqNum") 
	private String  seqNum;
	
	@JSONField(name="Action") 
	private String  action;
	
	@JSONField(name="OverseasDailyWithdrawalLimit")
	private String  overseasDailyWithdrawalLimit;
	
	@JSONField(name="StartDate") 
	private String  startDate;
	
	@JSONField(name="EndDate") 
	private String  endDate;

	@XmlElement(name = "CardNum") 
	public String getCardNum() {
		return cardNum;
	}

	@XmlElement(name = "SeqNum") 
	public String getSeqNum() {
		return seqNum;
	}

	@XmlElement(name = "Action") 
	public String getAction() {
		return action;
	}

	@XmlElement(name = "OverseasDailyWithdrawalLimit") 
	public String getOverseasDailyWithdrawalLimit() {
		return overseasDailyWithdrawalLimit;
	}

	@XmlElement(name = "StartDate") 
	public String getStartDate() {
		return startDate;
	}

	@XmlElement(name = "EndDate") 
	public String getEndDate() {
		return endDate;
	}

	public void setCardNum(String cardNum) {
		this.cardNum = cardNum;
	}

	public void setSeqNum(String seqNum) {
		this.seqNum = seqNum;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public void setOverseasDailyWithdrawalLimit(String overseasDailyWithdrawalLimit) {
		this.overseasDailyWithdrawalLimit = overseasDailyWithdrawalLimit;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	
	
	



}
