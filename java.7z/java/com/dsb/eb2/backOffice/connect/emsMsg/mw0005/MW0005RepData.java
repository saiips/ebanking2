package com.dsb.eb2.backOffice.connect.emsMsg.mw0005;

import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class MW0005RepData extends FrmData
{
	public MW0005RepData(){}
	
	@Override
	public String getServiceID()
	{
		return "MW0005";
	}
	
	@JSONField(name="TotalNumOfRates")
	private String totalNumOfRates;
	
	@JSONField(name="RateDetails")
	private List<RateDetails> rateDetails;

}
