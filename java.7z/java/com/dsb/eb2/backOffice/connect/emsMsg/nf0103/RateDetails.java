package com.dsb.eb2.backOffice.connect.emsMsg.nf0103;
import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class RateDetails 
{

	public RateDetails(){}
	
	@JSONField(name="Ccy") 
	private String ccy;
	
	@JSONField(name="AccountType") 
	private String accountType;
	
	@JSONField(name="Tiers") 
	private List<Tiers> tiers;
}
