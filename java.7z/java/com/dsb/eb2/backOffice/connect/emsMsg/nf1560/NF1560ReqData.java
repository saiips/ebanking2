package com.dsb.eb2.backOffice.connect.emsMsg.nf1560;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"accountNumber","numOfAccts"})
public class NF1560ReqData extends FrmData
{

	public NF1560ReqData(){}
	
	@Override
	public String getServiceID() {
		// TODO Auto-generated method stub
		return "NF1560";
	}
	
	private List<String> accountNumber;
	
	private String numOfAccts;

	@XmlElement(name = "AccountNumber")
	public List<String> getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(List<String> accountNumber) {
		this.accountNumber = accountNumber;
	}

	@XmlElement(name = "NumOfAccts")
	public String getNumOfAccts() {
		return numOfAccts;
	}

	public void setNumOfAccts(String numOfAccts) {
		this.numOfAccts = numOfAccts;
	}


}
