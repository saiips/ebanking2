package com.dsb.eb2.backOffice.connect.emsMsg.nf0103;
import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class Tiers 
{

	public Tiers(){}
	
	@JSONField(name="FromAmt") 
	private String fromAmt;
	
	@JSONField(name="ToAmt") 
	private String toAmt;
	
	@JSONField(name="InterestRate") 
	private String interestRate;
}
