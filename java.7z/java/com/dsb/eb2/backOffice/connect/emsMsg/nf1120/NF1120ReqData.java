package com.dsb.eb2.backOffice.connect.emsMsg.nf1120;
import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class NF1120ReqData  extends FrmData
{
    public NF1120ReqData(){}

	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1120";
	}
	
	@JSONField(name="CardNumber")
	private String cardNumber;
	
	@JSONField(name="SequenceNumber")
	private String sequenceNumber;
}
