package com.dsb.eb2.backOffice.connect.emsMsg.nf0103;
import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class NF0103ReqData  extends FrmData
{

	public NF0103ReqData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF0103";
	}
	
	@JSONField(name="SystemCode")
	private String  systemCode;
	
	@JSONField(name="Option") 
	private String  option;
	
	@JSONField(name="Currency")
	private String  currency;
	
	@JSONField(name="AccountType") 
	private String  accountType;
	
	@JSONField(name="LastKey") 
	private String  lastKey;

}
