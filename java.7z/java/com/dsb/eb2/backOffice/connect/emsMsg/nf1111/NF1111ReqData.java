package com.dsb.eb2.backOffice.connect.emsMsg.nf1111;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class NF1111ReqData extends FrmData {

	public NF1111ReqData() {
	}

	@JSONField(serialize = false)
	@Override
	public String getServiceID() {
		return "NF1111";
	}

	@JSONField(name = "AccountNumber")
	private String accountNumber;

	@JSONField(name = "StartDate")
	private String startDate;

	@JSONField(name = "EndDate")
	private String endDate;

	@JSONField(name = "LastKey")
	private String lastKey;

	@JSONField(name = "ItemsRequested")
	private String itemsRequested;

	@JSONField(name = "RequestOption")
	private String requestOption;
}
