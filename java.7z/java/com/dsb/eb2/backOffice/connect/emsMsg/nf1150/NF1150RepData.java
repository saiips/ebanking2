package com.dsb.eb2.backOffice.connect.emsMsg.nf1150;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"pbReplyMsg"})
public class NF1150RepData extends FrmData{

	@Override
	public String getServiceID() {
		return "NF1150";
	}
	
	@JSONField(name="PBReplyMsg")
	private String pbReplyMsg;

	@XmlElement(name="PBReplyMsg")
	public String getPbReplyMsg() {
		return pbReplyMsg;
	}

	public void setPbReplyMsg(String pbReplyMsg) {
		this.pbReplyMsg = pbReplyMsg;
	}
	
}
