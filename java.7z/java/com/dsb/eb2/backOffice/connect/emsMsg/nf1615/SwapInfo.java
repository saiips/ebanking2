package com.dsb.eb2.backOffice.connect.emsMsg.nf1615;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"hKDPrincipal","hKDEffectiveInterest","swapHKDPI","swapHKDInterestRate","swapSpotRate","forwardExchangeRate"})
public class SwapInfo {
	
	public SwapInfo() {}

	@JSONField(name="HKDPrincipal")
	private String hKDPrincipal;
	
	@JSONField(name="HKDEffectiveInterest")
	private String hKDEffectiveInterest;
	
	@JSONField(name="SwapHKDPI")
	private String swapHKDPI;
	
	@JSONField(name="SwapHKDInterestRate")
	private String swapHKDInterestRate;
	
	@JSONField(name="SwapSpotRate")
	private String swapSpotRate;
	
	@JSONField(name="ForwardExchangeRate")
	private String forwardExchangeRate;

    @XmlElement(name = "HKDPrincipal")
	public String gethKDPrincipal() {
		return hKDPrincipal;
	}

	public void sethKDPrincipal(String hKDPrincipal) {
		this.hKDPrincipal = hKDPrincipal;
	}

    @XmlElement(name = "HKDEffectiveInterest")
	public String gethKDEffectiveInterest() {
		return hKDEffectiveInterest;
	}

	public void sethKDEffectiveInterest(String hKDEffectiveInterest) {
		this.hKDEffectiveInterest = hKDEffectiveInterest;
	}

    @XmlElement(name = "SwapHKDPI")
	public String getSwapHKDPI() {
		return swapHKDPI;
	}

	public void setSwapHKDPI(String swapHKDPI) {
		this.swapHKDPI = swapHKDPI;
	}

    @XmlElement(name = "SwapHKDInterestRate")
	public String getSwapHKDInterestRate() {
		return swapHKDInterestRate;
	}

	public void setSwapHKDInterestRate(String swapHKDInterestRate) {
		this.swapHKDInterestRate = swapHKDInterestRate;
	}

    @XmlElement(name = "SwapSpotRate")
	public String getSwapSpotRate() {
		return swapSpotRate;
	}

	public void setSwapSpotRate(String swapSpotRate) {
		this.swapSpotRate = swapSpotRate;
	}

    @XmlElement(name = "ForwardExchangeRate")
	public String getForwardExchangeRate() {
		return forwardExchangeRate;
	}

	public void setForwardExchangeRate(String forwardExchangeRate) {
		this.forwardExchangeRate = forwardExchangeRate;
	}
	
	



}
