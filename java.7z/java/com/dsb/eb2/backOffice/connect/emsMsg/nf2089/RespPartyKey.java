package com.dsb.eb2.backOffice.connect.emsMsg.nf2089;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;


@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"division","branchNum"})
public class RespPartyKey {
	
	public RespPartyKey() {}
	
	
	@JSONField(name="Division")
	private String division;
	
	@JSONField(name="BranchNum")
	private String branchNum;

	@XmlElement(name = "Division")
	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	@XmlElement(name = "BranchNum")
	public String getBranchNum() {
		return branchNum;
	}

	public void setBranchNum(String branchNum) {
		this.branchNum = branchNum;
	}
	
	
}



