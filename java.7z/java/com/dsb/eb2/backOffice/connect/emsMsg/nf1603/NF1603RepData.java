package com.dsb.eb2.backOffice.connect.emsMsg.nf1603;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"hostTxnSeqNum"})
public class  NF1603RepData extends FrmData
{
    
	public NF1603RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1603";
	}
	
	@JSONField(name="HostTxnSeqNum")
	private String hostTxnSeqNum;

	@XmlElement(name = "HostTxnSeqNum")
	public String getHostTxnSeqNum() {
		return hostTxnSeqNum;
	}
	
	public void setHostTxnSeqNum(String hostTxnSeqNum) {
		this.hostTxnSeqNum = hostTxnSeqNum;
	}
	
	
}
