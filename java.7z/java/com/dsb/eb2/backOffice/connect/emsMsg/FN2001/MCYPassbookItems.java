package com.dsb.eb2.backOffice.connect.emsMsg.FN2001;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder ={"sign","tranDate","mnemonic","tranAmt","bal","ccy","exRate","tellerID","filler"})
public class MCYPassbookItems
{
	@JSONField(name="Sign")
    private String sign;
    
	@JSONField(name="TranDate")
    private String tranDate;
    
	@JSONField(name="Mnemonic")
    private String mnemonic;
    
	@JSONField(name="TranAmt")
    private String tranAmt;
    
	@JSONField(name="Bal")
    private String bal;
    
	@JSONField(name="Ccy")
    private String ccy;
    
	@JSONField(name="ExRate")
    private String exRate;
    
	@JSONField(name="TellerID")
    private String tellerID;
    
	@JSONField(name="Filler")
    private String filler;

    @XmlElement(name = "Sign")
    public String getSign()
    {
        return sign;
    }

    public void setSign(String sign)
    {
        this.sign = sign;
    }

    @XmlElement(name = "TranDate")
    public String getTranDate()
    {
        return tranDate;
    }

    public void setTranDate(String tranDate)
    {
        this.tranDate = tranDate;
    }

    @XmlElement(name = "Mnemonic")
    public String getMnemonic()
    {
        return mnemonic;
    }

    public void setMnemonic(String mnemonic)
    {
        this.mnemonic = mnemonic;
    }

    @XmlElement(name = "TranAmt")
    public String getTranAmt()
    {
        return tranAmt;
    }

    public void setTranAmt(String tranAmt)
    {
        this.tranAmt = tranAmt;
    }

    @XmlElement(name = "Bal")
    public String getBal()
    {
        return bal;
    }

    public void setBal(String bal)
    {
        this.bal = bal;
    }

    @XmlElement(name = "Ccy")
    public String getCcy()
    {
        return ccy;
    }

    public void setCcy(String ccy)
    {
        this.ccy = ccy;
    }

    @XmlElement(name = "ExRate")
    public String getExRate()
    {
        return exRate;
    }

    public void setExRate(String exRate)
    {
        this.exRate = exRate;
    }

    @XmlElement(name = "TellerID")
    public String getTellerID()
    {
        return tellerID;
    }

    public void setTellerID(String tellerID)
    {
        this.tellerID = tellerID;
    }

    @XmlElement(name = "Filler")
    public String getFiller()
    {
        return filler;
    }

    public void setFiller(String filler)
    {
        this.filler = filler;
    }
    
}
