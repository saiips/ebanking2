package com.dsb.eb2.backOffice.connect.emsMsg;

import java.io.ByteArrayInputStream;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.dsb.eb2.util.JSONUtils;
import com.dsb.eb2.util.StringUtils;
import com.dsb.eb2.util.XMLUtils;

/**
 * EMS消息工具类
 * 
 * @author
 * 
 */
public class EmsMsgUtils
{

    private static Map<Class<?>, JAXBContext> contextMap = new HashMap<Class<?>, JAXBContext>();
    
    private static Logger logger = LoggerFactory.getLogger(EmsMsgUtils.class);

	public static JAXBContext getJAXBContext(Class<?> cl) throws JAXBException
    {
        synchronized (contextMap)
        {
            if (contextMap.containsKey(cl))
            {
                return contextMap.get(cl);
            } else
            {
                JAXBContext context = JAXBContext.newInstance(cl);
                contextMap.put(cl, context);
                return context;
            }
        }
    }

    /**
     * 将EmsReqMsg转换成XML
     * 
     * @param emsReqMsg
     * @return
     */
    public static String emsReqMsgToXML(EmsReqMsg emsReqMsg) throws Exception
    {
        StringWriter sw = new StringWriter();

        JAXBContext context = getJAXBContext(EmsReqMsg.class);
        Marshaller m = context.createMarshaller();
        m.marshal(emsReqMsg, sw);
        return sw.toString();
    }

    /**
     * 将XML装换成EmsReqMsg
     * 
     * @param source
     * @return
     */
    public static EmsReqMsg xmlToEmsReqMsg(String source) throws Exception
    {
        EmsReqMsg emsReqMsg = null;
        JAXBContext context = getJAXBContext(EmsReqMsg.class);
        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
        documentBuilderFactory.setNamespaceAware(true);
        XMLUtils.disableExternalEntityParsing(documentBuilderFactory);
        DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
        ByteArrayInputStream in = new ByteArrayInputStream(source.getBytes());
        Document document = documentBuilder.parse(in);
        Unmarshaller m = context.createUnmarshaller();
        emsReqMsg = (EmsReqMsg) m.unmarshal(document);
        
        return emsReqMsg;
    }

    /**
     * 将EmsRepMsg转换成XML
     * 
     * @param emsRepMsg
     * @return
     */
    public static String emsRepMsgToXML(EmsRepMsg emsRepMsg) throws Exception
    {
        StringWriter sw = new StringWriter();

        JAXBContext context = getJAXBContext(EmsRepMsg.class);
        Marshaller m = context.createMarshaller();
        m.marshal(emsRepMsg, sw);

        return sw.toString();
    }

    /**
     * 将XML转换成EmsRepMsg
     * 
     * @param source
     * @return
     */
    public static EmsRepMsg JSONToEmsRepMsg(String source) throws Exception
    {
    	logger.info("source = " + source);
        EmsRepMsg emsRepMsg = null;
        String xmlsource = JSONUtils.json2xml(source);
        logger.info("xmlsource = " + xmlsource);
        int start = xmlsource.indexOf("<ServiceID>") + "<ServiceID>".length();
        logger.info("start = " + start);
        int end = xmlsource.indexOf("</ServiceID>");
        logger.info("end = " + end);
        String serviceId = xmlsource.substring(start, end).toLowerCase();
        logger.info("serviceId = " + serviceId);
        xmlsource = xmlsource.replaceFirst(
            "<Payload>",
            "<Payload xsi:type=\""
                + serviceId
                + "RepData\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">");
        
        logger.info(xmlsource);
        JAXBContext context = getJAXBContext(EmsRepMsg.class);
        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
        documentBuilderFactory.setNamespaceAware(true);
        XMLUtils.disableExternalEntityParsing(documentBuilderFactory);
        DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
        ByteArrayInputStream in = new ByteArrayInputStream(xmlsource.getBytes("UTF-8"));
        Document document = documentBuilder.parse(in);
        Unmarshaller m = context.createUnmarshaller();
        emsRepMsg = (EmsRepMsg) m.unmarshal(document);
        return emsRepMsg;
    }
    
    
    /**
     * 将JSON字符串转换成EmsRepMsg
     * 
     * @param source
     * @return
     */
    public static EmsRepMsg JSONToEmsRepMsg(String source, FrmData obj)
    {
    	FrmHdr emsHeader = new FrmHdr();
    	JSONObject repMsgJsonObj = JSON.parseObject(source);
    	String repMsgStr = repMsgJsonObj.getString("XMLRepMsg");
    	
    	JSONObject repMsgJSONObj = JSON.parseObject(repMsgStr);
    	
    	String hederStr = repMsgJSONObj.getString("Header");
    	String payloadStr = repMsgJSONObj.getString("Payload");
    	
    	emsHeader = (FrmHdr)JSONUtils.JsonToObj(hederStr, new FrmHdr());
    	
    	
    	if(!StringUtils.isEmpty(payloadStr))
    	{
    		obj = (FrmData)JSONUtils.JsonToObj(payloadStr, obj);
    	}
    	
    	EmsRepMsg emsRepMsg = new EmsRepMsg();
    	emsRepMsg.setFrmData(obj);
    	emsRepMsg.setFrmHdr(emsHeader);
    	
    	
    	return emsRepMsg;
    }
}
