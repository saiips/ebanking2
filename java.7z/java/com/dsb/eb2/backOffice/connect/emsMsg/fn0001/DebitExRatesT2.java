package com.dsb.eb2.backOffice.connect.emsMsg.fn0001;


import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class DebitExRatesT2 {

	public DebitExRatesT2() {}
	
	@JSONField(name="PreferredRate")
	public String preferredRate;
	
	@JSONField(name="MinProfitRate")
	public String minProfitRate;
	
	@JSONField(name="CostRate")
	public String costRate;
	
	
}

