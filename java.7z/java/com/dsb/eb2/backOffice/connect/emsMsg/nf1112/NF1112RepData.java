package com.dsb.eb2.backOffice.connect.emsMsg.nf1112;
import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class NF1112RepData extends FrmData 
{
	
	public NF1112RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String  getServiceID() {
		
		return "NF1112";
	}
	
	@JSONField(name="AccountNumber")
	private String accountNumber;
	
	@JSONField(name="DateOpened")
	private String dateOpened;
	
	@JSONField(name="DateClosed")
	private String dateClosed;
	
	@JSONField(name="DrawDownDate")
	private String drawDownDate;
	
	@JSONField(name="LoanType")
	private String loanType;
	
	@JSONField(name="EmCardNumber")
	private String emCardNumber;
	
	@JSONField(name="Status")
	private String status;
	
	@JSONField(name="CurrentRevolvingSequenceNumber")
	private String currentRevolvingSequenceNumber;
	
	@JSONField(name="HoldCode")
	private String holdCode;
	
	@JSONField(name="LoanAmount")
	private String loanAmount;
	
	@JSONField(name="InitialUnearnedInterest")
	private String initialUnearnedInterest;
	
	@JSONField(name="LoanOutstanding")
	private String loanOutstanding;
	
	@JSONField(name="CalculationMethodCode")
	private String calculationMethodCode;
	
	@JSONField(name="InterestRatePerAnnum")
	private String interestRatePerAnnum;
	
	@JSONField(name="OverdueInterestRatePerAnnum")
	private String overdueInterestRatePerAnnum;
	
	@JSONField(name="TotalInterest")
	private String totalInterest;
	
	@JSONField(name="LifeInsurancePremium")
	private String lifeInsurancePremium;
	
	@JSONField(name="TotalLifeInsuranceCommission")
	private String totalLifeInsuranceCommission;
	
	@JSONField(name="MonthlyInstallmentAmount")
	private String monthlyInstallmentAmount;
	
	@JSONField(name="TotalNumberOfInstallment")
	private String totalNumberOfInstallment;
	
	@JSONField(name="NumberOfOrdinaryPaid")
	private String numberOfOrdinaryPaid;
	
	@JSONField(name="RepaymentMethod")
	private String repaymentMethod;
	
	@JSONField(name="MonthlyDueDay")
	private String monthlyDueDay;
	
	@JSONField(name="LastDueDate")
	private String lastDueDate;
	
	@JSONField(name="NextDueDate")
	private String nextDueDate;
	
	@JSONField(name="AutopayAccountNumber")
	private String autopayAccountNumber;
	
	@JSONField(name="AutopayAccountName")
	private String autopayAccountName;
	
	@JSONField(name="CreditCardNumber")
	private String creditCardNumber;
		
	@JSONField(name="CreditCardExpiryDate")
	private String creditCardExpiryDate;
	
	@JSONField(name="PartialPayment")
	private String partialPayment;
	
	@JSONField(name="PrePayment")
	private String prePayment;
	
	@JSONField(name="NumberOfInstallmentOverdue")
	private String numberOfInstallmentOverdue;
	
	@JSONField(name="OverdueAmount")
	private String overdueAmount;
	
	@JSONField(name="CsSourceCode")
	private String csSourceCode;
	
	@JSONField(name="CsApplication")
	private String csApplication;
	
	@JSONField(name="MemoLine1")
	private String memoLine1;
	
	@JSONField(name="MemoLine2")
	private String memoLine2;
	
	@JSONField(name="MemoLine3")
	private String memoLine3;
	
	@JSONField(name="MemoLine4")
	private String memoLine4;
	
	@JSONField(name="MonthlyIncome")
	private String monthlyIncome;
	
	@JSONField(name="InterestRebateCharge2")
	private String interestRebateCharge2;
	
	@JSONField(name="RebateProgramDescription2")
	private String rebateProgramDescription2;
	
	@JSONField(name="RebateDate2")
	private String rebateDate2;
	
	@JSONField(name="Filler1")
	private String filler1;
	
	@JSONField(name="ChinaLoanProjectCode")
	private String chinaLoanProjectCode;
	
	@JSONField(name="CurrentDepositCode")
	private String currentDepositCode;
	
	@JSONField(name="ExceptDepositCode")
	private String exceptDepositCode;
	
	@JSONField(name="NumberOfInstallmentExtended")
	private String numberOfInstallmentExtended;
	
	@JSONField(name="ExtensionDate")
	private String extensionDate;
	
	@JSONField(name="PrincipalAmount")
	private String principalAmount;
	
	@JSONField(name="InterestLifePremium")
	private String interestLifePremium;
	
	@JSONField(name="PersonalLoanAmount")
	private String personalLoanAmount;
	
	@JSONField(name="InstallmentPaid")
	private String installmentPaid;
	
	@JSONField(name="PlCharge")
	private String plCharge;
	
	@JSONField(name="OverdueCharge")
	private String overdueCharge;
	
	@JSONField(name="ExtensionCharge")
	private String extensionCharge;
	
	@JSONField(name="PenaltyCharge")
	private String penaltyCharge;
	
	@JSONField(name="TotalAmountPayable")
	private String totalAmountPayable;
	
	@JSONField(name="NumberOfInstallmentUnearned")
	private String numberOfInstallmentUnearned;
	
	@JSONField(name="OutstandingUnearnedInterest")
	private String outstandingUnearnedInterest;
	
	@JSONField(name="PreDiscountLoanAmount")
	private String preDiscountLoanAmount;
	
	@JSONField(name="GuarantorInformation")
	private List<GuarantorInformation> guarantorInformation;
	
	@JSONField(name="InterestRebateCharge1")
	private String interestRebateCharge1;
	
	@JSONField(name="RebateProgramDescription1")
	private String rebateProgramDescription1;
	
	@JSONField(name="RebateDate1")
	private String rebateDate1;
	
	@JSONField(name="AnnualizedPercentageRate")
	private String annualizedPercentageRate;
	
	@JSONField(name="TotalInterestRebateCharge")
	private String totalInterestRebateCharge;
	
	@JSONField(name="SpecialNetPrinciple")
	private String specialNetPrinciple;
	
	@JSONField(name="AccruedInterest")
	private String accruedInterest;
	
	@JSONField(name="LastInstallmentDate")
	private String lastInstallmentDate;
	
	@JSONField(name="RevLimit")
	private String revLimit;
	
	@JSONField(name="RevLimitExpiryDate")
	private String revLimitExpiryDate;
	
	@JSONField(name="MaxTenor")
	private String maxTenor;
	
	@JSONField(name="MaxInstAmt")
	private String maxInstAmt;
	
	@JSONField(name="AvailTopupAmt")
	private String availTopupAmt;
	
	@JSONField(name="LatePaymentFee")
	private String latePaymentFee;
	
	@JSONField(name="LoanSubType")
	private String loanSubType;
	
	@JSONField(name="TotalSettlementAmt")
	private String totalSettlementAmt;
	
	@JSONField(name="CashOutAmt")
	private String cashOutAmt;

	@Override
	public String toString() {
		return "NF1112RepData [accountNumber=" + accountNumber + ", dateOpened=" + dateOpened + ", dateClosed="
				+ dateClosed + ", drawDownDate=" + drawDownDate + ", loanType=" + loanType + ", emCardNumber="
				+ emCardNumber + ", status=" + status + ", currentRevolvingSequenceNumber="
				+ currentRevolvingSequenceNumber + ", holdCode=" + holdCode + ", loanAmount=" + loanAmount
				+ ", initialUnearnedInterest=" + initialUnearnedInterest + ", loanOutstanding=" + loanOutstanding
				+ ", calculationMethodCode=" + calculationMethodCode + ", interestRatePerAnnum=" + interestRatePerAnnum
				+ ", overdueInterestRatePerAnnum=" + overdueInterestRatePerAnnum + ", totalInterest=" + totalInterest
				+ ", lifeInsurancePremium=" + lifeInsurancePremium + ", totalLifeInsuranceCommission="
				+ totalLifeInsuranceCommission + ", monthlyInstallmentAmount=" + monthlyInstallmentAmount
				+ ", totalNumberOfInstallment=" + totalNumberOfInstallment + ", numberOfOrdinaryPaid="
				+ numberOfOrdinaryPaid + ", repaymentMethod=" + repaymentMethod + ", monthlyDueDay=" + monthlyDueDay
				+ ", lastDueDate=" + lastDueDate + ", nextDueDate=" + nextDueDate + ", autopayAccountNumber="
				+ autopayAccountNumber + ", autopayAccountName=" + autopayAccountName + ", creditCardNumber="
				+ creditCardNumber + ", creditCardExpiryDate=" + creditCardExpiryDate + ", partialPayment="
				+ partialPayment + ", prePayment=" + prePayment + ", numberOfInstallmentOverdue="
				+ numberOfInstallmentOverdue + ", overdueAmount=" + overdueAmount + ", csSourceCode=" + csSourceCode
				+ ", csApplication=" + csApplication + ", memoLine1=" + memoLine1 + ", memoLine2=" + memoLine2
				+ ", memoLine3=" + memoLine3 + ", memoLine4=" + memoLine4 + ", monthlyIncome=" + monthlyIncome
				+ ", interestRebateCharge2=" + interestRebateCharge2 + ", rebateProgramDescription2="
				+ rebateProgramDescription2 + ", rebateDate2=" + rebateDate2 + ", filler1=" + filler1
				+ ", chinaLoanProjectCode=" + chinaLoanProjectCode + ", currentDepositCode=" + currentDepositCode
				+ ", exceptDepositCode=" + exceptDepositCode + ", numberOfInstallmentExtended="
				+ numberOfInstallmentExtended + ", extensionDate=" + extensionDate + ", principalAmount="
				+ principalAmount + ", interestLifePremium=" + interestLifePremium + ", personalLoanAmount="
				+ personalLoanAmount + ", installmentPaid=" + installmentPaid + ", plCharge=" + plCharge
				+ ", overdueCharge=" + overdueCharge + ", extensionCharge=" + extensionCharge + ", penaltyCharge="
				+ penaltyCharge + ", totalAmountPayable=" + totalAmountPayable + ", numberOfInstallmentUnearned="
				+ numberOfInstallmentUnearned + ", outstandingUnearnedInterest=" + outstandingUnearnedInterest
				+ ", preDiscountLoanAmount=" + preDiscountLoanAmount + ", guarantorInformation=" + guarantorInformation
				+ ", interestRebateCharge1=" + interestRebateCharge1 + ", rebateProgramDescription1="
				+ rebateProgramDescription1 + ", rebateDate1=" + rebateDate1 + ", annualizedPercentageRate="
				+ annualizedPercentageRate + ", totalInterestRebateCharge=" + totalInterestRebateCharge
				+ ", specialNetPrinciple=" + specialNetPrinciple + ", accruedInterest=" + accruedInterest
				+ ", lastInstallmentDate=" + lastInstallmentDate + ", revLimit=" + revLimit + ", revLimitExpiryDate="
				+ revLimitExpiryDate + ", maxTenor=" + maxTenor + ", maxInstAmt=" + maxInstAmt + ", availTopupAmt="
				+ availTopupAmt + ", latePaymentFee=" + latePaymentFee + ", loanSubType=" + loanSubType
				+ ", totalSettlementAmt=" + totalSettlementAmt + ", cashOutAmt=" + cashOutAmt + "]";
	}
	
}
