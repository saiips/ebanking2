package com.dsb.eb2.backOffice.connect.emsMsg.nf2089;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;


@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"dateSigned","tIN","gIIN","exemptionCode"})
public class SelfDeclForm1Info {
	
	public SelfDeclForm1Info() {}
	
	
	@JSONField(name="DateSigned")
	private String dateSigned;
	
	@JSONField(name="TIN")
	private String tIN;
	
	@JSONField(name="GIIN")
	private String gIIN;
	
	@JSONField(name="ExemptionCode")
	private String exemptionCode;
	

	@XmlElement(name = "DateSigned")
	public String getDateSigned() {
		return dateSigned;
	}

	public void setDateSigned(String dateSigned) {
		this.dateSigned = dateSigned;
	}

	@XmlElement(name = "TIN")
	public String gettIN() {
		return tIN;
	}

	public void settIN(String tIN) {
		this.tIN = tIN;
	}

	@XmlElement(name = "GIIN")
	public String getgIIN() {
		return gIIN;
	}

	public void setgIIN(String gIIN) {
		this.gIIN = gIIN;
	}

	@XmlElement(name = "ExemptionCode")
	public String getExemptionCode() {
		return exemptionCode;
	}

	public void setExemptionCode(String exemptionCode) {
		this.exemptionCode = exemptionCode;
	}
	

	
}



