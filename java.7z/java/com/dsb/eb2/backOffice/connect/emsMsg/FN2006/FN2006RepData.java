package com.dsb.eb2.backOffice.connect.emsMsg.FN2006;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class FN2006RepData extends FrmData
{

	@JSONField(name="AcctNum")
    private String acctNum;
    
	@JSONField(name="HostTranSeqNum")
    private String hostTranSeqNum;
    
	@JSONField(name="AcctName")
    private String acctName;
    
	@JSONField(name="SignatureNum")
    private String signatureNum;

    @Override
    public String getServiceID()
    {
        return "FN2006";
    }
    
}
