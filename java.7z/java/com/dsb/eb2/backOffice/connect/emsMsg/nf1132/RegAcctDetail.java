package com.dsb.eb2.backOffice.connect.emsMsg.nf1132;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class RegAcctDetail
{
	public RegAcctDetail(){}
	
	@JSONField(name="Type")
	private String  type;
	
	@JSONField(name="RecPartyCode")
    private String  recPartyCode;
	
	@JSONField(name="RecPartyAcctNum")
	private String  recPartyAcctNum;
	
	@JSONField(name="PayRef") 
	private String  payRef;
	
	@JSONField(name="RecPartyName")
	private String  recPartyName;
	
	@JSONField(name="AcctName") 
	private String  acctName;
	
	@JSONField(name="ACNo") 
	private String  aCNo;
	
	@JSONField(name="BenAcctNum") 
	private String  benAcctNum;
	
	@JSONField(name="BenAcctNumBankType") 
	private String  benAcctNumBankType;
	
	@JSONField(name="BenName") 
	private String  benName;
	
	@JSONField(name="DailyLimit") 
	private String  dailyLimit;
	
	@JSONField(name="CreDate") 
	private String  creDate;
	
	@JSONField(name="UserId") 
	private String  userId;


}
