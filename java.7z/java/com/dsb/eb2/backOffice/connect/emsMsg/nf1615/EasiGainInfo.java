package com.dsb.eb2.backOffice.connect.emsMsg.nf1615;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"monthlyPaymentAccount","monthlyInterest","lastMonthInterest","previousPaidDate"})
public class EasiGainInfo {
	public EasiGainInfo() {}
	
	@JSONField(name="MonthlyPaymentAccount")
	private String monthlyPaymentAccount;
	
	@JSONField(name="MonthlyInterest")
	private String monthlyInterest;
	
	@JSONField(name="LastMonthInterest")
	private String lastMonthInterest;
	
	@JSONField(name="PreviousPaidDate")
	private String previousPaidDate;

    @XmlElement(name = "MonthlyPaymentAccount")
	public String getMonthlyPaymentAccount() {
		return monthlyPaymentAccount;
	}

	public void setMonthlyPaymentAccount(String monthlyPaymentAccount) {
		this.monthlyPaymentAccount = monthlyPaymentAccount;
	}

    @XmlElement(name = "MonthlyInterest")
	public String getMonthlyInterest() {
		return monthlyInterest;
	}

	public void setMonthlyInterest(String monthlyInterest) {
		this.monthlyInterest = monthlyInterest;
	}

    @XmlElement(name = "LastMonthInterest")
	public String getLastMonthInterest() {
		return lastMonthInterest;
	}

	public void setLastMonthInterest(String lastMonthInterest) {
		this.lastMonthInterest = lastMonthInterest;
	}

    @XmlElement(name = "PreviousPaidDate")
	public String getPreviousPaidDate() {
		return previousPaidDate;
	}

	public void setPreviousPaidDate(String previousPaidDate) {
		this.previousPaidDate = previousPaidDate;
	}
	
	

}
