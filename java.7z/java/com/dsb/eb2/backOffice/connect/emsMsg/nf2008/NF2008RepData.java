package com.dsb.eb2.backOffice.connect.emsMsg.nf2008;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;


@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"acctNum","hostTranSeqNum","masterSignatureNum"})
public class NF2008RepData  extends FrmData
{
    
	public NF2008RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF2008";
	}
	
	@JSONField(name="AcctNum")
	private String acctNum;
	
	@JSONField(name="HostTranSeqNum")
	private String hostTranSeqNum;
	
	@JSONField(name="MasterSignatureNum")
	private String masterSignatureNum;

	@XmlElement(name = "AcctNum")
	public String getAcctNum() {
		return acctNum;
	}

	public void setAcctNum(String acctNum) {
		this.acctNum = acctNum;
	}

	@XmlElement(name = "HostTranSeqNum")
	public String getHostTranSeqNum() {
		return hostTranSeqNum;
	}

	public void setHostTranSeqNum(String hostTranSeqNum) {
		this.hostTranSeqNum = hostTranSeqNum;
	}

	@XmlElement(name = "MasterSignatureNum")
	public String getMasterSignatureNum() {
		return masterSignatureNum;
	}

	public void setMasterSignatureNum(String masterSignatureNum) {
		this.masterSignatureNum = masterSignatureNum;
	}
	
	
	
	
	
}



