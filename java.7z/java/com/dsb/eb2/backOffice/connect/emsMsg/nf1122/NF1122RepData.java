package com.dsb.eb2.backOffice.connect.emsMsg.nf1122;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"searchStatus","teleUserID","createdDate","closedDate",
				"phoneIDType","status","acctOwnerCnt","opBranch","lastPinGenDate",
				"pinAckDate","lastPinChgDate","suspDate","actDate","dormDate","hotDate",
				"wrongPinCnt","lastWrongPinDate","lastTransDate","lastAmendDate","appFeeInd",
				"analFeeInd","dueDate","lastFeeCollDate","allowAcctRegFlag","allowFundTransferFlag","acctOwnerInfo"})
public class NF1122RepData extends FrmData{

	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1122";
	}
	
	@JSONField(name="SearchStatus")
	private String searchStatus;
	
	@JSONField(name="TeleUserID")
	private String teleUserID;
	
	@JSONField(name="CreatedDate")
	private String createdDate;
	
	@JSONField(name="ClosedDate")
	private String closedDate;
	
	@JSONField(name="PhoneIDType")
	private String phoneIDType;
	
	@JSONField(name="Status")
	private String status;
	
	@JSONField(name="AcctOwnerCnt")
	private String acctOwnerCnt;

	
	@JSONField(name="OpBranch")
	private String opBranch;
	
	@JSONField(name="LastPinGenDate")
	private String lastPinGenDate;
	
	@JSONField(name="PinAckDate")
	private String pinAckDate;
	
	@JSONField(name="LastPinChgDate")
	private String lastPinChgDate;
	
	@JSONField(name="SuspDate")
	private String suspDate;
	
	@JSONField(name="ActDate")
	private String actDate;
	
	@JSONField(name="DormDate")
	private String dormDate;
	
	@JSONField(name="HotDate")
	private String hotDate;
	
	@JSONField(name="WrongPinCnt")
	private String wrongPinCnt;
	
	@JSONField(name="LastWrongPinDate")
	private String lastWrongPinDate;
	
	@JSONField(name="LastTransDate")
	private String lastTransDate;
	
	@JSONField(name="LastAmendDate")
	private String lastAmendDate;
	
	@JSONField(name="AppFeeInd")
	private String appFeeInd;
	
	@JSONField(name="AnalFeeInd")
	private String analFeeInd;
	
	@JSONField(name="DueDate")
	private String dueDate;
	
	@JSONField(name="LastFeeCollDate")
	private String lastFeeCollDate;
	
	@JSONField(name="AllowAcctRegFlag")
	private String allowAcctRegFlag;
	
	@JSONField(name="AllowFundTransferFlag")
	private String allowFundTransferFlag;

	@JSONField(name="AcctOwnerInfo")
	private List <AcctOwnerInfo> acctOwnerInfo;

	@XmlElement(name="SearchStatus")
	public String getSearchStatus() {
		return searchStatus;
	}

	public void setSearchStatus(String searchStatus) {
		this.searchStatus = searchStatus;
	}

	@XmlElement(name="TeleUserID")
	public String getTeleUserID() {
		return teleUserID;
	}

	public void setTeleUserID(String teleUserID) {
		this.teleUserID = teleUserID;
	}

	@XmlElement(name="CreatedDate")
	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	@XmlElement(name="ClosedDate")
	public String getClosedDate() {
		return closedDate;
	}

	public void setClosedDate(String closedDate) {
		this.closedDate = closedDate;
	}

	@XmlElement(name="PhoneIDType")
	public String getPhoneIDType() {
		return phoneIDType;
	}

	public void setPhoneIDType(String phoneIDType) {
		this.phoneIDType = phoneIDType;
	}

	@XmlElement(name="Status")
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@XmlElement(name="AcctOwnerCnt")
	public String getAcctOwnerCnt() {
		return acctOwnerCnt;
	}

	public void setAcctOwnerCnt(String acctOwnerCnt) {
		this.acctOwnerCnt = acctOwnerCnt;
	}

	@XmlElement(name="OpBranch")
	public String getOpBranch() {
		return opBranch;
	}

	public void setOpBranch(String opBranch) {
		this.opBranch = opBranch;
	}

	@XmlElement(name="LastPinGenDate")
	public String getLastPinGenDate() {
		return lastPinGenDate;
	}

	public void setLastPinGenDate(String lastPinGenDate) {
		this.lastPinGenDate = lastPinGenDate;
	}

	@XmlElement(name="PinAckDate")
	public String getPinAckDate() {
		return pinAckDate;
	}

	public void setPinAckDate(String pinAckDate) {
		this.pinAckDate = pinAckDate;
	}

	@XmlElement(name="LastPinChgDate")
	public String getLastPinChgDate() {
		return lastPinChgDate;
	}

	public void setLastPinChgDate(String lastPinChgDate) {
		this.lastPinChgDate = lastPinChgDate;
	}

	@XmlElement(name="SuspDate")
	public String getSuspDate() {
		return suspDate;
	}

	public void setSuspDate(String suspDate) {
		this.suspDate = suspDate;
	}

	@XmlElement(name="ActDate")
	public String getActDate() {
		return actDate;
	}

	public void setActDate(String actDate) {
		this.actDate = actDate;
	}

	@XmlElement(name="DormDate")
	public String getDormDate() {
		return dormDate;
	}

	public void setDormDate(String dormDate) {
		this.dormDate = dormDate;
	}

	@XmlElement(name="HotDate")
	public String getHotDate() {
		return hotDate;
	}

	public void setHotDate(String hotDate) {
		this.hotDate = hotDate;
	}

	@XmlElement(name="WrongPinCnt")
	public String getWrongPinCnt() {
		return wrongPinCnt;
	}

	public void setWrongPinCnt(String wrongPinCnt) {
		this.wrongPinCnt = wrongPinCnt;
	}

	@XmlElement(name="LastWrongPinDate")
	public String getLastWrongPinDate() {
		return lastWrongPinDate;
	}

	public void setLastWrongPinDate(String lastWrongPinDate) {
		this.lastWrongPinDate = lastWrongPinDate;
	}

	@XmlElement(name="LastTransDate")
	public String getLastTransDate() {
		return lastTransDate;
	}

	public void setLastTransDate(String lastTransDate) {
		this.lastTransDate = lastTransDate;
	}

	@XmlElement(name="LastAmendDate")
	public String getLastAmendDate() {
		return lastAmendDate;
	}

	public void setLastAmendDate(String lastAmendDate) {
		this.lastAmendDate = lastAmendDate;
	}

	@XmlElement(name="AppFeeInd")
	public String getAppFeeInd() {
		return appFeeInd;
	}

	public void setAppFeeInd(String appFeeInd) {
		this.appFeeInd = appFeeInd;
	}

	@XmlElement(name="AnalFeeInd")
	public String getAnalFeeInd() {
		return analFeeInd;
	}

	public void setAnalFeeInd(String analFeeInd) {
		this.analFeeInd = analFeeInd;
	}

	@XmlElement(name="DueDate")
	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	@XmlElement(name="LastFeeCollDate")
	public String getLastFeeCollDate() {
		return lastFeeCollDate;
	}

	public void setLastFeeCollDate(String lastFeeCollDate) {
		this.lastFeeCollDate = lastFeeCollDate;
	}

	@XmlElement(name="AllowAcctRegFlag")
	public String getAllowAcctRegFlag() {
		return allowAcctRegFlag;
	}

	public void setAllowAcctRegFlag(String allowAcctRegFlag) {
		this.allowAcctRegFlag = allowAcctRegFlag;
	}

	@XmlElement(name="AllowFundTransferFlag")
	public String getAllowFundTransferFlag() {
		return allowFundTransferFlag;
	}

	public void setAllowFundTransferFlag(String allowFundTransferFlag) {
		this.allowFundTransferFlag = allowFundTransferFlag;
	}

	@XmlElement(name="AcctOwnerInfo")
	public List<AcctOwnerInfo> getAcctOwnerInfo() {
		return acctOwnerInfo;
	}

	public void setAcctOwnerInfo(List<AcctOwnerInfo> acctOwnerInfo) {
		this.acctOwnerInfo = acctOwnerInfo;
	}
	
}
