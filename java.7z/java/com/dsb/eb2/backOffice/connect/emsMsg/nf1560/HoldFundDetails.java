package com.dsb.eb2.backOffice.connect.emsMsg.nf1560;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"float1","float2","float3","float9"})
public class HoldFundDetails 
{
	public HoldFundDetails(){}
	
	private String float1 = "";
	
	private String float2 = "";
	
	private String float3 = "";
	
	private String float9 = "";
	
	@XmlElement(name = "Float1")	
	public String getFloat1() {
		return float1;
	}
	public void setFloat1(String float1) {
		this.float1 = float1;
	}
	
	@XmlElement(name = "Float2")	
	public String getFloat2() {
		return float2;
	}
	public void setFloat2(String float2) {
		this.float2 = float2;
	}
	@XmlElement(name = "Float3")		
	public String getFloat3() {
		return float3;
	}
	public void setFloat3(String float3) {
		this.float3 = float3;
	}
	@XmlElement(name = "Float9")	
	public String getFloat9() {
		return float9;
	}
	public void setFloat9(String float9) {
		this.float9 = float9;
	}
}
