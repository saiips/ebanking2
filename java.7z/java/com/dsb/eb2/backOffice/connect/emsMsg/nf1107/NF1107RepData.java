package com.dsb.eb2.backOffice.connect.emsMsg.nf1107;

import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class NF1107RepData  extends FrmData
{
    
	@Override
	public String toString() {
		return "NF1107RepData [numOfAccts=" + numOfAccts + ", acctDetails=" + acctDetails + "]";
	}

	public NF1107RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1107";
	}
	
	
	@JSONField(name="NumOfAccts") 
	private String numOfAccts;
	
	@JSONField(name="AcctDetails") 
	private List<AcctDetails> acctDetails = new ArrayList<AcctDetails>();
	
}

