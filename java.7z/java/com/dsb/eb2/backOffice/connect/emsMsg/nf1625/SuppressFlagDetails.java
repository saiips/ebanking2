package com.dsb.eb2.backOffice.connect.emsMsg.nf1625;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"type","productType","suppressFlag"})
public class SuppressFlagDetails {
	
	public SuppressFlagDetails() {}
	
	@JSONField(name="Type")
	private String type;
	
	@JSONField(name="ProductType")
	private String productType;
	
	@JSONField(name="SuppressFlag")
	private String suppressFlag;

    @XmlElement(name = "Type")
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

    @XmlElement(name = "ProductType")
	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

    @XmlElement(name = "SuppressFlag")
	public String getSuppressFlag() {
		return suppressFlag;
	}

	public void setSuppressFlag(String suppressFlag) {
		this.suppressFlag = suppressFlag;
	}
	
	

	
}

