package com.dsb.eb2.backOffice.connect.emsMsg.nf1108;

import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1107.AcctDetails;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class LowBalFeeWaiverDetails {
	
	@Override
	public String toString() {
		return "LowBalFeeWaiverDetails [code=" + code + ", createDate=" + createDate + ", expiryDate=" + expiryDate
				+ ", evidenceCode=" + evidenceCode + ", evidence=" + evidence + ", lastCreateDate=" + lastCreateDate
				+ "]";
	}

	public LowBalFeeWaiverDetails() {}
	
	@JSONField(name="Code")
	public String code;
	
	@JSONField(name="CreateDate")
	public String createDate;
	
	@JSONField(name="ExpiryDate")
	public String expiryDate;

	@JSONField(name="EvidenceCode")
	public String evidenceCode;

	@JSONField(name="Evidence")
	public String evidence;

	@JSONField(name="LastCreateDate")
	public String lastCreateDate;

}
