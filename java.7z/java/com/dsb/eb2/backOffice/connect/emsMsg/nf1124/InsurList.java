package com.dsb.eb2.backOffice.connect.emsMsg.nf1124;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"product","userCode","premium","status","cancelCode","lastPrem",
		"lastBill","effDate","lastClaim","cancelled","reinstated"})
public class InsurList {

	public InsurList() {}

	@JSONField(name = "Product")
	private String product;
	
	@JSONField(name = "UserCode")
	private String userCode;
	
	@JSONField(name = "Premium")
	private String premium;
	
	@JSONField(name = "Status")
	private String status;
	
	@JSONField(name = "CancelCode")
	private String cancelCode;
	
	@JSONField(name = "LastPrem")
	private String lastPrem;
	
	@JSONField(name = "LastBill")
	private String lastBill;
	
	@JSONField(name = "EffDate")
	private String effDate;
	
	@JSONField(name = "LastClaim")
	private String lastClaim;
	
	@JSONField(name = "Cancelled")
	private String cancelled;
	
	@JSONField(name = "Reinstated")
	private String reinstated;

	
	
	@XmlElement(name = "Product")
	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	@XmlElement(name = "UserCode")
	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	@XmlElement(name = "Premium")
	public String getPremium() {
		return premium;
	}

	public void setPremium(String premium) {
		this.premium = premium;
	}
	
	@XmlElement(name ="Status")
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@XmlElement(name = "CancelCode")
	public String getCancelCode() {
		return cancelCode;
	}

	public void setCancelCode(String cancelCode) {
		this.cancelCode = cancelCode;
	}

	@XmlElement(name = "LastPrem")
	public String getLastPrem() {
		return lastPrem;
	}

	public void setLastPrem(String lastPrem) {
		this.lastPrem = lastPrem;
	}

	@XmlElement(name = "LastBill")
	public String getLastBill() {
		return lastBill;
	}

	public void setLastBill(String lastBill) {
		this.lastBill = lastBill;
	}

	@XmlElement(name = "EffDate")
	public String getEffDate() {
		return effDate;
	}

	public void setEffDate(String effDate) {
		this.effDate = effDate;
	}

	@XmlElement(name = "LastClaim")
	public String getLastClaim() {
		return lastClaim;
	}

	public void setLastClaim(String lastClaim) {
		this.lastClaim = lastClaim;
	}

	@XmlElement(name = "Cancelled")
	public String getCancelled() {
		return cancelled;
	}

	public void setCancelled(String cancelled) {
		this.cancelled = cancelled;
	}

	@XmlElement(name = "Reinstated")
	public String getReinstated() {
		return reinstated;
	}

	public void setReinstated(String reinstated) {
		this.reinstated = reinstated;
	}

}