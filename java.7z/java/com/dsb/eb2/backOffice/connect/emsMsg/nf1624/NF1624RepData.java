package com.dsb.eb2.backOffice.connect.emsMsg.nf1624;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"lastKey","moreItemsInd","numOfItems","suppressFlagDetails"})
public class NF1624RepData  extends FrmData
{
    
	public NF1624RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1624";
	}
	
	@JSONField(name="LastKey")
	private String lastKey;
	
	@JSONField(name="MoreItemsInd")
	private String moreItemsInd;
	
	@JSONField(name="NumOfItems")
	private String numOfItems;
	
	@JSONField(name="SuppressFlagDetails")
	private List<SuppressFlagDetails> suppressFlagDetails;

    @XmlElement(name = "LastKey")
	public String getLastKey() {
		return lastKey;
	}

	public void setLastKey(String lastKey) {
		this.lastKey = lastKey;
	}

    @XmlElement(name = "MoreItemsInd")
	public String getMoreItemsInd() {
		return moreItemsInd;
	}

	public void setMoreItemsInd(String moreItemsInd) {
		this.moreItemsInd = moreItemsInd;
	}

    @XmlElement(name = "NumOfItems")
	public String getNumOfItems() {
		return numOfItems;
	}

	public void setNumOfItems(String numOfItems) {
		this.numOfItems = numOfItems;
	}

    @XmlElement(name = "SuppressFlagDetails")
	public List<SuppressFlagDetails> getSuppressFlagDetails() {
		return suppressFlagDetails;
	}

	public void setSuppressFlagDetails(List<SuppressFlagDetails> suppressFlagDetails) {
		this.suppressFlagDetails = suppressFlagDetails;
	}
	
	
	
	
}



