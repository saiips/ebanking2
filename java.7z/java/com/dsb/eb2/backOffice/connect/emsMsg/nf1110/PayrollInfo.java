package com.dsb.eb2.backOffice.connect.emsMsg.nf1110;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class PayrollInfo {
	
	public PayrollInfo() {
	}

	@JSONField(name="EnrolDate")
	private String enrolDate;
	
	@JSONField(name="CreditMethod")
	private String creditMethod;
	
	@JSONField(name="CreditAmt")
	private String creditAmt;
	
	@JSONField(name="EnrolBranch")
	private String enrolBranch;
	
	@JSONField(name="PayrollFlag")
	private String payrollFlag;
	
	@JSONField(name="PayrollFlagLastUpdateDate")
	private String payrollFlagLastUpdateDate;
	
	@JSONField(name="ClassCode")
	private String classCode;
	
	@JSONField(name="SourceID")
	private String sourceID;
	
	@JSONField(name="StaffID")
	private String staffID;
}
