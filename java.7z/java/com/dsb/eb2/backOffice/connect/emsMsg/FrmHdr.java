package com.dsb.eb2.backOffice.connect.emsMsg;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * EMS消息头
 * 
 * @author cxj
 * 
 */
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(name = "Header", propOrder = { "bankCode", "custNo", "custID",
    "channelID", "loginID", "branchID", "terminalID", "serviceID",
    "serviceVersion", "emsMsgID", "txDateTime", "agentID", "serviceCharge",
    "language", "autoResubmitFlag", "retriedCount", "returnCode", "remarks",
    "txRefNo", "messageSequence", "overrideLevel", "errorCorrectionFlag",
    "reservedbyHOST", "branchNumber", "staffInfoAccessAuthLevel", "detail",
    "cycleDate", "sysTraceNum", "retryProcessFlag", "deptCode", "emsSeqNo" })
public class FrmHdr
{
	@JSONField(name="BankCode")
    private String bankCode;

	@JSONField(name="CustNo")
    private String custNo;

	@JSONField(name="CustID")
    private String custID;

	@JSONField(name="ChannelID")
    private String channelID;

	@JSONField(name="LoginID")
    private String loginID;

	@JSONField(name="BranchID")
    private String branchID;

	@JSONField(name="TerminalID")
    private String terminalID;

	@JSONField(name="ServiceID")
    private String serviceID;

	@JSONField(name="CustNo")
    private String serviceVersion;

	@JSONField(name="EMSMsgID")
    private String emsMsgID;

	@JSONField(name="TxDateTime")
    private String txDateTime;

	@JSONField(name="AgentID")
    private String agentID;

	@JSONField(name="ServiceCharge")
    private String serviceCharge;

	@JSONField(name="Language")
    private String language;

	@JSONField(name="AutoResubmitFlag")
    private String autoResubmitFlag;

	@JSONField(name="RetriedCount")
    private String retriedCount;

	@JSONField(name="ReturnCode")
    private String returnCode;

	@JSONField(name="Remarks")
    private String remarks;

	@JSONField(name="TxRefNo")
    private String txRefNo;

	@JSONField(name="MessageSequence")
    private String messageSequence;

	@JSONField(name="OverrideLevel")
    private String overrideLevel;

	@JSONField(name="ErrorCorrectionFlag")
    private String errorCorrectionFlag;

	@JSONField(name="ReservedbyHOST")
    private String reservedbyHOST;

	@JSONField(name="BranchNumber")
    private String branchNumber;

	@JSONField(name="StaffInfoAccessAuthLevel")
    private String staffInfoAccessAuthLevel;

	@JSONField(name="Detail")
    private List<Detail> detail;

	@JSONField(name="CycleDate")
    private String cycleDate;

	@JSONField(name="SysTraceNum")
    private String sysTraceNum;

	@JSONField(name="RetryProcessFlag")
    private String retryProcessFlag;

	@JSONField(name="DeptCode")
    private String deptCode;

	@JSONField(name="EmsSeqNo")
    private String emsSeqNo;

    @XmlElement(name = "BankCode")
    public String getBankCode()
    {
        return bankCode;
    }

    public void setBankCode(String bankCode)
    {
        this.bankCode = bankCode;
    }

    @XmlElement(name = "CustNo")
    public String getCustNo()
    {
        return custNo;
    }

    public void setCustNo(String custNo)
    {
        this.custNo = custNo;
    }

    @XmlElement(name = "CustID")
    public String getCustID()
    {
        return custID;
    }

    public void setCustID(String custID)
    {
        this.custID = custID;
    }

    @XmlElement(name = "ChannelID")
    public String getChannelID()
    {
        return channelID;
    }

    public void setChannelID(String channelID)
    {
        this.channelID = channelID;
    }

    @XmlElement(name = "LoginID")
    public String getLoginID()
    {
        return loginID;
    }

    public void setLoginID(String loginID)
    {
        this.loginID = loginID;
    }

    @XmlElement(name = "BranchID")
    public String getBranchID()
    {
        return branchID;
    }

    public void setBranchID(String branchID)
    {
        this.branchID = branchID;
    }

    @XmlElement(name = "TerminalID")
    public String getTerminalID()
    {
        return terminalID;
    }

    public void setTerminalID(String terminalID)
    {
        this.terminalID = terminalID;
    }

    @XmlElement(name = "ServiceID")
    public String getServiceID()
    {
        return serviceID;
    }

    public void setServiceID(String serviceID)
    {
        this.serviceID = serviceID;
    }

    @XmlElement(name = "EMSMsgID")
    public String getEmsMsgID()
    {
        return emsMsgID;
    }

    public void setEmsMsgID(String emsMsgID)
    {
        this.emsMsgID = emsMsgID;
    }

    @XmlElement(name = "TxDateTime")
    public String getTxDateTime()
    {
        return txDateTime;
    }

    public void setTxDateTime(String txDateTime)
    {
        this.txDateTime = txDateTime;
    }

    @XmlElement(name = "AgentID")
    public String getAgentID()
    {
        return agentID;
    }

    public void setAgentID(String agentID)
    {
        this.agentID = agentID;
    }

    @XmlElement(name = "ServiceCharge")
    public String getServiceCharge()
    {
        return serviceCharge;
    }

    public void setServiceCharge(String serviceCharge)
    {
        this.serviceCharge = serviceCharge;
    }

    @XmlElement(name = "Language")
    public String getLanguage()
    {
        return language;
    }

    public void setLanguage(String language)
    {
        this.language = language;
    }

    @XmlElement(name = "AutoResubmitFlag")
    public String getAutoResubmitFlag()
    {
        return autoResubmitFlag;
    }

    public void setAutoResubmitFlag(String autoResubmitFlag)
    {
        this.autoResubmitFlag = autoResubmitFlag;
    }

    @XmlElement(name = "RetriedCount")
    public String getRetriedCount()
    {
        return retriedCount;
    }

    public void setRetriedCount(String retriedCount)
    {
        this.retriedCount = retriedCount;
    }

    @XmlElement(name = "ReturnCode")
    public String getReturnCode()
    {
        return returnCode;
    }

    public void setReturnCode(String returnCode)
    {
        this.returnCode = returnCode;
    }

    @XmlElement(name = "Remarks")
    public String getRemarks()
    {
        return remarks;
    }

    public void setRemarks(String remarks)
    {
        this.remarks = remarks;
    }

    @XmlElement(name = "ServiceVersion")
    public String getServiceVersion()
    {
        return serviceVersion;
    }

    public void setServiceVersion(String serviceVersion)
    {
        this.serviceVersion = serviceVersion;
    }

    @XmlElement(name = "TxRefNo")
    public String getTxRefNo()
    {
        return txRefNo;
    }

    public void setTxRefNo(String txRefNo)
    {
        this.txRefNo = txRefNo;
    }

    @XmlElement(name = "MessageSequence")
    public String getMessageSequence()
    {
        return messageSequence;
    }

    public void setMessageSequence(String messageSequence)
    {
        this.messageSequence = messageSequence;
    }

    @XmlElement(name = "OverrideLevel")
    public String getOverrideLevel()
    {
        return overrideLevel;
    }

    public void setOverrideLevel(String overrideLevel)
    {
        this.overrideLevel = overrideLevel;
    }

    @XmlElement(name = "ErrorCorrectionFlag")
    public String getErrorCorrectionFlag()
    {
        return errorCorrectionFlag;
    }

    public void setErrorCorrectionFlag(String errorCorrectionFlag)
    {
        this.errorCorrectionFlag = errorCorrectionFlag;
    }

    @XmlElement(name = "ReservedbyHOST")
    public String getReservedbyHOST()
    {
        return reservedbyHOST;
    }

    public void setReservedbyHOST(String reservedbyHOST)
    {
        this.reservedbyHOST = reservedbyHOST;
    }

    @XmlElement(name = "BranchNumber")
    public String getBranchNumber()
    {
        return branchNumber;
    }

    public void setBranchNumber(String branchNumber)
    {
        this.branchNumber = branchNumber;
    }

    @XmlElement(name = "StaffInfoAccessAuthLevel")
    public String getStaffInfoAccessAuthLevel()
    {
        return staffInfoAccessAuthLevel;
    }

    public void setStaffInfoAccessAuthLevel(String staffInfoAccessAuthLevel)
    {
        this.staffInfoAccessAuthLevel = staffInfoAccessAuthLevel;
    }

    @XmlElement(name = "Detail")
    public List<Detail> getDetail()
    {
        return detail;
    }

    public void setDetail(List<Detail> detail)
    {
        this.detail = detail;
    }

    @XmlElement(name = "CycleDate")
    public String getCycleDate()
    {
        return cycleDate;
    }

    public void setCycleDate(String cycleDate)
    {
        this.cycleDate = cycleDate;
    }

    @XmlElement(name = "SysTraceNum")
    public String getSysTraceNum()
    {
        return sysTraceNum;
    }

    public void setSysTraceNum(String sysTraceNum)
    {
        this.sysTraceNum = sysTraceNum;
    }

    @XmlElement(name = "RetryProcessFlag")
    public String getRetryProcessFlag()
    {
        return retryProcessFlag;
    }

    public void setRetryProcessFlag(String retryProcessFlag)
    {
        this.retryProcessFlag = retryProcessFlag;
    }

    @XmlElement(name = "DeptCode")
    public String getDeptCode()
    {
        return deptCode;
    }

    public void setDeptCode(String deptCode)
    {
        this.deptCode = deptCode;
    }

    @XmlElement(name = "EmsSeqNo")
    public String getEmsSeqNo()
    {
        return emsSeqNo;
    }

    public void setEmsSeqNo(String emsSeqNo)
    {
        this.emsSeqNo = emsSeqNo;
    }

}
