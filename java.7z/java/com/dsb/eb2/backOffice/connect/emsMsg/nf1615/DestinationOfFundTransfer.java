package com.dsb.eb2.backOffice.connect.emsMsg.nf1615;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"creditAccountNumber","creditCurrency","creditAmount","creditExchangeRate","creditFXDealNumber","creditHKDEquivalent","withdrawalAmount","withdrawalExchangeRate","withdrawalFXDealNumber","crossExchangeRate"})
public class DestinationOfFundTransfer {

	public DestinationOfFundTransfer() {}

	@JSONField(name="CreditAccountNumber")
	private String creditAccountNumber;
	
	@JSONField(name="CreditCurrency")
	private String creditCurrency;
	
	@JSONField(name="CreditAmount")
	private String creditAmount;
	
	@JSONField(name="CreditExchangeRate")
	private String creditExchangeRate;
	
	@JSONField(name="CreditFXDealNumber")
	private String creditFXDealNumber;
	
	@JSONField(name="CreditHKDEquivalent")
	private String creditHKDEquivalent;
	
	@JSONField(name="WithdrawalAmount")
	private String withdrawalAmount;
	
	@JSONField(name="WithdrawalExchangeRate")
	private String withdrawalExchangeRate;
	
	@JSONField(name="WithdrawalFXDealNumber")
	private String withdrawalFXDealNumber;
	
	@JSONField(name="CrossExchangeRate")
	private String crossExchangeRate;

    @XmlElement(name = "CreditAccountNumber")
	public String getCreditAccountNumber() {
		return creditAccountNumber;
	}

	public void setCreditAccountNumber(String creditAccountNumber) {
		this.creditAccountNumber = creditAccountNumber;
	}

    @XmlElement(name = "CreditCurrency")
	public String getCreditCurrency() {
		return creditCurrency;
	}

	public void setCreditCurrency(String creditCurrency) {
		this.creditCurrency = creditCurrency;
	}

    @XmlElement(name = "CreditAmount")
	public String getCreditAmount() {
		return creditAmount;
	}

	public void setCreditAmount(String creditAmount) {
		this.creditAmount = creditAmount;
	}

    @XmlElement(name = "CreditExchangeRate")
	public String getCreditExchangeRate() {
		return creditExchangeRate;
	}

	public void setCreditExchangeRate(String creditExchangeRate) {
		this.creditExchangeRate = creditExchangeRate;
	}

    @XmlElement(name = "CreditFXDealNumber")
	public String getCreditFXDealNumber() {
		return creditFXDealNumber;
	}

	public void setCreditFXDealNumber(String creditFXDealNumber) {
		this.creditFXDealNumber = creditFXDealNumber;
	}

    @XmlElement(name = "CreditHKDEquivalent")
	public String getCreditHKDEquivalent() {
		return creditHKDEquivalent;
	}

	public void setCreditHKDEquivalent(String creditHKDEquivalent) {
		this.creditHKDEquivalent = creditHKDEquivalent;
	}

    @XmlElement(name = "WithdrawalAmount")
	public String getWithdrawalAmount() {
		return withdrawalAmount;
	}

	public void setWithdrawalAmount(String withdrawalAmount) {
		this.withdrawalAmount = withdrawalAmount;
	}

    @XmlElement(name = "WithdrawalExchangeRate")
	public String getWithdrawalExchangeRate() {
		return withdrawalExchangeRate;
	}

	public void setWithdrawalExchangeRate(String withdrawalExchangeRate) {
		this.withdrawalExchangeRate = withdrawalExchangeRate;
	}

    @XmlElement(name = "WithdrawalFXDealNumber")
	public String getWithdrawalFXDealNumber() {
		return withdrawalFXDealNumber;
	}

	public void setWithdrawalFXDealNumber(String withdrawalFXDealNumber) {
		this.withdrawalFXDealNumber = withdrawalFXDealNumber;
	}

    @XmlElement(name = "CrossExchangeRate")
	public String getCrossExchangeRate() {
		return crossExchangeRate;
	}

	public void setCrossExchangeRate(String crossExchangeRate) {
		this.crossExchangeRate = crossExchangeRate;
	}
	
	
	
	

	
}
