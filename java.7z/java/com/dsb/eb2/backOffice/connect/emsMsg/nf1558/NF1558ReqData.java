package com.dsb.eb2.backOffice.connect.emsMsg.nf1558;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"accountNumber","accountType","cCY","floatAmt","floatCode","reason","usrEntityCode","filler1"})
public class NF1558ReqData  extends FrmData
{
    
	public NF1558ReqData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1558";
	}
	
	@JSONField(name="AccountNumber")
	private String accountNumber;
	
	@JSONField(name="AccountType") 
	private String accountType;
	
	@JSONField(name="CCY") 
	private String cCY;
	
	@JSONField(name="FloatAmt") 
	private String floatAmt;
	
	@JSONField(name="FloatCode") 
	private String floatCode;
	
	@JSONField(name="Reason") 
	private String reason;
	
	@JSONField(name="UsrEntityCode") 
	private String usrEntityCode;
	
	@JSONField(name="Filler1") 
	private String filler1;

    @XmlElement(name = "AccountNumber")
	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

    @XmlElement(name = "AccountType")
	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

    @XmlElement(name = "CCY")
	public String getcCY() {
		return cCY;
	}

	public void setcCY(String cCY) {
		this.cCY = cCY;
	}

    @XmlElement(name = "FloatAmt")
	public String getFloatAmt() {
		return floatAmt;
	}

	public void setFloatAmt(String floatAmt) {
		this.floatAmt = floatAmt;
	}

    @XmlElement(name = "FloatCode")
	public String getFloatCode() {
		return floatCode;
	}

	public void setFloatCode(String floatCode) {
		this.floatCode = floatCode;
	}

    @XmlElement(name = "Reason")
	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

    @XmlElement(name = "UsrEntityCode")
	public String getUsrEntityCode() {
		return usrEntityCode;
	}

	public void setUsrEntityCode(String usrEntityCode) {
		this.usrEntityCode = usrEntityCode;
	}

    @XmlElement(name = "Filler1")
	public String getFiller1() {
		return filler1;
	}

	public void setFiller1(String filler1) {
		this.filler1 = filler1;
	}
	
}


