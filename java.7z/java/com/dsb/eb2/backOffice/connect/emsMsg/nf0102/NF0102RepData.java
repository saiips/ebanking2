package com.dsb.eb2.backOffice.connect.emsMsg.nf0102;

import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class NF0102RepData  extends FrmData
{
    
	public NF0102RepData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF0102";
	}
	
	@JSONField(name="NoOfRows")
	private String noOfRows;
	
	@JSONField(name="DpRateDetails")
	private List<DpRateDetails> dpRateDetails;
}
