package com.dsb.eb2.backOffice.connect.emsMsg.nf1527;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"addrCode","pdtType","acctNum"})
public class  NF1527ReqData extends FrmData
{
    
	public NF1527ReqData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1527";
	}
	 
	@JSONField(name="AddrCode")
	private String addrCode;
	
	@JSONField(name="PdtType")
	private String pdtType;
	
	@JSONField(name="AcctNum")
	private String acctNum;

	@XmlElement(name = "AddrCode")
	public String getAddrCode() {
		return addrCode;
	}

	public void setAddrCode(String addrCode) {
		this.addrCode = addrCode;
	}

	@XmlElement(name = "PdtType")
	public String getPdtType() {
		return pdtType;
	}

	public void setPdtType(String pdtType) {
		this.pdtType = pdtType;
	}

	@XmlElement(name = "AcctNum")
	public String getAcctNum() {
		return acctNum;
	}

	public void setAcctNum(String acctNum) {
		this.acctNum = acctNum;
	}



	
}