package com.dsb.eb2.backOffice.connect.emsMsg.nf0102;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class DpRateDetails {

	public DpRateDetails() {}
	
	
	@JSONField(name="Ccy")
	private String ccy;
	
	@JSONField(name="Call")
	private String call;
	
	@JSONField(name="SevenDays")
	private String sevenDays;
	
	@JSONField(name="FourteenDays")
	private String fourteenDays;
	
	@JSONField(name="OneMonths")
	private String oneMonths;
	
	@JSONField(name="TwoMonths")
	private String twoMonths;
	
	@JSONField(name="ThreeMonths")
	private String threeMonths;
	
	@JSONField(name="SixMonths")
	private String sixMonths;
	
	@JSONField(name="NineMonths")
	private String nineMonths;
	
	@JSONField(name="TwelveMonths")
	private String twelveMonths;

	
}
