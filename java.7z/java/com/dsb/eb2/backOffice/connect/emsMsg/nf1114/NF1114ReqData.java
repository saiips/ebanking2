package com.dsb.eb2.backOffice.connect.emsMsg.nf1114;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class NF1114ReqData  extends FrmData
{
    
	public NF1114ReqData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1114";
	}
	
	@JSONField(name="CreditCardAccountNbr")
	private String creditCardAccountNbr;
	
	@JSONField(name="CardLinkCustOrgNbr")
	private String cardLinkCustOrgNbr;
	
	@JSONField(name="CreditCardCustNbr")
	private String creditCardCustNbr;

}
