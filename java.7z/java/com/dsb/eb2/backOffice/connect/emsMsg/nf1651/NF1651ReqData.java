package com.dsb.eb2.backOffice.connect.emsMsg.nf1651;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"cardHolderNum","custIdNum","dateOfBirth","reqType","reqField","phoneNum","lastCVX"})
public class NF1651ReqData  extends FrmData
{
    
	public NF1651ReqData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1651";
	}
	
	
	@JSONField(name="CardHolderNum")
	private String cardHolderNum;
	
	@JSONField(name="CustIdNum")
	private String custIdNum;
	
	@JSONField(name="DateOfBirth")
	private String dateOfBirth;
	
	@JSONField(name="ReqType")
	private String reqType;
	
	@JSONField(name="ReqField")
	private String reqField;
	
	@JSONField(name="PhoneNum")
	private String phoneNum;
	
	@JSONField(name="LastCVX")
	private String lastCVX;

    @XmlElement(name = "CardHolderNum")
	public String getCardHolderNum() {
		return cardHolderNum;
	}

	public void setCardHolderNum(String cardHolderNum) {
		this.cardHolderNum = cardHolderNum;
	}

    @XmlElement(name = "CustIdNum")
	public String getCustIdNum() {
		return custIdNum;
	}

	public void setCustIdNum(String custIdNum) {
		this.custIdNum = custIdNum;
	}

    @XmlElement(name = "DateOfBirth")
	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

    @XmlElement(name = "ReqType")
	public String getReqType() {
		return reqType;
	}

	public void setReqType(String reqType) {
		this.reqType = reqType;
	}

    @XmlElement(name = "ReqField")
	public String getReqField() {
		return reqField;
	}

	public void setReqField(String reqField) {
		this.reqField = reqField;
	}

    @XmlElement(name = "PhoneNum")
	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

    @XmlElement(name = "LastCVX")
	public String getLastCVX() {
		return lastCVX;
	}

	public void setLastCVX(String lastCVX) {
		this.lastCVX = lastCVX;
	}
	
	
	
}
