package com.dsb.eb2.backOffice.connect.emsMsg.nf1652;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"transDate","postingDate","transDesc","transCcy","transAmt","hKDEq","exRate"})
public class TransDetails {

	public TransDetails() {}
	
	
	@JSONField(name="TransDate")
	private String transDate;
	
	@JSONField(name="PostingDate")
	private String postingDate;
	
	@JSONField(name="TransDesc")
	private String transDesc;
	
	@JSONField(name="TransCcy")
	private String transCcy;
	
	@JSONField(name="TransAmt")
	private String transAmt;
	
	@JSONField(name="HKDEq")
	private String hKDEq;
	
	@JSONField(name="ExRate")
	private String exRate;

    @XmlElement(name = "TransDate")
	public String getTransDate() {
		return transDate;
	}

	public void setTransDate(String transDate) {
		this.transDate = transDate;
	}

    @XmlElement(name = "PostingDate")
	public String getPostingDate() {
		return postingDate;
	}

	public void setPostingDate(String postingDate) {
		this.postingDate = postingDate;
	}

    @XmlElement(name = "TransDesc")
	public String getTransDesc() {
		return transDesc;
	}

	public void setTransDesc(String transDesc) {
		this.transDesc = transDesc;
	}

    @XmlElement(name = "TransCcy")
	public String getTransCcy() {
		return transCcy;
	}

	public void setTransCcy(String transCcy) {
		this.transCcy = transCcy;
	}

    @XmlElement(name = "TransAmt")
	public String getTransAmt() {
		return transAmt;
	}

	public void setTransAmt(String transAmt) {
		this.transAmt = transAmt;
	}

    @XmlElement(name = "HKDEq")
	public String gethKDEq() {
		return hKDEq;
	}

	public void sethKDEq(String hKDEq) {
		this.hKDEq = hKDEq;
	}

    @XmlElement(name = "ExRate")
	public String getExRate() {
		return exRate;
	}

	public void setExRate(String exRate) {
		this.exRate = exRate;
	}
	
	

	
}

