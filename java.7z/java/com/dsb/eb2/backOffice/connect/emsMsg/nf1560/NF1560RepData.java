package com.dsb.eb2.backOffice.connect.emsMsg.nf1560;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"numOfAccts","acctDetails","fdInformaiton","filler1"})
public class NF1560RepData extends FrmData 
{

	public NF1560RepData(){}
	
	@Override
	public String getServiceID() {
		// TODO Auto-generated method stub
		return "NF1560";
	}

	private String numOfAccts = "";
	
	private List<AcctDetails> acctDetails;


	private List<FDInformaiton> fdInformaiton;

	private String filler1 = "";

	@XmlElement(name = "NumOfAccts")
	public String getNumOfAccts() {
		return numOfAccts;
	}

	public void setNumOfAccts(String numOfAccts) {
		this.numOfAccts = numOfAccts;
	}

	@XmlElement(name = "AcctDetails")
	public List<AcctDetails> getAcctDetails() {
		return acctDetails;
	}

	public void setAcctDetails(List<AcctDetails> acctDetails) {
		this.acctDetails = acctDetails;
	}

	@XmlElement(name = "FDInformaiton")
	public List<FDInformaiton> getFdInformaiton() {
		return fdInformaiton;
	}

	public void setFdInformaiton(List<FDInformaiton> fdInformaiton) {
		this.fdInformaiton = fdInformaiton;
	}

	@XmlElement(name = "Filler1")
	public String getFiller1() {
		return filler1;
	}

	public void setFiller1(String filler1) {
		this.filler1 = filler1;
	}

}
