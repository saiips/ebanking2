package com.dsb.eb2.backOffice.connect.emsMsg.nf1551;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"orderType","orderCurrency","presetExchangeRate","prevailingExchangeRate","transactionCurrency","transactionAmount","debitAccountNumber","debitCurrencyCode","DebitAmount","CreditAccountNumber","CreditCurrencyCode","CreditAmount","expiryDate"})
public class NF1551RepData extends FrmData{
	
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF1551";
	}
	
	
	public NF1551RepData() {}


	@JSONField(name="OrderType")
	private String orderType;
	
	@JSONField(name="OrderCurrency")
	private String orderCurrency;
	
	@JSONField(name="PresetExchangeRate")
	private String presetExchangeRate;
	
	@JSONField(name="PrevailingExchangeRate")
	private String prevailingExchangeRate;
	
	@JSONField(name="TransactionCurrency")
	private String transactionCurrency;
	
	@JSONField(name="TransactionAmount")
	private String transactionAmount;
	
	@JSONField(name="DebitAccountNumber")
	private String debitAccountNumber;
	
	@JSONField(name="DebitCurrencyCode")
	private String debitCurrencyCode;
	
	@JSONField(name="")
	private String DebitAmount;
	
	@JSONField(name="")
	private String CreditAccountNumber;
	
	@JSONField(name="")
	private String CreditCurrencyCode;
	
	@JSONField(name="")
	private String CreditAmount;
	
	@JSONField(name="ExpiryDate")
	private String expiryDate;

    @XmlElement(name = "OrderType")
	public String getOrderType() {
		return orderType;
	}


	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}


    @XmlElement(name = "OrderCurrency")
	public String getOrderCurrency() {
		return orderCurrency;
	}


	public void setOrderCurrency(String orderCurrency) {
		this.orderCurrency = orderCurrency;
	}


    @XmlElement(name = "PresetExchangeRate")
	public String getPresetExchangeRate() {
		return presetExchangeRate;
	}


	public void setPresetExchangeRate(String presetExchangeRate) {
		this.presetExchangeRate = presetExchangeRate;
	}


    @XmlElement(name = "PrevailingExchangeRate")
	public String getPrevailingExchangeRate() {
		return prevailingExchangeRate;
	}


	public void setPrevailingExchangeRate(String prevailingExchangeRate) {
		this.prevailingExchangeRate = prevailingExchangeRate;
	}


    @XmlElement(name = "TransactionCurrency")
	public String getTransactionCurrency() {
		return transactionCurrency;
	}


	public void setTransactionCurrency(String transactionCurrency) {
		this.transactionCurrency = transactionCurrency;
	}


    @XmlElement(name = "TransactionAmount")
	public String getTransactionAmount() {
		return transactionAmount;
	}


	public void setTransactionAmount(String transactionAmount) {
		this.transactionAmount = transactionAmount;
	}


    @XmlElement(name = "DebitAccountNumber")
	public String getDebitAccountNumber() {
		return debitAccountNumber;
	}


	public void setDebitAccountNumber(String debitAccountNumber) {
		this.debitAccountNumber = debitAccountNumber;
	}


    @XmlElement(name = "DebitCurrencyCode")
	public String getDebitCurrencyCode() {
		return debitCurrencyCode;
	}


	public void setDebitCurrencyCode(String debitCurrencyCode) {
		this.debitCurrencyCode = debitCurrencyCode;
	}


    @XmlElement(name = "DebitAmount")
	public String getDebitAmount() {
		return DebitAmount;
	}


	public void setDebitAmount(String debitAmount) {
		DebitAmount = debitAmount;
	}


    @XmlElement(name = "CreditAccountNumber")
	public String getCreditAccountNumber() {
		return CreditAccountNumber;
	}


	public void setCreditAccountNumber(String creditAccountNumber) {
		CreditAccountNumber = creditAccountNumber;
	}


    @XmlElement(name = "CreditCurrencyCode")
	public String getCreditCurrencyCode() {
		return CreditCurrencyCode;
	}


	public void setCreditCurrencyCode(String creditCurrencyCode) {
		CreditCurrencyCode = creditCurrencyCode;
	}


    @XmlElement(name = "CreditAmount")
	public String getCreditAmount() {
		return CreditAmount;
	}


	public void setCreditAmount(String creditAmount) {
		CreditAmount = creditAmount;
	}


    @XmlElement(name = "ExpiryDate")
	public String getExpiryDate() {
		return expiryDate;
	}


	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	

}
