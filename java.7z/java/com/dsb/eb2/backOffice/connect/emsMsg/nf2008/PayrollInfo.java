package com.dsb.eb2.backOffice.connect.emsMsg.nf2008;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
@XmlType(propOrder = {"enrolDate","creditMethod","creditAmt","enrolBranch","classCode","beforeDiscountedPayrollCreditAmt","staffID"})
public class PayrollInfo {

	public PayrollInfo() {}
	
	
	@JSONField(name="EnrolDate")
	private String enrolDate;
	
	@JSONField(name="CreditMethod")
	private String creditMethod;
	
	@JSONField(name="CreditAmt")
	private String creditAmt;
	
	@JSONField(name="EnrolBranch")
	private String enrolBranch;
	
	@JSONField(name="ClassCode")
	private String classCode;
	
	@JSONField(name="BeforeDiscountedPayrollCreditAmt")
	private String beforeDiscountedPayrollCreditAmt;
	
	@JSONField(name="StaffID")
	private String staffID;

	@XmlElement(name = "EnrolDate")
	public String getEnrolDate() {
		return enrolDate;
	}

	public void setEnrolDate(String enrolDate) {
		this.enrolDate = enrolDate;
	}

	@XmlElement(name = "CreditMethod")
	public String getCreditMethod() {
		return creditMethod;
	}

	public void setCreditMethod(String creditMethod) {
		this.creditMethod = creditMethod;
	}

	@XmlElement(name = "CreditAmt")
	public String getCreditAmt() {
		return creditAmt;
	}

	public void setCreditAmt(String creditAmt) {
		this.creditAmt = creditAmt;
	}

	@XmlElement(name = "EnrolBranch")
	public String getEnrolBranch() {
		return enrolBranch;
	}

	public void setEnrolBranch(String enrolBranch) {
		this.enrolBranch = enrolBranch;
	}

	@XmlElement(name = "ClassCode")
	public String getClassCode() {
		return classCode;
	}

	public void setClassCode(String classCode) {
		this.classCode = classCode;
	}

	@XmlElement(name = "BeforeDiscountedPayrollCreditAmt")
	public String getBeforeDiscountedPayrollCreditAmt() {
		return beforeDiscountedPayrollCreditAmt;
	}

	public void setBeforeDiscountedPayrollCreditAmt(String beforeDiscountedPayrollCreditAmt) {
		this.beforeDiscountedPayrollCreditAmt = beforeDiscountedPayrollCreditAmt;
	}

	@XmlElement(name = "StaffID")
	public String getStaffID() {
		return staffID;
	}

	public void setStaffID(String staffID) {
		this.staffID = staffID;
	}

	
}


