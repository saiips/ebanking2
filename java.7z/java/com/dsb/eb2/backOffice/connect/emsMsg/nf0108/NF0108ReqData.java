package com.dsb.eb2.backOffice.connect.emsMsg.nf0108;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class NF0108ReqData  extends FrmData
{
    
	public NF0108ReqData(){}
	
	@JSONField(serialize=false)
	@Override
	public String getServiceID() {
		return "NF0108";
	}
	
	@JSONField(name="AccountNumber")
	private String accountNumber;
	
	@JSONField(name="CloseCurrency") 
	private String closeCurrency;

}



