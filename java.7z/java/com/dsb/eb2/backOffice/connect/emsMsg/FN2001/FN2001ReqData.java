package com.dsb.eb2.backOffice.connect.emsMsg.FN2001;

import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;
import com.dsb.eb2.backOffice.connect.emsMsg.fn0006.SpotPositData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class FN2001ReqData extends FrmData
{
	@JSONField(name="AcctNum")
    private String acctNum;
    
	
	@JSONField(name="AcctType")
    private String acctType;
    
	
	@JSONField(name="WithdrawalType")
    private String withdrawalType;
    
	
	@JSONField(name="BalanceOrPassbookBalance")
    private String balanceOrPassbookBalance;
    
	
	@JSONField(name="TxCcy")
    private String txCcy;
    
	
	@JSONField(name="TxAmt")
    private String txAmt;
    
	
	@JSONField(name="AcctCcy")
    private String acctCcy ;
    
	
	@JSONField(name="AcctCcyAmt")
    private String acctCcyAmt;
    
	@JSONField(name="ExInd")
    private String exInd;
    
	@JSONField(name="BuyExRate")
    private String buyExRate ;
    
	@JSONField(name="SellExRate")
    private String sellExRate;
    
	@JSONField(name="CrossExRate")
    private String crossExRate ;
    
	@JSONField(name="HKDEquivalent")
    private String hKDEquivalent ;
    
	@JSONField(name="PassbookLineNum")
    private String passbookLineNum ;
    
	@JSONField(name="PassbookPageNum")
    private String passbookPageNum ;
    
	@JSONField(name="ChequeNum")
    private String chequeNum;
    
	@JSONField(name="Narrative")
    private String narrative ;
    
	@JSONField(name="AsOfDate")
    private String asOfDate ;
    
	@JSONField(name="BuyDealNum")
    private String buyDealNum ;
    
	@JSONField(name="SellDealNum")
    private String sellDealnum;
    
	@JSONField(name="SpotDealCreator")
    private String spotDealCreator;
    
	@JSONField(name="SpotDealRefSuffix")
    private String spotDealRefSuffix;
    
    private List<SpotPositionBookingData> spotPositionBookingData = new ArrayList<SpotPositionBookingData>();
    @Override
    public String getServiceID()
    {
        return "FN2001";
    }

}
