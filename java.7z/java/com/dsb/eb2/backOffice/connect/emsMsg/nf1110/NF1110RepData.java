package com.dsb.eb2.backOffice.connect.emsMsg.nf1110;

import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmData;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class NF1110RepData extends FrmData {
	@JSONField(serialize = false)
	@Override
	public String getServiceID() {
		return "NF1110";
	}

	public NF1110RepData() {
	}

	@JSONField(name = "AccountNumber")
	private String accountNumber;

	@JSONField(name = "DateOpened")
	private String dateOpened;

	@JSONField(name = "DateClosed")
	private String dateClosed;

	@JSONField(name = "LastTxDate")
	private String lastTxDate;

	@JSONField(name = "Filler1")
	private String filler1;

	@JSONField(name = "PenaltyInterestRate")
	private String penaltyInterestRate;

	@JSONField(name = "ChequeAccountIndicator")
	private String chequeAccountIndicator;

	@JSONField(name = "HoldCode1")
	private String holdCode1;

	@JSONField(name = "HoldCode2")
	private String holdCode2;

	@JSONField(name = "HoldCode3")
	private String holdCode3;

	@JSONField(name = "HoldCode4")
	private String holdCode4;

	@JSONField(name = "StatusCode")
	private String statusCode;

	@JSONField(name = "AccountOwnerCnt")
	private String accountOwnerCnt;

	@JSONField(name = "AccountOwnerInfo")
	private List<AccountOwnerInfo> accountOwnerInfo = new ArrayList<AccountOwnerInfo>();

	@JSONField(name = "CCY")
	private String cCY;

	@JSONField(name = "CurrentBalance")
	private String currentBalance;

	@JSONField(name = "AvailableBalance")
	private String availableBalance;

	@JSONField(name = "DebitAccruedInterest")
	private String debitAccruedInterest;

	@JSONField(name = "CreditAccruedInterest")
	private String creditAccruedInterest;

	@JSONField(name = "Float1")
	private String float1;

	@JSONField(name = "Float2")
	private String float2;

	@JSONField(name = "Float3")
	private String float3;

	@JSONField(name = "Float9")
	private String float9;

	@JSONField(name = "StatementDay")
	private String statementDay;

	@JSONField(name = "AverageBalance2WorkDaysBefore")
	private String averageBalance2WorkDaysBefore;

	@JSONField(name = "SecuredCode")
	private String securedCode;

	@JSONField(name = "UpperLimit")
	private String upperLimit;

	@JSONField(name = "UpperInterestRate")
	private String upperInterestRate;

	@JSONField(name = "UpperRateCode")
	private String upperRateCode;

	@JSONField(name = "LowerLimit")
	private String lowerLimit;

	@JSONField(name = "LowerInterestRate")
	private String lowerInterestRate;

	@JSONField(name = "LowerRateCode")
	private String lowerRateCode;

	@JSONField(name = "MinimumPayment")
	private String minimumPayment;

	@JSONField(name = "MinimumPaymentDate")
	private String minimumPaymentDate;

	@JSONField(name = "DaysPastDue")
	private String daysPastDue;

	@JSONField(name = "AbsoluteUpperRate")
	private String absoluteUpperRate;

	@JSONField(name = "RenewalCode")
	private String renewalCode;

	@JSONField(name = "AccountCode")
	private String accountCode;

	@JSONField(name = "AbsoluteLowerRate")
	private String absoluteLowerRate;

	@JSONField(name = "ExpiryDate")
	private String expiryDate;

	@JSONField(name = "CharacterType")
	private String characterType;

	@JSONField(name = "SourceCode")
	private String sourceCode;

	@JSONField(name = "OverlineCode")
	private String overlineCode;

	@JSONField(name = "UpperInterestRateSpread")
	private String upperInterestRateSpread;

	@JSONField(name = "LowerInterestRateSpread")
	private String lowerInterestRateSpread;

	@JSONField(name = "LowerExpiryDate")
	private String lowerExpiryDate;

	@JSONField(name = "CreditInterestLimit")
	private String creditInterestLimit;

	@JSONField(name = "CreditInterestRateCode")
	private String creditInterestRateCode;

	@JSONField(name = "CreditInterestRate")
	private String creditInterestRate;

	@JSONField(name = "CreditInterestExpiryDate")
	private String creditInterestExpiryDate;

	@JSONField(name = "AccountName")
	private String accountName;

	@JSONField(name = "StatementName1")
	private String statementName1;

	@JSONField(name = "StatementName2")
	private String statementName2;

	@JSONField(name = "TrustClientInd")
	private String trustClientInd;

	@JSONField(name = "AccountIndicator")
	private String accountIndicator;

	@JSONField(name = "AddressCode")
	private String addressCode;

	@JSONField(name = "ListDailyFlag")
	private String listDailyFlag;

	@JSONField(name = "WaiveODInterestInd")
	private String waiveODInterestInd;

	@JSONField(name = "WaiveUnauthorizedODChargeInd")
	private String waiveUnauthorizedODChargeInd;

	@JSONField(name = "WaiveDormantChargeInd")
	private String waiveDormantChargeInd;

	@JSONField(name = "InterestRateSpread")
	private String interestRateSpread;

	@JSONField(name = "OfficerCode")
	private String officerCode;

	@JSONField(name = "SignatureNo")
	private String signatureNo;

	@JSONField(name = "CutoffCreditAccruedInterest")
	private String cutoffCreditAccruedInterest;

	@JSONField(name = "CutoffDebitAccruedInterest")
	private String cutoffDebitAccruedInterest;

	@JSONField(name = "JointAccountFlag")
	private String jointAccountFlag;

	@JSONField(name = "SettlementAccountFlag")
	private String settlementAccountFlag;

	@JSONField(name = "InvestmentAccountFlag")
	private String investmentAccountFlag;

	@JSONField(name = "AutopayAccountFlag")
	private String autopayAccountFlag;

	@JSONField(name = "MinimumPaymentInd")
	private String minimumPaymentInd;

	@JSONField(name = "StaffInd")
	private String staffInd;

	@JSONField(name = "AdvanceClassificationCode")
	private String advanceClassificationCode;

	@JSONField(name = "CountryCode")
	private String sountryCode;

	@JSONField(name = "DistrictCode")
	private String districtCode;

	@JSONField(name = "HKMCRefNo")
	private String hKMCRefNo;

	@JSONField(name = "GuaranteePercentage")
	private String guaranteePercentage;

	@JSONField(name = "LINKFlag")
	private String lINKFlag;

	@JSONField(name = "LINKFlagLastUpdateDate")
	private String lINKFlagLastUpdateDate;

	@JSONField(name = "MTRFlag")
	private String mmTRFlag;

	@JSONField(name = "MTRFlagLastUpdateDate")
	private String mTRFlagLastUpdateDate;

	@JSONField(name = "PayrollInfo")
	private List<PayrollInfo> payrollInfo;

	@JSONField(name = "OctopusAavsFlag")
	private String octopusAavsFlag;

	@JSONField(name = "OctopusAavsFlagLastUpdDate")
	private String octopusAavsFlagLastUpdDate;

	@JSONField(name = "TierIntInd")
	private String tierIntInd;

	@JSONField(name = "InsurCompanyCode")
	private String insurCompanyCode;

	@JSONField(name = "InsurCompanyName1")
	private String insurCompanyName1;

	@JSONField(name = "InsurCompanyName2")
	private String insurCompanyName2;

	@JSONField(name = "LatestCashSurrValueInfo")
	private List<LatestCashSurrValueInfo> latestCashSurrValueInfo;

	@JSONField(name = "LatestApprovedLTVInfo")
	private List<LatestApprovedLTVInfo> latestApprovedLTVInfo;

	@JSONField(name = "ExceedLimitPercentage")
	private String exceedLimitPercentage;

	@JSONField(name = "DateHitExceed7Percent")
	private String dateHitExceed7Percent;

	@JSONField(name = "DormantChargeFlag")
	private String dormantChargeFlag;

	@JSONField(name = "ReEnrollFlag")
	private String reEnrollFlag;

	@JSONField(name = "MonthlyGainIntFeeInd")
	private String monthlyGainIntFeeInd;

	@JSONField(name = "MonthlyGainIntFeeExpiryDate")
	private String monthlyGainIntFeeExpiryDate;

	@JSONField(name = "IBSLimitNum")
	private String iBSLimitNum;

	@JSONField(name = "IBSLimitAutoGenFlag")
	private String iBSLimitAutoGenFlag;

	@JSONField(name = "IncomeProofFlag")
	private String incomeProofFlag;
}
