package com.dsb.eb2.util;

import java.io.InputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

public class XMLUtils
{
    public static Document getDocument(InputStream is) throws Exception
    {
        Document doc = null;
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setValidating(true);
        factory.setIgnoringElementContentWhitespace(true);
        factory.setNamespaceAware(true);
        disableExternalEntityParsing(factory);
        try
        {
            DocumentBuilder builder = factory.newDocumentBuilder();
            doc = builder.parse(is);
        } catch (Exception e)
        {
            e.printStackTrace();
            throw e;
        }

        return doc;
    }

    public static String getTextValue(Element element)
    {
        Text textNode = (Text) element.getFirstChild();
        String value = "";
        if (textNode != null)
        {
            value = textNode.getData().trim();
        }
        return value;
    }
    
    /**  
     * Explicitly enable or disable the 'external-general-entities' and  
     * 'external-parameter-entities' features of the underlying  
     * DocumentBuilderFactory.  
     *  
     * TODO This is a naive approach that simply tries to apply all known  
     * feature name/URL values in turn until one succeeds, or none do.  
     *  
     * @param factory  
     * factory which will have external general and parameter entities enabled  
     * or disabled.  
     * @param enableExternalEntities  
     * if true external entities will be explicitly enabled, otherwise they  
     * will be explicitly disabled.  
     */  
    public static void disableExternalEntityParsing(DocumentBuilderFactory factory)  
    {  
        // Feature list drawn from:  
        // https://www.owasp.org/index.php/XML_External_Entity_(XXE)_Processing  
  
        /* Enable or disable external general entities */  
//        String[] externalGeneralEntitiesFeatures = {  
//            // General  
//            "http://xml.org/sax/features/external-general-entities",  
//            // Xerces 1  
//            "http://xerces.apache.org/xerces-j/features.html#external-general-entities",  
//            // Xerces 2  
//            "http://xerces.apache.org/xerces2-j/features.html#external-general-entities",  
//        };  
////        boolean success = false;  
//        for (String feature: externalGeneralEntitiesFeatures) {  
//            try {  
//                factory.setFeature(feature, false);  
////                success = true;  
////                break;  
//            } catch (ParserConfigurationException e) {  
//            }  
//        }  
        try { 
        	factory.setXIncludeAware(false);
            factory.setExpandEntityReferences(false);
            factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
            factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl",true);
        } catch (Exception e)
        {
            e.printStackTrace();
        } 
    }  
}
