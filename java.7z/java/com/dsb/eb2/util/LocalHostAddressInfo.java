/*
 * LocalHostAddressInfo.java
 *
 * Created on November 21, 2000, 5:08 PM
 */

package com.dsb.eb2.util;

import java.net.*;

public class LocalHostAddressInfo extends Object {

    public static String getName() {
	InetAddress localHost;
	String localHostName = "unknown";

	try {
	    localHost = InetAddress.getLocalHost();
            localHostName = localHost.getHostName();
        } catch (UnknownHostException e) {
        }
        return localHostName;
    }
       
    public static String getIp() {
	InetAddress localHost;
	byte[] addressByte;
        String localHostIp = "unknown";

	try {
	    localHost = InetAddress.getLocalHost();
            addressByte = localHost.getAddress();
            if (addressByte.length == 4) {
              localHostIp = (addressByte[0] & 0xFF) + "." + (addressByte[1] & 0xFF)
			                            + "." + (addressByte[2] & 0xFF)
			                            + "." + (addressByte[3] & 0xFF);   
            }              
        } catch (UnknownHostException e) {
	}
        return localHostIp;
    }
    
    
    public static void main(String[] args) {
    }
    
}