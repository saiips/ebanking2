package com.dsb.eb2.util;

public class SystemEnvironment {
	 static String default_home = "/ebank/";

	  /**
	   * Constructor
	   */
	  public SystemEnvironment() {
	  }

	  public static String getHome() {
	    String ebank_home=null;

	    ebank_home = System.getProperty("EBANK_HOME");
	    if (ebank_home == null)
	      ebank_home = default_home;

	    return ebank_home;
	  }
}
