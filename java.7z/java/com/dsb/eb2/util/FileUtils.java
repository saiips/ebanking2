package com.dsb.eb2.util;

import java.io.File;

/**
 * 文本文件的處理工具類
 * 
 * @author user
 * 
 */
public class FileUtils
{
    public static boolean isFileExist(String path)
    {
        File file = new File(path);
        return file.exists();
    }
    
    public static String translate(String sFilename) {
		String tFilename=sFilename;
    char separatorFound;

		if (sFilename != null) {
      if (sFilename.indexOf("/") == -1)
        separatorFound = '\\';
      else
        separatorFound = '/';
	  	tFilename = sFilename.replace(separatorFound, File.separatorChar);
  		if (File.separatorChar != '\\') {
			  if (tFilename.length() > 1)
		  	{
	  			if (tFilename.charAt(1) == ':')
  				{
					  tFilename = tFilename.substring(2);
				  }
			  }
		  }
    }
		return tFilename;
	}
}
