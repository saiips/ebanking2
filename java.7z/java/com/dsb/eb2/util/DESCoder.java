package com.dsb.eb2.util;

import org.bouncycastle.crypto.engines.DESedeEngine;
import org.bouncycastle.crypto.modes.CBCBlockCipher;
import org.bouncycastle.crypto.paddings.PaddedBufferedBlockCipher;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.util.encoders.Hex;

  
public class DESCoder {
    
    public static String encryptData(String keyStr, String encryptData) throws Exception{  
    	
    	byte[] keybyte = convertTo24BytesKey(keyStr);
        byte[] data = encryptData.getBytes();
        
    	PaddedBufferedBlockCipher cipher = new PaddedBufferedBlockCipher(new CBCBlockCipher(new DESedeEngine()));
        // initialise the cipher with the key bytes, for encryption
        cipher.init(true, new KeyParameter(keybyte));
        int inBlockSize = data.length;
        int outBlockSize = cipher.getOutputSize(inBlockSize);
        byte[] outBlock = new byte[outBlockSize];
        
        String result = "";
        try  {
            int outLen = cipher.processBytes(data, 0, data.length, outBlock, 0);
            if (outLen>0) {
                result = new String(Hex.encode(outBlock, 0, outLen));
            }
            outLen = cipher.doFinal(outBlock,0);
            if (outLen>0) {
                String lastStr = new String(Hex.encode(outBlock, 0, outLen));
            	result = result.concat(lastStr);
            }
        }
        catch (Exception e){
        	throw new Exception("3DES encryption error!");
        }
        return result;  
    }

    public static String decryptData(String keyStr, String decryptData) throws Exception{  
    	byte[] keybyte = convertTo24BytesKey(keyStr);
    	byte[] data = Hex.decode(decryptData);
    	PaddedBufferedBlockCipher cipher = new PaddedBufferedBlockCipher(new CBCBlockCipher(new DESedeEngine()));
    	cipher.init(false, new KeyParameter(keybyte));
        int inBlockSize = data.length;
        int outBlockSize = cipher.getOutputSize(inBlockSize);
        byte[] outBlock = new byte[outBlockSize];
        String result = "";
        try  {
            int outLen = cipher.processBytes(data, 0, data.length, outBlock, 0);
            outLen = cipher.doFinal(outBlock,0);
            if (outLen > 0) {
            	if(outLen >= outBlock.length){
            		result = new String(outBlock);
            	}else{
            		byte[] subOutBlock = new byte[outLen];
            		for(int i = 0; i < outLen; i++){
            			subOutBlock[i] = outBlock[i];
                    }
            		result = new String(subOutBlock);
            	}
            }
        }
        catch (Exception e){
        	throw new Exception("3DES decryption error!");
        }
        return result;  
    }  
    
    public static byte[] convertTo24BytesKey(String keyStr){  
        byte[] bkeys = keyStr.getBytes();
        byte[] enk = new byte[24];  
        for (int i=0;i<24;i++){  
            enk[i] = bkeys[i];  
        }
        return enk;  
    }
    
    public static String convertSessionId2Key3Des(String keyStr){
    	if(keyStr != null && keyStr.length() > 24){
    		return keyStr.substring(0, 24);
    	}else{
    		return keyStr;
    	}
    }
    
    public static void main(String[] args) throws Exception{  
    	
    	String keyStr = "0yz2XspH4wLQFvxVQFVRCFny";
        byte[] enk = convertTo24BytesKey("0yz2XspH4wLQFvxVQFVRCFny");
        String pwd = "1234567";
        String pword = encryptData(keyStr, pwd);  

        String decryptStr = decryptData(keyStr,pword);  
    }  

}  

