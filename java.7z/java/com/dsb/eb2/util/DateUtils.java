package com.dsb.eb2.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

/**
 * <p>
 * 处理日期的工具类，日期指java.util.Date及其子类（不包括java.sql.Timestamp）.
 * </p>
 * 
 * <p>
 * 注意：解析/格式化日期字符串采用的是SimpleDateFormat
 * </p>
 * 
 * @author
 * 
 * 
 */
public class DateUtils
{
	
	public final static String STR_TIMEFORMAT_D_MMM_YYYY = "d-MMM-yyyy";
	
	public final static String STR_TIMEFORMAT_YYYYNMYDR = "yyyy年M月d日";
	
	
    /**
     * 生成日期对象
     * 
     * @param year
     *            the year .
     * @param month
     *            the month between 1-12.
     * @param date
     *            the day of the month between 1-31.
     * @return 日期
     */
    public static Date getDate(int year, int month, int date)
    {
        return getDate(year, month, date, 0, 0, 0);
    }

    /**
     * 生成日期对象
     * 
     * @param year
     *            the year .
     * @param month
     *            the month between 1-12.
     * @param date
     *            the day of the month between 1-31.
     * @param hrs
     *            the hours between 0-23.
     * @param min
     *            the minutes between 0-59.
     * @param sec
     *            the seconds between 0-59.
     * @return 日期
     */
    public static Date getDate(int year, int month, int date, int hrs, int min,
        int sec)
    {
        Calendar cal = new GregorianCalendar(year, month - 1, date, hrs, min,
            sec);
        return cal.getTime();
    }

    /**
     * 设置给定日期的时分秒等属性
     * 
     * @param d --
     *            待设置的日期
     * @param hrs --
     *            小时(0-23)，若为负值则不设置，以下同。
     * @param min --
     *            分(0-59)
     * @param sec --
     *            秒(0-59)
     * @return 日期
     */
    public static Date setDate(Date d, int hrs, int min, int sec)
    {
        return setDate(d, -1, -1, -1, hrs, min, sec);
    }

    /**
     * 设置给定日期的年月日时分秒等属性
     * 
     * 
     * @param d --
     *            待设置的日期
     * @param year --
     *            年，若为负值则不设置，以下同。
     * @param month --
     *            月(1-12)
     * @param date --
     *            日(1-31)
     * @param hrs --
     *            小时(0-23)
     * @param min --
     *            分(0-59)
     * @param sec --
     *            秒(0-59)
     * @return 日期
     */
    public static Date setDate(Date d, int year, int month, int date, int hrs,
        int min, int sec)
    {

        Calendar cal = Calendar.getInstance();
        cal.setTime(d);
        if (year >= 0) cal.set(Calendar.YEAR, year);
        if (month >= 1) cal.set(Calendar.MONTH, month - 1);
        if (date >= 1) cal.set(Calendar.DATE, date);
        if (hrs >= 0) cal.set(Calendar.HOUR_OF_DAY, hrs);
        if (min >= 0) cal.set(Calendar.MINUTE, min);
        if (sec >= 0) cal.set(Calendar.SECOND, sec);
        return cal.getTime();
    }

    // -----------------------计算---------------------------

    /**
     * 计算2个日期相隔的天数，返回前一个日期减去后一个日期的天数，2个日期的格式必须同为 指定的格式
     * 
     * @param dateString1 --
     *            被比较的日期
     * @param dateString2 --
     *            比较的日期
     * @param format --
     *            日期的格式
     * @return 相差的天数
     * @throws ParseException
     * @see #betweenDays(Date date1, Date date2)
     */
    public static int betweenDays(String dateString1, String dateString2,
        String format) throws ParseException
    {
        return betweenDays(parse(dateString1, format), parse(dateString2,
            format));
    }

    /**
     * 计算2个日期相隔的天数，返回前一个日期减去后一个日期的天数
     * 
     * @param date1 --
     *            被比较的日期
     * @param date2 --
     *            比较的日期
     * @return 相差的天数
     */
    public static int betweenDays(Date date1, Date date2)
    {
        long balance = date1.getTime() - date2.getTime();
        balance = balance / (24 * 60 * 60 * 1000);
        return (int) balance;
    }

    /**
     * 把一个日期增加多少天，返回新的日期对象
     * 
     * @param dateString --
     *            指定的日期参数
     * @param format --
     *            日期的格式
     * @param days --
     *            增加的天数
     * @return 增加后的日期
     * @throws ParseException
     * @see #addDays(Date date, int days)
     */
    public static String addDays(String dateString, String format, int days)
        throws ParseException
    {
        Date date = addDays(parse(dateString, format), days);
        return format(date, format);
    }

    /**
     * 把一个日期增加多少天，返回新的日期对象
     * 
     * @param date --
     *            指定的日期参数
     * @param days --
     *            增加的天数
     * @return 增加后的日期
     */
    public static Date addDays(Date date, int days)
    {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.DATE, days);
        return c.getTime();
    }

    public static Date addMonths(Date date, int months)
    {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.MONTH, months);
        return c.getTime();
    }

    public static Date addYears(Date date, int years)
    {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.YEAR, years);
        return c.getTime();
    }

    /**
     * 把一个日期类型对象转换成另一个日期类型的对象，比如:java.util.Date -> java.sql.Date
     * 
     * @param date --
     *            待转换的日期
     * @param clazz --
     *            目标类型
     * @return clazz类型的日期对象
     */
    public static Date transform(Date date, Class<?> clazz)
    {
        if (clazz == java.util.Date.class)
        {
            return new java.util.Date(date.getTime());
        } else if (clazz == java.sql.Date.class)
        {
            return new java.sql.Date(date.getTime());
        } else if (clazz == java.sql.Time.class)
        {
            return new java.sql.Time(date.getTime());
        }

        throw new IllegalArgumentException("[ Unsupported type: "
            + clazz.getName() + " ]");
    }

    // -------------------------解析/格式化--------------------------

    /**
     * 转换日期的字符串格式
     * 
     * 过程：parse -> format
     * 
     * @param dateString --
     *            字符串日期
     * @param currentFormat --
     *            当前格式
     * @param newFormat --
     *            新的格式
     * @return 格式化后的日期字符串
     * @throws ParseException
     * @see #parse(String dateString, String format)
     * @see #format(Date date, String format)
     */
    public static String format(String dateString, String currentFormat,
        String newFormat) throws ParseException
    {
        Date date = parse(dateString, currentFormat);
        return format(date, newFormat);
    }

    /**
     * 格式化日期以获取期望的字符串格式，如果未指定格式，则采用默认的格式
     * 
     * @param date --
     *            指定的日期参数
     * @param format --
     *            目标格式
     * @return 格式化后的日期字符串
     * @see #getDefaultFormat(Date date)
     */
    public static String format(Date date, String format)
    {
        if (format == null)
        {
            format = getDefaultFormat(date);
        }
        return new SimpleDateFormat(format, Locale.ENGLISH).format(date);
    }
    
    /**
    *根据语言版本返回特定的日期格式
    */
    public static String timeFormat(String lang)
    {
    	
        if("E".equals(lang.toUpperCase()))
        {
        	return STR_TIMEFORMAT_D_MMM_YYYY;
        }
        else
        {
        	return STR_TIMEFORMAT_YYYYNMYDR;
        }
    	
    }
    
    /**
     * 解析日期
     * 
     * 
     * @param dateString --
     *            指定的日期字符串
     * @param format --
     *            当前日期格式，如果未指定将自动判断
     * @return 识别后的日期对象
     * @throws ParseException
     * @see #getDefaultFormat(String dateString)
     */
    public static Date parse(String dateString, String format)
        throws ParseException
    {
        if (format == null)
        {
            format = getDefaultFormat(dateString);
        }
        return new SimpleDateFormat(format, Locale.ENGLISH).parse(dateString);
    }

    /**
     * 根据类型返回默认的格式 日期：yyyy-MM-dd 时间：HH:mm:ss
     * 
     * @param date --
     *            日期参数
     * @return 返回该对象类型对应的默认格式
     */
    public static String getDefaultFormat(Date date)
    {
        if (date.getClass() == java.util.Date.class)
        {
            return "yyyy-MM-dd";
        } else if (date.getClass() == java.sql.Date.class)
        {
            return "yyyy-MM-dd";
        } else if (date.getClass() == java.sql.Time.class)
        {
            return "HH:mm:ss";
        }

        throw new IllegalArgumentException("[ Unsupported type: "
            + date.getClass().getName() + " ]");
    }

    /**
     * 根据字符串格式判断类型，然后返回默认的格式，只会返回支持的格式
     * 
     * 支持的格式有： a.日期：yyyy-MM-dd和yyyyMMdd; b.时间：HH:mm:ss,HHmmss; c.毫秒：SSS或者与时间组合
     * HH:mm:ss.SSS 和HHmmssSSS d.以上的组合
     * 
     * 其中'-'，':'代表分隔符,
     * 
     * @param dateString --
     *            指定的日期字符串
     * @return 适合的日期格式
     */
    public static String getDefaultFormat(String dateString)
    {
        dateString = dateString.trim();
        if (dateString.indexOf(" ") > -1)
        {
            dateString = dateString.replaceAll(" +", " ");
            String[] array = dateString.split(" ");
            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < array.length; i++)
            {
                sb.append(getDefaultFormat(array[i]));
                if (i != array.length - 1)
                {
                    sb.append(" ");
                }
            }
            return sb.toString();
        }

        boolean pureDigit = dateString.matches("^\\d+$");
        if (pureDigit)
        {
            if (dateString.length() == 3)
            {
                return "SSS";
            } else if (dateString.length() == 6)
            {
                return "HHmmss";
            } else if (dateString.length() == 8)
            {
                return "yyyyMMdd";
            } else if (dateString.length() == 9)
            {
                return "HHmmssSSS";
            }
        } else
        {
            if (dateString.matches("^\\d{2}.\\d{2}.\\d{2}$"))
            {
                char separator = dateString.charAt(2);
                return ("HH" + separator + "mm" + separator + "ss");
            } else if (dateString.matches("^\\d{4}.\\d{2}.\\d{2}$"))
            {
                char separator = dateString.charAt(4);
                return ("yyyy" + separator + "MM" + separator + "dd");
            } else if (dateString.matches("^\\d{2}.\\d{2}.\\d{4}$"))
            {
                char separator = dateString.charAt(2);
                return ("MM" + separator + "dd" + separator + "yyyy");
            } else if (dateString.matches("^\\d{6}.\\d{3}$"))
            {
                char separator = dateString.charAt(6);
                return ("HHmmss" + separator + "SSS");
            } else if (dateString.matches("^\\d{2}.\\d{2}.\\d{2}.\\d{3}$"))
            {
                char separator = dateString.charAt(2);
                char separator1 = dateString.charAt(8);
                return ("HH" + separator + "mm" + separator + "ss" + separator1 + "SSS");
            }
        }

        throw new IllegalArgumentException(
            " [ No suitable default format! ] ");
    }
    
    public static Date truncateDate(Date dateToTruncate) throws Exception {
		ValidationUtil.validateObjectNull(dateToTruncate, "Empty or invalid dateToTruncate: " + dateToTruncate);
		Date result = null;
		Calendar cal = Calendar.getInstance();
		cal.setTime(dateToTruncate);
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		result = cal.getTime();
		return result;
	}
    
    public static Date getWindowStartDate(Date endDate, Integer windowSize) throws Exception {
		ValidationUtil.validateObjectNull(endDate, "Empty or invalid endDate: " + endDate);
		ValidationUtil.validateIntegerValue(windowSize, "Empty or invalid windowSize: " + windowSize);
		Date result = null;
		Calendar cal = Calendar.getInstance();
		cal.setTime(endDate);
		cal.add(Calendar.DAY_OF_MONTH, 0 - (windowSize.intValue() - 1)); //- 1 to include current day
		result = cal.getTime();
		return result;
	}
}
