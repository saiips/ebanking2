package com.dsb.eb2.util;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Iterator;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.MemoryCacheImageInputStream;

public class ImageUtils {

	/*
	 * 常見圖片格式(jpg,jpeg,png,gif,bmp);
	 * jdk rt.jar包默認僅支持:jpeg,png,gif,bmp,wbmp 等圖片格式.
	 */
	public static final String TYPE_JPEG = "jpg";

	public static final String TYPE_PNG = "png";

	public static final String TYPE_GIF = "gif";

	public static final String TYPE_BMP = "bmp";

	public static final String TYPE_UNKNOWN = "unknown";

	/**
	 * 根据文件流判断图片类型
	 * 
	 * @param fis
	 * @return jpeg(jpg)/png/gif/bmp
	 */
	public static String getPicType(ByteArrayInputStream fis) {
		// 读取文件的前几个字节来判断图片格式
		byte[] b = new byte[4];
		try {
			fis.read(b, 0, b.length);
			String type = bytesToHexString(b).toUpperCase();
			if (type.contains("FFD8FF")) {
				return TYPE_JPEG;
			} else if (type.contains("89504E47")) {
				return TYPE_PNG;
			} else if (type.contains("47494638")) {
				return TYPE_GIF;
			} else if (type.contains("424D")) {
				return TYPE_BMP;
			} else {
				return TYPE_UNKNOWN;
			}
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}

	/**
	 * byte数组转换成16进制字符串
	 * 
	 * @param src
	 * @return
	 */
	public static String bytesToHexString(byte[] src) {
		StringBuilder stringBuilder = new StringBuilder();
		if (src == null || src.length <= 0) {
			return null;
		}
		for (int i = 0; i < src.length; i++) {
			int v = src[i] & 0xFF;
			String hv = Integer.toHexString(v);
			if (hv.length() < 2) {
				stringBuilder.append(0);
			}
			stringBuilder.append(hv);
		}
		return stringBuilder.toString();
	}

	/**
	 * 根據圖片字節型數組判斷圖片格式
	 * 
	 * @param bys
	 * @return jpeg(jpg),png,gif,bmp.
	 */
	public static String getPicType(byte[] bys) {
		String type = "";
		ByteArrayInputStream bais = null;
		MemoryCacheImageInputStream mcis = null;
		try {
			bais = new ByteArrayInputStream(bys);
			mcis = new MemoryCacheImageInputStream(bais);
			Iterator<ImageReader> itr = ImageIO.getImageReaders(mcis);
			while (itr.hasNext()) {
				ImageReader reader = (ImageReader) itr.next();
				String imageName = reader.getClass().getSimpleName();
				if (imageName != null) {
					if ("JPEGImageReader".equals(imageName)) {
						type = TYPE_JPEG;
					} else if ("PNGImageReader".equals(imageName)) {
						type = TYPE_PNG;
					} else if ("GIFImageReader".equals(imageName)) {
						type = TYPE_GIF;
					} else if ("BMPImageReader".equals(imageName)) {
						type = TYPE_BMP;
					} else {
						type = TYPE_UNKNOWN;
					}
				}
			}
		} catch (Exception e) {
			type = TYPE_UNKNOWN;
		} finally {
			if (bais != null) {
				try {
					bais.close();
				} catch (IOException ioe) {
					type = TYPE_UNKNOWN;
				}
			}
			if (mcis != null) {
				try {
					mcis.close();
				} catch (IOException ioe) {
					type = TYPE_UNKNOWN;
				}
			}
		}
		return type;
	}

}
