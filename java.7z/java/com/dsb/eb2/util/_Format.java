package com.dsb.eb2.util;

import java.util.*;

public class _Format {
 
  public static String format(String s, int len, char ch, char mode) {
    StringBuffer sb = new StringBuffer();
    StringBuffer result = new StringBuffer(); 
    int padding = len - s.length();
    
    if(s.length() == len)
      return s;  

    while(padding > 0) {
      sb.append(ch);
      padding--;
    }

    switch(mode) {
      case 'L':
        result.append(sb.toString()+s);
        break;
      case 'R': 
      default :
        result.append(s+sb.toString());
        break;
    }

    return result.toString(); 
  }

/**
  *param s    : String value
  *param dlen : Decimal length
  *return String after adding decimal point
 */
  public static String addDecimal(String s, int dlen) {
    StringBuffer sb = new StringBuffer();
    // Check null string
    if(s == null)
      return null;
    // Compare string & decimal point length 
    if(s.length() < dlen)
      return s; 
    // Check wether decimal point already in the string
    if(s.indexOf(".") > 0)
      return s;
    sb.append(s.substring(0,s.length()-dlen));
    sb.append(".");
    sb.append(s.substring(s.length()-dlen,s.length()));
    return sb.toString();
  }

/**
  *param String s	: Input string
  *param int slen	: Total string length of the numeric value
  *param int dlen	: Decimal part length of the numeric value
  *return string after removing decimal point 
 */
  public static String removeDecimal(String s, int slen, int dlen) {
    String integerPart, decimalPart;
    // 0] validation 
    if(s.indexOf(".") < 0) // check decimal point
      return null;
    if(dlen > slen)  // check string length & decimal length
      return null;
    // 1] format new string with padding 0 on right
    String newStr = format(s.trim(),slen+dlen,'0','R');
    // 2] split integer part & decimal of the number
    integerPart = newStr.substring(0,newStr.indexOf("."));
    decimalPart = newStr.substring(newStr.indexOf(".")+1,newStr.length()).substring(0,dlen);
    // 3] format the new string with implied decimal point
    String resultStr = format(integerPart+decimalPart,slen,'0','L');
    return resultStr.substring(0,slen); // result string with length = slen
  }
  public static String normalBitAddDecimal(String in_bit)
  {
	StringBuffer sb = new StringBuffer();
	sb.append(in_bit);

	if (in_bit.indexOf(".") < 0)
		sb.append(".00");
	else 
	{
	  int a = in_bit.substring(in_bit.indexOf(".")+1).length();
		if (a==1)
		sb.append("0");
	}

	return sb.toString();
  }

	

}

