package com.dsb.eb2.util;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dsb.eb2.api.common.smsOTP.constant.SMSOTPConstant;
import com.dsb.eb2.bankApp.dao.eBankKeyPair.EBankKeyPariBean;
import com.dsb.eb2.util.rsaUtils.RSACoder;
import com.dsb.eb2.util.rsaUtils.RSAKeys;

public class SecurityUtils {
	
	private static Logger logger = LoggerFactory.getLogger(SecurityUtils.class);
	
	public static final Pattern BLANK_REGEX = Pattern.compile("^\\s*$");
	
	public static boolean isEmpty(String val)
	{
		boolean result = false;
		
		if(val == null || BLANK_REGEX.matcher(val).find())
		{
			result = true;
		}
		
		return result;
	}
	
	private static String getStackTrace(Exception exception)
  	{
  		String s = "null";
  		try
  		{
  			if(exception != null)
  			{
  				Writer writer = new StringWriter();
  				PrintWriter printWriter = new PrintWriter(writer);
  				exception.printStackTrace(printWriter);
  				s = writer.toString();
  			}
  		}catch (Exception e)
  		{
  			try
  			{
  				logger.info("InterExceptionAlert.getStackTrace catch a exception : " + e.getMessage() + " | " + e);
  			} catch (Exception e2) {
  				e2.printStackTrace();
  			}
  		}
  		return s;
  	}
	
	public static String decryptOTP(String encryptOTP, String privateKey) throws Exception{
		String rs = "";
		try {
			byte[] encryptData = RSAKeys.decryptBASE64(encryptOTP);
			byte[] decryptData = RSACoder.decryptByPrivateKey(encryptData, privateKey);
			rs = new String(decryptData);
		} catch (Exception e) {
			logger.error("SecurityUtils decryptOTP error:" + e);
			throw e;
		}
		return rs;
	}
	
	public static boolean checkValidMobile(String smsMobileNo,boolean supportOverseaMobile) {
		if(smsMobileNo == null || "".equals(smsMobileNo.trim())){
			return false;
		}else{
			smsMobileNo = smsMobileNo.trim();
			
			if(!supportOverseaMobile){	//local mobile number
				if(!validLocalMobileNumber(smsMobileNo)){
					return false;
				}
			}else{
				if(validLocalMobileNumber(smsMobileNo)){
					return true;
				}
				//Start, valid as Overseas Mobile Number, with prefix non-852
				else if (smsMobileNo.startsWith(SMSOTPConstant.LOCAL_AREA_CODE)) {   
					return false;
				}
				//End, valid as Overseas Mobile Number, with prefix non-852
				else if(smsMobileNo.trim().length() < SMSOTPConstant.OVERSEA_NUMBER_MIN_INL_LEN ){	//oversea mobile
					return false;
				}
			}
		}
		
		return true;
	}
	
	private static boolean validLocalMobileNumber(String mobile){
		if(mobile == null || "".equals(mobile.trim())){
			return false;
		}
		mobile = mobile.trim();
		if(mobile.length() != 8 && mobile.length() != 11){
			return false;
		}else{
			if(mobile.length() == 11){
				if(!mobile.startsWith(SMSOTPConstant.LOCAL_AREA_CODE)){
					return false;
				}
				mobile = mobile.substring(3);
			}
			String prefix = mobile.substring(0, 1);
			if(!checkLocalPrefix(prefix)){
				return false;
			}
		}
		
		return true;
	}
	
	private static boolean checkLocalPrefix(String prefix){
		for (int i=0; i < SMSOTPConstant.VALID_LOCAL_PREIX.length; i++) {
			if (SMSOTPConstant.VALID_LOCAL_PREIX[i].equals(prefix)) {
				return true;
			}
		}
		return false;
	}
	
	/*public static EBankKeyPariBean getkeyPairDesc(LinkedList<EBankKeyPariBean> eBankKeyPariBeanList) {
		Map<String,EBankKeyPariBean> EBankKeyPariBeanMap = new HashMap<String,EBankKeyPariBean>();
		EBankKeyPariBean eBankKeyPariBean = null;
		EBankKeyPariBean keyPairDesc = null;
		for(int i=0;i<eBankKeyPariBeanList.size();i++) {
			eBankKeyPariBean = eBankKeyPariBeanList.get(i);
			EBankKeyPariBeanMap.put(eBankKeyPariBean.getName()+SMSOTPConstant.EBANK_KEYPAIR_NAME_DELIMITER+eBankKeyPariBean.getKeyIndex(), eBankKeyPariBean);
		}
		for(int i=0;i<EBankKeyPariBeanMap.size();i++) {
			if(EBankKeyPariBeanMap.containsKey(SMSOTPConstant.EBANK_KEYPAIR_NAME_PREFIX+SMSOTPConstant.EBANK_KEYPAIR_NAME_DELIMITER+i)){
				keyPairDesc = EBankKeyPariBeanMap.get(SMSOTPConstant.EBANK_KEYPAIR_NAME_PREFIX+SMSOTPConstant.EBANK_KEYPAIR_NAME_DELIMITER+i);
				if(keyPairDesc != null) {break;}
			}
		}
		return keyPairDesc;
	}*/
	public static String getRemoteHost(HttpServletRequest request) {
		String ip = request.getHeader("X-Forwarded-For");
		if (ip == null || ip.length() == 0 || "unknow".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknow".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknow".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}
		
		return ip.equals("0:0:0:0:0:0:0:1") ? "127.0.0.1" : filterInvalidChar(ip);
	}
	public static String filterInvalidChar(String inputString){
			
			if(inputString != null){
				if(inputString.indexOf("%0d") != -1){
					inputString = inputString.replaceAll("%0d", "");
				}
				if(inputString.indexOf("\r") != -1){
					inputString = inputString.replaceAll("\r", "");
				}
				if(inputString.indexOf("%0a") != -1){
					inputString = inputString.replaceAll("%0a", "");
				}
				if(inputString.indexOf("\n") != -1){
					inputString = inputString.replaceAll("\n", "");
				}
				if(inputString.indexOf("%") != -1){
					inputString = inputString.replaceAll("%", "");
				}
			}
			
			return inputString;
		}
	/*public static void resetObject(Object object,String request) {
		try
		{
			if(object != null && !isEmpty(request))
			{
				JSONObject jsonObject = JSONObject.fromObject(request);
				JSONObject.json
				if(jsonObject != null && jsonObject.size() > 0)
				{
					Class cls = object.getClass();
					Field[] allFields = cls.getDeclaredFields();
					if(allFields != null && allFields.length > 0)
					{
						for(int i = 0; i < allFields.length; i++)
						{
							try
							{
								String fieldName = allFields[i].getName();
								String fieldType = allFields[i].getType().getName();
								String fieldValue = EbankMsgUtil.getJSONValue(jsonObject.get(fieldName));
								if(!isEmpty(fieldValue)
									&& 
										(
											String.class.getName().equals(fieldType)
											|| short.class.getName().equals(fieldType)
											|| int.class.getName().equals(fieldType)
											|| long.class.getName().equals(fieldType)
											|| double.class.getName().equals(fieldType)
											|| float.class.getName().equals(fieldType)
										)
								)
								{
									cls.getMethod(getSetMethodName(fieldName), allFields[i].getType()).invoke(object, jsonObject.get(fieldName));
								}
							} catch (Exception e){
							}
						}
					}
				}
			}
		} catch (Exception e){
		}
	}*/
}
