package com.dsb.eb2.util;

import java.io.BufferedInputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * <p>
 * io操作的工具集
 * </p>
 * 
 * 注意：io流必须自己关闭
 * 
 * @author
 * 
 */
public class IOUtils
{
    /**
     * 缓冲区大小
     */
    public static final int BUFFER_SIZE = 8 * 1024;

    /**
     * 从输入流读取数据写入到输出流中
     * 
     * @param is --
     *            输入流
     * @param os --
     *            输出流
     * @throws IOException
     */
    public static void write(InputStream is, final OutputStream os)
        throws IOException
    {
        read(is, new ReadActionHandler()
        {
            public void handle(int readNum, byte[] buffer) throws IOException
            {
                os.write(buffer, 0, readNum);
            }
        });
    }

    /**
     * 循环读取输入流的数据，并在每次读取数据之后调用ReadActionHandler的handle方法， 供用户处理数据
     * 
     * @param is --
     *            输入流
     * @param handler --
     *            数据处理器
     * @throws IOException
     */
    public static void read(InputStream is, ReadActionHandler handler)
        throws IOException
    {
        int readNum = 0;
        byte[] buffer = new byte[BUFFER_SIZE];
        BufferedInputStream bis = new BufferedInputStream(is);
        while ((readNum = bis.read(buffer, 0, buffer.length)) != -1)
        {
            handler.handle(readNum, buffer);
        }
    }

    /**
     * 读操作的动作处理接口，在每一次循环读之后调用
     * 
     * @author
     * 
     */
    public interface ReadActionHandler
    {
        /**
         * 处理数据
         * 
         * @param readNum --
         *            实际读取的字节数
         * @param buffer --
         *            字节数组,大小为 BUFFER_SIZE
         * @throws IOException
         */
        public void handle(int readNum, byte[] buffer) throws IOException;
    }

    // -------------------------- base --------------------------------

    /**
     * 关闭io流，释放资源
     * 
     * @param closeable
     */
    public static void close(Closeable closeable)
    {
        if (closeable == null) return;

        try
        {
            closeable.close();
        } catch (IOException ioe)
        {
            ioe.printStackTrace();
        }
    }
}
