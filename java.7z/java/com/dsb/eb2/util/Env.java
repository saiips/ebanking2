package com.dsb.eb2.util;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Stack;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This class is used to pass information with hierarchical structure between
 * methods.
 */
public class Env extends Hashtable {
	private static Logger lg = LoggerFactory.getLogger(Env.class);
	// we specifically expect keys to be strings,
	// values to be strings or string-arrays;
	// more types may be added later. We expect
	// to use serializability; more important, we
	// expect to add read and write to editable text-files

	/**
	 * Convert a Hashtable object into an Env object.
	 *
	 */
	public Env(Hashtable H) {
		addHashtable(H);
	}

	private void addHashtable(Hashtable H) {
		Enumeration k = H.keys();
		while (k.hasMoreElements()) {
			Object S = k.nextElement();
			this.put(S, H.get(S));
		}
//  addEnvironmentFile();
	}

	/**
	 * Display all the content of the Env object in a string, used for debugging
	 * purpose.
	 */
	public String toString() {
		StringBuffer sB = new StringBuffer();
		Enumeration k = keys();
		while (k.hasMoreElements()) {
			String S = (String) k.nextElement();
			sB.append(S);
			sB.append("=");
			sB.append(getStr(S));
			sB.append(", \t");
		}
		return sB.toString();
	}

	/**
	 * Display all the content of the Env object in tree like view, used for
	 * debugging purpose.
	 */
	public String toStringRec() {
		// use if subEnvs might be cyclic
		StringBuffer sB = new StringBuffer();
		tSS(this, new Stack(), sB);
		return sB.toString();
	}

	private void tSS(Env E, Stack eS, StringBuffer sB) {
		// tostring subfunction for safe recursive Envs
		if (0 <= eS.search(E)) {
			sB.append("***CYCLIC ENV***\n");
			return;
		}
		eS.push(E);
		Enumeration k = E.keys();
		while (k.hasMoreElements()) {
			String key = (String) k.nextElement();
			for (int i = 0; i < eS.size(); i++)
				sB.append("  ");
			sB.append(key);
			sB.append("=");
			Object ob = E.get(key);
			if (null == ob)
				sB.append("null;\n");
			else if (ob instanceof String) {
				sB.append((String) ob);
				sB.append(";\n");
			} else if (ob instanceof String[]) {
				sB.append(Misc.stringArrayJoin((String[]) ob, ", "));
				sB.append(";\n");
			} else if (ob instanceof Env) {
				sB.append("[\n");
				tSS((Env) ob, eS, sB);
				for (int i = 0; i <= eS.size(); i++)
					sB.append("  ");
				sB.append("]\n");
			} else
				sB.append("??\n");
		}
		eS.pop();
	}

	public Env() {
	}

	public void putQuotedVal(String key, String val) {
		val = Misc.evalQuotedChars(val);
		if (!key.startsWith("[]"))
			put(key, val);
		else
			put(key.substring(2, key.length()), Misc.stringSplit(val));
	}

	/**
	 * Convert a HttpServletRequest object into an Env object.
	 *
	 */
	public Env(HttpServletRequest req) {
		lg.info("reading an httpservletrequest");
		Enumeration E = req.getParameterNames();
		while (E.hasMoreElements()) {
			String name = (String) E.nextElement();
			String[] vals = req.getParameterValues(name);
			if (vals.length != 1)
				this.put(name, vals);
			else
				this.put(name, vals[0]);
		}
		lg.info("got through initial env");
//  addEnvironmentFile();
	}

	public String getStr(String key) {
		Object ob = this.get(key);
		if (ob == null)
			lg.info("null getStr for [" + key + "]");
		if (ob instanceof String)
			return (String) ob;
		else if (ob instanceof String[])
			return Misc.stringArrayJoin((String[]) ob, ", ");
		else if (ob instanceof Env)
			return "[" + ((Env) ob).toString() + "]";
		else
			return null;
	}

	public String getStr(String key, String dflt) {
		Object ob = this.get(key);
		if (ob == null)
			return dflt;
		if (ob instanceof String)
			return (String) ob;
		else if (ob instanceof String[])
			return Misc.stringArrayJoin((String[]) ob, ", ");
		else
			return dflt;
	}

	public String[] getStrSeq(String key) {
		Object ob = this.get(key);
		if (ob == null)
			lg.info("null getStrSeq for [" + key + "]");
		if (ob instanceof String[])
			return (String[]) ob;
		else if (ob instanceof String)
			return new String[] { (String) ob };
		else
			return null;
	}

	public int getInt(String key, int dfault) {
		Object ob = this.get(key);
		if (ob == null)
			return dfault;
		if (ob instanceof String)
			return Integer.parseInt((String) ob);
		return ((Integer) ob).intValue();
	}

	public void append2StrSeq(String key, String val) {
		Object ob = get(key);
		if (null == ob)
			return;
		String[] A;
		if (ob instanceof String[])
			A = (String[]) ob;
		else if (ob instanceof String)
			A = new String[] { (String) ob };
		else
			return;
		String[] B = new String[A.length + 1];
		for (int i = 0; i < A.length; i++)
			B[i] = A[i];
		B[A.length] = val;
		put(key, B);
	}

	public void takeStrSeq(String key, int numToTake) {
		Object ob = get(key);
		if (null == ob)
			return;
		String[] A;
		if (ob instanceof String[])
			A = (String[]) ob;
		else if (ob instanceof String)
			A = new String[] { (String) ob };
		else
			return;
		if (numToTake >= A.length)
			return;
		String[] B = new String[numToTake];
		for (int i = 0; i < numToTake; i++)
			B[i] = A[i];
		put(key, B);
	}

	public Env getEnv(String key) {
		Object ob = get(key);
		if (ob == null || !(ob instanceof Env))
			return null;
		return (Env) ob;
	}

	public void put(String[] keys, Object val) {
		// put(["subEnv","subsubEnv","subSubSubEnv","key"],"val")
		// makes sure that
		// this.getEnv("subEnv").getEnv("subsubEnv").get("key")=="val"
		if (null == keys || 0 == keys.length)
			return;
		Env E = this;
		int lastIndex = keys.length - 1;
		for (int i = 0; i < lastIndex; i++) {
			Object ob = E.get(keys[i]);
			if (null == ob || !(ob instanceof Env)) {
				ob = new Env();
				E.put(keys[i], ob);
			}
			E = (Env) ob;
		}
		E.put(keys[lastIndex], val);
	}

	public Object get(String[] keys) {
		if (null == keys || 0 == keys.length)
			return null;
		Env E = this;
		int lastIndex = keys.length - 1;
		for (int i = 0; i < lastIndex; i++) {
			Object ob = E.get(keys[i]);
			if (null == ob || !(ob instanceof Env))
				return null;
			E = (Env) ob;
		}
		return E.get(keys[lastIndex]);
	}

	/**
	 * Put a value by using a key with '_' as separator between different level of
	 * sub-environments.
	 *
	 * Example : Env e = new Env(); e.putSplit( "subkey1_subkey2_key4", "value4");
	 *
	 * // the following lines will display the same value "value4"
	 *
	 */
	public void putSplit(String key, Object val) {
		if (null == key)
			return;
		if (key.indexOf('_') < 0)
			put(key, val);
		else
			put(Misc.stringSplit(key, '_'), val);
	}

	public Object getSplit(String key) {
		if (null == key)
			return null;
		if (key.indexOf('_') < 0)
			return get(key);
		return get(Misc.stringSplit(key, '_'));
	}
}
