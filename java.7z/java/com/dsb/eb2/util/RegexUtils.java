package com.dsb.eb2.util;

/**
 * 正则表达式的一些帮助函数
 * 
 * @author
 * 
 */
public class RegexUtils
{

    /**
     * 特殊字符
     */
    private static char[] SPEC_CHAR = { '\\', '$', '(', ')', '*', '+',
        '.', '[', '?', '^', '{', '|' };

    /**
     * 转义特殊字符
     * 
     * @param value
     * @return -- string
     */
    public static String filter(String value)
    {
        for (int i = 0; i < SPEC_CHAR.length; i++)
        {
            value = value.replaceAll("\\" + SPEC_CHAR[i], "\\\\\\"
                + SPEC_CHAR[i]);
        }
        return value;
    }
}
