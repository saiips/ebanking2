package com.dsb.eb2.util;
 
 
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLEventWriter;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import de.odysseus.staxon.json.JsonXMLConfig;
import de.odysseus.staxon.json.JsonXMLConfigBuilder;
import de.odysseus.staxon.json.JsonXMLInputFactory;
import de.odysseus.staxon.json.JsonXMLOutputFactory;
import de.odysseus.staxon.xml.util.PrettyXMLEventWriter;
/**
 * @author
 * 操作json的封装方法
 * 
 */
public class JSONUtils {
	
	 /**
     * 单位缩进字符串。
     */
    private static String SPACE = "   ";
    
	/**
	 * json转换成对象
	 * @param:传入对象，json字符串
	 * @return:Object
	 */
	public static Object JsonToObj(String jsonStr, Object obj) {
		if(StringUtils.isEmpty(jsonStr))
		{
			return obj;
		}
		return JSON.parseObject(jsonStr, obj.getClass());
	}
	
	public static Object JsonToObj(JSONObject jsonObj, Object obj)
	{
		String jsonStr = jsonObj.toJSONString();
		return JSONUtils.JsonToObj(jsonStr, obj);
	}
	
	/**
	 * 对象转换成json
	 * @param:传入对象
	 * @return:json字符串
	 */
	public static String objToJson(Object obj){
		return JSON.toJSONString(obj);
	}
	
	/**
	 * 对象转换成json
	 * @param:传入对象
	 * @return:json字符串
	 */
	public static String objToEmsJson(Object obj){
		String sourceStr = JSON.toJSONString(obj);
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("XMLReqMsg", sourceStr);
		return JSON.toJSONString(jsonObj);
	}
	
	/**
	 * 对象转换成json
	 * @param:json字符串
	 * @param:传入对象
	 * @return:json字符串
	 */
	public static Object jsonToArray(String jsonStr, Object obj)
	{
		return JSON.parseArray(jsonStr, obj.getClass());
	}
	
	
	/**
     * 返回格式化JSON字符串。
     * 
     * @param json 未格式化的JSON字符串。
     * @return 格式化的JSON字符串。
     */
    public String formatJson(String json)
    {
        StringBuffer result = new StringBuffer();
 
        int length = json.length();
        int number = 0;
        char key = 0;
        //遍历输入字符串。
        for (int i = 0; i < length; i++)
        {
            //1、获取当前字符。
            key = json.charAt(i);
 
            //2、如果当前字符是前方括号、前花括号做如下处理：
            if((key == '[') || (key == '{') )
            {
                //（1）如果前面还有字符，并且字符为“：”，打印：换行和缩进字符字符串。
                if((i - 1 > 0) && (json.charAt(i - 1) == ':'))
                {
                    result.append('\n');
                    result.append(indent(number));
                }
 
                //（2）打印：当前字符。
                result.append(key);
 
                //（3）前方括号、前花括号，的后面必须换行。打印：换行。
                result.append('\n');
 
                //（4）每出现一次前方括号、前花括号；缩进次数增加一次。打印：新行缩进。
                number++;
                result.append(indent(number));
 
                //（5）进行下一次循环。
                continue;
            }
 
            //3、如果当前字符是后方括号、后花括号做如下处理：
            if((key == ']') || (key == '}') )
            {
                //（1）后方括号、后花括号，的前面必须换行。打印：换行。
                result.append('\n');
 
                //（2）每出现一次后方括号、后花括号；缩进次数减少一次。打印：缩进。
                number--;
                result.append(indent(number));
 
                //（3）打印：当前字符。
                result.append(key);
 
                //（4）如果当前字符后面还有字符，并且字符不为“，”，打印：换行。
                if(((i + 1) < length) && (json.charAt(i + 1) != ','))
                {
                    result.append('\n');
                }
 
                continue;
            }
 
            //4、如果当前字符是逗号。逗号后面换行，并缩进，不改变缩进次数。
            if((key == ','))
            {
                result.append(key);
                result.append('\n');
                result.append(indent(number));
                continue;
            }
 
            //5、打印：当前字符。
            result.append(key);
        }
 
        return result.toString();
    }
 
    /**
     * 返回指定次数的缩进字符串。每一次缩进三个空格，即SPACE。
     * 
     * @param number 缩进次数。
     * @return 指定缩进次数的字符串。
     */
    private String indent(int number)
    {
        StringBuffer result = new StringBuffer();
        for(int i = 0; i < number; i++)
        {
            result.append(SPACE);
        }
        return result.toString();
    }
	
    public static JSONObject decryptBase64(String base64Str) throws Exception{
		if(base64Str == null || "".equals(base64Str)){
			return new JSONObject();
		}else{
			return JSONObject.parseObject(new String(Base64.decode(base64Str)));
		}
	}
	
	public static String encryptBase64(JSONObject jsonObj) throws Exception{
		if(jsonObj == null || "".equals(jsonObj)){
			return "";
		}else{
			return Base64.encode(jsonObj.toString().getBytes("UTF-8")).replace("\r\n", "");
		}
	}
	
	/**
	 * json string convert to xml string
	 */
	public static String json2xml(String json){
		StringReader input = new StringReader(json);
		StringWriter output = new StringWriter();
		JsonXMLConfig config = new JsonXMLConfigBuilder().multiplePI(false).repairingNamespaces(false).build();
		try {
			XMLEventReader reader = new JsonXMLInputFactory(config).createXMLEventReader(input);
			XMLEventWriter writer = XMLOutputFactory.newInstance().createXMLEventWriter(output);
			writer = new PrettyXMLEventWriter(writer);
			writer.add(reader);
			reader.close();
			writer.close();
		} catch( Exception e){
			e.printStackTrace();
		} finally {
			try {
				output.close();
				input.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if(output.toString().length()>=38){//remove <?xml version="1.0" encoding="UTF-8"?>
			return output.toString().substring(39);
		}
		return output.toString();
	}
	
	/**
	 * xml string convert to json string
	 */
	public static String xml2json(String xml){
		StringReader input = new StringReader(xml);
		StringWriter output = new StringWriter();
		JsonXMLConfig config = new JsonXMLConfigBuilder().autoArray(true).autoPrimitive(true).prettyPrint(true).build();
		try {
			XMLEventReader reader = XMLInputFactory.newInstance().createXMLEventReader(input);
			XMLEventWriter writer = new JsonXMLOutputFactory(config).createXMLEventWriter(output);
			writer.add(reader);
			reader.close();
			writer.close();
		} catch( Exception e){
			e.printStackTrace();
		} finally {
			try {
				output.close();
				input.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return output.toString();
	}
	
}