package com.dsb.eb2.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.nio.charset.IllegalCharsetNameException;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EncodeUtil {
	
	private static Logger logger = LoggerFactory.getLogger(EncodeUtil.class);
	public static final String CHARSET_UTF8 = "UTF-8";
	public static final String CHARSET_BIG5 = "big5";
	public static final String CHARSET_ISO88591 = "ISO-8859-1";
	public static final String CHARSET_CP1252 = "cp1252";
	
	public static String convert(String value, String fromCharSet, String toCharSet) throws UnsupportedEncodingException
	{
		return new String(value.getBytes(fromCharSet), toCharSet);
	}

	public static String encode(ResultSet rs, String colName, String toCharset) throws SQLException, IOException, UnsupportedEncodingException, IllegalCharsetNameException{
		return encode(rs.getBinaryStream(colName), toCharset);
	}

	public static String encode(InputStream is, String toCharset) throws IOException, UnsupportedEncodingException, IllegalCharsetNameException  {
		if (is == null) {
			return null;
		}

		if (toCharset == null || !Charset.isSupported(toCharset)) {
			return null;
		}
	
		byte[] byteArray = new byte[is.available()];
		is.read(byteArray, 0, is.available());

		return new String(byteArray, toCharset);	
	}

	public static String encode(String origStr, String toCharset) throws UnsupportedEncodingException {
		return new String(origStr.getBytes(), toCharset);
	}

	public static boolean checkFileEncoding(String fileName, String encoding) {
		FileInputStream fi;
		InputStreamReader ir; 	
		boolean result = false;
		try {
			fi = new FileInputStream(fileName);
			ir = new InputStreamReader(fi, encoding); 	

			ir.close();
			fi.close();
			
			logger.info("No Error. Encode in:" + encoding);
	
		}
		catch (Exception e) {
			logger.error("Error:"+ e);
		}	
		return result;
	}

	public static void main(String args[]) {
		checkFileEncoding(args[0], args[1]);
	}
}
