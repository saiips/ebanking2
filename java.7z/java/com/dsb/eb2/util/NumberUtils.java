package com.dsb.eb2.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.DecimalFormat;
import java.text.ParseException;

/**
 * 提供处理 Number 型对象的函数
 * 
 * 注意：解析/格式化 字符串使用的是 DecimalFormat
 * 
 * @author 
 * 
 * 
 */
public class NumberUtils
{
    /**
     * 把一个Number子类型对象转换成指定类型的另一个Number子类型对象 比如：Short -> Integer
     * 
     * @param number --
     *            待转换的对象
     * @param clazz --
     *            目标类型，必须是对象类型
     * @return 转换过的对象
     */
    public static Number transform(Number number, Class<?> clazz)
    {
        if (clazz == Byte.class)
        {
            return Byte.valueOf(number.byteValue());
        } else if (clazz == Short.class)
        {
            return Short.valueOf(number.shortValue());
        } else if (clazz == Integer.class)
        {
            return Integer.valueOf(number.intValue());
        } else if (clazz == Long.class)
        {
            return Long.valueOf(number.longValue());
        } else if (clazz == Float.class)
        {
            return new Float(number.floatValue());
        } else if (clazz == Double.class)
        {
            return new Double(number.doubleValue());
        } else if (clazz == BigInteger.class)
        {
            return new BigInteger(number.toString());
        } else if (clazz == BigDecimal.class)
        {
            return new BigDecimal(number.toString());
        }

        throw new IllegalArgumentException("[ Unsupported type: "
            + clazz.getName() + " ]");
    }

    // -------------------------解析/格式化--------------------------

    /**
     * 转换数值的字符串格式
     * 
     * 过程：parse -> format
     * 
     * @param numberString --
     *            数值字符串
     * @param currentFormat --
     *            当前格式
     * @param newFormat --
     *            新的格式
     * @return -- 新格式的字符串
     * @throws ParseException
     * @see #parse(String numberString, String format)
     * @see #format(Number number, String format)
     */
    public static String format(String numberString, String currentFormat,
        String newFormat) throws ParseException
    {
        Number number = parse(numberString, currentFormat);
        return format(number, newFormat);
    }

    /**
     * 以指定的格式解析number 字符串
     * 
     * @param numberString --
     *            待解析的number字符串
     * @param format --
     *            格式
     * @return Number对象
     * @throws ParseException
     */
    public static Number parse(String numberString, String format)
        throws ParseException
    {
        if (format == null)
        {
            format = getDefaultFormat(numberString);
        }
        return new DecimalFormat(format).parse(numberString);
    }

    /**
     * 使用指定的格式格式化数值对象，如果未指定格式，则采用默认的格式
     * 
     * @param number --
     *            待格式化的Number对象
     * @param format --
     *            用来格式化的格式
     * @return 格式化后的Number字符串
     * @see #getDefaultFormat(Number number)
     */
    public static String format(Number number, String format)
    {
        if (format == null)
        {
            format = getDefaultFormat(number);
        }
        return new DecimalFormat(format).format(number);
    }

    /**
     * 根据类型返回默认的格式 整型：#,##0 浮点型：#,##0.00
     * 
     * @param number --
     *            数值参数
     * @return 返回该对象类型对应的默认格式
     */
    public static String getDefaultFormat(Number number)
    {
        if ((number instanceof Byte) || (number instanceof Short)
            || (number instanceof Integer) || (number instanceof Long)
            || (number instanceof BigInteger))
        {
            return "#,##0";
        } else if ((number instanceof Float) || (number instanceof Double)
            || (number instanceof BigDecimal))
        {
            return "#,##0.00";
        }

        throw new IllegalArgumentException("[ Unsupported type: "
            + number.getClass().getName() + " ]");
    }

    /**
     * 识别指定的字符串，返回适合的格式
     * 
     * @param numberString --
     *            待识别的数值字符串
     * @return 适合该字符串的格式
     */
    public static String getDefaultFormat(String numberString)
    {
        numberString = numberString.trim();
        numberString = numberString.replaceAll("\\d", "#");
        return numberString;
    }
}
