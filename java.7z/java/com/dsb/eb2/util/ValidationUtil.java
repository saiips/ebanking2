package com.dsb.eb2.util;

import java.util.Date;

public class ValidationUtil {
    public static void validateObjectNull(Object value, String errorMsg) throws NullPointerException {
        if(value == null)
            throw new NullPointerException(errorMsg);
    }
    
    public static void validateNullableLongValue(Long value, String errorMsg) throws IllegalArgumentException, Exception {
        if(value != null && value.longValue() <= 0)
            throw new IllegalArgumentException(errorMsg);
    }
    
    public static void validateLongValue(Long value, String errorMsg) throws NullPointerException, IllegalArgumentException, Exception {
        ValidationUtil.validateObjectNull(value, errorMsg);
        if(value.longValue() <= 0)
            throw new IllegalArgumentException(errorMsg);
    }
    
    public static void validateNonEmptyStringValue(String value, String errorMsg) throws NullPointerException, IllegalArgumentException, Exception {
        ValidationUtil.validateObjectNull(value, errorMsg);
        if (value.trim().length() == 0)
            throw new IllegalArgumentException(errorMsg);
    }
    
    public static void validateDateValue(Date value, String errorMsg) throws NullPointerException {
        ValidationUtil.validateObjectNull(value, errorMsg);
        if(value == null)
            throw new NullPointerException(errorMsg);
    }    
    
    public static void validateDateValueByCurrentDate(Date value, String errorMsg) throws NullPointerException, Exception {
        ValidationUtil.validateObjectNull(value, errorMsg);
        Date currentTime = new Date();
        if(currentTime.compareTo(value) > 0) //parameter should not be less than current system time
            throw new IllegalArgumentException(errorMsg);
    }
    
    public static void validateIntegerValue(Integer value, String errorMsg) throws NullPointerException, IllegalArgumentException, Exception {
        ValidationUtil.validateObjectNull(value, errorMsg);
        if(value.intValue() < 0)
            throw new IllegalArgumentException(errorMsg);
    }
    
    public static void validateBooleanValue(Boolean value, String errorMsg) throws NullPointerException, Exception {
            ValidationUtil.validateObjectNull(value, errorMsg);
    }
    
    public static void validateBeforeGivenDate(Date inputDate, Date referrenceDate, String errorMsg)
        throws NullPointerException, Exception {
        ValidationUtil.validateObjectNull(inputDate, "Input date cannot be null");
        ValidationUtil.validateObjectNull(referrenceDate, "Reference date cannot be null");
        if (!(inputDate.compareTo(referrenceDate) < 0)) {
            throw new IllegalArgumentException(errorMsg);    
        }
    }
    
    public static void validateBeforeOrEqualGivenDate(Date inputDate, Date referrenceDate, String errorMsg)
        throws NullPointerException, Exception {
        ValidationUtil.validateObjectNull(inputDate, "Input date cannot be null");
        ValidationUtil.validateObjectNull(referrenceDate, "Reference date cannot be null");
        if (!(inputDate.compareTo(referrenceDate) <= 0 )) {
            throw new IllegalArgumentException(errorMsg);    
        }
    }
    
    public static void validateAfterGivenDate(Date inputDate, Date referrenceDate, String errorMsg)
        throws NullPointerException, Exception {
        ValidationUtil.validateObjectNull(inputDate, "Input date cannot be null");
        ValidationUtil.validateObjectNull(referrenceDate, "Reference date cannot be null");
        if (!(inputDate.compareTo(referrenceDate) > 0)) {
            throw new IllegalArgumentException(errorMsg);    
        }
    }
    
    public static void validateAfterOrEqualGivenDate(Date inputDate, Date referrenceDate, String errorMsg)
        throws NullPointerException, Exception {
        ValidationUtil.validateObjectNull(inputDate, "Input date cannot be null");
        ValidationUtil.validateObjectNull(referrenceDate, "Reference date cannot be null");
        if (!(inputDate.compareTo(referrenceDate) >= 0)) {
            throw new IllegalArgumentException(errorMsg);    
        }
        
    }
    
    public static void validateWithinGivenDateRange(Date inputDate, Date referenceStartDate, Date referenceEndDate, String errorMsg)
        throws NullPointerException, Exception {
        ValidationUtil.validateObjectNull(inputDate, "Input date cannot be null");
        ValidationUtil.validateObjectNull(referenceStartDate, "Reference start date cannot be null");
        ValidationUtil.validateObjectNull(referenceEndDate, "Reference end date cannot be null");
        if (!(inputDate.compareTo(referenceStartDate) >= 0) && (inputDate.compareTo(referenceEndDate) <= 0)) {
            throw new IllegalArgumentException(errorMsg);    
        }
    }
}
