package com.dsb.eb2.util;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>
 * 字节处理类 提供一些常用的字符处理函数
 * </p>
 * 
 * @author 
 * 
 */
public class ByteUtils
{
    /**
     * 2个字节数组相加
     * 
     * @param first
     * @param second
     * @return
     */
    public static byte[] add(byte[] first, byte[] second)
    {
        byte[] sum = new byte[first.length + second.length];
        System.arraycopy(first, 0, sum, 0, first.length);
        System.arraycopy(second, 0, sum, first.length, second.length);
        return sum;
    }

    /**
     * 2个字节数组相加
     * 
     * @param first --
     *            第一个字节数组
     * @param firstStartPos --
     *            第一个字节起始位置
     * @param firstEndPos --
     *            第一个字节结束位置
     * @param second --
     *            第二个字节数组
     * @param secondStartPos --
     *            第二个字节起始位置
     * @param secondEndPos --
     *            第二个字节结束位置
     * @return -- sum
     */
    public static byte[] add(byte[] first, int firstStartPos, int firstEndPos,
        byte[] second, int secondStartPos, int secondEndPos)
    {
        int fNum = firstEndPos - firstStartPos;
        int sNum = secondEndPos - secondStartPos;

        byte[] sum = new byte[fNum + sNum];
        System.arraycopy(first, firstStartPos, sum, 0, fNum);
        System.arraycopy(second, secondStartPos, sum, fNum, sNum);
        return sum;
    }

    /**
     * 1个字节数组加一个字节
     * 
     * @param first
     * @param second
     * @return
     */
    public static byte[] add(byte[] first, byte second)
    {
        return add(first, new byte[] { second });
    }

    /**
     * 一个字节加1个字节数组
     * 
     * @param first
     * @param second
     * @return
     */
    public static byte[] add(byte first, byte[] second)
    {
        return add(new byte[] { first }, second);
    }

    /**
     * 把无符号的字节转成有符号的字节
     * 
     * @param c
     * @return
     */
    public static byte toSignedByte(int c)
    {
        if (c > 127)
        {
            return (byte) (c - 256);
        }
        return (byte) c;
    }

    /**
     * 把有符号的字节转成无符号的字节
     * 
     * @param b
     * @return
     */
    public static int toUnsignedByte(byte b)
    {
        if (b < 0)
        {
            return b + 256;
        }
        return b;
    }

    /**
     * 转换成16进制字符串
     * 
     * @param b
     * @return
     */
    public static String toHexString(byte b)
    {
        String s = Integer.toHexString(toUnsignedByte(b));
        if (s.length() == 1) return "0" + s;
        return s;
    }

    /**
     * 转换成16进制字符串
     * 
     * @param bytes
     * @return
     */
    public static String toHexString(byte[] bytes)
    {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < bytes.length; i++)
        {
            sb.append(toHexString(bytes[i]));
        }
        return sb.toString();
    }

    /**
     * 把16进制字符串转换成字节码，与toHexString对应
     * 
     * @param hex --
     *            16进制的字符串，长度必须为2的倍数
     * @return -- 字节码，2个字符对应一个字节
     */
    public static byte[] fromHexString(String hex)
    {
        byte[] bytes = new byte[hex.length() / 2];
        for (int i = 0; i < hex.length() / 2; i++)
        {
            bytes[i] = (byte) Integer.parseInt(
                hex.substring(i * 2, (i + 1) * 2), 16);
        }
        return bytes;
    }

    /**
     * 分割数组
     * 
     * @param data --
     *            待分割数据
     * @param delimiter --
     *            分割符
     * @return -- 数组的数组
     */
    public static byte[][] split(byte[] data, byte delimiter)
    {
        return split(data, new byte[] { delimiter });
    }

    /**
     * 分割数组
     * 
     * @param data --
     *            待分割数据
     * @param delimiter --
     *            分割符
     * @return -- 数组的数组ArrayList<byte[]>
     */
    public static byte[][] split(byte[] data, byte[] delimiter)
    {
        if (delimiter.length == 0) return new byte[][] { data };

        List<byte[]> result = new ArrayList<byte[]>();
        int index = 0;
        outer: for (int i = 0; i < data.length; i++)
        {
            if (data.length - i < delimiter.length)
            {
                byte[] newBytes = new byte[data.length - index];
                System.arraycopy(data, index, newBytes, 0, newBytes.length);
                result.add(newBytes);
                break;
            }

            if (data.length - i == delimiter.length)
            {
                boolean match = true;
                for (int j = 0; j < delimiter.length; j++)
                {
                    if (data[i + j] != delimiter[j])
                    {
                        match = false;
                        break;
                    }
                }
                if (match)
                {
                    byte[] newBytes = new byte[data.length - index
                        - delimiter.length];
                    System.arraycopy(data, index, newBytes, 0, newBytes.length);
                    result.add(newBytes);
                    result.add(new byte[] {});
                } else
                {
                    byte[] newBytes = new byte[data.length - index];
                    System.arraycopy(data, index, newBytes, 0, newBytes.length);
                    result.add(newBytes);
                }

                break;
            }

            for (int j = 0; j < delimiter.length; j++)
            {
                if (data[i + j] != delimiter[j]) continue outer;
            }

            byte[] newBytes = new byte[i - index];
            System.arraycopy(data, index, newBytes, 0, newBytes.length);
            result.add(newBytes);

            i += delimiter.length;
            index = i;
            i--; //补偿
        }
        return (byte[][]) result.toArray(new byte[result.size()][]);
    }

    /**
     * 比较是否相等
     * 
     * @param b1 --
     *            byte[]
     * @param b2 --
     *            byte[]
     * @return -- boolean
     */
    public static boolean equals(byte[] b1, byte[] b2)
    {
        return toHexString(b1).equals(toHexString(b2));
    }

    public static void main(String[] args) throws UnsupportedEncodingException
    {
//        byte[] data = { 3, 4, 1, 3, 5, 4, 1, 3, 1 };
//        byte[] delimiter = { 5 };
//        byte[][] result = split(data, delimiter);
//
    }

}
