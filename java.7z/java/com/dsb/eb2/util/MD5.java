package com.dsb.eb2.util;

import java.security.MessageDigest;

public class MD5 {
        public static String byte2hex(byte[] b) {
                String hs = ""; 
                String stmp = ""; 
                for (int n = 0; n < b.length; n++) { 
                        stmp = (java.lang.Integer.toHexString(b[n] & 0XFF)); 
                        if (stmp.length() == 1) { 
                                hs = hs + "0" + stmp; 
                        } 
                        else { 
                                hs = hs + stmp; 
                        } 
                } 
                return hs.toUpperCase(); 
        } 	
        public String genHashValue(String newVal) throws Exception {
                MessageDigest md5 = MessageDigest.getInstance("MD5");
        	byte[] rawData = newVal.getBytes();
        	md5.update(rawData);
        	byte[] hashVal = md5.digest();
        	return byte2hex(hashVal);
        }
}