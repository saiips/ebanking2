package com.dsb.eb2.util;

import java.util.Map;

public class CollectionUtil {
	
	public static boolean isEmpty(Map<String, Object> map) {
		boolean falg = false;
		if(map == null || map.isEmpty()) {
			falg = true;
		}
		if(map.entrySet().isEmpty()) {
			falg = true;
		}
		return falg;
	}
}
