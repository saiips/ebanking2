package com.dsb.eb2.util;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dsb.eb2.framework.controller.ApiGateway;

/**
 * <p>
 * 格式化对象，只支持Date和Number类型
 * </p>
 * 
 * @author 
 * 
 */
public class FormatUtils
{

	private static Logger logger = LoggerFactory.getLogger(FormatUtils.class);
	
    /**
     * 使用默认的格式进行格式化
     * 
     * @param value --
     *            待格式化的对象
     * @return -- 默认格式的字符串对象
     * @see #format(Object value, String formatString)
     */
    public static String format(Object value)
    {
        return format(value, null);
    }

    /**
     * 使用指定的格式进行格式化
     * 
     * @param value --
     *            待格式化的对象
     * @param formatString --
     *            用来格式化的格式
     * @return -- formatString格式 的字符串对象
     */
    public static String format(Object value, String formatString)
    {
        if (value instanceof Number)
        {
            return NumberUtils.format((Number) value, formatString);
        } else if (value instanceof Date)
        {
            return DateUtils.format((Date) value, formatString);
        } else
        {
            return value.toString();
        }
    }
    
    
    public static String getStackTrace(Exception exception)
  	{
  		String s = "null";
  		try
  		{
  			if(exception != null)
  			{
  				Writer writer = new StringWriter();
  				PrintWriter printWriter = new PrintWriter(writer);
  				exception.printStackTrace(printWriter);
  				s = writer.toString();
  			}
  		}catch (Exception e)
  		{
  			try
  			{
  				logger.info("FormatUtils.getStackTrace catch a exception : " + e.getMessage() + " | " + e);
  			} catch (Exception e2) {
  				e2.printStackTrace();
  			}
  		}
  		return s;
  	}

}
