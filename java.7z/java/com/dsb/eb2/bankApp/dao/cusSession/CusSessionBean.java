package com.dsb.eb2.bankApp.dao.cusSession;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.dsb.eb2.framework.model.Base;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@NoArgsConstructor
@Getter @Setter
@Table(name="CUS_SESSION")
public class CusSessionBean extends Base {
	
	@Transient
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue
	@Column(name="SESSION_ID",nullable=false)
	@JsonProperty("SESSION_ID")
	private String sessionId; 
	
	@Column(name="STATUS")
	@JsonProperty("STATUS")
	private String status;

	@Override
	public String toString() {
		return "CusSession [sessionId=" + sessionId + ", status=" + status + "]";
	}
	
}
