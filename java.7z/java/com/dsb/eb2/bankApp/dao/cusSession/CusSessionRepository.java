package com.dsb.eb2.bankApp.dao.cusSession;



import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dsb.eb2.framework.repository.BaseRepository;

/*
 * UPDATE/ INSERT /DELETE CusSession table
 */

@Repository
public interface CusSessionRepository extends BaseRepository<CusSessionBean, String> {
    
	
	    @Modifying
	    @Query(value = "INSERT INTO CUS_SESSION(SESSION_ID,STATUS,VERSION) values(?1,?2,?3)",nativeQuery=true)
	    @Transactional
	    public int insertCusSession(String SESSION_ID,String STATUS,Long VERSION);
	    
	    
       

}
