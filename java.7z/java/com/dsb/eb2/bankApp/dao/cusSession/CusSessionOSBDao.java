package com.dsb.eb2.bankApp.dao.cusSession;

import java.io.IOException;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.dsb.eb2.framework.controller.ApiGateway;
import com.dsb.eb2.framework.log.Loggable;
import com.dsb.eb2.util.JSONUtils;

import lombok.NoArgsConstructor;

@Loggable
@Component
@NoArgsConstructor
public class CusSessionOSBDao extends ApiGateway{
	
	public JSONObject checkSessionUIDIsvalidate(Map<String,String> map)throws IOException, Exception {
		String serviceURL = super.getGatewayURL() + "/CusSession/GetStaBySessionIdService/submit";
		String response = super.doRequest("DATA", "POST", "OTHERS", "N", null, serviceURL, "POST", JSONUtils.objToJson(map));
		return (JSONObject)JSONUtils.JsonToObj(response, new JSONObject());
	}
}
