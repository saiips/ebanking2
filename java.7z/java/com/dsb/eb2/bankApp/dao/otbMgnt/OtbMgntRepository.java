package com.dsb.eb2.bankApp.dao.otbMgnt;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dsb.eb2.framework.repository.BaseRepository;

@Repository
public interface OtbMgntRepository extends BaseRepository<OtbMgntBean, String> {

	@Query(value="UPDATE CUS_OTB_MGNT SET REFER_NO=:refno, CREATE_DATE = TO_DATE(:createTime,'yyyymmddhh24miss')," + 
			"RETRY_COUNT=0,IP_ADDR=:ip, ENCRYPTED_KEY=:OTP WHERE CUST_ID =:custId",nativeQuery=true)
	@Modifying
	public void updateSMSOTP(@Param("refno")String refno,@Param("createTime")String createTime,@Param("ip")String ip,@Param("OTP")String OTP,@Param("custId")String custId); 
	@Query(value="INSERT INTO CUS_OTB_MGNT (REFER_NO,CUST_ID,CREATE_DATE,RETRY_COUNT,IP_ADDR,ENCRYPTED_KEY)" + 
			"VALUES(:refno,:custId,TO_DATE(:createTime,'yyyymmddhh24miss'),0,:ip,:OTP)",nativeQuery=true)
	@Modifying
	public void insertSMSOTP(@Param("refno")String refno,@Param("custId")String custId,@Param("createTime")String createTime,@Param("ip")String ip,@Param("OTP")String OTP); 
	@Query(value="UPDATE CUS_OTB_MGNT SET RETRY_COUNT=:count WHERE CUST_ID =:custId",nativeQuery=true)
	@Modifying
	public void updateSMSOTPFailCount(@Param("count")int count,@Param("custId")String custId); 

	@Query(value="DELETE FROM CUS_OTB_MGNT WHERE CUST_ID =:custId",nativeQuery=true)
	@Modifying
	public void deleteSMSOTP(@Param("custId")String custId); 
}




