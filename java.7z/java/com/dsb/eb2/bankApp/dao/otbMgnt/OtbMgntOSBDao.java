package com.dsb.eb2.bankApp.dao.otbMgnt;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.logging.LogLevel;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.System.exeption.SystemException;
import com.dsb.eb2.framework.controller.ApiGateway;
import com.dsb.eb2.framework.log.Loggable;
import com.dsb.eb2.sso.controller.LoginController;
import com.dsb.eb2.util.FormatUtils;
import com.dsb.eb2.util.JSONUtils;
import com.dsb.eb2.util.StringUtils;

@Component
@Loggable
public class OtbMgntOSBDao extends ApiGateway{
	private static Logger log = LoggerFactory.getLogger(LoginController.class);
	//SELECT REFER_NUM FROM CUS_OTB_MGNT WHERE CUST_ID = ?
	@Loggable(result = false, value = LogLevel.INFO)
	public boolean selectSMSOTP(Map<String,String> map) throws SystemException{
		boolean flag = false;
		JSONObject json = null;
		String REFER_NO = "";
		try {
//			String serviceURL = "http://10.26.129.131:7001" + "/CusOtbMgnt/GetReferNumByCustIDService/submit";
			String serviceURL = super.getGatewayURL() + "/CusOtbMgnt/GetReferNumByCustIDService/submit";
			String response = super.doRequest("DATA", "POST", "OTHERS", "N", null, serviceURL, "POST", JSONUtils.objToJson(map));
			json = (JSONObject)JSONUtils.JsonToObj(response, new JSONObject());
			REFER_NO = json.getString("REFER_NUM");
			if(!StringUtils.isEmpty(REFER_NO)) {
				flag = true;
			}
		}catch(Exception e) {
			log.info(FormatUtils.getStackTrace(e));
			throw new SystemException(SystemStatusCode.SCC_SEND_SMS_OTP_ERROR);
		}
		return flag;
	}
	//SELECT REFER_NUM,TO_CHAR(CREATE_DATE,'yyyymmddhh24miss') AS CREATE_DATE,RETRY_COUNT,IP_ADDR,ENCRYPT_KEY FROM CUS_OTB_MGNT WHERE CUST_ID = ?
	@Loggable(result = false, value = LogLevel.INFO)
	public OtbMgntBean selectOTP(String CUST_ID)throws SystemException {
		OtbMgntBean OtbMgntBean = new OtbMgntBean();
		Map<String,String> map = new HashMap<String,String>();
		JSONObject json = null;
		String refNo = "";
		String ip = "";
		int failcount = 0;
		String otp = "";
		String createTime = "";
		try {
			map.put("CUST_ID", CUST_ID);
//			String serviceURL = "http://10.26.129.131:7001" + "/CusOtbMgnt/GetReferNumAndIPByCustIDService/submit";
			String serviceURL = super.getGatewayURL() + "/CusOtbMgnt/GetReferNumAndIPByCustIDService/submit";
			String response = super.doRequest("DATA", "POST", "OTHERS", "N", null, serviceURL, "POST", JSONUtils.objToJson(map));
			json = (JSONObject)JSONUtils.JsonToObj(response, new JSONObject());
			refNo = json.getString("REFER_NUM");
			createTime = json.getString("CREATE_DATE");
			failcount = Integer.valueOf(json.getString("RETRY_COUNT"));
			ip = json.getString("IP_ADDR");
			otp = json.getString("ENCRYPT_KEY");
			OtbMgntBean.setCustId(CUST_ID);
			OtbMgntBean.setRefNo(refNo);
			OtbMgntBean.setCreateTime(createTime);
			OtbMgntBean.setFailcount(failcount);
			OtbMgntBean.setIp(ip);
			OtbMgntBean.setOtp(otp);
		}catch(Exception e) {
			log.info(FormatUtils.getStackTrace(e));
			throw new SystemException(SystemStatusCode.SSC_UNEXPECTED);
		}
		return OtbMgntBean;
	}
}
