package com.dsb.eb2.bankApp.dao.otbMgnt;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.dsb.eb2.framework.model.Base;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="CUS_OTB_MGNT")
@Getter @Setter @NoArgsConstructor
public class OtbMgntBean extends Base{
	
	@Transient
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="CUST_ID", unique=true, nullable = false)
	@JsonProperty("CUST_ID")
	private String custId;
	
	@Column(name="REFER_NUM")
	@JsonProperty("REFER_NUM")
	private String refNo;
	
	@Column(name="IP_ADDR")
	@JsonProperty("IP_ADDR")
	private String ip;
	
	@Column(name="RETRY_COUNT")
	@JsonProperty("RETRY_COUNT")
	private int failcount;
	
	@Column(name="ENCRYPT_KEY")
	@JsonProperty("ENCRYPT_KEY")
	private String otp;
	
	@Column(name="CREATE_DATE")
	@JsonProperty("CREATE_DATE")
	private String createTime;
	
	private String Private_key;
	
	private String Public_key;
	
}

