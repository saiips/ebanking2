package com.dsb.eb2.bankApp.dao.cardTypeDef;

import javax.persistence.Column;
import javax.persistence.Id;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class CardTypeDef {
	
	@Id
	@Column(name="CARD_TYPE")
	public String	cardType;
	
	@Column(name="ACCT_TYPE")
	public String	acctType;
	
	@Column(name="PROD_SUB_CODE")
	public String	proSubCode;
	
	@Column(name="TABLE1")
	public String	table1;
	
	@Column(name="TABLE2")
	public String	table2;

}
