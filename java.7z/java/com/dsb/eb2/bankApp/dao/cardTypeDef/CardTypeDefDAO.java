package com.dsb.eb2.bankApp.dao.cardTypeDef;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.dsb.eb2.framework.controller.ApiGateway;
import com.dsb.eb2.framework.util.WebAppProperties;


public class CardTypeDefDAO extends ApiGateway{
	
	@Autowired
	private WebAppProperties webapp;
	
	public CardTypeDef getCardTypeDef(String cardType) throws IOException, Exception {

		String url = webapp.getUrl() + "/BranchService/GetAllBranch?cardType=\" + cardType";

		CardTypeDef detail = (CardTypeDef) super.getObject(url, "", CardTypeDef.class);

		return detail;
	}
	
	public List<CardTypeDef> getCardTypeDefList() throws IOException, Exception {

		String url = webapp.getUrl() + "/BranchService/GetAllBranch";

		List<CardTypeDef> cardTypeDefList =  new ArrayList<CardTypeDef>();

		return cardTypeDefList;
	}

}
