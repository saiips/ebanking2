package com.dsb.eb2.bankApp.dao.activityLog;

import java.util.Date;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dsb.eb2.framework.repository.BaseRepository;


@Repository
@Transactional
public interface ActivityLogRepository extends BaseRepository<ActivityLogBean, String> {

	
	@Query(value = "INSERT INTO LOG_ACTIVITY_RECORD(CUST_ID, MAIN_TYPE, SUB_TYPE, EXTEND_TYPE, RETURN_CODE,CHANNEL_CODE, DETAIL, CREATION_DATE, SESSION_ID) values(?1,?2,?3,?4,?5,?6,?7,?8,?9)",nativeQuery=true)
	@Modifying
	public void insertActivityLogBean(@Param("CUST_ID") String CUST_ID,@Param("MAIN_TYPE") int MAIN_TYPE,@Param("SUB_TYPE") int SUB_TYPE, @Param("EXTEND_TYPE") int EXTEND_TYPE,
			@Param("RETURN_CODE") int RETURN_CODE,@Param("CHANNEL_CODE") String CHANNEL_CODE,@Param("DETAIL") String DETAIL,@Param("CREATION_DATE") Date CREATION_DATE,@Param("SESSION_ID") String SESSION_ID);
	
	@Query(value="UPDATE LOG_ACTIVITY_RECORD SET MAIN_TYPE =:MAIN_TYPE WHERE SUB_TYPE =:SUB_TYPE", nativeQuery=true)
	@Modifying
	void updateActivityLog(@Param("MAIN_TYPE")int MAIN_TYPE,@Param("SUB_TYPE")int SUB_TYPE);
    
}
