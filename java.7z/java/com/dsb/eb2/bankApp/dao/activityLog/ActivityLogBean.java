package com.dsb.eb2.bankApp.dao.activityLog;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.dsb.eb2.bankApp.System.FunctionType;
import com.dsb.eb2.framework.model.Base;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Entity
@Table(name="LOG_ACTIVITY_RECORD")
@Data
public class ActivityLogBean extends Base{
	
	@Transient
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="CUST_ID", nullable = false)
	@JsonProperty("CUST_ID")
	private String custId;
	
	
	@Column(name="MAIN_TYPE", nullable = false)
	@JsonProperty("MAIN_TYPE")
	private int mainType;
	
	@Column(name="SUB_TYPE", nullable = false)
	@JsonProperty("SUB_TYPE")
	private int subType;

	
	@Column(name="EXTEND_TYPE", nullable = false)
	@JsonProperty("EXTEND_TYPE")
	private int extendedType = FunctionType.ET_NOT_APPLICABLE;
	
	@Column(name="RETURN_CODE")
	@JsonProperty("RETURN_CODE")
	private int returnCode;
	
	@Column(name="CHANNEL_CODE")
	@JsonProperty("CHANNEL_CODE")
	private String channelCode = "EB";
	
	@Column(name="DETAIL")
	@JsonProperty("DETAIL")
	private String details;
	
	
	@Column(name="CREATION_DATE", nullable = false)
	@JsonProperty("CREATION_DATE")
	private java.util.Date creationDate;
    
	@Column(name="SESSION_ID")
	@JsonProperty("SESSION_ID")
	private String sessionId;

	public ActivityLogBean(String custId, int mainType, int subType) {
		super();
		this.custId = custId;
		this.mainType = mainType;
		this.subType = subType;
	}
	
	public ActivityLogBean(String custId, int mainType, int subType, int returnCode) {
		super();
		this.custId = custId;
		this.mainType = mainType;
		this.subType = subType;
		this.returnCode = returnCode;
	}

	public ActivityLogBean(String custId, int mainType, int subType, int returnCode, String details) {
		super();
		this.custId = custId;
		this.mainType = mainType;
		this.subType = subType;
		this.returnCode = returnCode;
		this.details = details;
	}
	
	public ActivityLogBean(String custId, int mainType, int subType, int returnCode, String channelCode,
			String details) {
		super();
		this.custId = custId;
		this.mainType = mainType;
		this.subType = subType;
		this.returnCode = returnCode;
		this.channelCode = channelCode;
		this.details = details;
	}

	public ActivityLogBean() {
		super();
		// TODO Auto-generated constructor stub
	}

}

