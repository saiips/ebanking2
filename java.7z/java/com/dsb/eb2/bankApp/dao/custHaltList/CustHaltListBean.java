package com.dsb.eb2.bankApp.dao.custHaltList;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter @Setter
public class CustHaltListBean implements Serializable {


	private static final long serialVersionUID = 1L;
	
	
	@GeneratedValue
	@Column(name="ID_TYPE")
	private String idType;
	
	@Id
	@Column(name="LOGIN_ID")
	private String loginId;
	
	@Column(name="UPDATE_DATETIME")
	private String updateDatetime;
	
	@Column(name="CUST_ID")
	private String custId;
	
	@Column(name="SUSPEND_STATUS")
	private String suspendStatus;
	
	@Column(name="REASON")
	private String reason;
	
	@Column(name="UPDATE_STATUS_BY")
	private String updateStatusBy;
	
	
	
}
