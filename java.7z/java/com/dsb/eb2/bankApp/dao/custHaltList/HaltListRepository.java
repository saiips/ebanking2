package com.dsb.eb2.bankApp.dao.custHaltList;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dsb.eb2.framework.repository.BaseRepository;

@Repository
public interface HaltListRepository extends BaseRepository<CustHaltListBean, String>{
	
	@Query(value="SELECT CUST_ID, SUSPEND_STATUS FROM CUS_HALT_LIST  WHERE CUST_ID =:custId", nativeQuery=true)
	@Modifying
	List<CustHaltListBean> selectHaltList(@Param("custId")String custId);
}
