package com.dsb.eb2.bankApp.dao.custHaltList;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustHaltListService {

	@Autowired
	private CustHaltListDao custHaltListDao;
	
	@Autowired
	private HaltListRepository haltListRepository;

	
	public List<CustHaltListBean> checkhalt(String custId) throws IOException, Exception{
		//List<CustHaltListBean> haltList = (List<CustHaltListBean>) custHaltListDao.getAllHalt();
		List<CustHaltListBean> haltList = haltListRepository.selectHaltList(custId);
		return haltList;

	}
	
}
