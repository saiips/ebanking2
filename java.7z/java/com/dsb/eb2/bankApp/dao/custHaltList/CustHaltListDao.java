package com.dsb.eb2.bankApp.dao.custHaltList;

import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Component;

import com.dsb.eb2.framework.controller.ApiGateway;

@Component
public class CustHaltListDao  extends ApiGateway {

	public List<CustHaltListBean> getAllHalt() throws IOException, Exception {
		String url = super.getGatewayURL() + "/custHaltListService/getAllHalt";
		List<CustHaltListBean> allBranchList = (List<CustHaltListBean>)super.getObject(url, "", CustHaltListBean.class);
		return allBranchList;
	}

}
