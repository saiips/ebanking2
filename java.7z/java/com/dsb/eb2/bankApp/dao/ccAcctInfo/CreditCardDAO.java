package com.dsb.eb2.bankApp.dao.ccAcctInfo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.dsb.eb2.framework.controller.ApiGateway;
import com.dsb.eb2.framework.log.Loggable;
import com.dsb.eb2.framework.util.WebAppProperties;
import com.dsb.eb2.util.JSONUtils;

@Service
@Loggable
public class CreditCardDAO extends ApiGateway {

	@Autowired
	private WebAppProperties webapp;

	public CreditCardInfo getCreditCardDetail(String acctNum) throws IOException, Exception {

		String url = webapp.getUrl() + "/BranchService/GetAllBranch?acctNum=\" + acctNum";

		CreditCardInfo detail = (CreditCardInfo) super.getObject(url, "", CreditCardInfo.class);

		return detail;
	}
	
	public List<CreditCardInfo> getAllCreditCardList(String custId) throws IOException, Exception{
		
		String url = webapp.getUrl() + "/CreditCardService/GetAllCreditCardList?custId=\" + custId";

		List<CreditCardInfo> cclist = (ArrayList<CreditCardInfo>) super.getObject(url, "", CreditCardInfo.class);

		return cclist;
	}

	public JSONObject getCustNumByCustId(Map<String,String> map) throws Exception, Exception  {
		String url = webapp.getUrl() + "cusCcAcctInfo/GetCustNumByCustIdAndCusNumService/submit?";
		String custNum =(String)super.getObject(url, "", CreditCardInfo.class);   //取第一个
		String response = super.doRequest("DATA", "POST", "OTHERS", "N", null, url, "POST", JSONUtils.objToJson(map));
		return (JSONObject)JSONUtils.JsonToObj(response, new JSONObject());
	}
	
	public String getCustIdByAcctNum(String acctNum) throws Exception {
		String custId = "";
    	try {    		
			String serviceURL = super.getGatewayURL() + "/cusCcAcctInfo/GetCustIdByCCAcctNumService/submit";
			Map<String,String> map = new HashMap<String,String>();
			map.put("ACCT_NUM", acctNum);
			String requestPayload =  JSONUtils.objToJson(map);
	    	String type = "DATA";			
	    	String responsePayload  = super.doRequest(type, "POST", "OTHERS", "N", null, serviceURL, "POST", requestPayload);
	    	System.out.println("requestPayload="+requestPayload);
	    	System.out.println("responsePayload="+responsePayload);
	    	custId = JSONObject.parseObject(responsePayload).getString("CUST_ID");	  
	    	System.out.println("custId="+custId);
		}catch(Exception e) {
			throw e;
		}
		return custId;
	}

	public String getPrimProf(String custNum,String custId) {
		
		return null;
	}
	
	public String getSuppProf(String custId) {
		
		return null;
	}

}
