package com.dsb.eb2.bankApp.dao.ccAcctInfo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;

import com.dsb.eb2.backOffice.connect.emsMsg.nf1107.AcctDetails;
import com.dsb.eb2.bankApp.dao.cardTypeDef.CardTypeDef;
import com.dsb.eb2.bankApp.dao.cardTypeDef.CardTypeDefDAO;
import com.dsb.eb2.util.Env;


public class CreditCardService {

	@Autowired
	private CreditCardDAO ccAcctInfoDao;
	
	@Autowired
	private CardTypeDefDAO dao;
	
	private List<CardTypeDef> cardTypeDefList;

	public List<CardTypeDef> getCardTypeDefList() throws IOException, Exception {
		cardTypeDefList = dao.getCardTypeDefList();
		return cardTypeDefList;
	}

	public void setCardTypeDefList(List<CardTypeDef> cardTypeDefList) {
		this.cardTypeDefList = cardTypeDefList;
	}

	public CreditCardInfo getDBCreditCardDetail(String acctNum) throws IOException, Exception {

		CreditCardInfo detail = ccAcctInfoDao.getCreditCardDetail(acctNum);

		return detail;

	}

	public List<CreditCardInfo> getDBAllCreditCardList(String custId) throws IOException, Exception {

		List<CreditCardInfo> cclist = ccAcctInfoDao.getAllCreditCardList(custId);

		return cclist;
	}	
	
	public CardTypeDef getCardTypeDefByCardType(String cardType) throws IOException, Exception {
		
		CardTypeDef cardTypeDef = dao.getCardTypeDef(cardType);
		return cardTypeDef;
	}

//	public Env getCreditCardList(String custId) {
//		String custNum = ccAcctInfoDao.getCustNumByCustId(custId);
//		Env response = new Env();
//		return response;
//	}

	public Env getPrimProfEnv(String custNum, String custId, Env response) {

		String primProf = ccAcctInfoDao.getPrimProf(custNum, custId);
		return response;

	}

	public Env getSuppProfEnv(String custId, Env response) {

		String suppProf = ccAcctInfoDao.getSuppProf(custId);
		return response;
	}
	
	public List<AcctDetails> getCreditCardList(String custId) throws IOException, Exception
	{
		List<CreditCardInfo> dbList = getDBAllCreditCardList(custId);
		List<AcctDetails> detailList =  new ArrayList<AcctDetails>();
		Map<String,String> subTypeList = getSubTypeList();
		String acctNum = null;
		String acctType = null;
		String proSubCode = null;
		String balance = null;
		String status = null;
		String iAcctInd = null;
		
		if(dbList != null && dbList.size() > 0) {
			for(CreditCardInfo info : dbList) {
				acctNum = info.getAcctNum();
				acctType = info.getCardType();
				proSubCode = subTypeList.get(acctType);
				balance =  info.getOutstandBalance();
				status = info.getCardStatus();
				iAcctInd = "N";
				AcctDetails detail = new AcctDetails();
				detail.setAcctNum(acctNum);;
				detail.setAcctType(acctType);
				detail.setProdSubCode(proSubCode);
				detail.setBalance(balance);
				detail.setStatusCode(status);
				detail.setIacctInd(iAcctInd);
				detailList.add(detail);
			}			
		}
		return detailList;
	}
	
	public Map<String,String> getSubTypeList(){
		
		Map<String,String> subTypeList = new HashMap<String,String>();
		for(CardTypeDef def : cardTypeDefList) {
			subTypeList.put(def.getCardType(), def.getProSubCode());
		}
		return subTypeList;		
	}

}
