package com.dsb.eb2.bankApp.dao.ccAcctInfo;

import javax.persistence.Column;
import javax.persistence.Id;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class CreditCardInfo {
	
	@Id
	@Column(name="ACCT_NUM")
	public String	acctNum;
	
	@Column(name="CUST_ID")
	public String	custId;
	
	@Column(name="CUST_NUM")
	public String	custNum;
	
	@Column(name="CARD_TYPE")
	public String	cardType;
	
	@Column(name="CUST_TITLE")
	public String	custTitle;
	
	@Column(name="CUST_NAME")
	public String	custName;
	
	@Column(name="BLOCK_CODE")
	public String	blockCode;
	
	@Column(name="CARD_STATUS")
	public String	cardStatus;
	
	@Column(name="STMT_FLAG")
	public String	stmtFlag;
	
	@Column(name="AVAIL_LIMIT")
	public String	availLimit;
	
	@Column(name="CREDIT_LIMIT")
	public String	creditLimit;
	
	@Column(name="OUTSTAND_BAL")
	public String	outstandBalance;
	
	@Column(name="PAY_DUE_DATE")
	public String	payDueDate;
	
	@Column(name="HOLDER_ORG")
	public String	holderOrg;
	
	@Column(name="HOLDER_CARD_TYPE")
	public String	holderCardType;
	
	@Column(name="XSTATUS")
	public String	xStatus;
	
	@Column(name="CARD_NATURE")
	public String	cardNature;
	
	@Column(name="DOB_BONUS")
	public String	dobBonus;
	
	@Column(name="ADDR_MTCE_DATE")
	public String	addrMtceDate;
	
	@Column(name="MEMBER_SINCE")
	public String	memberSince;
	
	@Column(name="NUM_OF_STAR")
	public String	numOfStar;
	
	@Column(name="COLLATERAL_CODE")
	public String	collateralCode;
	
	@Column(name="ACCOUNT_OPEN_DATE")
	public String	accountOpenDate;

	
	

}
