package com.dsb.eb2.bankApp.dao.bioRegDevice;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.dsb.eb2.framework.controller.ApiGateway;
import com.dsb.eb2.util.JSONUtils;

@Service
public class BioRegDeviceDao extends ApiGateway{
	
	private static Logger logger = LoggerFactory.getLogger(BioRegDeviceDao.class);
	
	public Map<String,String> getBioInfoByCustID(String custId) throws IOException, Exception {
		
		try {
			String serviceURL = super.getGatewayURL() + "/CusBiometricRegDevice/GetBioInfoByCustIDService/submit";
			Map<String,String> map = new HashMap<String,String>();
			map.put("CUST_ID", custId);
			String requestPayload =  JSONUtils.objToJson(map);
	    	String type = "DATA";
	    	
	    	logger.info("requestPayload = " + requestPayload);
	    	String responsePayload  = super.doRequest(type, "POST", "OTHERS", "N", null, serviceURL, "POST", JSONUtils.objToJson(map));
	    	logger.info("responsePayload = " + responsePayload);
	    	Map<String,String> repmap = new HashMap<String,String>();
	    	repmap = JSONObject.parseObject(responsePayload,new TypeReference<Map<String,String>>(){});
	    	return repmap;
		}catch(Exception e) {
			logger.error("BioRegDeviceDao GetBioInfoByCustID error!");
			throw e;
		}
	}

}
