package com.dsb.eb2.bankApp.dao.branch;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class Branch {
	
    private String code;
	
	private String description;
	
	private String descriptionEn;
	
	private String descriptionTc; 
	
	private String exist;
	
	

}
