package com.dsb.eb2.bankApp.dao.branch;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class BranchService {

	@Autowired
	private BranchDao branchdao;
	
	private static Logger logger = LoggerFactory.getLogger(BranchService.class);

	private static final Hashtable tpbDetTable = new Hashtable();

	private static final Hashtable tpbEngTable = new Hashtable();

	private static final Hashtable tpbAllDetTable = new Hashtable();

	private static final Hashtable tpbAllEngTable = new Hashtable();
	
	private static final ArrayList sortedChiBranchList = new ArrayList();

	public void refresh() throws IOException, Exception {

		tpbDetTable.clear();
		tpbEngTable.clear();
		tpbAllDetTable.clear();
		tpbAllEngTable.clear();
		String[] textDesc;

		List<Branch> allBranchTable = branchdao.getAllBranch();
		if (allBranchTable != null && allBranchTable.size() > 0) {
			for (Branch branch : allBranchTable) {
				String exist = branch.getExist();
				textDesc = new String[2];
				textDesc[0] = branch.getDescriptionEn();
				if(branch.getDescriptionTc() !=  null) {
	                textDesc[1] = branch.getDescriptionTc();
	            } else {
	                textDesc[1] = "";
	            }
				logger.info("ccyCode:" + branch.getCode() + " ENG_DESC:" + branch.getDescriptionEn() + " textDesc[0]:" + textDesc[0] + " textDesc[1]:" + textDesc[1] + " exist:" + exist);
				if (exist.equals("Y"))
				{
			        tpbDetTable.put(branch.getCode(),textDesc);
		        	tpbEngTable.put("ENG_DESC", branch.getCode());
		    	}
				
				tpbAllDetTable.put(branch.getCode(),textDesc);
				tpbAllEngTable.put("ENG_DESC", branch.getCode());

			}
		}
		Vector v = sortbyEngname();

	}

	public synchronized static Vector sortbyEngname() {
		List keys = new ArrayList(tpbEngTable.keySet());
		Collections.sort(keys);
		Iterator itr = keys.iterator();
		sortedChiBranchList.clear();
		Vector engTbl = new Vector();
		for (int i = 0; i < tpbEngTable.size(); i++) {
			Object key = itr.next();
			String[] tmp = { (String) tpbEngTable.get(key), (String) key };
			String[] BranchName = new String[2];
			BranchName[0] = (String) key;
			BranchName[1] = ((String[]) tpbDetTable.get(((String) tpbEngTable.get(key))))[1];
			sortedChiBranchList.add(BranchName);
			engTbl.add(tmp);
		}
		return engTbl;
	}

	public String findCompleteBranchCode(String twoDigitCode) {
		
		Enumeration e = tpbAllDetTable.keys();
	    String key = "";
	    while (e.hasMoreElements()) {
	      key = (String)e.nextElement();
	      if (twoDigitCode.equals(key.substring(1,3)))
	        return key;
	    }
	    return null;		
	}

}
