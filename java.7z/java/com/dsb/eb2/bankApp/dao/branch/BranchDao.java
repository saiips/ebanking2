package com.dsb.eb2.bankApp.dao.branch;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.dsb.eb2.framework.controller.ApiGateway;
import com.dsb.eb2.framework.util.WebAppProperties;

public class BranchDao extends ApiGateway{
	
	@Autowired
	private WebAppProperties webapp;
	
	public List<Branch> getAllBranch() throws IOException, Exception{
		
		String url = webapp.getUrl() + "/BranchService/GetAllBranch";
			
		List<Branch> allBranchList = (ArrayList<Branch>)super.getObject(url, "", Branch.class);
			
		return allBranchList;
	}
}
