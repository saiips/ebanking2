package com.dsb.eb2.bankApp.dao.rating;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dsb.eb2.framework.repository.BaseRepository;

@Repository
public interface RatingRepository extends BaseRepository<RatingBean,String>{
	
	@Query(value="insert into CUS_RATING(SESSION_ID,RATING,SUBMIT_DATE)values(:SESSION_ID,:RATING,TO_DATE(:SUBMIT_DATE,'yyyymmdd'))",nativeQuery=true)
	@Modifying
	public int saveRatingBean(@Param("SESSION_ID")String SESSION_ID,@Param("RATING")int RATING,@Param("SUBMIT_DATE")String SubmitDate);
	
}
