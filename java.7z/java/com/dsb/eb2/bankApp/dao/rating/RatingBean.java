package com.dsb.eb2.bankApp.dao.rating;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.dsb.eb2.framework.model.Base;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="CUS_RATING")
@Getter @Setter @NoArgsConstructor
public class RatingBean extends Base{
	
	@Transient
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="SESSION_ID", unique=true, nullable = false)
	@JsonProperty("SESSION_ID")
	private String sessionID;
	@Column(name="RATING")
	@JsonProperty("RATING")
	private int rating;
	
	@Column(name="SUBMIT_DATE")
	@JsonProperty("SUBMIT_DATE")
	private java.util.Date SubmitDate;
}
