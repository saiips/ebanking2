package com.dsb.eb2.bankApp.dao.rating;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.dsb.eb2.framework.controller.ApiGateway;
import com.dsb.eb2.framework.log.Loggable;
import com.dsb.eb2.util.JSONUtils;

@Component
@Loggable
public class RatingOSBDao extends ApiGateway{
	
	public JSONObject checkSessionUidUnique(Map<String,String> map) throws Exception{
		String serviceURL = super.getGatewayURL() + "/CusRating/GetCountBySessionIDService/submit";
		String response = super.doRequest("DATA", "POST", "OTHERS", "N", null, serviceURL, "POST", JSONUtils.objToJson(map));
		return (JSONObject)JSONUtils.JsonToObj(response, new JSONObject());
	}
	
}
