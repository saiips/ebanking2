package com.dsb.eb2.bankApp.dao.preference;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.dsb.eb2.framework.model.Base;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="CUS_PREFERENCE")
@IdClass(CusPreferencePK.class)
@Getter @Setter @NoArgsConstructor
public class CusPreference extends Base{
	
	@Transient
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="CUST_ID", unique=true, nullable = false)
	@JsonProperty("CUST_ID")
	private String custId; //VARCHAR2(20 BYTE) NOT NULL ENABLE, 
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="PREF_TYPE", unique=true, nullable = false)
	@JsonProperty("PREF_TYPE")
	private String prefType; //VARCHAR2(50 BYTE) NOT NULL ENABLE, 
	
	@Column(name="PREF_VALUE")
	@JsonProperty("PREF_VALUE")
	private String prefValue; //VARCHAR2(500 BYTE), 
	
	@Column(name="LAST_UPDATE_DATE")
	@JsonProperty("LAST_UPDATE_DATE")
	private Date LastUpdateDate; //DATE, 
	
	@Column(name="LAST_UPDATE_BY")
	@JsonProperty("LAST_UPDATE_BY")
	private String LastUpdateBy; //VARCHAR2(50 BYTE), 
}
