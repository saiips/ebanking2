package com.dsb.eb2.bankApp.dao.preference;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter @Setter @NoArgsConstructor
public class CusPreferencePK implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String custId;
	
	private String prefType;
}
