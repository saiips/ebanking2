package com.dsb.eb2.bankApp.dao.preference;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.logging.LogLevel;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.System.exeption.SystemException;
import com.dsb.eb2.framework.controller.ApiGateway;
import com.dsb.eb2.framework.log.Loggable;
import com.dsb.eb2.sso.controller.LoginController;
import com.dsb.eb2.util.FormatUtils;
import com.dsb.eb2.util.JSONUtils;

@Component
@Loggable
public class CusPreferenceOSBDao extends ApiGateway{
	private static Logger log = LoggerFactory.getLogger(LoginController.class);
	//SELECT PREF_VALUE FROM CUS_PREFERENCE WHERE CUST_ID = ? AND PREF_TYPE = ?
	@Loggable(result = false, value = LogLevel.INFO)
	public String getSmsLang(String cust_id,String prefType) throws SystemException{
		JSONObject json = null;
		String PREFVALUE = "";
		try {
			Map<String,String> map = new HashMap<String,String>();
			map.put("CUST_ID",cust_id);
			map.put("PREF_TYPE", prefType);
//			String serviceURL = "http://10.26.129.131:7001" + "/CusPreference/GetPrefValByCustIdAndPrefTypeService/submit";
			String serviceURL = super.getGatewayURL() + "/CusPreference/GetPrefValByCustIdAndPrefTypeService/submit";
			String response = super.doRequest("DATA", "POST", "OTHERS", "N", null, serviceURL, "POST", JSONUtils.objToJson(map));
			json = (JSONObject)JSONUtils.JsonToObj(response, new JSONObject());
			PREFVALUE = json.getString("PREF_VALUE");
		} catch (IOException e) {
			log.info(FormatUtils.getStackTrace(e));
			throw new SystemException(SystemStatusCode.SCC_SEND_SMS_OTP_ERROR);
		} catch (Exception e) {
			log.info(FormatUtils.getStackTrace(e));
			throw new SystemException(SystemStatusCode.SCC_SEND_SMS_OTP_ERROR);
		}
		return PREFVALUE;
	}
}
