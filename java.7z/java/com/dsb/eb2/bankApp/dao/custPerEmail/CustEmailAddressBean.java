package com.dsb.eb2.bankApp.dao.custPerEmail;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.dsb.eb2.framework.model.Base;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@NoArgsConstructor
@Getter @Setter
@Table(name="CUS_EMAIL_ADDRESS")
public class CustEmailAddressBean extends Base {
	
	@Transient
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue
	@Column(name="CUST_ID",nullable=false)
	@JsonProperty("CUST_ID")
	private String custId; 
	
	@Column(name="PERM_EMAIL")
	@JsonProperty("PERM_EMAIL")
	private String permEmail;
	
	@Column(name="TEMP_EMAIL")
	@JsonProperty("TEMP_EMAIL")
	private String tempEmail;
	
	@Column(name="LAST_UPDATE_BY")
	@JsonProperty("LAST_UPDATE_BY")
	private String lastUpdateBy;
	
	@Column(name="LAST_UPDATE_DATE")
	@JsonProperty("LAST_UPDATE_DATE")
	private java.util.Date lastUpdateDate;
	
	
	@Column(name="HOST_RETURN_REF_NUM")
	@JsonProperty("HOST_RETURN_REF_NUM")
	private String hostReturnRefNum;
	
	@Column(name="HOST_EMAIL_UPDATE_DATE")
	@JsonProperty("HOST_EMAIL_UPDATE_DATE")
	private java.util.Date hostEmailUpdateDate;
		
}