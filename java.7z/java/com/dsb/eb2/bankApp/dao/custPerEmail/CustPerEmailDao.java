package com.dsb.eb2.bankApp.dao.custPerEmail;

import java.io.IOException;

import org.springframework.stereotype.Repository;

import com.alibaba.fastjson.JSONObject;
import com.dsb.eb2.framework.controller.ApiGateway;

@Repository
public class CustPerEmailDao extends ApiGateway{
	
	public String getEmailDetailByCustId(String CUST_ID) throws IOException, Exception {
		
		//String url = super.getGatewayURL() + "/CusEmailAddress/Resources/GetCustIDAndEmailByCustIDService";
	    String url = "http://10.26.129.131:7001" + "/CusEmailAddress/GetCustIDAndEmailByCustIDService/submit";
		
		JSONObject jsObj = new JSONObject();
		jsObj.put("CUST_ID", CUST_ID);
		String responseStr =  super.doRequest("DATA", "POST", "OTHERS", "N", null, url, "POST", jsObj.toString());	
		
		return responseStr;
	}
	
	public String getEmailDetailByRefNo(String HOST_RETURN_REF_NUM) throws IOException, Exception {
		//String url = super.getGatewayURL() + "/CusEmailAddress/Resources/GetCustIDAndEmailByHostRefNumService";
	    String url = "http://10.26.129.131:7001" + "/CusEmailAddress/GetCustIDAndEmailByHostRefNumService/submit";
		
		JSONObject jsObj = new JSONObject();
		jsObj.put("HOST_RETURN_REF_NUM", HOST_RETURN_REF_NUM);
		String responseStr =  super.doRequest("DATA", "POST", "OTHERS", "N", null, url, "POST", jsObj.toString());	
		
		return responseStr;
	}
	
}
