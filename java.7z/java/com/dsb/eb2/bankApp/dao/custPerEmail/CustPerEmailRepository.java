package com.dsb.eb2.bankApp.dao.custPerEmail;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dsb.eb2.framework.repository.BaseRepository;
@Repository
public interface CustPerEmailRepository extends BaseRepository<CustEmailAddressBean,String>{

       @Transactional
	   @Modifying
	   @Query(value = "INSERT INTO CUS_EMAIL_ADDRESS(CUST_ID,LAST_UPDATE_DATE) values(:CUST_ID,SYSDATE)",nativeQuery=true)
	   public int insertCustPerEmail(@Param("CUST_ID")String CUST_ID);	
	   
	   @Transactional
	   @Modifying
	   @Query(value = "UPDATE CUS_EMAIL_ADDRESS SET PERM_EMAIL=:PERM_EMAIL, TEMP_EMAIL=:TEMP_EMAIL, LAST_UPDATE_BY=:LAST_UPDATE_BY, LAST_UPDATE_DATE= SYSDATE, HOST_RETURN_REF_NUM=:HOST_RETURN_REF_NUM, HOST_EMAIL_UPDATE_DATE=:HOST_EMAIL_UPDATE_DATE WHERE CUST_ID =:CUST_ID", nativeQuery=true)
	   public int updatePermEmail(@Param("PERM_EMAIL")String PERM_EMAIL,@Param("TEMP_EMAIL")String TEMP_EMAIL,@Param("LAST_UPDATE_BY")String LAST_UPDATE_BY,@Param("HOST_RETURN_REF_NUM")String HOST_RETURN_REF_NUM,@Param("HOST_EMAIL_UPDATE_DATE")String HOST_EMAIL_UPDATE_DATE,@Param("CUST_ID")String CUST_ID);
	    
	   @Transactional
	   @Modifying
	   @Query(value = "UPDATE CUS_EMAIL_ADDRESS SET TEMP_EMAIL=:TEMP_EMAIL, LAST_UPDATE_BY=:LAST_UPDATE_BY, LAST_UPDATE_DATE= SYSDATE, HOST_RETURN_REF_NUM=:HOST_RETURN_REF_NUM WHERE CUST_ID =:CUST_ID ", nativeQuery=true)
	   public int updateTempEmail(@Param("TEMP_EMAIL")String TEMP_EMAIL,@Param("LAST_UPDATE_BY")String LAST_UPDATE_BY,@Param("HOST_RETURN_REF_NUM")String HOST_RETURN_REF_NUM,@Param("CUST_ID")String CUST_ID);	
	   
	   @Transactional
	   @Modifying
	   @Query(value = "UPDATE CUS_EMAIL_ADDRESS SET HOST_RETURN_REF_NUM=:HOST_RETURN_REF_NUM WHERE CUST_ID =:CUST_ID ", nativeQuery=true)
	   public void updateTempEmailNORefNum(@Param("HOST_RETURN_REF_NUM")String HOST_RETURN_REF_NUM,@Param("CUST_ID")String CUST_ID);	
	   
	   
	   
}
