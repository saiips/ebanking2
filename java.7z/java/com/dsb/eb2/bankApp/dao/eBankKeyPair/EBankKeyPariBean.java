package com.dsb.eb2.bankApp.dao.eBankKeyPair;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.dsb.eb2.framework.model.Base;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="SYS_EBANK_KEYPAIR")
@Getter @Setter @NoArgsConstructor
public class EBankKeyPariBean extends Base{
	
	@Transient
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue
	@Column(name="KEY_NAME")
	@JsonProperty("KEY_NAME")
	protected String name;
	
	@Column(name="KEY_INDEX")
	@JsonProperty("KEY_INDEX")
	protected String keyIndex;
	
	@Column(name="PRIVATE_KEY")
	@JsonProperty("PRIVATE_KEY")
	protected String privateKey;
	
	@Column(name="PUBLIC_KEY")
	@JsonProperty("PUBLIC_KEY")
	protected String publicKey;

}
