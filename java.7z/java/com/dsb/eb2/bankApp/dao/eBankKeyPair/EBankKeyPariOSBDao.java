package com.dsb.eb2.bankApp.dao.eBankKeyPair;

import java.io.IOException;

import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.dsb.eb2.framework.controller.ApiGateway;
import com.dsb.eb2.framework.log.Loggable;
import com.dsb.eb2.util.JSONUtils;

@Component
@Loggable
public class EBankKeyPariOSBDao extends ApiGateway {

	//SELECT KEY_NAME, KEY_INDEX, PRIVATE_KEY, PUBLIC_KEY FROM SYS_EBANK_KEYPAIR ORDER BY KEY_INDEX
	public JSONObject findSMSOtpKey(String request) throws IOException, Exception{
//		String serviceURL = "http://10.26.129.131:7001" + "/SysEbankKeypair/GetAllInfoService/submit";
		String serviceURL = super.getGatewayURL() + "/SysEbankKeypair/GetAllInfoService/submit";
		String response = super.doRequest("DATA", "POST", "OTHERS", "N", null, serviceURL, "POST", JSONUtils.objToJson(request));
		return (JSONObject)JSONUtils.JsonToObj(response, new JSONObject());
	}
}
