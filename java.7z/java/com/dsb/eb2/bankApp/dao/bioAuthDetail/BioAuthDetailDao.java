package com.dsb.eb2.bankApp.dao.bioAuthDetail;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsMsgUtils;
import com.dsb.eb2.bankApp.biometric.BiometricHandler;
import com.dsb.eb2.framework.controller.ApiGateway;
import com.dsb.eb2.framework.util.WebAppProperties;
import com.dsb.eb2.util.JSONUtils;

@Service
public class BioAuthDetailDao  extends ApiGateway{
	
	@Autowired
	private WebAppProperties webapp;
	
	private static Logger logger = LoggerFactory.getLogger(BioAuthDetailDao.class);
	
	public JSONObject getAuthDetailByToken(String token,String status) throws IOException, Exception{
		
		
		try {
			String serviceURL = super.getGatewayURL() + "/cusBiometricAuthDetail/getAuthDetailByTokenService/submit";
			Map<String,String> map = new HashMap<String,String>();
			map.put("TOKEN", token);
			map.put("TOKEN_STATUS", status);
			String requestPayload =  JSONUtils.objToJson(map);
	    	String type = "DATA";
	    	
	    	logger.info("requestPayload = " + requestPayload);
	    	String responsePayload  = super.doRequest(type, "POST", "OTHERS", "N", null, serviceURL, "POST", JSONUtils.objToJson(map));
	    	logger.info("responsePayload = " + responsePayload);
	    	JSONObject responseJsonObj = (JSONObject)JSONUtils.JsonToObj(responsePayload, new JSONObject());
	    	return responseJsonObj;
	    	
		}catch(Exception e) {
			logger.error("BioRegDeviceDao GetBioInfoByCustID error!");
			throw e;
		}
		
	}
	
	public int getBioAuthDetailCountByCustId(String custId, String authenMethod) throws Exception {
		
		try {
			int cnt = 0;
			String serviceURL = super.getGatewayURL() + "/cusBiometricAuthDetail/GetBiometricLoginAuthExistByCustIdService/submit";
			Map<String,String> map = new HashMap<String,String>();
			map.put("CUST_ID", custId);
			map.put("AUTHEN_METHOD", authenMethod);
			String requestPayload =  JSONUtils.objToJson(map);
	    	String type = "DATA";
	    	
	    	logger.info("requestPayload = " + requestPayload);
	    	String responsePayload  = super.doRequest(type, "POST", "OTHERS", "N", null, serviceURL, "POST", JSONUtils.objToJson(map));
	    	logger.info("responsePayload = " + responsePayload);
	    	JSONObject responseJsonObj = (JSONObject)JSONUtils.JsonToObj(responsePayload, new JSONObject());
	    	String countStr = responseJsonObj.getString("CNT");
	    	if(!StringUtils.isEmpty(countStr)) {
	    		cnt = Integer.parseInt(countStr);
	    	}
	    	return cnt;
	    	
		}catch(Exception e) {
			logger.error("BioRegDeviceDao GetBioInfoByCustID error!");
			throw e;
		}
		
	}
	

}
