package com.dsb.eb2.bankApp.dao.bioAuthDetail;

import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dsb.eb2.framework.repository.BaseRepository;

@Repository
public interface BioAuthDetailRepository  extends BaseRepository<BioAuthDetail, String> {
	
	@Transactional
	@Modifying
    @Query(value = "INSERT INTO CUS_BIOMETRIC_AUTH_DETAIL(CUST_ID,TOKEN,AUTHEN_METHOD,LOGIN_METHOD,LOGIN_CHANNEL,TOKEN_STATUS,LAST_UPDATE_DATE,VERSION) "
    		 +"values(?1,?2,?3,?4,?5,?6,?7,?8)",nativeQuery=true)
    public int insertBioAuthDetail(String custId,String token,String authenMethod, String loginMethod,
    		String channel,String tokenStatus,Date lastDate,Long version);
	
	@Transactional
	@Modifying 
    @Query(value = "UPDATE CUS_BIOMETRIC_AUTH_DETAIL SET TOKEN_STATUS = :TOKEN_STATUS, LAST_UPDATE_DATE = :LAST_UPDATE_DATE WHERE TOKEN = :TOKEN",nativeQuery=true)
	public int updateBioTokenStatus(@Param("TOKEN_STATUS")String TOKEN_STATUS, @Param("LAST_UPDATE_DATE")Date LAST_UPDATE_DATE,@Param("TOKEN")String TOKEN); 
	
}
