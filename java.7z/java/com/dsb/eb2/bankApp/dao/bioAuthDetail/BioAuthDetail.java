package com.dsb.eb2.bankApp.dao.bioAuthDetail;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.dsb.eb2.framework.model.Base;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@NoArgsConstructor
@Getter @Setter
@Table(name="CUS_BIOMETRIC_AUTH_DETAIL")
public class BioAuthDetail extends Base{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name="ID")
	private String id;
	//(strategy = GenerationType.SEQUENCE, generator = "SEQ_CUSTOMER")
//	@SequenceGenerator(sequenceName = "SEQ_CUSTOMER", allocationSize = 1, name = "SEQ_CUSTOMER")
	@Column(name="CUST_ID")
	private String customerId;
	
	@Column(name="TOKEN")
	private String token;
	
	@Column(name="AUTHEN_METHOD")
	private String authenMethod;
	
	@Column(name="LOGIN_METHOD")
	private String loginMethod;
	
	@Column(name="LOGIN_CHANNEL")
	private String channel;
	
	@Column(name="TOKEN_STATUS")
	private String tokenStatus;
	
	@Column(name="LAST_UPDATE_DATE")
	private Date updateDate;

}
