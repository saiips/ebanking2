package com.dsb.eb2.bankApp.dao.customer;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.alibaba.fastjson.JSONObject;
import com.dsb.eb2.backOffice.connect.EMSQueueConnector;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsMsgFactory;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsRepMsg;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsReqMsg;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1108.NF1108RepData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1108.NF1108ReqData;
import com.dsb.eb2.framework.controller.ApiGateway;
import com.dsb.eb2.util.JSONUtils;

@Repository
public class CustomerDao extends ApiGateway{
	

	public CustomerBean getCustomerByCustId(String custId)  throws IOException, Exception {
		
		String url = super.getGatewayURL() + "customer/getcustomerByCustId?custId=" + custId;
		
		CustomerBean  cust = (CustomerBean) super.getObject(url, "", CustomerBean.class);
		
		return cust;
		
	}
	
	public EmsRepMsg loadCustDetailsFromAgent(String custId) throws IOException, Exception{
		
		 System.out.println("gggg");
		
		 NF1108ReqData req = new NF1108ReqData();
		
		 EmsReqMsg emsReqMsg = EmsMsgFactory.createEmsReqMsg(req, custId);
		
		 EMSQueueConnector connector = new EMSQueueConnector();
		 
		 EmsRepMsg emsRepMsg = connector.invoke(emsReqMsg, new NF1108RepData());
		 
		 return emsRepMsg;
	}
	
	public String getCustIdByEBId(String ebId) throws IOException, Exception {
		
		String custId = "";
    	try {    		
			String serviceURL = super.getGatewayURL() + "/CusCustomer/GetAllCustByEbIDService/submit";
			Map<String,String> map = new HashMap<String,String>();
			map.put("EBANK_ID", ebId);
			String requestPayload =  JSONUtils.objToJson(map);
	    	String type = "DATA";
			
	    	String responsePayload  = super.doRequest(type, "POST", "OTHERS", "N", null, serviceURL, "POST", requestPayload);
	    	custId = JSONObject.parseObject(responsePayload).getString("CUST_ID");	    	
		}catch(Exception e) {
			throw e;
		}
		return custId;
	}

}
