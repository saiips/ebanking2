package com.dsb.eb2.bankApp.dao.customer;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.dsb.eb2.framework.model.Base;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@NoArgsConstructor
@Getter @Setter
@Table(name="CUS_CUSTOMER")
public class CustomerBean extends Base {
	
	@Transient
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="CUST_ID",nullable=false)
	@JsonProperty("CUST_ID")
	private String custId; 
	
	@Column(name="EBANK_ID")
	@JsonProperty("EBANK_ID")
	private String ebankId;
	
	@Column(name="EBANK_ID_STATUS")
	@JsonProperty("EBANK_ID_STATUS")
	private String ebankIdStatus;
	
	@Column(name="EBANK_TYPE")
	@JsonProperty("EBANK_TYPE")
	private String ebankType;
	
	@Column(name="FULL_NAME")
	@JsonProperty("FULL_NAME")
	private String fullName;
	
	@Column(name="TITLE")
	@JsonProperty("TITLE")
	private String title;
	
	@Column(name="SEX")
	@JsonProperty("SEX")
	private String sex;
	
	@Column(name="DATE_OF_BIRTH")
	@JsonProperty("DATE_OF_BIRTH")
	private java.util.Date dateOfBirth;
	
	@Column(name="DM_OPTOUT")
	@JsonProperty("DM_OPTOUT")
	private String dmOptout;
	
	@Column(name="STAFF_IND")
	@JsonProperty("STAFF_IND")
	private String staffInd;
	
	@Column(name="FIRST_REG_DATE")
	@JsonProperty("FIRST_REG_DATE")
	private java.util.Date firstRegDate;
	
	@Column(name="RE_REG_DATE")
	@JsonProperty("RE_REG_DATE")
	private java.util.Date reRegDate;
	
	@Column(name="LAST_LOGIN_SUCCESS_DATE")
	@JsonProperty("LAST_LOGIN_SUCCESS_DATE")
	private java.util.Date lastLoginSuccessDate;
	
	@Column(name="LAST_LOGIN_FAIL_DATE")
	@JsonProperty("LAST_LOGIN_FAIL_DATE")
	private java.util.Date lastLoginFailDate;
	
	@Column(name="LOGIN_FAIL_COUNT")
	@JsonProperty("LOGIN_FAIL_COUNT")
	private String loginFailCount;
	
	@Column(name="BIO_REMIND_FLAG")
	@JsonProperty("BIO_REMIND_FLAG")
	private String bioRemindFlag;
	
	@Column(name="BIO_REMIND_DATE")
	@JsonProperty("BIO_REMIND_DATE")
	private java.util.Date bioRemindDate;
	
   @Override
    public String toString() {
        return String.format(
                "Customer[customerId=%d, fullName='%s', mobileNumber='%s']",
                custId, fullName);
    }
	
}
