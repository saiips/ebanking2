package com.dsb.eb2.bankApp.dao.customer;

import java.io.IOException;

import org.springframework.stereotype.Repository;

import com.dsb.eb2.backOffice.connect.EMSQueueConnector;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsMsgFactory;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsRepMsg;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsReqMsg;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1108.NF1108ReqData;
import com.dsb.eb2.framework.controller.ApiGateway;

@Repository
public class CustomerDaoImpl extends ApiGateway{
	

	public CustomerBean getCustomerByCustId(String custId)  throws IOException, Exception {
		
		String url = super.getGatewayURL() + "customer/getcustomerByCustId?custId=" + custId;
		
		CustomerBean cust = (CustomerBean) super.getObject(url, "", CustomerBean.class);
		
		return cust;
		
	}
	
public CustomerBean getCustomerByebankId(String ebankId)  throws IOException, Exception {
		
		String url = super.getGatewayURL() + "customer/getcustomerByCustId?custId=" + ebankId;
		
		CustomerBean cust = (CustomerBean) super.getObject(url, "", CustomerBean.class);
		
		return cust;
		
	}
	
	public EmsRepMsg loadCustDetailsFromAgent(String custId) throws IOException, Exception{
		
		 NF1108ReqData req = new NF1108ReqData();
		
		 EmsReqMsg emsReqMsg = EmsMsgFactory.createEmsReqMsg(req, custId + "       000");
		
		 EMSQueueConnector connector = new EMSQueueConnector();
		 
		 EmsRepMsg emsRepMsg = connector.invoke(emsReqMsg, null);
		 
		 return emsRepMsg;
	}

}
