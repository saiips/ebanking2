package com.dsb.eb2.bankApp.dao.customer;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dsb.eb2.framework.repository.BaseRepository;

/*
 * UPDATE/ INSERT /DELETE Customer table
 */

@Repository
//@Transactional
public interface CustomerRepository extends BaseRepository<CustomerBean, String> {

	
	
    
//    @Query(value="UPDATE CUSTOMER SET FIRST_REGISTRATION_DATE=TO_DATE(:FIRST_REGISTRATION_DATE,'yyyymmddhh24miss') WHERE CUSTOMER_ID =:CUSTOMER_ID",nativeQuery=true)
//	@Modifying
//	public void updateFirstRegistrationDate(@Param("FIRST_REGISTRATION_DATE")String FIRST_REGISTRATION_DATE,@Param("CUSTOMER_ID")String CUSTOMER_ID);
//    
//    
//    @Query(value="UPDATE CUSTOMER SET RE_REGISTRATION_DATE=TO_DATE(:RE_REGISTRATION_DATE,'yyyymmddhh24miss') WHERE CUSTOMER_ID =:CUSTOMER_ID",nativeQuery=true)
//	@Modifying
//	public void updateReRegistrationDate(@Param("RE_REGISTRATION_DATE")String RE_REGISTRATION_DATE,@Param("CUSTOMER_ID")String CUSTOMER_ID);
//    
//    
//    @Query(value="UPDATE CUSTOMER SET LAST_LOGIN_SUCCESS_DATE=TO_DATE(:LAST_LOGIN_SUCCESS_DATE,'yyyymmddhh24miss') WHERE CUSTOMER_ID =:CUSTOMER_ID",nativeQuery=true)
//	@Modifying
//	public void updateLastLoginSuccessDate(@Param("LAST_LOGIN_SUCCESS_DATE")String LAST_LOGIN_SUCCESS_DATE,@Param("CUSTOMER_ID")String CUSTOMER_ID);
    
  
	    @Query(value="SELECT * FROM CUS_CUSTOMER  WHERE EBANK_ID =:EBANK_ID",nativeQuery=true)
	    List<CustomerBean> findByEbankIdReturnSteam(@Param("EBANK_ID")String EBANK_ID);
	    
	    @Query(value="SELECT * FROM CUS_CUSTOMER  WHERE CUST_ID =:CUST_ID",nativeQuery=true)
	    List<CustomerBean> findByCustomerIdReturnSteam(@Param("CUST_ID")String CUST_ID);
    	    
//    @Query(value="UPDATE CUSTOMER SET  EBANK_ID_STATUS =:EBANK_ID_STATUS WHERE CUSTOMER_ID =:CUSTOMER_ID", nativeQuery=true)
//	@Modifying
//	void updateEbankIdbyCustId(@Param("EBANK_ID_STATUS")String EBANK_ID_STATUS,@Param("CUSTOMER_ID")String CUSTOMER_ID); 
//	
//	@Query(value="UPDATE CUSTOMER SET  EBANK_ID_STATUS =:EBANK_ID_STATUS where EBANK_ID =:EBANK_ID", nativeQuery=true)
//	@Modifying
//	void updateEbankIdbyEbid(@Param("EBANK_ID_STATUS")String EBANK_ID_STATUS,@Param("EBANK_ID")String EBANK_ID);
	
}
