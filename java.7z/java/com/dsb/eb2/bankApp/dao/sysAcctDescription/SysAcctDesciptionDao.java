package com.dsb.eb2.bankApp.dao.sysAcctDescription;

import java.io.IOException;

import org.springframework.stereotype.Repository;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.dsb.eb2.framework.controller.ApiGateway;
import com.dsb.eb2.util.StringUtils;

@Repository
public class SysAcctDesciptionDao  extends ApiGateway{

    public SysAcctDescriptionBean getAcctDesciptionByType(String acctType,String subType)  throws IOException, Exception {
		
		 String url = super.getGatewayURL() + "/SysAcctDescription/GetInfoByTypeService/submit";
	  //  String url = "http://10.26.129.131:7001" + "/SysAcctDescription/GetInfoByTypeService/submit";
		
		JSONObject jsObj = new JSONObject();
		jsObj.put("ACCT_TYPE", acctType);
		jsObj.put("ACCT_SUB_TYPE", subType);
		String responseStr =  super.doRequest("DATA", "POST", "OTHERS", "N", null, url, "POST", jsObj.toString());	
					
		SysAcctDescriptionBean  acct = null;
		
		if(!StringUtils.isEmpty(responseStr)) {
			
			acct = JSON.parseObject(responseStr, SysAcctDescriptionBean.class);
		}
		
		return acct;
		
	}
	
}
