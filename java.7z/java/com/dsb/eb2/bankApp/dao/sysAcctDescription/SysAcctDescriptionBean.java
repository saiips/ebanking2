package com.dsb.eb2.bankApp.dao.sysAcctDescription;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.dsb.eb2.framework.model.Base;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@NoArgsConstructor
@Getter @Setter
@Table(name="SYS_ACCT_DESCRIPTION")
public class SysAcctDescriptionBean extends Base{
	
	@Transient
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue
	@Column(name="ACCT_TYPE",nullable=false)
	@JsonProperty("ACCT_TYPE")
	private String acctType; 
	
	@Column(name="ACCT_SUB_TYPE")
	@JsonProperty("ACCT_SUB_TYPE")
	private String acctSubType;
	
	@Column(name="ENG_DESC")
	@JsonProperty("ENG_DESC")
	private String engDesc;
	
	
	@Column(name="CHI_DESC")
	@JsonProperty("CHI_DESC")
	private String chiDesc;
	
	
	@Column(name="SORT_ORDER")
	@JsonProperty("SORT_ORDER")
	private String sortOrder;
	
	
	
	

}
