package com.dsb.eb2.bankApp.dao.bioTxnAuth;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@NoArgsConstructor
@Getter @Setter
@Table(name="CUS_BIOMETRIC_TXN_AUTH")
public class BioTxnAuthBean {
	
	@Id
	@GeneratedValue
	@Column(name="ID")
	private String id;
	
	@Column(name="BIO_TXN_AUTH_ID")
	private String bioTxnAuthId;
	
	@Column(name="CUST_ID")
	private String custId;
	
	@Column(name="TXN_TYPE")
	private String txnType;
	
	@Column(name="FIDO_ID")
	private String fidoId;
	
	@Column(name="DESC_1")
	private String desc1;
	
	@Column(name="DESC_2")
	private String desc2;
	
	@Column(name="DESC_3")
	private String desc3;
	
	@Column(name="DESC_4")
	private String desc4;
	
	@Column(name="DESC_5")
	private String desc5;
	
	@Column(name="DESC_6")
	private String desc6;
	
	@Column(name="DESC_7")
	private String desc7;
	
	@Column(name="DESC_8")
	private String desc8;
	
	@Column(name="NOTIF_TITLE")
	private String notifTitle;
	
	@Column(name="NOTIF_BODY")
	private String notifBody;
	
	@Column(name="REF_NUM")
	private String refNum;
	
	@Column(name="STATUS")
	private String status;
	
	@Column(name="LAST_UPDATE_DATE")
	private String lastUpdateDate;
	
	@Column(name="QRCODE_TOKEN")
	private String qrCodeToken;
	
	@Column(name="CHANNEL")
	private String channel;
	
	@Column(name="AUTH_TYPE")
	private String authType;
	
	@Column(name="MAIN_TYPE")
	private String mainType;
	
	@Column(name="SUB_TYPE")
	private String subType;	

}
