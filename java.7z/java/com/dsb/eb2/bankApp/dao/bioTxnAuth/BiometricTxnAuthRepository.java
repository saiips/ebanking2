package com.dsb.eb2.bankApp.dao.bioTxnAuth;

import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dsb.eb2.framework.repository.BaseRepository;

@Repository
public interface BiometricTxnAuthRepository  extends BaseRepository<BioTxnAuthBean, String> {
	
	@Transactional
	@Modifying 
    @Query(value = "UPDATE  CUS_BIOMETRIC_TXN_AUTH SET STATUS = :STATUS ,LAST_UPDATE_DATE = :LAST_UPDATE_DATE WHERE CUST_ID =:CUST_ID",nativeQuery=true)
	public int updateBioTokenStatus(@Param("STATUS")String STATUS, @Param("LAST_UPDATE_DATE")Date LAST_UPDATE_DATE,@Param("CUST_ID")String CUST_ID); 

}
