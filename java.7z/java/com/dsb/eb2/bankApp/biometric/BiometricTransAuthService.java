package com.dsb.eb2.bankApp.biometric;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.dsb.eb2.backOffice.connect.webService.handle.HandleBiometricAuth;
import com.dsb.eb2.backOffice.connect.webService.logPush.LogPushResponse;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.System.exeption.SystemException;

@Service
public class BiometricTransAuthService {

	private static Logger logger = LoggerFactory.getLogger(BiometricTransAuthService.class);
	
	@Autowired
	public EmsLogPushProcessor logPush;
	
	@Autowired
	public HandleBiometricAuth handleBioAuth;

	/**
	 * Generate QR code (Login)
	 * @throws Exception 
	 */
	public String genLoginQRcode() throws Exception {
		
		logger.info("genLoginQRcode start");

		String qrcodeToken = null;

		try {
			JSONObject inputData = new JSONObject();
			inputData.put("requestType", BiometricConstants.GEN_LOGIN_QRCODE);
			inputData.put("param", "");
			qrcodeToken = handleBioAuth.invoke(inputData);
		} catch (Exception e) {
			logger.error("BiometricTransAuthService call osb genLoginQRcode error!");
			throw e;
		}
		logger.info("genLoginQRcode start. qrcodeToken:" + qrcodeToken);
		return qrcodeToken;
	}

	/**
	 * Notification (Login)
	 */
	public String genLoginNotification() throws SystemException {

		logger.info("genLoginNotification() start");
		String token = null;

		try {
			JSONObject inputData = new JSONObject();
			inputData.put("requestType", BiometricConstants.GEN_LOGIN_NOTIF);
			inputData.put("param", "");
			token = handleBioAuth.invoke(inputData);
		} catch (Exception e) {
			logger.error("genLoginNotification() error:" + e.getMessage());
			throw new SystemException(SystemStatusCode.SSC_UNEXPECTED);
		}
		logger.info("genLoginNotification() end");
		return token;
	}

	/**
	 * Push Notification by ebanking
	 */
	public HashMap<String, String> pushNotification(String fioId, String msgTitle, String msgBody, boolean isIOS)
			throws SystemException {
		return pushNotification(fioId, msgTitle, msgBody, isIOS, false);
	}

	/**
	 * Push Notification by ebanking
	 */
	public HashMap<String, String> pushNotification(String fioId, String msgTitle, String msgBody, boolean isIOS,
			boolean isSecureLogin) throws SystemException {
		logger.info("pushNotification() start. ");
		HashMap<String, String> result = null;
		try {
			JSONObject rootObject = new JSONObject();
			rootObject.put("fioUserId", fioId);

			JSONObject data = new JSONObject();
			if (isSecureLogin) {
				data.put("text", "DATA");
			}
			data.put("title", msgTitle);
			data.put("body", msgBody);
			rootObject.put("data", data.toString());

			JSONObject notification = new JSONObject();
			if (isIOS) {
				notification.put("title", msgTitle);
				notification.put("body", msgBody);
			}
			rootObject.put("notification", notification.toString());

			// call osb
			HashMap<String, String> req = new HashMap<String, String>();
			req.put("requestType", "");
			req.put("requestData", rootObject.toString());

			//result = this.process(req);
			result = new HashMap<String, String>();
			result.put("status", "200");
			result.put("responseBody", "{\r\n" + 
					"	\"message\":{\r\n" + 
					"		\"status\":\"SUCCESS\"\r\n" + 
					"	}\r\n" + 
					"}");

		} catch (Exception e) {
			logger.error("pushNotification() error:" + e.getMessage());
			throw e;
		}
		if (result == null) {
			logger.info("pushNotification() end. result is null.");
		} else {
			logger.info("pushNotification() end. result is not null.");
		}
		return result;
	}
	
	public boolean logPushMessage(int msgType, String templateId, String custid, String deviceId, String msgTitle, String msgBody, 
			  int lang, String acctNum)
	{
		logger.info("BiometricTransAuthService lang:"+lang);
		logPush.setCustId(custid);
		logPush.setAccNum(acctNum);
		logPush.setMsgType(msgType);
		if(templateId != null && !"".equals(templateId)){
			logPush.setTemplateID(templateId);
		}
		logPush.setRecipient(deviceId);
		logPush.setTitle(msgTitle);
		logPush.setContent(msgBody);
		//english
		if(lang == 0){
			logPush.setLanguage("E");
		}else{
			logPush.setLanguage("T");
		}
		boolean rs = false;
		try{
			LogPushResponse resp = logPush.logPush();
			if(resp != null){
				if(String.valueOf(SystemStatusCode.SSC_NORMAL_EMS_RESPONE).equals(resp.getEmsHeader().getReturnCode())){
					rs = true;
				}
			}
		}catch(Exception e){
			logger.info("BiometricTransAuthService logPushMessage catch exception:" + e.getMessage());
		}
		logger.info("BiometricTransAuthService logPushMessage result:" + rs);
		
		return rs;
	}

	public HashMap<String, String> process(HashMap<String, String> req) throws SystemException {
		logger.info("process() start");

		try {

		} catch (Exception e) {
			logger.error("process() error:" + e.getMessage());
			throw new SystemException(SystemStatusCode.SSC_UNEXPECTED);
		}
		logger.info("process() end");
		return null;
	}	
}
