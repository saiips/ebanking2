package com.dsb.eb2.bankApp.biometric;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.logging.LogLevel;
import org.springframework.stereotype.Service;

import com.dsb.eb2.backOffice.connect.webService.handle.HandleLogPush;
import com.dsb.eb2.backOffice.connect.webService.logPush.EmsHeaderType;
import com.dsb.eb2.backOffice.connect.webService.logPush.LogPushRequest;
import com.dsb.eb2.backOffice.connect.webService.logPush.LogPushResponse;
import com.dsb.eb2.framework.log.Loggable;
import com.dsb.eb2.util.StringUtils;

@Service
public class EmsLogPushProcessor extends java.lang.Object{
	
	private static Logger logger = LoggerFactory.getLogger(BiometricHandler.class);
	
	@Autowired
	private HandleLogPush handleLogPush;
	
	//common header
	
	private String serviceID;
	public String getServiceID() {
		return serviceID;
	}

	public void setServiceID(String serviceID) {
		this.serviceID = serviceID;
	}

	public String getChannelID() {
		return channelID;
	}

	public void setChannelID(String channelID) {
		this.channelID = channelID;
	}

	private String channelID;
	private EmsHeaderType emsHeader;
	private String custId;
	private String reservedbyHost;
	
	//SendEmailRequest
	private String accNum;
	private String recipient;
	private String title;
	private String content;
	private String language;
	private int msgType = -1;
	private String refNum;
	private String templateID;
	private List<String> templateContent;
	
	public LogPushResponse logPush() throws Exception
	{
		try {
			LogPushResponse response = new LogPushResponse();
			logger.info("beg.EmsLogPushProcessor.logPush()");
			LogPushRequest request = this.getRequest();			
			response = handleLogPush.invoke(request);		
			logger.info("end.EmsLogPushProcessor.getResponse");
		
			return response;
		}catch(Exception e) {
			throw e;
		}
		
	}
	
	private LogPushRequest getRequest()
	{
		try {			
			LogPushRequest rq = new LogPushRequest();
			rq.setEmsHeader(prepareEmsHeaderTypeParam());
			prepareEmsBodyParam(rq);
			return rq;
		}catch (Exception e){
			throw e;
		}
	}
	
	//********************** common beg **********************
	private EmsHeaderType prepareEmsHeaderTypeParam()
	{
		EmsHeaderType emsHeaderType = new EmsHeaderType();
		
		emsHeaderType.setBankCode("6");
		if(StringUtils.isBlank(serviceID))
		{
			serviceID = "IB";
		}
		
		if(StringUtils.isBlank(channelID))
		{
			channelID = "EB";
		}
		
		emsHeaderType.setChannelID(channelID);
		emsHeaderType.setServiceID(serviceID);
		emsHeaderType.setServiceVersion(1);
		emsHeaderType.setCustID(custId);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		String formattedDate = sdf.format(new java.util.Date());
		emsHeaderType.setTxDateTime(formattedDate);
		return emsHeaderType;
	}
	
	@Loggable(result = false, value = LogLevel.INFO)
	private LogPushRequest prepareEmsBodyParam(LogPushRequest requestBean)
	{
		LogPushRequest result = null;
		if(requestBean != null)
		{
			String rq_accNum = this.getAccNum();
			String rq_recipient = this.getRecipient();
			String rq_title = this.getTitle();
			String rq_content = this.getContent();
			String rq_language = this.getLanguage() == null ? "E" : this.getLanguage();
			int rq_msgType = this.getMsgType();
			String rq_templateID = this.getTemplateID();
			List<String> rq_templateContent = new ArrayList<String>();
			rq_templateContent.add("");
			
			logger.info("EmsLogPushProcessor: rq_accNum=" + rq_accNum
																+ ", rq_recipient=" + rq_recipient
																+ ", rq_title=" + rq_title
																+ ", rq_content=" + rq_content
																+ ", rq_language=" + rq_language
																+ ", rq_msgType=" + rq_msgType
																+ ", rq_templateID=" + rq_templateID
																+ ", rq_templateContent=" + rq_templateContent);
			requestBean.setAcctNum(rq_accNum);
			requestBean.setRecipient(rq_recipient);
			requestBean.setTitle(rq_title);
			requestBean.setContent(rq_content);
			requestBean.setLanguage(rq_language);
			requestBean.setMsgType(rq_msgType);
			requestBean.setRefNum(requestBean.getEmsHeader().getSysTraceNum());
			requestBean.setTemplateID(rq_templateID);
			requestBean.setTemplateContent(null);
			
			result = requestBean;
		}
		return result;
	}
	//********************** common end **********************

	public EmsHeaderType getEmsHeader() {
		return emsHeader;
	}

	public void setEmsHeader(EmsHeaderType emsHeader) {
		this.emsHeader = emsHeader;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getReservedbyHost() {
		return reservedbyHost;
	}

	public void setReservedbyHost(String reservedbyHost) {
		this.reservedbyHost = reservedbyHost;
	}
	
	public String getAccNum() {
		return accNum;
	}

	public void setAccNum(String accNum) {
		this.accNum = accNum;
	}

	public String getRecipient() {
		return recipient;
	}

	public void setRecipient(String recipient) {
		this.recipient = recipient;
	}


	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public int getMsgType() {
		return msgType;
	}

	public void setMsgType(int msgType) {
		this.msgType = msgType;
	}

	public String getRefNum() {
		return refNum;
	}

	public void setRefNum(String refNum) {
		this.refNum = refNum;
	}

	public String getTemplateID() {
		return templateID;
	}

	public void setTemplateID(String templateID) {
		this.templateID = templateID;
	}

	public List<String> getTemplateContent() {
		return templateContent;
	}

	public void setTemplateContent(List<String> templateContent) {
		this.templateContent = templateContent;
	}
}
