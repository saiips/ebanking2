package com.dsb.eb2.bankApp.biometric;

import java.text.SimpleDateFormat;

public class BiometricConstants {
	
	public static final String LOGIN_TYPE_EB = "EB_LOGIN";
	public static final String LOGIN_TYPE_ISEC = "ISEC_LOGIN";
	
	public static final String TLK_TOKEN = "tlkToken";
	public static final String EBID = "EBID";

	// FIDO request type
	public static final String BIOMETRIC_FIDO_INIT_REG = "InitReg";
	public static final String BIOMETRIC_FIDO_FINISH_REG = "FinishReg";
	public static final String BIOMETRIC_FIDO_INIT_ADDAUTH = "InitAddAuth";
	public static final String BIOMETRIC_FIDO_FINISH_ADDAUTH = "FinishAddAuth";
	public static final String BIOMETRIC_FIDO_DE_REG = "DeReg";
	public static final String BIOMETRIC_FIDO_INIT_LOGIN = "InitLoginAuth";
	public static final String BIOMETRIC_FIDO_FINISH_LOGIN = "FinishLoginAuth";
	public static final String BIOMETRIC_FIDO_PUSH_NOTIF = "PushNotification";
	public static final String BIOMETRIC_FIDO_PUSH_NOTIF_WITH_TOKEN = "PushNotificationWithToken";
	public static final String BIOMETRIC_FIDO_DEVICE_CHECKING = "DeviceChecking";
	public static final String BIOMETRIC_FIDO_GET_SOFT_TOKEN_STATUS = "GetSoftTokenStatus";
	public static final String BIOMETRIC_FIDO_CHANGE_SOFT_TOKEN_STATUS = "ChangeSoftTokenStatus";
	public static final String BIOMETRIC_FIDO_SAFETYNET_CHECKING = "SafetyNetChecking";
	public static final String BIOMETRIC_FIDO_SYSTEM_HEALTH_CHECK = "SystemHealthCheck";
	public static final String BIOMETRIC_FIDO_GET_STATUS = "GetTokenStatus";
	
	public static final String GEN_LOGIN_QRCODE = "GenLoginQRcode";
	public static final String VALIDATE_LOGIN_QRCODE = "ValidateLoginQRcode";
	public static final String GEN_LOGIN_NOTIF = "GenLoginNotification";
	public static final String VALIDATE_LOGIN_NOTIF = "ValidateLoginNotif";
	public static final String CREATE_TRANS = "GreateTrans";
	public static final String CREATE_TRANS_WITH_NOTIF = "GreateTransWithNotif";
	public static final String CREATE_TRANS_WITH_QRCODE = "GreateTransWithQRcode";
	public static final String VALIDATE_TRANS_QRCODE = "ValidateTransQRcode";
	public static final String TRANS_REQUESTS = "TransRequests";
	public static final String TRANS_RESPONSES = "TransResponses";
	public static final String AUTH_TRANS_RESPONSES = "AuthTransResponses";
	public static final String RETRIEVE_TRANS_STATUS = "RetrieveTransStatus";
	public static final String CANCEL_TRANS_BY_MB = "CancelTransByMB";
	public static final String CANCEL_TRANS_BY_EB = "CancelTransByEB";
	public static final String PUSH_MSG_ACK = "PushMessageAck";

	public static final String BIOMETRIC_FIDO_SUCCESS_CODE = "201";
	public static final String BIOMETRIC_FIDO_OK_CODE = "200";

	// TLK server response transaction status
	public static final String TRANS_STATUS_PENDING = "PENDING";
	public static final String TRANS_STATUS_AUTHORIZED = "AUTHORIZED";
	public static final String TRANS_STATUS_RETRIEVED = "RETRIEVED";
	public static final String TRANS_STATUS_CANCELLED = "CANCELLED";
	public static final String TRANS_STATUS_QUERY_TIMEOUT = "QUERY_TIMEOUT";
	public static final String TRANS_STATUS_AUTH_TIMEOUT = "AUTHENTICATION_TIMEOUT";

	public static final String LOGIN_STATUS_EXPIRY = "EXPIRY";
	public static final String EBID_NOT_EXIST = "EBID_NOT_EXIST";
	public static final String CUSTID_NOT_EXIST = "CUSTID_NOT_EXIST";
	public static final String NO_REG_BIOAUTH = "NO_REG_BIOAUTH";

	// log push message type
	public static int LOGPUSH_ACTIVATE_MSGTYPE_ID = 1; // Activate Security Authentication Service
	public static int LOGPUSH_DEACTIVATE_MSGTYPE_ID = 2; // Deactivate Security Authentication Service
	public static int LOGPUSH_EB_LOGIN = 3; // Login e-Banking by Security Authentication Service
	public static int LOGPUSH_TXN_SIGNING = 4; // Transaction Signing by Security Authentication Service

	// Mobile Bank
	public static final String[] BIO_AUTH_NOTIFICATION_TITLE = { "Dah Sing Bank", "大新銀行" };

	public static final String[] BIO_AUTH_TYPE_LOGIN_EB_TITLE = { "login Dah Sing e-Banking Service", "登入網上理財服務" };
	public static final String[] BIO_AUTH_TYPE_ISECURITY_EB_TITLE = { "login Dah Sing i-Securities Services",
			"登入網上證券服務" };

	// language
	public static final int LANG_PREF_ENGLISH = 0;
	public static final int LANG_PREF_CHINESE = 1;

	public static final String LANG_PREF_ZH = "zh";
	public static final String LANG_PREF_ZH_TW = "zh_TW";
	public static final String LANG_PREF_ZH_HK = "zh_HK";
	public static final String LANG_PREF_EN_US = "en_US";

	public static final String BIO_PUSH_MESSAGE_EN_1 = "You have requested to ";
	public static final String BIO_PUSH_MESSAGE_EN_2 = " with Security Authentication at ";
	public static final String BIO_PUSH_MESSAGE_EN_3 = ". Please click here to authorize the instruction.";

	public static final String BIO_PUSH_MESSAGE_TC_1 = "您於";
	public static final String BIO_PUSH_MESSAGE_TC_2 = "要求透過保安認證";
	public static final String BIO_PUSH_MESSAGE_TC_3 = "。請按此授權相關指示。";

	public static final SimpleDateFormat BIO_PUSH_FORMATTER_TIME = new SimpleDateFormat("HH:mm:ss");
	public static final SimpleDateFormat BIO_PUSH_FORMATTER_DATE = new SimpleDateFormat("dd-MMM-yyyy");
	public static final SimpleDateFormat BIO_PUSH_FORMATTER_TC = new SimpleDateFormat("yyyy年MM月dd日HH:mm:ss");
	
	
	public static int convertLangType(String _lang) {
		int lang = 0;
		if(_lang instanceof String) {
			if(_lang.startsWith(BiometricConstants.LANG_PREF_ZH)) {
				lang = 1;
			}
		} else {
			lang = Integer.parseInt(_lang);
		}
		return lang;
	}

}
