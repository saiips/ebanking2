package com.dsb.eb2.bankApp.biometric;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dsb.eb2.bankApp.dao.bioAuthDetail.BioAuthDetailDao;
import com.dsb.eb2.bankApp.dao.bioAuthDetail.BioAuthDetailRepository;
import com.dsb.eb2.bankApp.dao.bioRegDevice.BioRegDeviceDao;
import com.dsb.eb2.bankApp.dao.bioTxnAuth.BiometricTxnAuthRepository;
import com.dsb.eb2.bankApp.dao.customer.CustomerDao;
import com.dsb.eb2.bankApp.dao.customer.CustomerRepository;
import com.dsb.eb2.framework.log.Loggable;
import com.dsb.eb2.util.StringUtils;

@Service
@Loggable
public class BiometricHandler {

	private static Logger logger = LoggerFactory.getLogger(BiometricHandler.class);
	
	@Autowired
	private BioAuthDetailRepository bioAuthDetailRepo; 
	
	@Autowired
	private BiometricTxnAuthRepository bioTxnAuthRepo; 
	
	@Autowired
	private BioRegDeviceDao bioRegDeviceDao;
	
	@Autowired
	private BioAuthDetailDao bioAuthDetailDao;
	
	@Autowired
	private CustomerDao customerDao;
	
	@Autowired
	private CustomerRepository res;
	
	@Autowired
	private BiometricTransAuthService bioAuthService;

	private static final String CHANNEL = "EB";

	public BiometricHandler() {
	}

	public String createLoginBioAuth(String bioAuthType, String custId, String loginType) {
		final String FUNCTION_NAME = "BiometricHandler.createLoginBioAuth ";

		String token = "";

		try {
			logger.info(FUNCTION_NAME + "bioAuthType=" + bioAuthType + ", custId=" + custId + ", loginType=" + loginType);


			if (BiometricConstants.GEN_LOGIN_QRCODE.equals(bioAuthType)) {
				token = bioAuthService.genLoginQRcode();
			} else if (BiometricConstants.GEN_LOGIN_NOTIF.equals(bioAuthType)) {
				token = bioAuthService.genLoginNotification();
			}

			if (!StringUtils.isEmpty(token)) {
				try {
					int cnt = 0;
					int count = 0;

					if (BiometricConstants.GEN_LOGIN_NOTIF.equals(bioAuthType)) {
						cnt = biometricLoginAuthExist(custId, bioAuthType);
					}

					String authenMethod = bioAuthType;
					String loginMethod = "EB";
					String status = "A";
					String channel = CHANNEL;

					if (cnt > 0) {						
						count = updateBiometricLoginAuth(status,new Date(),token);
					} else {						
						count = insertBiometricLoginAuth(token, authenMethod, loginMethod, custId, status, channel,
								loginType);
					}
					logger.info(FUNCTION_NAME + "count=" + String.valueOf(count));

					if (BiometricConstants.GEN_LOGIN_NOTIF.equals(bioAuthType)) {
						updateBiometricTransAuthStatus(custId, BiometricConstants.LOGIN_STATUS_EXPIRY);
					}
				} catch (Exception e) {
					throw e;
				}

			}

		} catch (Exception e) {
			logger.error(FUNCTION_NAME + "error:" + e.getMessage(), e);
		}

		logger.info(FUNCTION_NAME + "token=" + token);

		return token;
	}

	public int biometricLoginAuthExist(String custId, String authenMethod) throws Exception {

		int cnt = 0;

		cnt = bioAuthDetailDao.getBioAuthDetailCountByCustId(custId, authenMethod);

		return cnt;
	}

	public int updateBiometricLoginAuth(String status, Date lastUpdataDate, String token) throws Exception {

		int count = 0;
		try {
			count = bioAuthDetailRepo.updateBioTokenStatus(status, lastUpdataDate, token);
		}catch(Exception e) {
			logger.error("BiometricHandler updateBiometricLoginAuth error!");;
			throw e;
		}
		
		return count;

	}

	public synchronized int insertBiometricLoginAuth(String token, String authenMethod, String loginMethod, String custId,
			String status, String channel, String loginType) throws Exception {

		int count = 0;
		Long version = 1L;
		try {
			count = bioAuthDetailRepo.insertBioAuthDetail(custId, token, authenMethod, loginMethod, channel, status, new Date(), version);
		}catch(Exception e) {
			logger.error("insertBiometricLoginAuth error!!");
			e.printStackTrace();
			throw e;
		}
		return count;

	}
	
	public synchronized String[] getPushNotificationInfo(String custId)throws Exception
	{
		
		final String FUNCTION_NAME = "BiometricHandler.getPushNotificationInfo ";
	
		String[] pushNotificationInfo = null;
		try {
			Map<String,String> map = new HashMap<String,String>();	
			map = GetBioInfoByCustID(custId);
			if(map != null) {
				pushNotificationInfo = new String[3];
				pushNotificationInfo[0] = map.get("FIDO_ID");
				pushNotificationInfo[1] = map.get("DEVICE_BRAND");
				pushNotificationInfo[2] = map.get("DEVICE_ID");
			}
			
		}catch(Exception e) {
			logger.error(FUNCTION_NAME + "getPushNotificationInfo Exception error!");
			throw e;
		}		
		
		logger.info(FUNCTION_NAME + "pushNotificationInfo is null ?:" + (pushNotificationInfo == null) + ", pushNotificationInfo.length=" + (pushNotificationInfo != null ? pushNotificationInfo.length : 0));
		
		return pushNotificationInfo;
	}
	
	public synchronized int updateBiometricTransAuthStatus(String custId, String status)throws Exception
	{
	
		final String FUNCTION_NAME = "BiometricHandler.updateBiometricTransAuthStatus ";
		
		int count = 0;
		
		try
		{
			count = bioTxnAuthRepo.updateBioTokenStatus(status, new Date(), custId);
		
		}catch (Exception e)
		{
			throw e;
		}		
		
		return count;
	}
	
	public Map<String,String> GetBioInfoByCustID(String custId) throws IOException, Exception{
		Map<String,String> map = new HashMap<String,String>();	
		System.out.println("GetBioInfoByCustID bioRegDeviceDao = " +bioRegDeviceDao);
		map = bioRegDeviceDao.getBioInfoByCustID(custId);
		boolean flag = isCallOSBDBNoRecord(map);
		if(!flag) {
			return map;
		}
		return null;
	}
	
	public String getCustIdByEbId(String ebId) throws Exception {
		try {
			String custId = customerDao.getCustIdByEBId(ebId);
			return custId;
		}catch(Exception e) {
			throw e;
		}		
	}
	
	public boolean isCallOSBDBNoRecord(Map<String,String> map) {
		boolean flag = true;
		if(map == null)
		{
			return flag;
		}
		Iterator<Entry<String,String>> itera = map.entrySet().iterator();		
		while(itera.hasNext()) {
			Map.Entry<String, String> entry = (Map.Entry<String, String>) itera.next();
			if(!StringUtils.isEmpty(entry.getValue())) {
				flag = false;
			}
		}
		return flag;
	}

}
