package com.dsb.eb2.bankApp.biometric;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BiometricUtils {
	
	private static Logger logger = LoggerFactory.getLogger(BiometricUtils.class);
	
	public String getPushMessage(String[] txnTitle, Object lang)
	{
		String pushMessage = "";
		try
		{
			java.util.Date date = new java.util.Date();
			String dateString = "";
			
			if(isChiLanguage(lang))
			{
				dateString = BiometricConstants.BIO_PUSH_FORMATTER_TC.format(date);
				pushMessage = BiometricConstants.BIO_PUSH_MESSAGE_TC_1 + dateString + BiometricConstants.BIO_PUSH_MESSAGE_TC_2 + txnTitle[1] + BiometricConstants.BIO_PUSH_MESSAGE_TC_3;
			}else
			{
				dateString = BiometricConstants.BIO_PUSH_FORMATTER_TIME.format(date) + " on " + BiometricConstants.BIO_PUSH_FORMATTER_DATE.format(date);
				pushMessage = BiometricConstants.BIO_PUSH_MESSAGE_EN_1 + txnTitle[0] + BiometricConstants.BIO_PUSH_MESSAGE_EN_2 + dateString + BiometricConstants.BIO_PUSH_MESSAGE_EN_3;
			}
		}catch(Exception e)
		{
			logger.error("BiometricUtils.getPushMessage error :", e);
		}
		logger.info("BiometricUtils getPushMessage pushMessage = " + pushMessage);
		return pushMessage;
	}
	
	public static boolean isChiLanguage(Object lang)
	{
		boolean result = false;
		
		if(lang instanceof Integer)
		{
			if(BiometricConstants.LANG_PREF_CHINESE == (Integer)lang)
			{
				result = true;
			}
		}else if(lang instanceof String)
		{
			if(((String) lang).startsWith(BiometricConstants.LANG_PREF_ZH))
			{
				result = true;
			}
		}
		
		return result;
	}

}
