/*
 * AccountType.java
 *
 * Created on May 15, 2000, 11:37 AM
 */

package com.dsb.eb2.bankApp.account;

/**
 * Static class defining the symbol reference of
 * Account Type / Main Product.
 *
 * @author  Mike Chan
 * @version 0.0
 */
public class AccountType extends Object {

    public static final String AUTOPAY = "AP";
    public static final String ATM = "AT";
    public static final String CURRENT = "CA";
    public static final String CUSTOMER_STANDING_INSTR = "CI";
    public static final String CREDIT_CARD = "CS";
    public static final String CASH_CARD = "CH";
    public static final String EASI_GAIN = "EG";
    public static final String FIXED_DEPOSIT = "FD";
    public static final String HOME_BANKING = "HB";
    public static final String MORTGAGE_LOAN = "LN";
    public static final String MARGIN_TRADING = "MT";
    public static final String PAYMENT_COLLECTION = "PC";
    public static final String PERSONAL_LOAN = "PL";
    public static final String PHONE_BANKING = "PB";
    public static final String SAVINGS = "SA";
    public static final String UNIT_TRUST = "UT";
    public static final String SECURITIES = "SE";
    public static final String SHARE_MARGIN = "SM";

    public static boolean isDepositAcctType(String acctType) {
      if (acctType == null)
        return false;
      if ((acctType.equals(CURRENT))||
          (acctType.equals(SAVINGS))||
          (acctType.equals(FIXED_DEPOSIT)))
        return true;
      return false;
    }

    public static boolean isLoanAcctType(String acctType) {
      if (acctType == null)
        return false;
      if ((acctType.equals(MORTGAGE_LOAN))||
          (acctType.equals(PERSONAL_LOAN)))
        return true;
      return false;
    }
    
    public static boolean isDiscountLoan(String acctType, String productSubCode) {
        acctType = (acctType==null)?"":acctType;
        productSubCode = (productSubCode==null)?"":productSubCode;
        return (acctType.equals(PERSONAL_LOAN) && productSubCode.equals(ProductSubCode.DISCOUNT_LOAN));
    }

    public static boolean isCreditCardType(String acctType) {
      if (acctType == null)
        return false;
      if ((acctType.equals(CREDIT_CARD))||
          (acctType.equals(CASH_CARD)))
        return true;
      return false;
    }

    public static boolean isInvestmentType(String acctType, String productSubCode) {
      if (acctType == null)
        return false;
      if (acctType.equals(UNIT_TRUST) || acctType.equals(SECURITIES) 
      		|| (acctType.equals(FIXED_DEPOSIT) && productSubCode.equals(ProductSubCode.RETAIL_CD))
      		|| AccountType.isInvestPhase2Type(acctType, productSubCode))
        return true;
      return false;
    }

    public static boolean isRetailAcctType(String acctType) {
      if (acctType == null)
        return false;

      if ((acctType.equals(CURRENT)) || (acctType.equals(EASI_GAIN)) || (acctType.equals(FIXED_DEPOSIT))
          || (acctType.equals(MORTGAGE_LOAN)) || (acctType.equals(MARGIN_TRADING)) || (acctType.equals(PERSONAL_LOAN))
          || (acctType.equals(SAVINGS)) || (acctType.equals(UNIT_TRUST)))
        return true;
      else if (!( acctType.equals(AUTOPAY) || acctType.equals(ATM) || acctType.equals(CUSTOMER_STANDING_INSTR) || acctType.equals(CREDIT_CARD) //for account not in the list
               || acctType.equals(CASH_CARD) || acctType.equals(HOME_BANKING) || acctType.equals(PAYMENT_COLLECTION)))
        return true;
      else
        return false;
    }
    
    public static boolean isInvestPhase2Type(String acctType, String productSubCode) {
      return (acctType.equals(FIXED_DEPOSIT) &&
           (
             productSubCode.equals(ProductSubCode.EQUITY_LINKED_DEP) 
             || productSubCode.equals(ProductSubCode.STRUCTURED_DEP) 
             || productSubCode.equals(ProductSubCode.TARGET_REDEMPT_CTD) 
             || productSubCode.equals(ProductSubCode.REVERSE_FLOATER_CTD) 
             || productSubCode.equals(ProductSubCode.SWAP_HEDGED_CTD) 
             || productSubCode.equals(ProductSubCode.CCY_LINKED_PREM_DEP)
             || productSubCode.equals(ProductSubCode.CCY_LINKED_PRIN_GUA_DEP)   // Currency Linked Principal Guaranteed Deposit
           )
         );
    }
}