/*
 * ProductSubCode.java
 *
 * Created on May 18, 2000, 9:59 AM
 */
 
package com.dsb.eb2.bankApp.account;

/** 
 * Static class defining the symbol reference of 
 * Product Sub-Code.
 *
 * @author  Mike Chan
 * @version 0.0
 */
public class ProductSubCode extends Object {

  // for Credit Card (CS)
  public static final String MASTER_CLASSIC = "MC ";
  public static final String MASTER_GOLD = "MG ";
  public static final String VISA_CLASSIC = "VC ";
  public static final String VISA_GOLD = "VG ";
  public static final String MASTER_PLATINUM = "MP ";
  public static final String VISA_PLATINUM = "VP ";
  public static final String VIRTUAL_MASTER = "MV ";
  public static final String VIRTUAL_VISA = "VV ";
  public static final String PAYROLL_CARD = "VR ";
  public static final String VISA_INFINITE = "VI ";		// added for PDM07547
  
  // for Cash Card (CH)
  public static final String ECASH_CARD = "EC ";
  public static final String VCASH_CARD = "IC ";
  public static final String IN_MONEY_CARD = "IM ";

  // for ATM (AT)
  public static final String EXPRESS_MONEY_CARD = "EMC";
  
  // for Current (CA)
  public static final String FLEXIMONEY_OD = "FOD";
  public static final String EASI_CASH_OD = "EOD";
  public static final String I_ACCT_CA_CORE = "IAC";
  public static final String MAX_CALL_DEP_OD = "MOD";
  public static final String USD_CURRENT = "UCA";  
  public static final String RMB_CURRENT = "RCA";
  
  // for Saving (SA)
  public static final String USD_NOTE = "USN";
  public static final String MARGIN_TRADING = "MTD";
  public static final String I_ACCT_EASI_SAVE_CORE = "IAC";
  public static final String TARGET_SAVING = "TSD";
  public static final String THOMAS_N_FRD_KID = "TPB";
  public static final String ROBOT_KID = "DOK";
  public static final String TOOL_KID = "BPB";

  // for Fixed Deposit (FD)
  public static final String MONTHLY_GAIN_DEP = "MGA";
  public static final String FLOAT_RATE_SWAP_DEP = "FRS";
  public static final String PRIVILEGED_DEP = "PFD";
  public static final String MAX_CALL_DEP_FD = "MCA";
  /* for retail CD */  
  public static final String RETAIL_CD = "RCD";  
    
  // for Phone Banking (HB)
  public static final String REVOLVING_LOAN = "EMC";

  // for P-Loan (PL)
  public static final String TAX_LOAN = "TL ";
  public static final String CHINA_LOAN = "CL ";
  public static final String EXPRESS_MONEY_LOAN = "EMC";
  public static final String IN_MONEY_LOAN = "IN ";
  public static final String KIOSK_LOAN = "KL ";  
  public static final String EXPRESS_MONEY_INT_FR_LOAN = "EF ";
  public static final String DISCOUNT_LOAN = "MF ";
  
  // for Unit Trust 
  public static final String RETAIL_BOND = "RBD";
  public static final String PRIVATE_BANKING_PBN = "PBN";
  public static final String PRIVATE_BANKING_PPB = "PPB";
  
  // DSSD
  //public static final String DSSD = "EBD";  
  
  // FD investment products
  public static final String EQUITY_LINKED_DEP = "ELD";
  public static final String STRUCTURED_DEP = "EBD";
  public static final String TARGET_REDEMPT_CTD = "CDT";
  public static final String REVERSE_FLOATER_CTD = "CDR";
  public static final String SWAP_HEDGED_CTD = "CDW";
  public static final String CCY_LINKED_PREM_DEP = "CCD";
  public static final String CCY_LINKED_PRIN_GUA_DEP = "CGD";       // Currency Linked Principal Guaranteed Deposit
    
  // general
  public static final String NORMAL_OTHERS = "   ";

}
