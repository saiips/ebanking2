/*
 * DSB3pRetail.java
 *
 * Created on May 18, 2000, 12:20 PM
 */
 
package com.dsb.eb2.bankApp.account;

/** 
 * Class representing third-party retail accounts registered
 * by a customer via phone-banking.  
 * Only two types will be supported in this class:
 * 1. Current
 * 2. Savings
 * 
 * @author  Mike Chan
 * @version 0.0
 */
public class DSB3pRetail extends Account {

  protected boolean currOrSavAcctType;
  protected String ccy;
  protected boolean mcyInd; 
  
  /** Creates new DSB3pRetail */
  public DSB3pRetail(String acctNum,
                     AccountOwner[] acctOwners,
                     String bankCode,
                     String bankName,
                     boolean currOrSavAcctType,
                     String ccy,
                     boolean mcyInd) {
    this.acctNum = acctNum;
    this.acctOwners = acctOwners;
    this.bankCode = bankCode;
    this.bankName = bankName;
    this.currOrSavAcctType = currOrSavAcctType;
    this.ccy = ccy;
    this.mcyInd = mcyInd; 
  }

  public boolean isCurrentOrSavings() {
    return currOrSavAcctType;  
  }
    
  public String getCcy() {
    return ccy; 
  }
  
  public boolean isMcyAcct() {
    return mcyInd; 
  }
  
}