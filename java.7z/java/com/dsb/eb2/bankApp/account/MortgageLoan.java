/*
 * MortgageLoan.java
 *
 * Created on May 9, 2000, 10:33 AM
 */
 
package com.dsb.eb2.bankApp.account;

import java.util.*;

import com.dsb.eb2.bankApp.System.exeption.SystemException;

import java.text.*;

/** 
 * Class representing mortgage loan account.
 *
 * @author  Mike Chan
 * @version 0.0
 */
public class MortgageLoan extends Loan {

  /** Creates new MortgageLoan */
  public MortgageLoan(String acctNum,
                      AccountOwner[] acctOwners,
                      String bankCode,
                      String bankName,
                      String acctType,
                      String prodSubCode,
                      boolean iAcctInd,
                      String status,  
                      Map balance) {     
    this.acctNum = acctNum;
    this.acctOwners = acctOwners;
    this.bankCode = bankCode;
    this.bankName = bankName;
    this.acctType = acctType;
    this.prodSubCode = prodSubCode;
    this.iAcctInd = iAcctInd;
    this.status = status;
    this.balance = balance;
  }

  /* remember to add getActivities() later */
  
  public synchronized void refresh() throws SystemException {
	  
  } 
  
}