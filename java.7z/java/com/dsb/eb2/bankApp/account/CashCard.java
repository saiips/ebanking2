/*
 * CashCard.java
 *
 * Created on May 15, 2000, 7:25 PM
 */

package com.dsb.eb2.bankApp.account;

import java.util.*;

import com.dsb.eb2.bankApp.System.exeption.SystemException;

import java.text.*;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
/**
 * Class representing generic cash card accounts.
 *
 * @author  Mike Chan
 * @version 0.0
 */

public class CashCard extends DSBAccount {

  protected char cardStatus;
  protected char stmtFlag;
  protected char blockCode;
  protected double stmtBal;
  protected double minPay;
  protected double outstandBal;
  protected double availLimit;
  protected double creditLimit;
  protected Date payDueDate;
  protected String custNum;
  protected String holderOrg;
  protected String holderCardType;
  protected char expiryStatus;
  protected String cardNature; //Card nature by Lam Chi Kai on 20 AUG 2001

  /** Creates new VCash */
  public CashCard(String acctNum,
                  AccountOwner[] acctOwners,
                  String bankCode,
                  String bankName,
                  String acctType,
                  String prodSubCode,
                  boolean iAcctInd,
                  String status,
                  Map balance) {
    this.acctNum = acctNum;
    this.acctOwners = acctOwners;
    this.bankCode = bankCode;
    this.bankName = bankName;
    this.acctType = acctType;
    this.prodSubCode = prodSubCode;
    this.iAcctInd = iAcctInd;
    this.status = status;
    this.balance = balance;
  }

  public synchronized char getCardStatus() throws SystemException {
    initAcctDetails();
    return cardStatus;
  }

  public synchronized char getStmtFlag() throws SystemException {
    initAcctDetails();
    return stmtFlag;
  }

  public synchronized char getBlockCode() throws SystemException {
    initAcctDetails();
    return blockCode;
  }

  public synchronized double getStmtBal() throws SystemException {
    initAcctDetails();
    return stmtBal;
  }

  public synchronized double getMinPay() throws SystemException {
    initAcctDetails();
    return minPay;
  }

  public synchronized double getOutstandBal() throws SystemException {
    initAcctDetails();
    return outstandBal;
  }

  public synchronized double getAvailLimit() throws SystemException {
    initAcctDetails();
    return availLimit;
  }

  public synchronized double getCreditLimit() throws SystemException {
    initAcctDetails();
    return creditLimit;
  }

  public synchronized Date getPayDueDate() throws SystemException {
    initAcctDetails();
    return payDueDate;
  }

  public synchronized String getCustNum() throws SystemException {
    initAcctDetails();
    return custNum;
  }

  public synchronized String getHolderOrg() throws SystemException {
    initAcctDetails();
    return holderOrg;
  }

  public synchronized String getHolderCardType() throws SystemException {
    initAcctDetails();
    return holderCardType;
  }

  public synchronized char getExpiryStatus() throws SystemException {
    initAcctDetails();
    return expiryStatus;
  }

  public synchronized String getCardNature() throws SystemException {
    initAcctDetails();
    return cardNature; //Card nature by Lam Chi Kai on 20 AUG 2001
  }

  public synchronized void refresh() throws SystemException {
//    final String DATE_PATTERN = "yyyyMMdd";
//    ErrorLog el;
//    int checkPoint = 0;
//    try {
//       Env request = new Env();
//       request.put(EnvKey.BANK_CODE,BankCode.BC_SYS);
//       checkPoint++;
//       request.put(EnvKey.ACCT_NUM,acctNum);
//       checkPoint++;
//       request.put(EnvKey.CUST_ID,userId);
//       BackOfficeAgent agent = BackOfficeFactory.getAgent(BackOfficeFactory.CCARD_ACCT_ENQ_AGENT,true);
//       checkPoint++;
//       if (agent == null) {
//         el = new ErrorLog(SystemStatusCode.SSC_NO_AGENT_AVAILABLE,
//                           "No CCARD_ACCT_ENQ_AGENT available to handle request");
//         el.record();
//         throw new SystemException(SystemStatusCode.SSC_NO_AGENT_AVAILABLE);
//       }
//       checkPoint++;
//       Env response = agent.handle(request);
//       checkPoint++;
//
//
//       SimpleDateFormat sdf = new SimpleDateFormat(DATE_PATTERN);
//       cardStatus = (response.getStr(EnvKey.CARD_STATUS)).charAt(0);
//       checkPoint++;
//       stmtFlag = (response.getStr(EnvKey.STMT_FLAG)).charAt(0);
//       checkPoint++;
//       blockCode = (response.getStr(EnvKey.BLOCK_CODE)).charAt(0);
//       checkPoint++;
//       stmtBal = Double.parseDouble(response.getStr(EnvKey.STMT_BAL));
//       checkPoint++;
//       minPay = Double.parseDouble(response.getStr(EnvKey.MIN_PAY));
//       checkPoint++;
//       outstandBal = Double.parseDouble(response.getStr(EnvKey.OUTSTAND_BAL));
//       checkPoint++;
//       availLimit = Double.parseDouble(response.getStr(EnvKey.AVAIL_LIMIT));
//       checkPoint++;
//       creditLimit = Double.parseDouble(response.getStr(EnvKey.CR_LIMIT));
//       checkPoint++;
//       String payDueDateStr = response.getStr(EnvKey.PAY_DUE_DATE);
//       checkPoint++;
//       if ((payDueDateStr == null)||((payDueDateStr.trim()).length() == 0))
//         payDueDate = null;
//       else
//         payDueDate = sdf.parse(payDueDateStr);
//       checkPoint++;
//
//       int role = AccountOwner.SECONDARY_ROLE;
//       if ((acctNum != null)&&(acctNum.length() > 14)) {
//         if (acctNum.charAt(13) == '0')
//           role = AccountOwner.PRIMARY_ROLE;
//         else
//           role = AccountOwner.SECONDARY_ROLE;
//       }
//
//       acctOwners = new AccountOwner[1];
//       acctOwners[0] = new AccountOwner(response.getStr(EnvKey.CUST_ID),
//                                        response.getStr(EnvKey.TITLE),
//                                        response.getStr(EnvKey.NAME),
//                                        role);
//       checkPoint++;
//
//       custNum = response.getStr(EnvKey.CUST_NUM);
//       checkPoint++;
//       holderOrg = response.getStr(EnvKey.HOLDER_ORG);
//       checkPoint++;
//       holderCardType = response.getStr(EnvKey.HOLDER_CARD_TYPE);
//       checkPoint++;
//       expiryStatus = (response.getStr(EnvKey.XSTATUS)).charAt(0);
//       checkPoint++;
//       cardNature = response.getStr(EnvKey.CARD_NATURE); //Card nature by Lam Chi Kai on 20 AUG 2001
//       checkPoint++;
//    } catch (NullPointerException ex) {
//       el = new ErrorLog(SystemStatusCode.SSC_BOA_RESP_ERROR,
//                         "No Env or empty Env values obtained from CCARD_ACCT_ENQ_AGENT (CS-" + checkPoint + ")");
//       el.record();
//       throw new SystemException(SystemStatusCode.SSC_BOA_RESP_ERROR);
//    } catch (NumberFormatException ex) {
//       el = new ErrorLog(SystemStatusCode.SSC_BOA_RESP_ERROR,
//                         "Parsing error (number) for Env values obtained from CCARD_ACCT_ENQ_AGENT");
//       el.record();
//       throw new SystemException(SystemStatusCode.SSC_BOA_RESP_ERROR);
//    } catch (ParseException ex) {
//       el = new ErrorLog(SystemStatusCode.SSC_BOA_RESP_ERROR,
//                         "Parsing error (date) for Env values obtained from CCARD_ACCT_ENQ_AGENT");
//       el.record();
//       throw new SystemException(SystemStatusCode.SSC_BOA_RESP_ERROR);
//    }
  }

  public synchronized String toString() {
    StringBuffer sb = new StringBuffer();
    sb.append(super.toString());
    sb.append("Card Status           : " + cardStatus + "\n");
    sb.append("Statement Flag        : " + stmtFlag + "\n");
    sb.append("Block Code            : " + blockCode + "\n");
    sb.append("Statement Balance     : " + stmtBal + "\n");
    sb.append("Minimum Payment       : " + minPay + "\n");
    sb.append("Outstanding Balance   : " + outstandBal + "\n");
    sb.append("Available Limit       : " + availLimit + "\n");
    sb.append("Credit Limit          : " + creditLimit + "\n");
    sb.append("Payment Due Date      : " + payDueDate + "\n");
    sb.append("Cust Num              : " + custNum + "\n");
    sb.append("Card Holder Org       : " + holderOrg + "\n");
    sb.append("Card Holder Card Type : " + holderCardType + "\n");
    sb.append("Expiry Status         : " + expiryStatus + "\n");
    return sb.toString();
  }

//  public synchronized Vector getTransaction() throws SystemException
//  {
//  	Vector outputList = new Vector();
//
//	CreditCardTxLoader ccl = new CreditCardTxLoader(this.acctNum, this.bankCode, this.userId);
//
//	outputList = ccl.loadTransaction();
//
//
//	return outputList;
//  }

  public synchronized boolean isSuppCard() 
  {
  	if (this.acctNum.substring(13,14).equals("0"))
  		return false;
  	
  	return true;
  }  
}