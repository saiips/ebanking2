/*
 * CreditCard.java
 *
 * Created on May 15, 2000, 7:49 PM
 */

package com.dsb.eb2.bankApp.account;

import java.util.*;

import com.dsb.eb2.bankApp.System.exeption.SystemException;

/**
 * Class representing fixed deposit account.
 *
 * @author  Mike Chan
 * @version 0.0
 */
public class CreditCard extends DSBAccount {

  protected char cardStatus;
  protected char stmtFlag;
  protected char blockCode;
  protected double stmtBal;
  protected double minPay;
  protected double outstandBal;
  protected double availLimit;
  protected double creditLimit;
  protected Date payDueDate;
  protected int cashRewCredit;
  protected int cashRewEarn;
  protected String custNum;
  protected String holderOrg;
  protected String holderCardType;
  protected char expiryStatus;
  protected String cardNature; //Card nature by Lam Chi Kai on 20 AUG 2001
  protected CcBonusPoint ccBonus;
  protected Date memberSinceDate;
  protected int numOfStar; //Loyalty indicator added on 06 JAN 2004 by Cari

  /** Creates new CreditCard */

  //temp Constructor

  public CreditCard(String acctNum,
                    AccountOwner[] acctOwners,
                    String bankCode,
                    String bankName,
                    String acctType,
                    String prodSubCode,
                    boolean iAcctInd,
                    String status,
                    Map balance) {
    this.acctNum = acctNum;
    this.acctOwners = acctOwners;
    this.bankCode = bankCode;
    this.bankName = bankName;
    this.acctType = acctType;
    this.prodSubCode = prodSubCode;
    this.iAcctInd = iAcctInd;
    this.status = status;
    this.balance = balance;
  }

  public synchronized char getCardStatus() throws SystemException {
    initAcctDetails();
    return cardStatus;
  }

  public synchronized char getStmtFlag() throws SystemException {
    initAcctDetails();
    return stmtFlag;
  }

  public synchronized char getBlockCode() throws SystemException {
    initAcctDetails();
    return blockCode;
  }

  public synchronized double getStmtBal() throws SystemException {
    initAcctDetails();
    return stmtBal;
  }

  public synchronized double getMinPay() throws SystemException {
    initAcctDetails();
    return minPay;
  }

  public synchronized double getOutstandBal() throws SystemException {
    initAcctDetails();
    return outstandBal;
  }

  public synchronized double getAvailLimit() throws SystemException {
    initAcctDetails();
    return availLimit;
  }

  public synchronized double getCreditLimit() throws SystemException {
    initAcctDetails();
    return creditLimit;
  }

  public synchronized Date getPayDueDate() throws SystemException {
    initAcctDetails();
    return payDueDate;
  }

  public synchronized int getCashRewCredit() throws SystemException {
    initAcctDetails();
    return cashRewCredit;
  }

  public synchronized int getCashRewEarn() throws SystemException {
    initAcctDetails();
    return cashRewEarn;
  }

  public synchronized String getCustNum() throws SystemException {
    initAcctDetails();
    return custNum;
  }

  public synchronized String getHolderOrg() throws SystemException {
    initAcctDetails();
    return holderOrg;
  }

  public synchronized String getHolderCardType() throws SystemException {
    initAcctDetails();
    return holderCardType;
  }

  public synchronized char getExpiryStatus() throws SystemException {
    initAcctDetails();
    return expiryStatus;
  }

  public synchronized String getCardNature() throws SystemException {
    initAcctDetails();
    return cardNature; //Card nature by Lam Chi Kai on 20 AUG 2001
  }

  public synchronized Date getMemberSince() throws SystemException {
    initAcctDetails();
    return memberSinceDate;
  }

  public synchronized int getNumOfStar() throws SystemException {
    initAcctDetails();
    return numOfStar;
  }

  public synchronized String getRewardScheme() throws SystemException {
    initAcctDetails();
    if (ccBonus != null && ccBonus.isBonusPointScheme())
    	return ccBonus.BONUS_POINT_SCHEME;
    else
    	return ccBonus.CASH_REBATE_SCHEME;
  }

// getRewardSchemeType function is added for project Air (PDM04321)
  public synchronized String getRewardSchemeType() throws SystemException {
    initAcctDetails();
    if (ccBonus != null)
    	return ccBonus.getRewardScheme();
    else
    	return ccBonus.CASH_REBATE_SCHEME;
  }

  public synchronized boolean isBonusPointScheme() throws SystemException {
	  return getRewardScheme().equalsIgnoreCase(CcBonusPoint.BONUS_POINT_SCHEME);
  }

  public synchronized static boolean isBonusPointScheme(String rewardScheme) throws SystemException {
	  return (rewardScheme != null && rewardScheme.equalsIgnoreCase(CcBonusPoint.BONUS_POINT_SCHEME));
  }

  public synchronized double getBPLastMonthEarned() throws SystemException {
    initAcctDetails();
    if (ccBonus == null)
    	return 0.0;
    else
    	return ccBonus.getLastEarned();
  }

  public synchronized java.util.Date getBPExpiryDate() throws SystemException {
    initAcctDetails();
    if (ccBonus == null)
    	return null;
    else
    	return ccBonus.getExpiryDate();
  }

  public synchronized double getBPBalBroughtForward() throws SystemException {
    initAcctDetails();
    if (ccBonus == null)
    	return 0.0;
    else if (ccBonus.getOpenSign() != null && ccBonus.getOpenSign().equals("-"))
    	return -ccBonus.getOpenBal();
    else
    	return ccBonus.getOpenBal();
  }

  public synchronized double getBPCurrentMonthRedeemed() throws SystemException {
    initAcctDetails();
    if (ccBonus == null)
    	return 0.0;
    else
    	return ccBonus.getCtdRedeemed();
  }

  public synchronized double getBPCurrentBal() throws SystemException {
    initAcctDetails();
    if (ccBonus == null)
    	return 0.0;
    else if (ccBonus.getBalanceSign() != null && ccBonus.getBalanceSign().equals("-"))
    	return -ccBonus.getBalance();
    else
    	return ccBonus.getBalance();
  }

  /* remember to add getStatement() */

  /* remember to add getActivities() later */

  public synchronized void refresh() throws SystemException {
  }

  public synchronized String toString() {
    StringBuffer sb = new StringBuffer();
    sb.append(super.toString());
    sb.append("Card Status           : " + cardStatus + "\n");
    sb.append("Statement Flag        : " + stmtFlag + "\n");
    sb.append("Block Code            : " + blockCode + "\n");
    sb.append("Statement Balance     : " + stmtBal + "\n");
    sb.append("Minimum Payment       : " + minPay + "\n");
    sb.append("Outstanding Balance   : " + outstandBal + "\n");
    sb.append("Available Limit       : " + availLimit + "\n");
    sb.append("Credit Limit          : " + creditLimit + "\n");
    sb.append("Payment Due Date      : " + payDueDate + "\n");
    sb.append("Cash Reward Crediting : " + cashRewCredit + "\n");
    sb.append("Cash Reward Earned    : " + cashRewEarn + "\n");
    sb.append("Cust Num              : " + custNum + "\n");
    sb.append("Card Holder Org       : " + holderOrg + "\n");
    sb.append("Card Holder Card Type : " + holderCardType + "\n");
    sb.append("Expiry Status         : " + expiryStatus + "\n");
    sb.append("Bonus Pt / Cash Reward: " + ccBonus + "\n");
    sb.append("Number of Loyalty Star: " + numOfStar + "\n");
    return sb.toString();
  }

  public synchronized boolean isSuppCard()
  {
  	if (this.acctNum.substring(13,14).equals("0"))
  		return false;

  	return true;
  }

}




