package com.dsb.eb2.bankApp.account;

import java.util.*;

import com.dsb.eb2.bankApp.System.exeption.SystemException;

import java.text.*;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author Cari Pang
 * @version 1.0
 *
 * Class represent Retail Bond Account
 */

public class RetailBond extends DSBAccount {
  private double grandTotal;
  private Date detailLastUpdate;
  private Map bondHoldings;
  private boolean DEV = false;

  public RetailBond() {
  }

  public RetailBond(String acctNum,
                    AccountOwner[] acctOwners,
                    String bankCode,
                    String bankName,
                    String acctType,
                    String prodSubCode,
                    boolean iAcctInd,
                    String status,
                    Map balance) {
    this.acctNum = acctNum;
    this.acctOwners = acctOwners;
    this.bankCode = bankCode;
    this.bankName = bankName;
    this.acctType = acctType;
    this.prodSubCode = prodSubCode;
    this.iAcctInd = iAcctInd;
    this.status = status;
    this.balance = balance;

    this.bondHoldings = new Hashtable();
  }

  public synchronized void refresh() throws SystemException {
  }
}