/*
 * AccountNumDecoder.java
 *
 * Created on May 24, 2000, 1:46 PM
 */
 
package com.dsb.eb2.bankApp.account;

import java.sql.*;

import com.dsb.eb2.bankApp.System.SystemConfig;
import com.dsb.eb2.bankApp.System.exeption.SystemException;

/** 
 * Helper class which decodes the account type and currency
 * from an account number, based on an account table stored in database.
 * Note that this class is only for current and saving retail account.
 * 
 * @author  Mike Chan
 * @version 0.0
 */
public class AccountNumDecoder extends Object {

  private static final String DB_CONN_POOL_NAME 
    = SystemConfig.getSystemParameter("ebank_db_pool_name");
  
  private static final String SQL_SELECT_ACC_DEF
    = "SELECT ACCT_TYPE, ACCT_CCY " +
      "  FROM ACCT_NUM_DEF " +  
      "WHERE (FROM_ACCT_NUM <= ?) AND (TO_ACCT_NUM >= ?) ";
    
  private static final int FROM_ACCT_INDEX = 2;
  private static final int TO_ACCT_INDEX = 5;  
  private static final String MCY_INDICATOR = "MCY";
  
  private String acctNum;
  private String acctType = null;
  private String ccy = null;
  
  /** Creates new AccountNumDecoder */
  public AccountNumDecoder(String acctNum) {
    this.acctNum = acctNum;
  }
  
  public void decode() throws SystemException {

	  //call db
  }
  
  public String getAcctType() {
    return acctType; 
  }
  
  public String getAcctCcy() {
    return (isAcctMcy() ? null : ccy); 
  }
  
  public boolean isAcctMcy() {
    return ccy.equals(MCY_INDICATOR);
  }
 
  public static void main(String[] args) throws Exception {
    AccountNumDecoder decoder = new AccountNumDecoder("0033300000-00");
    decoder.decode();
    decoder = new AccountNumDecoder("0088800000-00");
    decoder.decode();

  }
}