/*
 * Current.java
 *
 * Created on May 6, 2000, 12:16 PM
 */

package com.dsb.eb2.bankApp.account;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dsb.eb2.backOffice.connect.EMSQueueConnector;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsMsgFactory;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsMsgUtils;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsRepMsg;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsReqMsg;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmHdr;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1110.AccountOwnerInfo;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1110.NF1110RepData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1110.NF1110ReqData;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.System.exeption.SystemException;

/**
 * Class representing current accounts, including Easi-Cash and Flexi-Money
 * accounts.
 *
 * @author Mike Chan
 * @version 0.0
 */
public class Current extends DSBAccount {
	
	private static Logger logger = LoggerFactory.getLogger(Current.class);
	private static String loggerFunctionName = "Current - ";

	protected String holdCode;
	protected double currentBal;
	protected double availableBal;
	protected double minPay;
	protected double upperLimit;
	protected Date accountOpenDate;

	/** Creates new Current */
	public Current(String acctNum, AccountOwner[] acctOwners, String bankCode, String bankName, String acctType,
			String prodSubCode, boolean iAcctInd, String status, Map balance, String acctName) {
		this.acctNum = acctNum;
		this.acctOwners = acctOwners;
		this.bankCode = bankCode;
		this.bankName = bankName;
		this.acctType = acctType;
		this.prodSubCode = prodSubCode;
		this.iAcctInd = iAcctInd;
		this.status = status;
		this.balance = balance;
		this.upperLimit = 0;
		this.acctName = acctName;
	}

	public Current(String acctNum, AccountOwner[] acctOwners, String bankCode, String bankName, String acctType,
			String prodSubCode, boolean iAcctInd, String status, Map balance) {
		this.acctNum = acctNum;
		this.acctOwners = acctOwners;
		this.bankCode = bankCode;
		this.bankName = bankName;
		this.acctType = acctType;
		this.prodSubCode = prodSubCode;
		this.iAcctInd = iAcctInd;
		this.status = status;
		this.balance = balance;
		this.upperLimit = 0;
	}

	public synchronized Date getAccountOpenDate() throws SystemException {
		initAcctDetails();
		return accountOpenDate;
	}

	public synchronized String getHoldCode() throws SystemException {
		initAcctDetails();
		return holdCode;
	}

	public synchronized double getCurrentBal() throws SystemException {
		initAcctDetails();
		return currentBal;
	}

	public synchronized double getAvailableBal() throws SystemException {
		initAcctDetails();
		return availableBal;
	}

	public synchronized double getMinPay() throws SystemException {
		initAcctDetails();
		return minPay;
	}

	public synchronized double getUpperLimit() throws SystemException {
		initAcctDetails();
		return upperLimit;
	}

	public synchronized boolean isOverdraftAcct() {
		/* true for Flexi-Money OD and Easi-Cash OD account */
		if ((prodSubCode.equals(ProductSubCode.FLEXIMONEY_OD)) || (prodSubCode.equals(ProductSubCode.EASI_CASH_OD))
				|| (prodSubCode.equals(ProductSubCode.MAX_CALL_DEP_OD)))
			return true;
		return false;
	}

	/* remember to add getStatement() */

	/* remember to add getActivities() later */

	public synchronized void refresh() throws SystemException {
	    /* for demo purpose
	    holdCode = "1200";
	    currentBal = 10000.00f;
	    availableBal = 9999.00f;
	    */
	    final String BOOLEAN_Y = "Y";
	    try {
	    	
	        final String DATE_PATTERN = "yyyyMMdd";
	        SimpleDateFormat sdf = new SimpleDateFormat(DATE_PATTERN);

	        //call NF1110 start
	       
	        NF1110ReqData request = new NF1110ReqData();
	        request.setAccountNumber(acctNum);
	        EmsReqMsg emsReqMsg = EmsMsgFactory.createEmsReqMsg(request, userId, "");
	       
	        String source = EmsMsgUtils.emsReqMsgToXML(emsReqMsg);
		    logger.info(loggerFunctionName + "emsReqMsgToXML :" + source);
			// invoke mq
			EMSQueueConnector connector = new EMSQueueConnector();
			EmsRepMsg emsRepMsg = connector.invoke(emsReqMsg,new NF1110RepData());
			FrmHdr frmHdr = emsRepMsg.getFrmHdr();
			NF1110RepData response = (NF1110RepData) emsRepMsg.getFrmData();
	        
	        
	       //call NF1110 end

		   logger.info("### CUR_ACCT_ENQ_AGENT response received. ###");

	       holdCode = response.getHoldCode1()+response.getHoldCode2()+response.getHoldCode3()+response.getHoldCode4();
	       currentBal = Double.parseDouble(response.getCurrentBalance());
	       availableBal = Double.parseDouble(response.getAvailableBalance());
	       minPay = Double.parseDouble(response.getMinimumPayment());
	// Begin Bug fix (accountOpenDate is 0 and is not used)
	       //SCR-DRD14058 START
	       String dateStr = response.getDateOpened();
	       if(dateStr != null && !"".equals(dateStr.trim()))
	           accountOpenDate = sdf.parse(dateStr.trim());
	       else
	           accountOpenDate = new java.util.Date(0);
	       //SCR-DRD14058 END
	// End Bug fix
	       List <AccountOwnerInfo> accountOwnerInfo = response.getAccountOwnerInfo();
	       int numOfOwners = accountOwnerInfo.size();
	       if (numOfOwners > 0) {
	         acctOwners = new AccountOwner[numOfOwners];
	         AccountOwner owner;
	         for (int i = 0; i < numOfOwners; i++) {
	            owner = new AccountOwner(accountOwnerInfo.get(i).getCustID(),
	            		accountOwnerInfo.get(i).getTitle(),
	            		accountOwnerInfo.get(i).getCustomerName1(),
	                                     ((accountOwnerInfo.get(i).getPrimaryOwnerInd()).equals(BOOLEAN_Y)
	                                      ? AccountOwner.PRIMARY_ROLE : AccountOwner.SECONDARY_ROLE));
	            acctOwners[i] = owner;
	         }
	       } else {
	         throw new SystemException(SystemStatusCode.SSC_NO_OWNER_FOUND);
	       }
	    } catch (NullPointerException ex) {
	       throw new SystemException(SystemStatusCode.SSC_BOA_RESP_ERROR);
	    } catch (NumberFormatException ex) {
	       throw new SystemException(SystemStatusCode.SSC_BOA_RESP_ERROR);
	    } catch (ParseException ex) {
	       throw new SystemException(SystemStatusCode.SSC_BOA_RESP_ERROR);
	    } catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error(e.getStackTrace().toString());;
		}
	}

	public synchronized String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append(super.toString());
		sb.append("Hold Code        : " + holdCode + "\n");
		sb.append("Current Balance  : " + currentBal + "\n");
		sb.append("Available Balance: " + availableBal + "\n");
		sb.append("Minimum Payment  : " + minPay + "\n");
		return sb.toString();
	}

}