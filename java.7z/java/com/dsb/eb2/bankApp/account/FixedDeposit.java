/*
 * FixedDeposit.java
 *
 * Created on May 15, 2000, 6:49 PM
 */

/*
 * Reference    Author      Date        Description
 * E2011004     Joe Leung   2011/04/01  PDM10453
 */
package com.dsb.eb2.bankApp.account;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import com.dsb.eb2.bankApp.System.exeption.SystemException;

/**
 * Class representing fixed deposit account.
 *
 * @author Mike Chan
 * @version 0.0
 */
public class FixedDeposit extends DSBAccount {

	protected String holdCode;
	protected int depositNumOfDur;
	protected char depositDurUnit;
	protected double interestRate;
	protected double principal;
	protected double totalPcpPlusInt;
	protected double interestOnMat;
	protected Date maturityDate;
	protected String renewType;
	protected int renewNumOfDur;
	protected char renewDurUnit;
	protected double basicRate;
	protected double markupRate;
	protected double pastDueInt;
	protected String creditAcctNum;
	protected String creditAcctCcy;
	protected String seqNum;
	protected boolean isSwap = false;
	protected String jointName1;
	protected String jointName2;
	protected String fdPrivIntFlag;

	// E2011004 Start
	protected String privMonIntPayFlag;
	protected String monIntPayAccNum;
	protected InterestRateHistory[] irhs;
	// E2011004 End

	// added by Franky Cheung 24 Mar 2004
	// for support of new schemes P+I+X and P+I-X
	protected double principalAdjustment;

	// currency switching phase 1b
	protected String currencySwitchIndt;
	private static final String logCategory = "EBANK";
	// currency switching phase 1b ends

	// PDM15434 Start
	protected String paymentOption;
	protected double monthlyPaymentPrincipal;
	protected double originalPrincipal;
	protected String promotionMonthly;
	protected double preferentialRate;
	protected double outsandingPrincipal;
	protected double interestAmount;
	// PDM15434 End

	// PDM18233
	protected String promotionCode;

	/** Creates new FixedDeposit */
	public FixedDeposit(String acctNum, AccountOwner[] acctOwners, String bankCode, String bankName, String acctType,
			String prodSubCode, boolean iAcctInd, String status, Map balance) {
		this.acctNum = acctNum;
		this.acctOwners = acctOwners;
		this.bankCode = bankCode;
		this.bankName = bankName;
		this.acctType = acctType;
		this.prodSubCode = prodSubCode;
		this.iAcctInd = iAcctInd;
		this.status = status;
		this.balance = balance;
		if (this.balance.containsKey("SWP")) {
			Object amt = this.balance.get("SWP");
			this.balance.remove("SWP");
			this.balance.put("USD", amt);
			this.isSwap = true;
		}
	}

	public synchronized String getHoldCode() throws SystemException {
		initAcctDetails();
		return holdCode;
	}

	public synchronized int getDepositNumOfDur() throws SystemException {
		initAcctDetails();
		return depositNumOfDur;
	}

	public synchronized char getDepositDurUnit() throws SystemException {
		initAcctDetails();
		return depositDurUnit;
	}

	public synchronized double getInterestRate() throws SystemException {
		initAcctDetails();
		return interestRate;
	}

	public synchronized double getPrincipal() throws SystemException {
		initAcctDetails();
		return principal;
	}

	public synchronized double getTotalPcpPlusInt() throws SystemException {
		initAcctDetails();
		return totalPcpPlusInt;
	}

	public synchronized double getInterestOnMat() throws SystemException {
		initAcctDetails();
		return interestOnMat;
	}

	public synchronized Date getMaturityDate() throws SystemException {
		initAcctDetails();
		return maturityDate;
	}

	public synchronized String getRenewType() throws SystemException {
		initAcctDetails();
		return renewType;
	}

	public synchronized int getRenewNumOfDur() throws SystemException {
		initAcctDetails();
		return renewNumOfDur;
	}

	public synchronized char getRenewDurUnit() throws SystemException {
		initAcctDetails();
		return renewDurUnit;
	}

	public synchronized double getBasicRate() throws SystemException {
		initAcctDetails();
		return basicRate;
	}

	public synchronized double getMarkupRate() throws SystemException {
		initAcctDetails();
		return markupRate;
	}

	public synchronized double getPastDueInt() throws SystemException {
		initAcctDetails();
		return pastDueInt;
	}

	public synchronized String getCreditAcctNum() throws SystemException {
		initAcctDetails();
		return creditAcctNum;
	}

	public synchronized String getCreditAcctCcy() throws SystemException {
		initAcctDetails();
		return creditAcctCcy;
	}

	public synchronized String getSeqNum() throws SystemException {
		initAcctDetails();
		return seqNum;
	}

	public synchronized boolean getIsSwap() throws SystemException {
		initAcctDetails();
		return isSwap;
	}

	public synchronized double getPrincipalAdj() throws SystemException {
		initAcctDetails();
		return principalAdjustment;
	}

//  public int getFdType() {
//    if (prodSubCode.equals(ProductSubCode.MONTHLY_GAIN_DEP))
//      return FixedDepositType.FDT_MONTHLY_GAIN;
//    if (prodSubCode.equals(ProductSubCode.PRIVILEGED_DEP)) {
//      if ((listAllCcy()[0]).equals(Currency.HKD_CCY))
//        return FixedDepositType.FDT_PRIVILEGED_HKD;
//      else
//        return FixedDepositType.FDT_PRIVILEGED_FOREX;
//    }
//    if (prodSubCode.equals(ProductSubCode.FLOAT_RATE_SWAP_DEP))
//      return FixedDepositType.FDT_FLOAT_RATE_SWAP;
//    if (prodSubCode.equals(ProductSubCode.MAX_CALL_DEP_FD))
//      return FixedDepositType.FDT_MAX_CALL_DEPOSIT;
//    /* for retail CD */
//    if (prodSubCode.equals(ProductSubCode.RETAIL_CD))
//      return FixedDepositType.FDT_RETAIL_CD;
//    return FixedDepositType.FDT_NORMAL;
//  }

	public synchronized String getJointName1() throws SystemException {
		initAcctDetails();
		return jointName1;
	}

	public synchronized String getJointName2() throws SystemException {
		initAcctDetails();
		return jointName2;
	}

	public synchronized String getFDPrivIntFlag() throws SystemException {
		initAcctDetails();
		return fdPrivIntFlag;
	}

	// E2011004 Start
	public synchronized void setPrivMonIntPayFlag(String v) {
		privMonIntPayFlag = v;
	}

	public synchronized void setMonIntPayAccNum(String v) {
		monIntPayAccNum = v;
	}

	public synchronized void setIRHS(InterestRateHistory[] v) {
		irhs = v;
	}

	public synchronized String getPrivMonIntPayFlag() throws SystemException {
		initAcctDetails();
		return privMonIntPayFlag;
	}

	public synchronized String getMonIntPayAccNum() throws SystemException {
		initAcctDetails();
		return monIntPayAccNum;
	}

	public synchronized InterestRateHistory[] getIRHS() throws SystemException {
		initAcctDetails();
		return irhs;
	}
	// E2011004 End

	/* remember to add getActivities() later */

	public synchronized void refresh() throws SystemException {
//    /* for demo purpose
//    double   interestRate_double    = 0.08      ;
//    double   principal_double       = 12300.00  ;
//    double   totalPcpPlusInt_double = 15000.00  ;
//    double   interestOnMat_double   = 1000.00   ;
//    maturityDate = new Date() ;
//
//
//    interestRate    = (double) interestRate_double;
//    principal       = (double) principal_double;
//    totalPcpPlusInt = (double) totalPcpPlusInt_double;
//    interestOnMat   = (double) interestOnMat_double;
//    */
//    final char CALL_DEPOSIT_DUR_UNIT = 'C';
//    final String DATE_PATTERN = "yyyyMMdd";
//    ErrorLog el;
//    try {
//       Env request = new Env();
//       request.put(EnvKey.BANK_CODE,BankCode.BC_SYS);
//       request.put(EnvKey.ACCT_NUM,acctNum);
//       request.put(EnvKey.CUST_ID,userId);
//       BackOfficeAgent agent = BackOfficeFactory.getAgent(BackOfficeFactory.FD_ACCT_ENQ_AGENT,true);
//       if (agent == null) {
//         el = new ErrorLog(SystemStatusCode.SSC_NO_AGENT_AVAILABLE,
//                           "No FD_ACCT_ENQ_AGENT available to handle request");
//         el.record();
//         throw new SystemException(SystemStatusCode.SSC_NO_AGENT_AVAILABLE);
//       }
//       Env response = agent.handle(request);
//
//
//       SimpleDateFormat sdf = new SimpleDateFormat(DATE_PATTERN);
//       holdCode             = response.getStr(EnvKey.HOLD_CODE);
//
//       depositNumOfDur      = Integer.parseInt(response.getStr(EnvKey.DEP_TERMS));
//
//       depositDurUnit       = (response.getStr(EnvKey.DEP_DUR_UNIT)).charAt(0);
//
//       interestRate         = Double.parseDouble(response.getStr(EnvKey.INT_RATE)); /* = basic rate + markup rate */
//
//       principal            = Double.parseDouble(response.getStr(EnvKey.PCP));
//
//       principalAdjustment      = Double.parseDouble(response.getStr(EnvKey.PCP_ADJ));
//
//       totalPcpPlusInt      = Double.parseDouble(response.getStr(EnvKey.TOTAL_PCP_PLUS_INT));
//
//       interestOnMat        = Double.parseDouble(response.getStr(EnvKey.INT_ON_MAT));
//
//
//       /* Newly added fields for FD Automation, they will be used in
//          FD Enquiry and FD Renewal as well as FD Uplift. */
//       markupRate   = Double.parseDouble(response.getStr(EnvKey.FD_MARKUP_RATE));
//
//       basicRate    = interestRate - markupRate;
//
//
//       pastDueInt   = Double.parseDouble(response.getStr(EnvKey.PAST_DUE_INT));
//
//       creditAcctNum= response.getStr(EnvKey.CREDIT_ACCT_NUM);
//
//       creditAcctCcy= response.getStr(EnvKey.CREDIT_ACCT_CCY);
//
//       seqNum       = response.getStr(EnvKey.SEQ_NUM);
//
//       jointName1 = response.getStr(EnvKey.FD_JOINT_NAME1);
//       if (jointName1.trim().length()==0)
//         jointName1 = jointName1.trim();
//
//       jointName2 = response.getStr(EnvKey.FD_JOINT_NAME2);
//       if (jointName2.trim().length()==0)
//         jointName2 = jointName2.trim();
//
//       fdPrivIntFlag = response.getStr(EnvKey.FD_PRIV_INT_FLAG);
//
//
//
//       if (depositDurUnit == CALL_DEPOSIT_DUR_UNIT)
//         maturityDate = null;
//       else
//         maturityDate = sdf.parse(response.getStr(EnvKey.MAT_DATE));
//       renewType = response.getStr(EnvKey.RENEW_TYPE);
//       renewNumOfDur = Integer.parseInt(response.getStr(EnvKey.RENEW_TERMS));
//       renewDurUnit = (response.getStr(EnvKey.RENEW_DUR_UNIT)).charAt(0);
//       Env acctOwnerEnv = response.getEnv(EnvKey.ACCT_OWNER);
//       int numOfOwners = acctOwnerEnv.getStrSeq(EnvKey.CUST_ID).length;
//       if (numOfOwners > 0) {
//         acctOwners = new AccountOwner[numOfOwners];
//         AccountOwner owner;
//         for (int i = 0; i < numOfOwners; i++) {
//            // no need to interpret the account role in fixed deposit - left it as OTHER_ROLE
//            owner = new AccountOwner(acctOwnerEnv.getStrSeq(EnvKey.CUST_ID)[i],
//                                     acctOwnerEnv.getStrSeq(EnvKey.TITLE)[i],
//                                     acctOwnerEnv.getStrSeq(EnvKey.NAME)[i],
//                                     AccountOwner.OTHER_ROLE);
//            acctOwners[i] = owner;
//
//            //set jointName1 default to A/C owner name
//            if (i==0 && jointName1.length()==0 && jointName2.length()==0) {
//              jointName1 = acctOwnerEnv.getStrSeq(EnvKey.NAME)[i];
//            }
//         }
//       } else {
//         el = new ErrorLog(SystemStatusCode.SSC_NO_OWNER_FOUND,
//                           "No owner retrieved from fixed deposit account " + acctNum);
//         el.record();
//         throw new SystemException(SystemStatusCode.SSC_NO_OWNER_FOUND);
//       }
//       
//       //E2011004 Start
//       setPrivMonIntPayFlag(response.getStr(EnvKey.PRIV_MON_INT_PAY_FLAG));
//       setMonIntPayAccNum(response.getStr(EnvKey.MON_INT_PAY_ACC_NUM));
//       
//       Env intRateHisEnv = response.getEnv(EnvKey.INT_RATE_HISORY_ENV);
//       if (intRateHisEnv != null && intRateHisEnv.getStrSeq(EnvKey.INT_END_DATE) != null && intRateHisEnv.getStrSeq(EnvKey.INT_END_DATE).length > 0) {
//           int numOfHis = intRateHisEnv.getStrSeq(EnvKey.INT_END_DATE).length;
//           if (numOfHis > 0) {
//               irhs = new InterestRateHistory[numOfHis];
//               for (int i = 0; i < numOfHis; i++) {
//                   InterestRateHistory irh = new InterestRateHistory();
//                   irh.setEndDate(intRateHisEnv.getStrSeq(EnvKey.INT_END_DATE)[i]);
//                   irh.setInterestAmount(Double.parseDouble(intRateHisEnv.getStrSeq(EnvKey.INT_AMOUNT)[i]));
//                   irh.setPaidFlag(intRateHisEnv.getStrSeq(EnvKey.INT_PAID_FLAG)[i]);
//                   irhs[i] = irh;
//               }
//           }
//       }
//       
//       //E2011004 End
//       //Currency switching phase 1B
//       this.currencySwitchIndt = response.getStr(EnvKey.CURR_SWITCH_INDT);
//       Log4jLogger.logInfo(FixedDeposit.logCategory, "Account number: " + this.acctNum);
//       Log4jLogger.logInfo(FixedDeposit.logCategory, "Account type: " + this.acctType);
//       Log4jLogger.logInfo(FixedDeposit.logCategory, "Product sub code: " + this.prodSubCode);
//       Log4jLogger.logInfo(FixedDeposit.logCategory, "Currency switching indicator: \"" + this.currencySwitchIndt + "\"");
//       ////Currency switching phase 1B ends
//       
//       
//       //PDM15434 Start
//       if(null != intRateHisEnv)
//       {
//    	   if(intRateHisEnv.getStr(EnvKey.MONTHLY_GAIN_PAYMENT_PRINCIPAL) != null && intRateHisEnv.getStr(EnvKey.MONTHLY_GAIN_PAYMENT_PRINCIPAL).length() > 0)
//    	   {
//    		   outsandingPrincipal = Double.parseDouble(intRateHisEnv.getStr(EnvKey.MONTHLY_GAIN_PAYMENT_PRINCIPAL));
//    	   }
//    	   
//    	   if(intRateHisEnv.getStr(EnvKey.MONTHLY_GAIN_MATURITY_INTEREST) != null && intRateHisEnv.getStr(EnvKey.MONTHLY_GAIN_MATURITY_INTEREST).length() > 0)
//    	   {
//    		   interestAmount = Double.parseDouble(intRateHisEnv.getStr(EnvKey.MONTHLY_GAIN_MATURITY_INTEREST));
//    	   }
//       }
//       
//       Env monthlyGainInfoEnv = response.getEnv(EnvKey.MONTHLY_GAIN_INFO);
//       if(null != monthlyGainInfoEnv)
//       {
//    	   if(monthlyGainInfoEnv.getStr(EnvKey.PAYMENT_OPTION) != null && monthlyGainInfoEnv.getStr(EnvKey.PAYMENT_OPTION).length() > 0)
//    	   {
//    		   paymentOption = monthlyGainInfoEnv.getStr(EnvKey.PAYMENT_OPTION);
//    	   }
//    	   
//    	   if(null != monthlyGainInfoEnv.getStr(EnvKey.PARTIAL_PRINCIPAL) && monthlyGainInfoEnv.getStr(EnvKey.PARTIAL_PRINCIPAL).length() > 0)
//    	   {
//    		   monthlyPaymentPrincipal = Double.parseDouble(monthlyGainInfoEnv.getStr(EnvKey.PARTIAL_PRINCIPAL));
//    	   }
//    	   
//    	   if(null != monthlyGainInfoEnv.getStr(EnvKey.ORIGINAL_PRINCIPAL) && monthlyGainInfoEnv.getStr(EnvKey.ORIGINAL_PRINCIPAL).length() > 0)
//    	   {
//    		   originalPrincipal = Double.parseDouble(monthlyGainInfoEnv.getStr(EnvKey.ORIGINAL_PRINCIPAL));
//    	   }
//    	   
//    	   if(null != monthlyGainInfoEnv.getStr(EnvKey.PROMOTION_NUMBER_OF_MONTHS) && monthlyGainInfoEnv.getStr(EnvKey.PROMOTION_NUMBER_OF_MONTHS).length() > 0)
//    	   {
//    		   promotionMonthly = monthlyGainInfoEnv.getStr(EnvKey.PROMOTION_NUMBER_OF_MONTHS);
//    	   }
//    	   
//    	   if(null != monthlyGainInfoEnv.getStr(EnvKey.PREFERENTIAL_RATE) && monthlyGainInfoEnv.getStr(EnvKey.PREFERENTIAL_RATE).length() > 0)
//    	   {
//    		   preferentialRate = Double.parseDouble(monthlyGainInfoEnv.getStr(EnvKey.PREFERENTIAL_RATE));
//    	   }
//       }
//       Log4jLogger.logInfo(FixedDeposit.logCategory, "Payment Option : " + this.paymentOption);
//       Log4jLogger.logInfo(FixedDeposit.logCategory, "Monthly payment principal : " + this.monthlyPaymentPrincipal);
//       Log4jLogger.logInfo(FixedDeposit.logCategory, "Original principal: " + this.originalPrincipal);
//       Log4jLogger.logInfo(FixedDeposit.logCategory, "Promotion number of months : " + this.promotionMonthly);
//       Log4jLogger.logInfo(FixedDeposit.logCategory, "Preferential Rate : " + this.preferentialRate);
//       Log4jLogger.logInfo(FixedDeposit.logCategory, "outstanding principal : " + this.outsandingPrincipal);
//       Log4jLogger.logInfo(FixedDeposit.logCategory, "interest amount : " + this.interestAmount);
//       //PDM15434 End
//       
//       //PDM18233
//       promotionCode = response.getStr("048121");
//       
//    } catch (NullPointerException ex) {
//       el = new ErrorLog(SystemStatusCode.SSC_BOA_RESP_ERROR,
//                         "No Env or empty Env values obtained from FD_ACCT_ENQ_AGENT");
//       el.record();
//       throw new SystemException(SystemStatusCode.SSC_BOA_RESP_ERROR);
//    } catch (NumberFormatException ex) {
//       el = new ErrorLog(SystemStatusCode.SSC_BOA_RESP_ERROR,
//                         "Parsing error (number) for Env values obtained from FD_ACCT_ENQ_AGENT");
//       el.record();
//       throw new SystemException(SystemStatusCode.SSC_BOA_RESP_ERROR);
//    } catch (ParseException ex) {
//       el = new ErrorLog(SystemStatusCode.SSC_BOA_RESP_ERROR,
//                         "Parsing error (date) for Env values obtained from FD_ACCT_ENQ_AGENT");
//       el.record();
//       throw new SystemException(SystemStatusCode.SSC_BOA_RESP_ERROR);
//    }
	}

	// PDM18233 Start
	public void setPromotionCode(String v) {
		promotionCode = v;
	}

	public String getPromotionCode() {
		return promotionCode;
	}
	// PDM18233 End

	public synchronized String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append(super.toString());
		sb.append("Hold Code                        : " + holdCode + "\n");
		sb.append("Deposit no. of Duration          : " + depositNumOfDur + "\n");
		sb.append("Deposit Duration Unit            : " + depositDurUnit + "\n");
		sb.append("Interest Rate                    : " + interestRate + "\n");
		sb.append("Principal                        : " + principal + "\n");
		sb.append("Principal Adjustment             : " + principalAdjustment + "\n");
		sb.append("Total Pcp + Interest             : " + totalPcpPlusInt + "\n");
		sb.append("Interest On Maturity             : " + interestOnMat + "\n");
		sb.append("Maturity Date                    : " + maturityDate + "\n");
		sb.append("Renewal Type                     : " + renewType + "\n");
		sb.append("Deposit no. of Duration (renewal): " + renewNumOfDur + "\n");
		sb.append("Deposit Duration Unit (renewal)  : " + renewDurUnit + "\n");
		sb.append("Joint Name 1                     : " + jointName1 + "\n");
		sb.append("Joint Name 2                     : " + jointName2 + "\n");
		sb.append("Privileged Interest Rate Flag    : " + fdPrivIntFlag + "\n");

		// PDM15434 Start
		sb.append("Payment Option					: " + paymentOption + "\n");
		sb.append("Monthly payment principal        : " + monthlyPaymentPrincipal + "\n");
		sb.append("Original principal               : " + originalPrincipal + "\n");
		sb.append("Promotion number of months       : " + promotionMonthly + "\n");
		sb.append("Preferential Rate 				: " + preferentialRate + "\n");
		// PDM15434 End
		return sb.toString();
	}

	// E2011006 Start
	public static String appendMessage(String[] msg) {
		String result = "";
		if (msg != null && msg.length > 0) {
			for (int i = 0; i < msg.length; i++) {
				if (msg[i] != null && !msg[i].equals("")) {
					result += " " + msg[i].trim();
				}
			}
		}
		return result;
	}
	// E2011006 End

	// currency switching phase 1b
	public synchronized String getCurrencySwitchIndt() throws SystemException {
		initAcctDetails();
		return currencySwitchIndt;
	}

	// for AcctProfEnqAgent (NF1107) to set the indicator
	public synchronized void setCurrencySwitchIndt(String currencySwitchIndt) {
		this.currencySwitchIndt = currencySwitchIndt;
	}
	// currency switching phase 1b ends

	// PDM15434 Start

	public synchronized String getPaymentOption() {
		return paymentOption;
	}

	public synchronized double getMonthlyPaymentPrincipal() {
		return monthlyPaymentPrincipal;
	}

	public synchronized double getOriginalPrincipal() {
		return originalPrincipal;
	}

	public synchronized String getPromotionMonthly() {
		return promotionMonthly;
	}

	public synchronized double getPreferentialRate() {
		return preferentialRate;
	}

	public double getInterestAmount() {
		return interestAmount;
	}

	public void setInterestAmount(double interestAmount) {
		this.interestAmount = interestAmount;
	}

	public double getOutsandingPrincipal() {
		return outsandingPrincipal;
	}

    public void setOutsandingPrincipal(double outsandingPrincipal) {
	    this.outsandingPrincipal = outsandingPrincipal;
    }
}

// PDM15434 End
