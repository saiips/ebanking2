/*
 * Reference    Author      Date        Description
 * E2011004     Joe Leung   2011/04/01  PDM10453
 */

package com.dsb.eb2.bankApp.account;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/** 
 * A class which represents the owner of a given account. 
 *
 * @author  Mike Chan
 * @version 0.0
 */
public class InterestRateHistory implements java.io.Serializable {
  
  private static SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy"); 

  private String startDate;
  private String endDate;
  private double interestAmount;
  private String paidFlag;
 
  /** Creates new AccountOwner */
  public InterestRateHistory(String startDate, String endDate, double interestAmount, String paidFlag) {
    this.startDate = startDate;
    this.endDate = endDate;
    this.interestAmount = interestAmount;
    this.paidFlag = paidFlag;
  }

  public InterestRateHistory() {}
  
  public String getStartDate() {
    return startDate; 
  }
  
  public void setStartDate(String v) {
      this.startDate = v;
  }
  
  public String getEndDate() {
    return endDate;
  }
  
  public void setEndDate(String v) {
      this.endDate = v;
  }
  
  public double getInterestAmount() {
    return interestAmount; 
  }
 
  public void setInterestAmount(double v) {
      this.interestAmount = v;
  }
  
  public String getPaidFlag() {
      return paidFlag;
  }
  
  public void setPaidFlag(String v) {
      this.paidFlag = v;
  }
  
  public boolean isPaid() {
      if (paidFlag != null && paidFlag.toUpperCase().equals("Y")) {
          return true;
      }
      else {
          return false;
      }
  }
   
  public String getPaymentDate() {
      Calendar paymentDate = Calendar.getInstance();
      int endYear = Integer.parseInt(endDate.substring(0,4));
      int endMonth = Integer.parseInt(endDate.substring(4,6));
      int endDay = Integer.parseInt(endDate.substring(6,8));
      paymentDate.set(endYear, endMonth - 1, endDay);
      paymentDate.add(Calendar.DAY_OF_YEAR, 1);
      return df.format(paymentDate.getTime());
  }
  
  
  
  public static void main(String args[]) {
      InterestRateHistory irh = new InterestRateHistory();
      irh.setEndDate("20121231");
  }
  
}