/*
 * Account.java
 *
 * Created on May 2, 2000, 1:58 PM
 */

package com.dsb.eb2.bankApp.account;

import com.dsb.eb2.bankApp.System.exeption.SystemException;

/**
 * An abstract class which generalizes all the DSB accounts related to a
 * particular customer - including own accounts and registered 3rd parties
 * accounts.
 * 
 * @author Mike Chan
 * @version 0.0
 */
public abstract class Account {

	protected String acctNum;
	protected AccountOwner[] acctOwners;
	protected String bankCode;
	protected String bankName;
	protected String userId;
	protected String custNum;

	public String getAcctNum() {
		return acctNum;
	}

	public synchronized AccountOwner[] getAcctOwners() throws SystemException {
		return acctOwners;
	}

	public String getBankCode() {
		return bankCode;
	}

	public String getBankName() {
		return bankName;
	}

	public void setAccountUser(String userId) {
		this.userId = userId;
	}

	public String getCustNum() throws SystemException {
		return custNum;
	}

	public void setCustNum(String custNum) {
		this.custNum = custNum;
	}

	public synchronized String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("Account number : " + acctNum + "\n");
		if ((acctOwners != null) && (acctOwners.length > 0)) {
			sb.append("Account owners :-\n");
			for (int i = 0; i < acctOwners.length; i++)
				sb.append(acctOwners[i].toString());
		}
		sb.append("Bank code      : " + bankCode + "\n");
		sb.append("Bank name      : " + bankName + "\n");
		return sb.toString();
	}

}