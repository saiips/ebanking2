package com.dsb.eb2.bankApp.account;

import java.util.Map;

import com.dsb.eb2.bankApp.System.exeption.SystemException;


public class ShareMargin extends DSBAccount{


	public ShareMargin(String acctNum,
            AccountOwner[] acctOwners,
            String bankCode,
            String bankName,
            String acctType,
            String prodSubCode,
            boolean iAcctInd,
            String status,
            Map balance,
            String acctName)
	{
		this.acctNum = acctNum;
	    this.acctOwners = acctOwners;
	    this.bankCode = bankCode;
	    this.bankName = bankName;
	    this.acctType = acctType;
	    this.prodSubCode = prodSubCode;
	    this.iAcctInd = iAcctInd;
	    this.status = status;
	    this.balance = balance;
	    this.acctName = acctName;
	}
	
	@Override
	public void refresh() throws SystemException {
		// TODO Auto-generated method stub
		
	}

}
