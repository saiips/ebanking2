/*
 * CardAct.java
 *
 */
 
package com.dsb.eb2.bankApp.account;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** 
 * @author  
 * @version 0.0
 */
public class ATMCardAct extends Object {
	
	private static Logger logger = LoggerFactory.getLogger(ATMCardAct.class);

  private String fullCustID;   // up to 20 chars
  private String acctNum;      // Card number to be activiated
  private String DOB;          // YYYYMMDD
  private String idNumber;     // ID number (six digit)
  private String seqNum;       // sequence number
  private String idType;       // HKID or passport number
  private String idPrefix;
  private String idSuffix;
  private String ppNumber;
  private String day;
  private String month;
  private String year;
 
  //SCR-PDM10588 Start
  private String status;
  private String startDate;
  private String endDate;
  private double overseaLimit = 0.0;
  private double atmLimit = 0.0;
  private String lastAction;
  private String lastUpdateDate;
  private String lastUpdateTime;
  private String cardExpiryDate;
  private String lastUpdateID;
  private String email1;
  private String email2;
  private String fromDate;
  private String fromMonth;
  private String fromYear;
  private String toDate;
  private String toMonth;
  private String toYear;
  private String cardType;
  private String displayCardNum;
  private String edmEmail;
  private String currency;
  private String optIn;
  private String declare;
  
  public final static Integer ERROR_NO_ID_TYPE                     = new Integer(1);
  public final static Integer ERROR_NO_HKID_PREFIX                 = new Integer(2);
  public final static Integer ERROR_INVALID_HKID_PREFIX            = new Integer(3);
  public final static Integer ERROR_NO_HKID_NUMBER                 = new Integer(4);
  public final static Integer ERROR_INVALID_HKID_NUMBER            = new Integer(5);
  public final static Integer ERROR_NO_HKID_SUFFIX                 = new Integer(6);
  public final static Integer ERROR_INVALID_HKID_SUFFIX            = new Integer(7);
  public final static Integer ERROR_NO_PASSPORT_NUMBER             = new Integer(8);
  public final static Integer ERROR_INVALID_PASSPORT_NUMBER        = new Integer(9);
  public final static Integer ERROR_NO_ACCOUNT_NUMBER              = new Integer(10);
  public final static Integer ERROR_INVALID_ACCOUNT_NUMBER         = new Integer(11);
  public final static Integer ERROR_INVALID_ACCOUNT_NUMBER_LENGTH  = new Integer(12);
  public final static Integer ERROR_NO_SEQ_NUMBER                  = new Integer(13);
  public final static Integer ERROR_INVALID_SEQ_NUMBER             = new Integer(14);
  public final static Integer ERROR_INVALID_SEQ_NUMBER_LENGTH      = new Integer(15);
  public final static Integer ERROR_INVALID_EMAIL                  = new Integer(16);
  public final static Integer ERROR_NO_DECLARE                     = new Integer(17);
  public final static Integer ERROR_INVALID_HKID                   = new Integer(18);
  
  //SCR-PDPO
  public final static Integer ERROR_NO_AGREE_DM 				   = new Integer(19);
  
  //SCR-PDPO Start
  private String agreeDM;
  private String crossMarketOptout;
  
  public void setAgreeDM(String v) {
	  agreeDM = v;
  }
  public String getAgreeDM() {
	  return agreeDM;
  }
  
  public void setCrossMarketOptout(String v) {
	  crossMarketOptout = v;
  }
  public String getCrossMarketOptout() {
	  return crossMarketOptout;
  }
  //SCR-PDPO End
  
  private static Hashtable engErrMsg = new Hashtable();
  private static Hashtable chiErrMsg = new Hashtable();
  //PDM10588-2B 
  static {
	  engErrMsg.put(ERROR_NO_ID_TYPE, "Please select the ID type.");
	  engErrMsg.put(ERROR_NO_HKID_PREFIX, "Please enter the prefix alphabet of your ID number.");
	  engErrMsg.put(ERROR_INVALID_HKID_PREFIX, "Invalid entry!  Only character or number are accepted!");
	  engErrMsg.put(ERROR_NO_HKID_NUMBER, "Please enter your ID number.");
	  engErrMsg.put(ERROR_INVALID_HKID_NUMBER, "Invalid entry!  Only numbers are accepted.");
	  engErrMsg.put(ERROR_NO_HKID_SUFFIX, "Please enter the number in brackets on your ID number.");
	  engErrMsg.put(ERROR_INVALID_HKID_SUFFIX, "Invalid entry!  Only character or number are accepted!");
	  engErrMsg.put(ERROR_NO_PASSPORT_NUMBER, "Please enter passport number.");
	  engErrMsg.put(ERROR_INVALID_PASSPORT_NUMBER, "Invalid passport number");
	  engErrMsg.put(ERROR_NO_ACCOUNT_NUMBER, "Please input 14-Digit account number");
	  engErrMsg.put(ERROR_INVALID_ACCOUNT_NUMBER, "Invalid 14-Digit account number!  Only numbers are accepted!");
	  engErrMsg.put(ERROR_INVALID_ACCOUNT_NUMBER_LENGTH, "Invalid account number length!");
	  engErrMsg.put(ERROR_NO_SEQ_NUMBER, "Please input sequence number");
	  engErrMsg.put(ERROR_INVALID_SEQ_NUMBER, "Invalid sequence number!  Only numbers are accepted!");
	  engErrMsg.put(ERROR_INVALID_SEQ_NUMBER_LENGTH, "Invalid sequence number length!");
	  engErrMsg.put(ERROR_INVALID_EMAIL, "Please input a valid email address.");
	  engErrMsg.put(ERROR_NO_DECLARE, "Please tick the check box to accept the relevant terms before confirming the application.");
      //SCR-PDPO
	  engErrMsg.put(ERROR_NO_AGREE_DM, "Please tick the check box to accept the above terms.");
	  
	  chiErrMsg.put(ERROR_NO_ID_TYPE, "請 選 擇 正 確 的 身 份 證 明 文 件。");
	  chiErrMsg.put(ERROR_NO_HKID_PREFIX, "請 輸 入 身 份 證 號 碼 的 頭 位 英 文 字 母。");
	  chiErrMsg.put(ERROR_INVALID_HKID_PREFIX, "輸 入 錯 誤！ 系 統 只 接 受 號 碼 及 英 文 字 母 的 輸 入。");
	  chiErrMsg.put(ERROR_NO_HKID_NUMBER, "請 輸 入 身 份 證 號 碼。");
	  chiErrMsg.put(ERROR_INVALID_HKID_NUMBER, "輸 入 錯 誤！ 系 統 只 接 受 號 碼 的 輸 入。");
	  chiErrMsg.put(ERROR_NO_HKID_SUFFIX, "請 輸 入 身 份 證 號 碼 括 弧 內 的 號 碼。");
	  chiErrMsg.put(ERROR_INVALID_HKID_SUFFIX, "輸 入 錯 誤！ 系 統 只 接 受 號 碼 及 英 文 字 母 的 輸 入。");
	  chiErrMsg.put(ERROR_NO_PASSPORT_NUMBER, "請 輸 入 護 照 號 碼。");
	  chiErrMsg.put(ERROR_INVALID_PASSPORT_NUMBER, "輸 入 錯 誤！ 系 統 只 接 受 號 碼 及 英 文 字 母 的 輸 入。");
	  chiErrMsg.put(ERROR_NO_ACCOUNT_NUMBER, "請 輸 入 14 位 數 字 戶 口 號 碼。");
	  chiErrMsg.put(ERROR_INVALID_ACCOUNT_NUMBER, "輸 入 錯 誤! 系 統 只 接 受 號 碼 的 輸 入。");
	  chiErrMsg.put(ERROR_INVALID_ACCOUNT_NUMBER_LENGTH, "14 位 數 字 户 口 號 碼 長 度 不 符。");
	  chiErrMsg.put(ERROR_NO_SEQ_NUMBER, "請 輸 入 發 卡 編 號。");
	  chiErrMsg.put(ERROR_INVALID_SEQ_NUMBER, "輸 入 錯 誤! 系 統 只 接 受 號 碼 的 輸 入。");
	  chiErrMsg.put(ERROR_INVALID_SEQ_NUMBER_LENGTH, "發卡編號長度不符!");
	  chiErrMsg.put(ERROR_INVALID_EMAIL, "請 輸 入 有 效 的 電 郵 地 址。");
	  chiErrMsg.put(ERROR_NO_DECLARE, "請於按「確定」前剔選方格以表示接納有關申請條款。");
	  //SCR-PDPO
	  chiErrMsg.put(ERROR_NO_AGREE_DM, "請剔選方格以表示接納以上條款。");
  }
  
  public void setDeclare(String v) {
	declare = v;  
  }
  public boolean isDeclare() {
	  if (declare != null && declare.equals("Y")) {
		  return true;
	  }
	  else {
		  return false;
	  }
  }
  
  public static String getErrMsg(String version, Integer errCode) {
	if (version != null && version.equals("0")) {
		return (String)engErrMsg.get(errCode);
	}
	else {
		return (String)chiErrMsg.get(errCode);
	}	
  }
  
  public void setOptIn(String v) {
      optIn = v;
  }
  public String getOptIn() {
      return optIn;
  }
  
  public void setCurrency(String v) {
      currency = v;
  }
  
  public String getCurrency() {
      return currency;
  }
  
  public void setEdmEmail(String v) {
      edmEmail = v;
  }
  
  public String getEdmEmail() {
	  return edmEmail;
  }
  
  public boolean isUpdateEdm() {
      if (edmEmail != null && edmEmail.equals("Y")) {
          return true;
      }
      else {
          return false;
      }
  }
  
  public void setDisplayCardNum(String v) {
      displayCardNum = v;
  }
  
  public String getDisplayCardNum() {
      return displayCardNum;
  }
  
  public void setCardType(String v) {
      cardType = v;
  }
  public String getCardType() {
      return cardType;
  }
  
  public void setEmail1(String v) {
      email1 = v;
  }
  public String getEmail1() {
      return email1;
  }
  public void setEmail2(String v) {
      email2 = v;
  }
  public String getEmail2() {
      return email2;
  }
  
  public void setFromDate(String v) {
      fromDate = v;
  }
  public String getFromDate() {
      return fromDate;
  }
  
  public void setFromMonth(String v) {
      fromMonth = v;
  }
  public String getFromMonth() {
      return fromMonth;
  }
  
  public void setFromYear(String v) {
      fromYear = v;
  }
  public String getFromYear() {
      return fromYear;
  }
  
  public void setToDate(String v) {
      toDate = v;
  }
  public String getToDate() {
      return toDate;
  }
  
  public void setToMonth(String v) {
      toMonth = v;
  }
  public String getToMonth() {
      return toMonth;
  }
  
  public void setToYear(String v) {
      toYear = v;
  }
  public String getToYear() {
      return toYear;
  }
  public void setStatus(String v) {
      status = v;
  }
  public String getStatus() {
      return status;
  }
  
  public void setStartDate(String v) {
      startDate = v;
  }
  public String getStartDate() {
      return startDate;
  }
  
  public void setEndDate(String v) {
      endDate = v;
  }
  public String getEndDate() {
      return endDate;
  }
  
  public void setOverseaLimit(double v) {
      overseaLimit = v;
  }
  public double getOverseaLimit() {
      return overseaLimit;
  }
  
  public String getOverseaLimitStr() {
      Double tmp = new Double(overseaLimit);
      int i = tmp.intValue();
      return new Integer(i).toString();
  }
  
  public void setAtmLimit(double v) {
      atmLimit = v;
  }
  public double getAtmLimit() {
      return atmLimit;
  }
  
  public String getAtmLimitStr() {
      Double tmp = new Double(atmLimit);
      int i = tmp.intValue();
      return new Integer(i).toString(); 
  }
  
  public void setLastAction(String v){
      lastAction = v;
  }
  public String getLastAction() {
      return lastAction;
  }
  
  public void setLastUpdateDate(String v) {
      lastUpdateDate = v;
  }
  public String getLastUpdateDate() {
      return lastUpdateDate;
  }
  
  public void setLastUpdateTime(String v) {
      lastUpdateTime = v;
  }
  public String getLastUpdateTime() {
      return lastUpdateTime;
  }
  
  public void setLastUpdateID(String v) {
      lastUpdateID = v;
  }
  public String getLastUpdateID() {
      return lastUpdateID;
  }
  
  public void setCardExpiryDate(String v) {
      cardExpiryDate = v;
  }
  public String getCardExpiryDate() {
      return cardExpiryDate;
  }
  //SCR-PDM10588 end
  
  public static SimpleDateFormat df = new SimpleDateFormat("yyyy"); 
  public static int START_YEAR = 0;
  public static int END_YEAR = 0;
  
  static {
      String sYear = df.format(new Date().getTime());
      try {
          START_YEAR = Integer.parseInt(sYear) - 90;
          END_YEAR = Integer.parseInt(sYear) - 18;
      }
      catch (Exception e){}
  }
  
  public ATMCardAct(String _fullCustID, String _acctNum, String _DOB, String _idNumber, String _seqNum) {
    this.fullCustID = _fullCustID;
    this.acctNum = _acctNum;
    this.DOB = _DOB;
    this.idNumber = _idNumber;
    this.seqNum = _seqNum;
  }
  
  public ATMCardAct() {}
  
  public String getDay() {
      return day == null ? "" : day;
  }
  
  public void setDay(String v) {
      day = v;
  }
  
  public String getMonth() {
      return month == null ? "" : month;
  }
  
  public void setMonth(String v) {
      month = v;
  }
  
  public String getYear() {
      return year == null ? "" : year;
  }
  
  public void setYear(String v) {
      year = v;
  }
  
  public String getIdPrefix() {
      return idPrefix == null ? "" : idPrefix;
  }
  
  public void setIdPrefix(String v) {
      idPrefix = v;
  }
  
  public String getIdSuffix() {
      return idSuffix == null ? "" : idSuffix;
  }
  
  public void setIdSuffix(String v) {
      idSuffix = v;
  }
  
  public String getPpNumber() {
      return ppNumber == null ? "" : ppNumber;
  }
  
  public void setPpNumber(String v) {
      ppNumber = v;
  }
  
  public String getFullCustID() {
    return fullCustID == null ? "" : fullCustID; 
  }
  
  public void setFullCustID(String v) {
      fullCustID = v; 
  }
    
  public String getAcctNum() {
    return acctNum == null ? "" : acctNum;
  }

  public void setAcctNum(String v) {
      acctNum = v;
  }

  public String getDOB() {
    return DOB == null ? "" : DOB; 
  }
 
  public void setDOB(String v) {
      DOB = v; 
  }
   
  public String getIdNumber() {
      return idNumber == null ? "" : idNumber;
  }
  
  public void setIdNumber(String v) {
      idNumber = v;
  }
  
  public String getSeqNum() {
      return seqNum == null ? "" : seqNum;
  }
  
  public void setSeqNum(String v) {
      seqNum = v;
  }
  
  public String getIdType() {
      return idType == null ? "" : idType;
  }
  
  public void setIdType(String v) {
      idType = v;
  }
  
  public String getHKID() {
      return idPrefix + idNumber + idSuffix;
  }
  
  public String getFullCustomerID() {
      return idType + getHKID();
  }
  
  public static int convert(String idType, int errorCode) {
      int result = errorCode;
      if (errorCode == 23103 && idType.equals("ID")) {
          result = 23103;
      }
      else {
          result = result + 200000;
      }
      return result;
  }
  
  //PDM10588-2B Start
  public static int convertForOptIn(String idType, int errorCode) {
      int result = errorCode;
      if (errorCode == 23103 && idType.equals("ID")) {
          result = 222295;
      }
      else {
          result = result + 200000;
      }
      return result;
  }
  //PDM10588-2B End
  
  public String toString() {
    StringBuffer sb = new StringBuffer();
    //sb.append("fullID: " + fullCustID + "\n");
    sb.append("id type: " + idType + "\n");
    sb.append("id prefix: " + idPrefix + "\n");
    sb.append("id num: " + idNumber + "\n");
    sb.append("id suffix: " + idSuffix + "\n");
    sb.append("pp number: " + ppNumber + "\n");
    sb.append("acct#: " + acctNum + "\n");
    sb.append("seq#: " + seqNum + "\n");
    sb.append("year: " + year + "\n");
    sb.append("month: " + month + "\n");
    sb.append("day: " + day + "\n");
    sb.append("DOB: " + DOB + "\n");
    return sb.toString();
  }
  
  //PDM10588-2B Start
  public String toOptString() {
	   StringBuffer sb = new StringBuffer();
	    //sb.append("fullID: " + fullCustID + "\n");
	    sb.append("id type: " + idType + "\n");
	    sb.append("id prefix: " + idPrefix + "\n");
	    sb.append("id num: " + idNumber + "\n");
	    sb.append("id suffix: " + idSuffix + "\n");
	    sb.append("pp number: " + ppNumber + "\n");
	    sb.append("acct#: " + acctNum + "\n");
	    sb.append("seq#: " + seqNum + "\n");
	    sb.append("year: " + year + "\n");
	    sb.append("month: " + month + "\n");
	    sb.append("day: " + day + "\n");
	    sb.append("DOB: " + DOB + "\n");
	    if (email1 != null && !email1.equals("") && email2 != null && !email2.equals("")) {
	    	sb.append("Email: " + email1 + "@" + email2 + "\n");
	    }
	    else {
	    	sb.append("Email: null\n");
	    }
	    return sb.toString();  
  }
  //PDM10588-2B End
  
  public boolean isATM() {
	  logger.info("ATMCardAct.java cardType:" + cardType);
      if (cardType != null && cardType.equals("atm")) {
          return true;
      }
      else {
          return false;
      }
  }
  
  public String toEnqString() {
      StringBuffer sb = new StringBuffer();
      //sb.append("Cust Id:" + getFullCustID() + "\n");
      sb.append("acct#:" + getAcctNum() + "\n");
      sb.append("seq#:" + getSeqNum() + "\n");
      return sb.toString();
  }
 
  public String toCreditEnqString() {
      StringBuffer sb = new StringBuffer();
      //sb.append("Cust Id:" + getFullCustID() + "\n");
      sb.append("acct#:" + getAcctNum() + "\n");
      return sb.toString();
  }
 
  public String toUpdString() {
      StringBuffer sb = new StringBuffer();
      //sb.append("Cust Id:" + getFullCustID() + "\n");
      sb.append("acct#:" + getAcctNum() + "\n");
      if (isATM()) {
          sb.append("seq#:" + getSeqNum() + "\n");
      }
      sb.append("action:" + getLastAction() + "\n");
      sb.append("activation start date:" + getStartDate() + "\n");
      sb.append("activation end date:" + getEndDate() + "\n");
      sb.append("withdraw limit:" + getOverseaLimit() + "\n");
      sb.append("Email:" + getEmail1() + "@" + getEmail2() + "\n");
      sb.append("CheckBox:" + isUpdateEdm() + "\n");
      return sb.toString();
  }
}