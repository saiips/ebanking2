/*
 * AccountOwner.java
 *
 * Created on May 2, 2000, 7:03 PM
 */

package com.dsb.eb2.bankApp.account;

/**
 * A class which represents the owner of a given account.
 *
 * @author Mike Chan
 * @version 0.0
 */
public class AccountOwner implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7786058288553226039L;
	public static final int PRIMARY_ROLE = 0;
	public static final int SECONDARY_ROLE = 1;
	public static final int OTHER_ROLE = 2;

	private String id;
	private String title;
	private String name;
	private int role;

	/** Creates new AccountOwner */
	public AccountOwner(String id, String title, String name, int role) {
		this.id = id;
		this.title = title;
		this.name = name;
		this.role = role;
	}

	public String getId() {
		return id;
	}

	public String getTitle() {
		return title;
	}

	public String getName() {
		return name;
	}

	public boolean hasPrimaryRole() {
		return (role == PRIMARY_ROLE);
	}

	public int hashcode() {
		return id.hashCode();
	}

	public boolean equals(Object obj) {
		if (obj instanceof AccountOwner) {
			AccountOwner owner = (AccountOwner) obj;
			if (id.equals(owner.getId()))
				return true;
		}
		return false;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("id   : " + id + "\n");
		sb.append("owner: " + title + " " + name + "\n");
		sb.append("role : " + role + "\n");
		return sb.toString();
	}

}