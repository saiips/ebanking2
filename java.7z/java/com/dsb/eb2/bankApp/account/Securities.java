package com.dsb.eb2.bankApp.account;

import java.util.*;
import java.text.*;
import java.util.GregorianCalendar;

import com.dsb.eb2.bankApp.System.exeption.SystemException;
import com.dsb.eb2.common.constant.EnvKey;
import com.dsb.eb2.util.Env;

import java.text.SimpleDateFormat;

/**
 * This class retrieves account information and transaction history of Security
 * account from eTrade Securities System by message 1688 (TRANSACTION HISTORY
 * ENQUIRY) and 1689 (PORTFOLIO INQUIRY).
 *
 * @author edft
 * @version $Revision: 1.0 $ $Date: Jun 15 2004 15:23:58 $
 * @see dsb.eBanking.bankApp.account.InvestmentStock
 * @see dsb.eBanking.bankApp.account.SecuritiesTx
 * @see PkgEasySocket.ECRequest1688
 * @see PkgEasySocket.ECRequest1689
 */
public class Securities extends DSBAccount implements Runnable {
	private String accountType;
	private boolean realTimeQuote;
	private double grandTotal;
	private double gainLossTotal;
	private Map stockHoldings;
	private boolean hasAllTxnsLoaded = false;
	private Date txnFromDate;
	private Date txnToDate;
	private Vector txns;
	private Thread loadTrx;
//	private String threadStatus;
	private String txnStatus;
	private SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

	/**
	 * constructor
	 */
	public Securities() {
		super();
	}

	/**
	 * constructor
	 *
	 * @param acctNum
	 * @param acctOwners
	 * @param bankCode
	 * @param bankName
	 * @param acctType
	 * @param prodSubCode
	 * @param iAcctInd
	 * @param status
	 */
	public Securities(String acctNum, AccountOwner[] acctOwners, String bankCode, String bankName, String acctType,
			String prodSubCode, boolean iAcctInd, String status) {
		this.acctNum = acctNum;
		this.acctOwners = acctOwners;
		this.bankCode = bankCode;
		this.bankName = bankName;
		this.acctType = acctType;
		this.prodSubCode = prodSubCode;
		this.iAcctInd = iAcctInd;
		this.status = status;
		balance = new Hashtable();
		stockHoldings = new Hashtable();
		txns = new Vector();
		setTxnDates();
	}

	private void setTxnDates() {
		GregorianCalendar gCal = new GregorianCalendar();
		// edkl 20070621 Change end date to today -1
		gCal.add(Calendar.DAY_OF_MONTH, -1);
		txnToDate = gCal.getTime();
		gCal = new GregorianCalendar();
		gCal.add(Calendar.MONTH, -3);
		String fromDate = sdf.format(gCal.getTime());
		gCal.set(Integer.parseInt(fromDate.substring(0, 4)), Integer.parseInt(fromDate.substring(4, 6)) - 1,
				gCal.getMinimum(Calendar.DAY_OF_MONTH));
		txnFromDate = gCal.getTime();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void refresh() throws SystemException {
		// TODO Auto-generated method stub
		
	}
}
