/*
 * TargetSavings.java
 *
 * Created on May 3, 2000, 11:57 AM
 */
 
package com.dsb.eb2.bankApp.account;

import java.util.*;

import com.dsb.eb2.bankApp.System.exeption.SystemException;

import java.text.*;
/** 
 * Class representing target savings account.
 *
 * @author  Mike Chan
 * @version 0.0
 */
public class TargetSavings extends DSBAccount {
  
  protected String holdCode;
  protected int depositNumOfDur;
  protected char depositDurUnit;
  protected double totalPcpPlusInt;
  protected double pcpOnMat;
  protected double interestOnMat;
  protected Date maturityDate;
  protected double monthlyDep;
  protected Date nextInstallDate;
  protected int remainNumInstall;
  protected String acctStatus;	//status from NF1116
  
  /** Creates new TargetSavings */
  public TargetSavings(String acctNum,
                       AccountOwner[] acctOwners,
                       String bankCode,
                       String bankName,
                       String acctType,
                       String prodSubCode,
                       boolean iAcctInd,
                       String status,
                       Map balance) {     
    this.acctNum = acctNum;
    this.acctOwners = acctOwners;
    this.bankCode = bankCode;
    this.bankName = bankName;
    this.acctType = acctType;
    this.prodSubCode = prodSubCode;
    this.iAcctInd = iAcctInd;
    this.status = status;
    this.balance = balance;
  }

  public synchronized String getHoldCode() throws SystemException {
    initAcctDetails();
    return holdCode;
  }  
  
  public synchronized int getDepositNumOfDur() throws SystemException {
    initAcctDetails();
    return depositNumOfDur;
  }
  
  public synchronized char getDepositDurUnit() throws SystemException {
    initAcctDetails();
    return depositDurUnit;
  }
  
  public synchronized double getTotalPcpPlusInt() throws SystemException {
    initAcctDetails();
    return totalPcpPlusInt;  
  }
  
  public synchronized double getInterestOnMat() throws SystemException {
    initAcctDetails();
    return interestOnMat;
  }
  
  public synchronized Date getMaturityDate() throws SystemException {
    initAcctDetails();
    return maturityDate;
  }
  
  public synchronized double getMonthlyDep() throws SystemException {
    initAcctDetails();
    return monthlyDep;  
  }
  
  public synchronized Date getNextInstallDate() throws SystemException {
    initAcctDetails();
    return nextInstallDate;  
  }
  
  public synchronized int getRemainNumInstall() throws SystemException {
    initAcctDetails();
    return remainNumInstall;
  }
  
  /* remember to add getActivities() later */
  
  public String getAcctStatus() {
	return acctStatus;
}

public void setAcctStatus(String acctStatus) {
	this.acctStatus = acctStatus;
}

public synchronized void refresh() throws SystemException {
  } 

  public synchronized String toString() {
    StringBuffer sb = new StringBuffer();
    sb.append(super.toString());
    sb.append("Hold Code              : " + holdCode + "\n");    
    sb.append("Deposit no. of Duration: " + depositNumOfDur + "\n");
    sb.append("Deposit Duration Unit  : " + depositDurUnit + "\n");
    sb.append("Total Pcp + Interest   : " + totalPcpPlusInt + "\n");
    sb.append("Pcp On Maturity        : " + pcpOnMat + "\n");
    sb.append("Interest On Maturity   : " + interestOnMat + "\n");
    sb.append("Maturity Date          : " + maturityDate + "\n");
    sb.append("Monthly Deposit        : " + monthlyDep + "\n");
    sb.append("Next Installment Date  : " + nextInstallDate + "\n");
    sb.append("Rem no. of Installment : " + remainNumInstall + "\n");
    return sb.toString();             
  }  
  
}