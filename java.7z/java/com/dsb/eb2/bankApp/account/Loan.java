/*
 * Loan.java
 *
 * Created on May 8, 2000, 5:29 PM
 */

package com.dsb.eb2.bankApp.account;

import java.util.*;

import com.dsb.eb2.bankApp.System.exeption.SystemException;

/**
 * Class representing generic loan accounts.
 *
 * @author  Mike Chan
 * @version 0.0
 */
public abstract class Loan extends DSBAccount {

  protected double origLoanAmt;
  protected Date nextRepayDate;
  protected double installAmt;
  protected double loanOutstand;
  protected int remainNumInstall;

  public synchronized double getOrigLoanAmt() throws SystemException {
    initAcctDetails();
    return origLoanAmt; 
  }

  public synchronized Date getNextRepayDate() throws SystemException {
    initAcctDetails();
    return nextRepayDate;
  }
  
  public synchronized double getInstallAmt() throws SystemException {
    initAcctDetails();
    return installAmt;  
  }
  
  public synchronized double getLoanOutstand() throws SystemException {
    initAcctDetails();
    return loanOutstand; 
  }
   
  public synchronized int getRemainNumInstall() throws SystemException {
    initAcctDetails();
    return remainNumInstall; 
  }

  public synchronized String toString() {
    StringBuffer sb = new StringBuffer();
    sb.append(super.toString());
    sb.append("Original Loan Amount        : " + origLoanAmt + "\n");
    sb.append("Next Repayment Date         : " + nextRepayDate + "\n");
    sb.append("Installment Amount          : " + installAmt + "\n");
    sb.append("Loan Outstanding            : " + loanOutstand + "\n");
    sb.append("remaining No. of Installment: " + remainNumInstall + "\n");    
    return sb.toString();             
  }  
  
}