/*
 * PLoan.java
 *
 * Created on May 9, 2000, 10:44 AM
 */

package com.dsb.eb2.bankApp.account;

import java.util.*;

import com.dsb.eb2.bankApp.System.exeption.SystemException;

import java.text.*;

/**
 * Class representing personal loan account.
 *
 * @author Mike Chan
 * @version 0.0
 */
public class PLoan extends Loan {

	protected String holdCode;
	protected int numOfInstallOverdue;
	protected double preDiscountLoanAmt;

	/** Creates new PLoan */
	public PLoan(String acctNum, AccountOwner[] acctOwners, String bankCode, String bankName, String acctType,
			String prodSubCode, boolean iAcctInd, String status, Map balance) {
		this.acctNum = acctNum;
		this.acctOwners = acctOwners;
		this.bankCode = bankCode;
		this.bankName = bankName;
		this.acctType = acctType;
		this.prodSubCode = prodSubCode;
		this.iAcctInd = iAcctInd;
		this.status = status;
		this.balance = balance;
	}

	public synchronized int getNumOfInstallOverdue() throws SystemException {
		initAcctDetails();
		return numOfInstallOverdue;
	}

	public synchronized void refresh() throws SystemException {
	}

	public synchronized String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append(super.toString());
		sb.append("Hold Code                   : " + holdCode + "\n");
		sb.append("# of Overdue Instalment     : " + numOfInstallOverdue + "\n");
		sb.append("Pre-discount Loan Amount    : " + preDiscountLoanAmt + "\n");
		return sb.toString();
	}

}