/*
 * Savings.java
 *
 * Created on May 4, 2000, 11:27 AM
 */
 
package com.dsb.eb2.bankApp.account;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import com.dsb.eb2.bankApp.System.exeption.SystemException;



/** 
 *
 * Class representing savings account.
 *
 * @author  Mike Chan
 * @version 0.0
 */
public class Savings extends DSBAccount {

  protected String holdCode;
  protected Map currentBals = new Hashtable();
  protected Map availableBals = new Hashtable();
  protected boolean stmtAcctInd;
  private Date dateOpen = null;
  
  protected String suppressPaperStatement;
  
  /** Creates new Savings */
  public Savings(String acctNum,
                 AccountOwner[] acctOwners,
                 String bankCode,
                 String bankName,
                 String acctType,
                 String prodSubCode,
                 boolean iAcctInd,
                 String status,
                 Map balance,
                 String acctName) {     
    this.acctNum = acctNum;
    this.acctOwners = acctOwners;
    this.bankCode = bankCode;
    this.bankName = bankName;
    this.acctType = acctType;
    this.prodSubCode = prodSubCode;
    this.iAcctInd = iAcctInd;
    this.status = status;
    this.balance = balance;
	addrCode = "";
	this.acctName = acctName;
  }
  
  public Savings(String acctNum,
                 AccountOwner[] acctOwners,
                 String bankCode,
                 String bankName,
                 String acctType,
                 String prodSubCode,
                 boolean iAcctInd,
                 String status,
                 Map balance) {     
     this.acctNum = acctNum;
     this.acctOwners = acctOwners;
     this.bankCode = bankCode;
     this.bankName = bankName;
     this.acctType = acctType;
     this.prodSubCode = prodSubCode;
     this.iAcctInd = iAcctInd;
     this.status = status;
     this.balance = balance;
     addrCode = "";
  }

  public String getSuppressPaperStatement() {
	return suppressPaperStatement;
}

public void setSuppressPaperStatement(String suppressPaperStatement) {
	this.suppressPaperStatement = suppressPaperStatement;
}

public synchronized String getHoldCode() throws SystemException {
    initAcctDetails();
    return holdCode;
  }  
  
  public synchronized Map getCurrentBals() throws SystemException {
    initAcctDetails();
    return currentBals;
  }
  
  public synchronized Map getAvailableBals() throws SystemException {
    initAcctDetails();
    return availableBals;
  }
  
  public synchronized boolean isStmtAcct() throws SystemException {
    initAcctDetails();
    return stmtAcctInd;  
  }
  
  public synchronized Date getDateOpen() throws SystemException {
      initAcctDetails();
      return dateOpen;
  }

  /* remember to add getStatement() */
  
  /* remember to add getActivities() later */
  
  public synchronized void refresh() throws SystemException {
   
  } 

  public synchronized String toString() {
    StringBuffer sb = new StringBuffer();
    sb.append(super.toString());
    sb.append("Hold Code         : " + holdCode + "\n");
    Iterator itr;
    String ccyKey;
    double balValue;
    if ((currentBals != null)&&(currentBals.size() > 0)) {
      itr = (currentBals.keySet()).iterator();
      while (itr.hasNext()) {
        ccyKey = (String)itr.next();
        balValue = ((Double)(currentBals.get(ccyKey))).doubleValue();
        sb.append("Current Balances  : (" + ccyKey + ") " + balValue + "\n");  
      }
    } else {
      sb.append("Current Balances  : \n");
    }
    if ((availableBals != null)&&(availableBals.size() > 0)) {
      itr = (availableBals.keySet()).iterator();
      while (itr.hasNext()) {
        ccyKey = (String)itr.next();
        balValue = ((Double)(availableBals.get(ccyKey))).doubleValue();
        sb.append("Available Balances: (" + ccyKey + ") " + balValue + "\n");  
      }
    } else {
      sb.append("Available Balances  : \n");
    }
    sb.append("Is Statement Acct : " + stmtAcctInd + "\n");
    return sb.toString();             
  }  
 

  
}