/*
 * AccountPreloader.java
 *
 * Created on June 29, 2000, 5:01 PM
 */
 
package com.dsb.eb2.bankApp.account;

import com.dsb.eb2.bankApp.System.exeption.SystemException;

/** 
 * An account preloader which preloads DSB account
 * in separate thread.
 *
 * @author  Mike Chan
 * @version 0.0
 */
public class AccountPreloader extends Thread {

  private DSBAccount acct;
  private boolean done = false;
  private SystemException se;
  
  /** Creates new AccountPreloader */
  public AccountPreloader(DSBAccount acct) {
    this.acct = acct;
  }
  
  public DSBAccount getPreloadedAcct() {
    return acct;
  }
  
  public synchronized boolean isDone() {
    return done; 
  }

  public synchronized SystemException getException() {
    return se;
  }
    
  public void run() {
    try {
      acct.refresh();   
    } catch (SystemException ex) {
      se = ex;  
    } finally {
      done = true; 
    }
  }
  
}