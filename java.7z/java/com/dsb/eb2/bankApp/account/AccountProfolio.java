package com.dsb.eb2.bankApp.account;

import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.dsb.eb2.backOffice.connect.EMSQueueConnector;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsMsgFactory;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsMsgUtils;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsRepMsg;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsReqMsg;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmHdr;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1107.AcctDetails;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1107.NF1107RepData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1107.NF1107ReqData;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.System.exeption.SystemException;
import com.dsb.eb2.bankApp.dao.branch.BranchService;
import com.dsb.eb2.bankApp.dao.ccAcctInfo.CreditCardService;
import com.dsb.eb2.sso.model.CustomerInfo;

public class AccountProfolio {

	private static Logger logger = LoggerFactory.getLogger(AccountProfolio.class);
	private static String loggerFunctionName = "AccountProfolio - ";

	private String custId;
	private String phBkId;
	private CustomerInfo customer;

	private Account[] availAccts = {};
	private Account[] unavailAccts = {};

	private ATMCardAct[] atmCardList;
	private String[] creditCardList;
	private String[] cashCardList;
	
	@Autowired
	private BranchService branchService;
	
	@Autowired
	private CreditCardService creditCardService;

	/** Creates new AccountProfolio */
	public AccountProfolio(String custId, String phBkId) {
		this.custId = custId;
		this.phBkId = phBkId;
	}

	public AccountProfolio(CustomerInfo customer) {
		this.customer = customer;
		this.custId = customer.getCustId();
		this.phBkId = customer.getPhBkId();
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getPhBkId() {
		return phBkId;
	}

	public void setPhBkId(String phBkId) {
		this.phBkId = phBkId;
	}

	public CustomerInfo getCustomer() {
		return customer;
	}

	public void setCustomer(CustomerInfo customer) {
		this.customer = customer;
	}

	public Account[] getAvailAccts() {
		return availAccts;
	}

	public void setAvailAccts(Account[] availAccts) {
		this.availAccts = availAccts;
	}

	public Account[] getUnavailAccts() {
		return unavailAccts;
	}

	public void setUnavailAccts(Account[] unavailAccts) {
		this.unavailAccts = unavailAccts;
	}

	public ATMCardAct[] getATMCard() {
		return atmCardList;
	}

	public void setATMCard(ATMCardAct[] v) {
		atmCardList = v;
	}

	public String[] getCreditCard() {
		return creditCardList;
	}

	public void setCreditCard(String[] v) {
		creditCardList = v;
	}

	public void setCashCard(String[] v) {
		cashCardList = v;
	}

	public String[] getCashCard() {
		return cashCardList;
	}

	public void load() throws SystemException {
		final String BOOLEAN_Y = "Y";
		try {
			logger.info(loggerFunctionName + "### " + custId + " - AccountProfolio - START ### " + new Date());
			
			// call osb nf107 start
			NF1107ReqData requestData = new NF1107ReqData();

			// create message and convert to xml format
			EmsReqMsg emsReqMsg = EmsMsgFactory.createEmsReqMsg(requestData, "BR21860755       000", "");

			String source = EmsMsgUtils.emsReqMsgToXML(emsReqMsg);
			logger.info(loggerFunctionName + "emsReqMsgToXML :" + source);
			// invoke mq
			EMSQueueConnector connector = new EMSQueueConnector();
			EmsRepMsg emsRepMsg = connector.invoke(emsReqMsg, new NF1107RepData());

			// convert receive xml to message bean
			// EmsRepMsg emsRepMsg = EmsMsgUtils.XMLToEmsRepMsg(result);
			NF1107RepData respondData = (NF1107RepData) emsRepMsg.getFrmData();
			FrmHdr frmHdr = emsRepMsg.getFrmHdr();
			logger.info(loggerFunctionName + "ReturnCode = " + frmHdr.getReturnCode());
			// call osb nf1107 end
			
			// call osb db 获取credit card start
			//List<CreditCardInfo> allCreditCardList = creditCardService.getDBAllCreditCardList(custId);
			//List<AcctDetails> ccDetailList = new ArrayList<AcctDetails>();
			String acctNum = null;
			String acctType = null;
			String prodSubCode = null;
			boolean iAcctInd = false;
			String status = null;
			String ccy = null;
			double balance = 0.0;
			String singleJointAcctInd = null;					
			Hashtable balances = null;
			String custNum = null;
			String acctName = null;
			String lastAcctNum = null;
			String lastAcctType = null;
			String lastProdSubCode = null;
			// WMD14137 Fatca checking begin
			String acctTypeInd = null;
			// WMD14137 Fatca checking end

			String lastFiller = null;

			// SCR-PDM10588 Start
			Vector vecATM = new Vector();
			Vector vecCredit = new Vector();
			Vector vecCash = new Vector();
			
			
			// call osb db 获取credit card end

			// int numOfAccts = 0;
			int numOfAccts = 30;
			Vector availAcctList = new Vector();
			Vector unavailAcctList = new Vector();
			logger.info(loggerFunctionName + "### Number of Account:" + numOfAccts);

			if (numOfAccts > 0) {
				Account account;
				List<AcctDetails> AcctDetails = new ArrayList<AcctDetails>();
				if (AcctDetails != null && AcctDetails.size() > 0) {					
					
					
					// SCR-PDM10588 End

					AcctDetails acctDetail = AcctDetails.get(0);
					logger.info(loggerFunctionName + "SCR-PDM10588 First Entry Start type:" + acctType + " acct:"
							+ acctNum);
					acctNum = acctDetail.getAcctNum();
					acctType = acctDetail.getAcctType();
					prodSubCode = acctDetail.getProdSubCode();
					acctTypeInd = acctDetail.getAcctTypeInd();

					iAcctInd = acctDetail.getIacctInd().equals(BOOLEAN_Y);
					singleJointAcctInd = acctDetail.getJointSignInd();
					status = acctDetail.getStatusCode();
					ccy = acctDetail.getCurrencyCode();
					custNum = "";
					balance = Double.parseDouble(acctDetail.getBalance());
					balances = new Hashtable();
					balances.put(ccy, new Double(balance));

					acctName = "";

					lastAcctNum = acctNum;
					lastAcctType = acctType;
					lastProdSubCode = prodSubCode;					

					for (int i = 0; i < numOfAccts; i++) {
						acctDetail = AcctDetails.get(i);
						logger.info(loggerFunctionName + " SCR-PDM10588 numOfAccts:" + numOfAccts + " i:" + i);
						acctNum = acctDetail.getAcctNum();
						acctType = acctDetail.getAcctType();
						prodSubCode = acctDetail.getProdSubCode();

						logger.info(loggerFunctionName + " SCR-PDM10588 Start type:" + acctType + " acct:" + acctNum);
						if (acctType != null && acctType.equals("AT")) {
							logger.info("SCR-PDM10588 Inside");
							if (acctNum.length() == 12 && !acctNum.substring(2, 5).equals("328")
									&& !acctNum.substring(2, 5).equals("329")) {
								ATMCardAct atm = new ATMCardAct();
								atm.setAcctNum(acctNum.substring(0, 10));
								atm.setSeqNum(acctNum.substring(10));
								atm.setFullCustID(custId);
								String fullBranchCode = branchService
										.findCompleteBranchCode(atm.getAcctNum().substring(0, 2));
								atm.setDisplayCardNum("040" + fullBranchCode + atm.getAcctNum().substring(2));
								vecATM.add(atm);
							}
						}
						logger.info(loggerFunctionName + " SCR-PDM10588 END");

						if ((acctNum.equals(lastAcctNum)) && (acctType.equals(lastAcctType))
								&& (prodSubCode.equals(lastProdSubCode))) {
							// current entry is for previous account
							ccy = acctDetail.getCurrencyCode();
							balance = Double.parseDouble(acctDetail.getBalance());
							balances.put(ccy, new Double(balance));
						} else {
							// current entry is for new account
							// finish previous account
							account = buildAccount(lastAcctNum, lastAcctType, lastProdSubCode, iAcctInd, status,
									balances, acctName);
							logger.info(
									loggerFunctionName + " ### " + custId + " - AccountProfolio - Process ACCT_TYPE ["
											+ acctType + "] ### [" + lastAcctNum + "]");
							// account allowed to show
							if (account != null) {
								account.setAccountUser(custId);
								account.setCustNum(custNum);
								logger.info(loggerFunctionName + " ### " + custId + " - AccountProfolio - Status ### ["
										+ lastAcctNum + "/" + status + "]");
								if ((status == null) || (status.indexOf(DSBAccount.ON_BATCH_ACCT_STATUS) == -1)) {
									// a normal account
									availAcctList.add(account);
								} else {
									// an account which is on-batch
									unavailAcctList.add(account);
								}

								// SCR-PDM10588 Start

								if (account instanceof CreditCard) {
									DSBAccount tmp = (DSBAccount) account;
									if (!tmp.isProblematic()) {
										logger.info(loggerFunctionName + " AccountProfolio credit card:"
												+ account.getAcctNum());
										vecCredit.add(account.getAcctNum());
									}
								}
								if (account instanceof CashCard) {
									logger.info(
											loggerFunctionName + " AccountProfolio cash card:" + account.getAcctNum());
									vecCash.add(account.getAcctNum());
								}

								// currency switching phase 1b
								if (account instanceof FixedDeposit) {
									FixedDeposit fdAccount = (FixedDeposit) account;
									if ((lastFiller != null) && (lastFiller.length() > 0)) {
										char currencySwitchingIndicator = lastFiller.charAt(0);
										fdAccount.setCurrencySwitchIndt(Character.toString(currencySwitchingIndicator));
										logger.info(loggerFunctionName + "NF1107 currency switching indicator: \""
												+ currencySwitchingIndicator + "\"");
									}
								}
							}
							// currency switching phase 1b ends

							// Joint Account indicator: "J"-Joint Account; Space - single Account
							if (account instanceof DSBAccount) {
								DSBAccount dsbacc = (DSBAccount) account;
								logger.info(loggerFunctionName + "NF1107 account number: " + dsbacc.getAcctNum()
										+ ",Joint Account indicator:[" + singleJointAcctInd + "], account type ind:["
										+ acctTypeInd + "]");
								dsbacc.setSingleAcctInd(singleJointAcctInd);
								dsbacc.setAcctTypeInd(acctTypeInd);
							}
							// SCR-PDM10588 End
						}

					}
				}

			}

		} catch (NullPointerException ex) {
			// currency switching phase 1b
			logger.error(loggerFunctionName + "error:" + ex.getMessage(), ex);
			// currency switching phase 1b ends
			ex.printStackTrace(System.out);
			throw new SystemException(SystemStatusCode.SSC_BOA_RESP_ERROR);
		} catch (NumberFormatException ex) {
			// currency switching phase 1b
			logger.error(loggerFunctionName + "error:" + ex.getMessage(), ex);
			// currency switching phase 1b ends
			ex.printStackTrace(System.out);
			throw new SystemException(SystemStatusCode.SSC_BOA_RESP_ERROR);

		} catch (Exception e) {
			// currency switching phase 1b
			logger.error(loggerFunctionName + "error:" + e.getMessage(), e);
			// currency switching phase 1b ends
			throw new SystemException(SystemStatusCode.SSC_BOA_RESP_ERROR);
		}

	}

	private Account buildAccount(String acctNum, String acctType, String prodSubCode, boolean iAcctInd, String status,
			Map balances, String acctName) throws SystemException {
		if (acctType == null) {
			throw new SystemException(SystemStatusCode.SSC_INVALID_ACCT_TYPE);
		}

		/* drop out problematic or closed accounts */
		if (status != null) {
// closed
			if (status.indexOf(DSBAccount.CLOSED_ACCT_STATUS) != -1)
				return null;
// with inconsistent status
			if (status.indexOf(DSBAccount.INCONSISTENT_ACCT_STATUS) != -1)
				return null;
		}


		/* find the actual 20-digits phone-banking ID */
		if ((acctType.equals(AccountType.PHONE_BANKING)) || (acctType.equals(AccountType.HOME_BANKING))) {
			if (acctNum.indexOf(phBkId) != -1) {
				phBkId = acctNum;
			}
		}
		return null;
	}

}
