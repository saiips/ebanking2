package com.dsb.eb2.bankApp.account;

/**
 * <p>Title: CcBonusPoint.java</p>
 * <p>Description: A class represent a reocrd of the table CC_BONUS_POINT</p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: Dah Sing Bank, eCommerce Development Team</p>
 * @author Franky Cheung
 * @version 1.0
 */

import java.util.*;

public class CcBonusPoint {

  public CcBonusPoint() {
    deleted = false;
  }
  public static final String BONUS_POINT_SCHEME = "B";
  public static final String AIR_BONUS_POINT_SCHEME = "U";
  public static final String CASH_REBATE_SCHEME = "C";
  private String cardOrg;
  private String cardType;
  private String cardNumber;
  private String rewardScheme;
  private String openSign;
  private double openBal;
  private String balanceSign;
  private double balance;
  private double ctdRedeemed;
  private double ctdForfeited;
  private double ctdAdjCr;
  private double ctdAdjDr;
  private double lastEarned;
  private double lastRedeemed;
  private double lastForfeited;
  private java.util.Date expiryDate;
  private double totalAwarded;
  private boolean deleted;
  private java.util.Date fileDate;
  private java.util.Date uploadDate;

  public boolean isBonusPointScheme() {
    return (getRewardScheme() != null 
    		// Below line is added for project Air (PDM04321) && getRewardScheme().equalsIgnoreCase(BONUS_POINT_SCHEME));
    		&& ((getRewardScheme().equalsIgnoreCase(BONUS_POINT_SCHEME))||(getRewardScheme().equalsIgnoreCase(AIR_BONUS_POINT_SCHEME))));
  }
  
  public String getCardOrg() {
    return cardOrg;
  }
  public void setCardOrg(String cardOrg) {
    this.cardOrg = cardOrg;
  }
  public void setCardType(String cardType) {
    this.cardType = cardType;
  }
  public String getCardType() {
    return cardType;
  }
  public void setCardNumber(String cardNumber) {
    this.cardNumber = cardNumber;
  }
  public String getCardNumber() {
    return cardNumber;
  }
  public void setRewardScheme(String rewardScheme) {
    this.rewardScheme = rewardScheme;
  }
  public String getRewardScheme() {
    return rewardScheme;
  }
  public void setOpenSign(String openSign) {
    this.openSign = openSign;
  }
  public String getOpenSign() {
    return openSign;
  }
  public void setOpenBal(double openBal) {
    this.openBal = openBal;
  }
  public double getOpenBal() {
    return openBal;
  }
  public void setBalanceSign(String balanceSign) {
    this.balanceSign = balanceSign;
  }
  public String getBalanceSign() {
    return balanceSign;
  }
  public void setBalance(double balance) {
    this.balance = balance;
  }
  public double getBalance() {
    return balance;
  }
  public void setCtdRedeemed(double ctdRedeemed) {
    this.ctdRedeemed = ctdRedeemed;
  }
  public double getCtdRedeemed() {
    return ctdRedeemed;
  }
  public void setCtdForfeited(double ctdForfeited) {
    this.ctdForfeited = ctdForfeited;
  }
  public double getCtdForfeited() {
    return ctdForfeited;
  }
  public void setCtdAdjCr(double ctdAdjCr) {
    this.ctdAdjCr = ctdAdjCr;
  }
  public double getCtdAdjCr() {
    return ctdAdjCr;
  }
  public void setCtdAdjDr(double ctdAdjDr) {
    this.ctdAdjDr = ctdAdjDr;
  }
  public double getCtdAdjDr() {
    return ctdAdjDr;
  }
  public void setLastEarned(double lastEarned) {
    this.lastEarned = lastEarned;
  }
  public double getLastEarned() {
    return lastEarned;
  }
  public void setLastRedeemed(double lastRedeemed) {
    this.lastRedeemed = lastRedeemed;
  }
  public double getLastRedeemed() {
    return lastRedeemed;
  }
  public void setLastForfeited(double lastForfeited) {
    this.lastForfeited = lastForfeited;
  }
  public double getLastForfeited() {
    return lastForfeited;
  }
  public void setExpiryDate(java.util.Date expiryDate) {
    this.expiryDate = expiryDate;
  }
  public java.util.Date getExpiryDate() {
    return expiryDate;
  }
  public void setTotalAwarded(double totalAwarded) {
    this.totalAwarded = totalAwarded;
  }
  public double getTotalAwarded() {
    return totalAwarded;
  }
  public void setDeleted(boolean deleted) {
    this.deleted = deleted;
  }
  public boolean isDeleted() {
    return deleted;
  }
  public void setFileDate(java.util.Date fileDate) {
    this.fileDate = fileDate;
  }
  public java.util.Date getFileDate() {
    return fileDate;
  }
  public void setUploadDate(java.util.Date uploadDate) {
    this.uploadDate = uploadDate;
  }
  public java.util.Date getUploadDate() {
    return uploadDate;
  }

  public String toString() {
    StringBuffer sb = new StringBuffer();
    sb.append("------ CcBonusPoint ------");
    sb.append("Card Org: " + cardOrg + "\n");
    sb.append("Card Type: " + cardType + "\n");
    sb.append("Card Number: " + cardNumber + "\n");
    sb.append("Reward Scheme: " + rewardScheme + "\n");
    sb.append("Open Sign: " + openSign + "\n");
    sb.append("Open Bal: " + openBal + "\n");
    sb.append("Balance Sign: " + balanceSign + "\n");
    sb.append("Balance: " + balance + "\n");
    sb.append("Cycle-To-Date Redeemed: " + ctdRedeemed +"\n");
    sb.append("Cycle-To-Date Forfeited: " + ctdForfeited+"\n");
    sb.append("Cycle-To-Date Adjustment Cr.: " + ctdAdjCr+"\n");
    sb.append("Cycle-To-Date Adjustment Dr.: " + ctdAdjDr+"\n");
    sb.append("Last Redeemed: " + lastRedeemed+"\n");
    sb.append("Last Forfeited: " + lastForfeited+"\n");
    sb.append("Expiry Date: " + expiryDate+"\n");
    sb.append("Total Awarded: " + totalAwarded+"\n");
    sb.append("File Date: " + fileDate +"\n");
    sb.append("Upload Date: " + uploadDate + "\n");
    sb.append("isDeleted: " + deleted+"\n");
    sb.append("----------------------------------------\n");
    return sb.toString();
  }
}