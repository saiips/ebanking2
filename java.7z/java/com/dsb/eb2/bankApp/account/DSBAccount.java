/*
 * DSBAccount.java
 *
 * Created on May 2, 2000, 2:12 PM
 */

package com.dsb.eb2.bankApp.account;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dsb.eb2.bankApp.System.exeption.SystemException;

/**
 * Abstract class which generalizes the accounts belong
 * to a given customer in the banking application.
 *
 * @author  Mike Chan
 * @version 0.0
 */
public abstract class DSBAccount extends Account {
	
	private static Logger logger = LoggerFactory.getLogger(DSBAccount.class);

  public static final String BOTH_TO_SIGN_JOINT_ACCT_HOLD_CODE = "80";
  public static final String CLOSED_ACCT_STATUS = "C";
  public static final String INCONSISTENT_ACCT_STATUS = "?";
  public static final String ON_BATCH_ACCT_STATUS = "*";
  
  protected String acctType;
  protected String prodSubCode;
  protected boolean iAcctInd;
  protected String status;
  protected Map balance;
  protected String addrCode;
  protected boolean singleAcctInd;
  
  //WMD14137 Fatca checking beign
  protected String acctTypeInd;
  //WMD14137 Fatca checking end
  
  // initialization
  protected boolean hasAcctDetailsInit = false;

  // custom problem indicator
  protected boolean problemInd = false;
  
  
  protected String acctName;
  
  public String getAcctName() {
	return acctName;
  }


  public synchronized AccountOwner[] getAcctOwners() throws SystemException {
     initAcctDetails();
     return acctOwners;   
  }  
  
  public String getAcctType() {
    return acctType; 
  }
  
  public String getProdSubCode() {
    return prodSubCode;
  }

  public boolean isIAcct() {
    return iAcctInd; 
  }
  
  public String getStatus() {
    return status;  
  }
   
  public synchronized boolean isProblematic() throws SystemException {
    return (problemInd)||((status != null)&&(status.indexOf(DSBAccount.ON_BATCH_ACCT_STATUS) != -1));  
  }
  
  public synchronized void setProblematic(boolean value) {
    problemInd = value;  
  }

  public double getBalance(String ccy) {
    double balanceValue = Double.NaN;
      try {
        Double value = (Double)(balance.get(ccy));
        balanceValue = value.doubleValue();
      } catch (NullPointerException ex) {
      } catch (ClassCastException ex) {
      }
    return balanceValue;
  }

  public Map getBalance() {
    return balance;
  }

  public boolean hasCcy(String ccy) {
    return balance.containsKey(ccy);
  }
  
  public String[] listAllCcy() {
    String[] ccys = null;
    Set s = balance.keySet();
    int numOfCcy = s.size();
    if (numOfCcy > 0) {
      ccys = new String[numOfCcy];
      s.toArray(ccys);  
    }
    return ccys;
  }
  
  public String getAddrCode() {
	return addrCode;
  }
  
  public void setAddrCode(String s) {
	addrCode = s;
  }
    
  public boolean isSingleAcctInd() {
	return singleAcctInd;
}

public void setSingleAcctInd(String singleJointAcctInd) {
	if(" ".equals(singleJointAcctInd)){
		this.singleAcctInd = true;
	}else{
		this.singleAcctInd = false;
	}
}

public String getAcctTypeInd() {
	return acctTypeInd;
}

public void setAcctTypeInd(String acctTypeInd) {
	this.acctTypeInd = acctTypeInd;
}

public abstract void refresh() throws SystemException;

  /* remember to add getActivities() later */

  public synchronized String toString() {
     StringBuffer sb = new StringBuffer();
     sb.append(super.toString());
     sb.append("Account type    : " + acctType + "\n");
     sb.append("Product sub-code: " + prodSubCode + "\n");
     sb.append("Is I-Acct       : " + iAcctInd + "\n");
     sb.append("Status          : " + status + "\n");
     Iterator itr = (balance.keySet()).iterator();
     String ccyKey;
     double balValue;
     while (itr.hasNext()) {
       ccyKey = (String)itr.next();
       balValue = ((Double)(balance.get(ccyKey))).doubleValue();
       sb.append("Balance         : (" + ccyKey + ") " + balValue + "\n");  
     }
     return sb.toString();             
  }

  protected synchronized void initAcctDetails() throws SystemException {
    // initialize if necessary
    if (hasAcctDetailsInit)
      return;
    logger.info("Before Refresh ["+ acctNum+ ","+ hasAcctDetailsInit+ "]");
    refresh();
    hasAcctDetailsInit = true;     
	logger.info("After Refresh ["+ acctNum+ ","+ hasAcctDetailsInit+ "]");
  }

  
  public static DSBAccount convertToDSBAccount(Account account)
  {
	  try {
		  return (DSBAccount)account;
	  }
	  catch (Exception e)
	  {
		  return null;
	  }
  }
}
