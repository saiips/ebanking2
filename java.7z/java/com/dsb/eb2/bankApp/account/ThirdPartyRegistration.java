/*
 * ThirdPartyRegistration.java
 *
 * Created on May 31, 2000, 5:58 PM
 */

package com.dsb.eb2.bankApp.account;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.dsb.eb2.backOffice.connect.EMSQueueConnector;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsMsgFactory;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsMsgUtils;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsRepMsg;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsReqMsg;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmHdr;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1132.NF1132RepData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1132.NF1132ReqData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1132.RegAcctDetails;
import com.dsb.eb2.bankApp.System.BankCode;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.System.exeption.SystemException;
import com.dsb.eb2.bankApp.dao.ccAcctInfo.CreditCardInfo;
import com.dsb.eb2.bankApp.dao.ccAcctInfo.CreditCardService;

/**
 * Class which retrieves the pre-registered third party accounts, including
 * retail accounts and credit card (payment) accounts, for a customer.
 *
 * @author Mike Chan
 * @version 0.0
 */
public class ThirdPartyRegistration extends Object {

	private static Logger logger = LoggerFactory.getLogger(ThirdPartyRegistration.class);
	private static String loggerFunctionName = "ThirdPartyRegistration - ";

	private final static String TYPE_CA = "CA";
	private final static String TYPE_SA = "SA";
	private final static String TYPE_CC = "PY";
	private final static String BIN_DARLINGTON = "03";
	private final static boolean DEBUG = true;

	private String custId;
	private String phBkId;

	/** enhancement to ignore credit card problem on batch **/
	private boolean ccError = false;
	
	@Autowired
	private CreditCardService creditCardService;

	/** Creates new ThirdPartyRegistration */
	public ThirdPartyRegistration(String custId, String phBkId) {
		this.custId = custId;
		this.phBkId = phBkId;
	}

	public Account[] getThirdPartyAccounts() throws SystemException {
		try {
			Account[] accounts = {};
			// call osb start

			NF1132ReqData requestData = new NF1132ReqData();

			// create message and convert to xml format
			EmsReqMsg emsReqMsg = EmsMsgFactory.createEmsReqMsg(requestData, "BR21860755       000", "");

			String source = EmsMsgUtils.emsReqMsgToXML(emsReqMsg);
			logger.info(loggerFunctionName + "emsReqMsgToXML :" + source);
			// invoke mq
			EMSQueueConnector connector = new EMSQueueConnector();
			EmsRepMsg emsRepMsg = connector.invoke(emsReqMsg,new NF1132RepData());

			// convert receive xml to message bean
			// EmsRepMsg emsRepMsg = EmsMsgUtils.XMLToEmsRepMsg(result);
			NF1132RepData response = (NF1132RepData) emsRepMsg.getFrmData();
			FrmHdr frmHdr = emsRepMsg.getFrmHdr();
//			Env request = new Env();
//			request.put(EnvKey.BANK_CODE, BankCode.BC_SYS);
//			request.put(EnvKey.CUST_ID, custId);
//			request.put(EnvKey.PHBK_USER_ID, phBkId);
//			BackOfficeAgent agent = BackOfficeFactory.getAgent(BackOfficeFactory.REG_3P_ACCT_ENQ_AGENT, true);
//			Env response = agent.handle(request);

			// call osb end

			logger.info("### REG_3P_ACCT_ENQ_AGENT response received. ###");

			if (Integer.parseInt(response.getNumOfItems()) > 0) {

				int numOfAccts = response.getRegAcctDetails().size();
				Vector acctList = new Vector();
				if (numOfAccts > 0) {
					Account account;
					List<RegAcctDetails> regAcctList = new ArrayList<RegAcctDetails>();
					regAcctList = response.getRegAcctDetails();
					for (RegAcctDetails regAcctDetail : regAcctList) {
						account = buildAccount(regAcctDetail.getACNo(),
								regAcctDetail.getType(), regAcctDetail.getAcctName());
						if (account != null) {
							account.setAccountUser(custId);
							acctList.add(account);
						}
					}
				}
				int actualNumOfAccts = acctList.size();
				if (actualNumOfAccts > 0) {
					accounts = new Account[actualNumOfAccts];
					acctList.toArray(accounts);
				}

			}
			return accounts;
		} catch (NullPointerException ex) {
			throw new SystemException(SystemStatusCode.SSC_BOA_RESP_ERROR);
		} catch (NumberFormatException ex) {
			throw new SystemException(SystemStatusCode.SSC_BOA_RESP_ERROR);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	// [start] 2013-11-04 Ken Li: fix pvcs log#687 show 'MB' channel ID when doing
	// InterFundTransfer and BillPayment
	public Account[] getThirdPartyAccounts(String channelId) throws SystemException {
		try {
			Account[] accounts = {};
			//origin start
//			Env request = new Env();
//			request.put(EnvKey.BANK_CODE, BankCode.BC_SYS);
//			request.put(EnvKey.CUST_ID, custId);
//			request.put(EnvKey.PHBK_USER_ID, phBkId);
//
//			request.put(EnvKey.CHANNEL_ID, channelId); // 2013-11-04 Ken Li: fix pvcs log#687 show 'MB' channel ID when
//														// doing InterFundTransfer and BillPayment
//
//			BackOfficeAgent agent = BackOfficeFactory.getAgent(BackOfficeFactory.REG_3P_ACCT_ENQ_AGENT, true);
//			Env response = agent.handle(request);
			//origin end
			
			// call osb start

			NF1132ReqData requestData = new NF1132ReqData();

			// create message and convert to xml format
			EmsReqMsg emsReqMsg = EmsMsgFactory.createEmsReqMsg(requestData, "BR21860755       000", "");

			String source = EmsMsgUtils.emsReqMsgToXML(emsReqMsg);
			logger.info(loggerFunctionName + "emsReqMsgToXML :" + source);
			// invoke mq
			EMSQueueConnector connector = new EMSQueueConnector();
			EmsRepMsg emsRepMsg = connector.invoke(emsReqMsg,new NF1132ReqData());

			// convert receive xml to message bean
			// EmsRepMsg emsRepMsg = EmsMsgUtils.XMLToEmsRepMsg(result);
			NF1132RepData response = (NF1132RepData) emsRepMsg.getFrmData();
			FrmHdr frmHdr = emsRepMsg.getFrmHdr();

			// call osb end
			

			logger.info("### REG_3P_ACCT_ENQ_AGENT response received. ###");

			if (Integer.parseInt(response.getNumOfItems()) > 0) {

				int numOfAccts = response.getRegAcctDetails().size();
				Vector acctList = new Vector();
				if (numOfAccts > 0) {
					Account account;
					List<RegAcctDetails> regAcctList = new ArrayList<RegAcctDetails>();
					regAcctList = response.getRegAcctDetails();
					for (RegAcctDetails regAcctDetail : regAcctList) {
						account = buildAccount(regAcctDetail.getACNo(),
								regAcctDetail.getType(), regAcctDetail.getAcctName());
						if (account != null) {
							account.setAccountUser(custId);
							acctList.add(account);
						}
					}
				}
				int actualNumOfAccts = acctList.size();
				if (actualNumOfAccts > 0) {
					accounts = new Account[actualNumOfAccts];
					acctList.toArray(accounts);
				}

			}
			
			List<CreditCardInfo> ccList = creditCardService.getDBAllCreditCardList(custId);
			if(ccList != null && ccList.size()>0) {
				for(CreditCardInfo ccInfo : ccList) {
					//transform cc
				}
			}
			
			return accounts;
		} catch (NullPointerException ex) {
			throw new SystemException(SystemStatusCode.SSC_BOA_RESP_ERROR);
		} catch (NumberFormatException ex) {
			throw new SystemException(SystemStatusCode.SSC_BOA_RESP_ERROR);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	// [start] 2013-11-04 Ken Li: fix pvcs log#687 show 'MB' channel ID when doing
	// InterFundTransfer and BillPayment

	public boolean hasCcError() {
		return ccError;
	}

	private Account buildAccount(String acctNum, String acct3pType, String acctName) throws IOException, Exception {
		AccountOwner acctOwner;
		AccountOwner[] acctOwners;
		int checkPoint = 0;
		if (acct3pType.equals(TYPE_CA) || acct3pType.equals(TYPE_SA)) {
			AccountNumDecoder decoder = new AccountNumDecoder(acctNum);
			decoder.decode();
			acctOwner = new AccountOwner(null, null, acctName, AccountOwner.OTHER_ROLE);
			acctOwners = new AccountOwner[1];
			acctOwners[0] = acctOwner;
			return new DSB3pRetail(acctNum, acctOwners, BankCode.BC_SYS, BankCode.getBankName(BankCode.BC_SYS),
					acct3pType.equals(TYPE_CA), decoder.getAcctCcy(), decoder.isAcctMcy());
		}
		if (acct3pType.equals(TYPE_CC)) {
			// Filter Darlington card
			if (acctNum.startsWith(BIN_DARLINGTON)) {
				return null;
			}
			try {
				//call db get credit card start
				logger.info("For cust id: " + custId);
				logger.info("Look up cust num for primary cardholder");
				
				//call db get credit card  end
				CreditCardInfo detail = creditCardService.getDBCreditCardDetail(acctNum);
				acctOwners = new AccountOwner[1];
				acctOwners[0] = new AccountOwner(custId, detail.getCustTitle(),
						detail.getCustName(), 0);
				
				return new DSB3pCreditCard(acctNum, acctOwners, BankCode.BC_SYS, BankCode.getBankName(BankCode.BC_SYS),
						detail.getCardStatus().charAt(0), detail.getStmtFlag().charAt(0), detail.getBlockCode().charAt(0),detail.getXStatus().charAt(0));
			} catch (NullPointerException ex) {

				// tolerate for customer no longer to have the third party credit card account
				// throw new SystemException(SystemStatusCode.SSC_BOA_RESP_ERROR);

//     Disable CREDIT CARD UNAVAILABLE handling features    
				/*
				 * } catch (SystemException ex) { // enhancement to ignore credit card problem
				 * on batch if (!CardCodeIgnoreList.checkIf3pDetailsIgnore(ex.getErrorCode()))
				 * throw ex; else { ccError = true; }
				 */

			} catch (SystemException ex) {
				if (ex.getErrorCode() != SystemStatusCode.SSC_BOA_RESP_ERROR)
					throw ex;
				else {
				}
			}

		}
		return null;
	}

	/**
	 * Get a list of registered beneficiaries stored in phone-banking
	 */
	public List getBeneficiaryName() throws SystemException {		
		List nameList = new ArrayList();		
		return nameList;
	}

	// [start] 2013-11-04 Ken Li: fix pvcs log#687 show 'MB' channel ID when doing
	// InterFundTransfer and BillPayment
	public List getBeneficiaryName(String channelId) throws SystemException {
		
		List nameList = new ArrayList();		
		return nameList;
	}
	// [end] 2013-11-04 Ken Li: fix pvcs log#687 show 'MB' channel ID when doing
	// InterFundTransfer and BillPayment

	public List getBeneficiaryNameAndAcct() throws SystemException {
		List nameList = new ArrayList();
		return nameList;
	}

	// SCR-OPC12002 Start
	public List getBeneficiaryNameAndAcctForOversea() throws SystemException {
		List nameList = new ArrayList();
		return nameList;
	}
	// SCR-OPC12002 End

//SCR-OPC12002 Start
	public List getBeneficiaryNameAndAcctForAll() throws SystemException {
		List nameList = new ArrayList();
		return nameList;
	}
	// SCR-OPC12002 End

	public static void main(String[] args) {
		try {
			ThirdPartyRegistration tpr = new ThirdPartyRegistration(args[0], args[1]);
			Account[] accts = tpr.getThirdPartyAccounts();
			if ((accts != null) && (accts.length > 0)) {
				for (int i = 0; i < accts.length; i++)
					logger.info("Account (" + i + "):" + accts[i]);
			} else {
				logger.info("No accounts in third party registration");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}
