/*
 * DSB3pCreditCard.java
 *
 * Created on May 31, 2000, 10:38 AM
 */
 
package com.dsb.eb2.bankApp.account;

/** 
 * Class representing third-party credit card accounts 
 * registered by a customer via phone-banking.  
 * Only three types will be supported in this class:
 * 1. Credit card
 * 2. E-Cash card
 * 3. V-Cash card
 * 
 * @author  Mike Chan
 * @version 0.0
 */
public class DSB3pCreditCard extends Account {

  protected char cardStatus;
  protected char stmtFlag;  
  protected char blockCode;  
  protected char expiryStatus;

  /** Creates new DSB3pCreditCard */
  public DSB3pCreditCard(String acctNum,
                         AccountOwner[] acctOwners,
                         String bankCode,
                         String bankName,
                         char cardStatus,
                         char stmtFlag,
                         char blockCode,
                         char expiryStatus) {
    this.acctNum = acctNum;
    this.acctOwners = acctOwners;
    this.bankCode = bankCode;
    this.bankName = bankName;
    this.cardStatus = cardStatus;
    this.stmtFlag = stmtFlag;
    this.blockCode = blockCode;
    this.expiryStatus = expiryStatus;
  }  
  
  public char getCardStatus() {
    return cardStatus;
  }
  
  public char getStmtFlag() {
    return stmtFlag;
  }
    
  public char getBlockCode() {
    return blockCode;
  }  

  public char getExpiryStatus() {
    return expiryStatus; 
  }

}