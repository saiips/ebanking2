/*
 * PinServer.java
 *
 * Created on July 19, 2004, 11:15 AM
 */
package com.dsb.eb2.bankApp.pinServer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dsb.eb2.backOffice.connect.webService.Constants.WebServiceConstants;
import com.dsb.eb2.backOffice.connect.webService.emsSOALogon.ThalesGetPublicKeyRequest;
import com.dsb.eb2.backOffice.connect.webService.emsSOALogon.ThalesGetPublicKeyResponse;
import com.dsb.eb2.backOffice.connect.webService.emsSOALogon.ThalesInitPinRequest;
import com.dsb.eb2.backOffice.connect.webService.emsSOALogon.ThalesInitPinResponse;
import com.dsb.eb2.backOffice.connect.webService.emsSOALogon.ThalesRanNumRequest;
import com.dsb.eb2.backOffice.connect.webService.emsSOALogon.ThalesRanNumResponse;
import com.dsb.eb2.backOffice.connect.webService.emsSOALogon.ThalesVerifyPinRequest;
import com.dsb.eb2.backOffice.connect.webService.emsSOALogon.ThalesVerifyPinResponse;
import com.dsb.eb2.backOffice.connect.webService.handle.Handle_emsSOALogon;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.System.exeption.ExtendedException;
import com.dsb.eb2.bankApp.System.exeption.SystemException;
import com.dsb.eb2.bankApp.kid.KidId;
import com.dsb.eb2.util.StringUtils;

/**
 * Model the MEVAS PIN server for login or PIN change.
 *
 * @author Zoe Wong
 * @version 0.0
 */
public class PinServer implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static Logger logger = LoggerFactory.getLogger(PinServer.class);

	/**
	 * Key index for encryption
	 */
	private String keyIndex;

	/**
	 * Random number for encryption
	 */
	private String randomNum;

	/**
	 * Reference number returned from PIN Server
	 */
	private String refNum;

	/**
	 * RSA Key for encryption
	 */
	private String rsaKey;

	private String custNum;
	private String docId;
	private String docType;

	// HSM PDM12770
	private String webPinRandom;
	private String webPinKeyIndex;

	// PDM17230
	private String webPinKeyModule;
	private String webPinKeyExponent;

	public String getWebPinKeyModule() {
		return webPinKeyModule;
	}

	public void setWebPinKeyModule(String webPinKeyModule) {
		this.webPinKeyModule = webPinKeyModule;
	}

	public String getWebPinKeyExponent() {
		return webPinKeyExponent;
	}

	public void setWebPinKeyExponent(String webPinKeyExponent) {
		this.webPinKeyExponent = webPinKeyExponent;
	}

	public void setWebPinRandom(String webPinRandom) {
		this.webPinRandom = webPinRandom;
	}

	public void setWebPinKeyIndex(String webPinKeyIndex) {
		this.webPinKeyIndex = webPinKeyIndex;
	}

	public String getWebPinRandom(String sessionId) {
		Handle_emsSOALogon handle = new Handle_emsSOALogon();
		// HSM PDM12270
		// Generate Random Number
		try {
			// Handle_emsSOALogon handle = new Handle_emsSOALogon(); // Autowired
			ThalesRanNumResponse ranNumRep = handle.invoke(new ThalesRanNumRequest());
			if (ranNumRep != null && ranNumRep.getEmsHeader().getReturnCode()
					.equals(WebServiceConstants.WEB_SERVICE_RETURN_SUCCESS)) {
				webPinRandom = (String) ranNumRep.getRandomNum();
				ThalesGetPublicKeyRequest publicKtyReq = new ThalesGetPublicKeyRequest();
				ThalesGetPublicKeyResponse publicKeyRep = handle.invoke(publicKtyReq);

				webPinKeyIndex = publicKeyRep.getPublicKeyIndex();
				webPinKeyExponent = publicKeyRep.getExp();
				webPinKeyModule = publicKeyRep.getPublicKey();

			}
		} catch (Exception ex) {
			logger.error(ex.getMessage(),ex);
			// throw new
			// SystemException(dsb.eBanking.bankApp.system.SystemStatusCode.SSC_NO_AGENT_AVAILABLE);
		}
		return webPinRandom;
	}

	public String getWebPinKeyIndex() {
		return webPinKeyIndex;
	}

	/**
	 * Constructor
	 */
	public PinServer() {
	}

	/**
	 * Accessor for the instance variable
	 */
	public String getKeyIndex() {
		return keyIndex;
	}

	/**
	 * Accessor for the instance variable
	 */
	public String getRandomNum() {
		return randomNum;
	}

	/**
	 * Accessor for the instance variable
	 */
	public String getRsaKey() {
		return rsaKey;
	}

	/**
	 * Access the refNum instance variable returned from PIN server after operation
	 * (e.g. PIN change)
	 */
	public String getRefNum() {
		return refNum;
	}

	public void setCustomerNumber(String custNum) {
		this.custNum = custNum;
	}

	public String getCustomerNumber() {
		return custNum;
	}

	public void setDocumentId(String docId) {
		this.docId = docId;
	}

	public String getDocumentId() {
		return docId;
	}

	public void setDocumentType(String docType) {
		this.docType = docType;
	}

	public String getDocumentType() {
		return docType;
	}

	/**
	 * Retrieve key index, random number, and rsa key from COI via the
	 * GetRandNoAgent
	 * 
	 * @throws ExtendedException
	 */
	public void loadRandomValues() {
	}

	/**
	 * Perform pin change operation via the PinChangeAgent
	 * 
	 * @param userId      mevas ID
	 * @param encPin      encrypted pin
	 * @param pinCheckSum check sum of pin
	 * @return Return system status indicating wrong password, consecutive
	 *         unsuccessful or successful
	 * @throws ExtendedException
	 */
	public int login(String custId, String encPin, String pinCheckSum) {
		return SystemStatusCode.SSC_NORMAL;
	}

	/**
	 * Perform pin change operation via the WebPin Login HSM PDM12270
	 */
	public int webPinLogin(String custId, String encPin, String pinCheckSum, String publicKeyIndex,
			String randomNumber) {
		logger.debug("WebPinLogin PinServer: login()");

		logger.debug("WebPinLogin: login() userid: |" + custId);
		logger.debug("WebPinLogin: login() keyIndex: |" + webPinKeyIndex);
		logger.debug("WebPinLogin: login() Optional publicKeyIndex: |" + publicKeyIndex);
		logger.debug("WebPinLogin: login() randomNum: |" + randomNum);

		// Handle_emsSOALogon handle = new Handle_emsSOALogon(); // Autowired
		ThalesVerifyPinRequest request = new ThalesVerifyPinRequest();
		request.setPBID(custId);
		request.setPKI(webPinKeyIndex);
		// overwritten if publicKeyIndex is not empty
		if (!StringUtils.isEmpty(publicKeyIndex))
			request.setPKI(publicKeyIndex);
		request.setMessage(encPin);
		request.setPINCheckSum(Integer.valueOf(pinCheckSum));

		String returnCode = "";
		Handle_emsSOALogon handle = new Handle_emsSOALogon();
		try {
			ThalesVerifyPinResponse response = handle.invoke(request);
			returnCode = response.getEmsHeader().getReturnCode();
		} catch (Exception e) {
			returnCode = String.valueOf(SystemStatusCode.SSC_UNEXPECTED);
			logger.error(e.getMessage(),e);
		}

		if (!WebServiceConstants.WEB_SERVICE_RETURN_SUCCESS.equals(returnCode)) {
			if ("8005".equals(returnCode))
				return SystemStatusCode.SSC_INCORRECT_PWD;

			if ("8004".equals(returnCode) || "8003".equals(returnCode))
				return SystemStatusCode.SSC_USER_ALREADY_HALTED;

			// pin change reminder
			if (String.valueOf(SystemStatusCode.SSC_VERIFY_PIN_SUCCESS_NEEDS_PIN_CHANGE).equals(returnCode)) {
				logger.debug("PinServer.webPinLogin(): Pin verification successful, pin change required, status code: "
						+ returnCode);
			}

			return Integer.valueOf(returnCode);
		}

		logger.debug("WebPin PinServer: login(): is Normal logon  ");
		return SystemStatusCode.SSC_NORMAL;
	}

	/**
	 * Perform kid pin change operation via the WebPin Login HSM PDM12270
	 */
	public int webPinKidLogin(String userId, String epin, String checksum, String kidType) throws Exception {
		logger.debug("WebPinKidLogin PinServer: login()");

		logger.debug("WebPinKidLogin: login() userid: |" + userId);
		logger.debug("WebPinKidLogin: login() keyIndex: |" + webPinKeyIndex);
		logger.debug("WebPinKidLogin: login() randomNum: |" + randomNum);
		logger.debug("WebPinKidLogin: login() checksum: |" + checksum);

		// Handle_emsSOALogon handle = new Handle_emsSOALogon(); // Autowired
		ThalesVerifyPinRequest request = new ThalesVerifyPinRequest();
		request.setPBID(KidId.getKidIdPrefix(kidType) + userId);
		request.setPINCheckSum(Integer.valueOf(checksum));
		request.setMessage(epin);
		request.setPKI(webPinKeyIndex);
		Handle_emsSOALogon handle = new Handle_emsSOALogon();
		ThalesVerifyPinResponse response = handle.invoke(request);

		String returnCode = response.getEmsHeader().getReturnCode();

		if (!WebServiceConstants.WEB_SERVICE_RETURN_SUCCESS.equals(returnCode)) {
			if ("8005".equals(returnCode))
				return SystemStatusCode.SSC_INCORRECT_PWD;

			if ("8004".equals(returnCode) || "8003".equals(returnCode))
				return SystemStatusCode.SSC_USER_ALREADY_HALTED;

			// pin change reminder
			if (String.valueOf(SystemStatusCode.SSC_VERIFY_PIN_SUCCESS_NEEDS_PIN_CHANGE).equals(returnCode)) {
				logger.debug("PinServer.webPinLogin(): Pin verification successful, pin change required, status code: "
						+ returnCode);
			}

			return Integer.valueOf(returnCode);
		}

		logger.debug("WebPinKidLogin PinServer: login(): is Normal logon");
		return SystemStatusCode.SSC_NORMAL;
	}

	/**
	 * Perform pin change operation via the PinChangeAgent
	 * 
	 * @param custId         customer ID
	 * @param custNum        customer number
	 * @param encCombinedPin encrypted current pin + new pin
	 * @param pinCheckSum    check sum of pin
	 * @return Return system status code
	 * @throws ExtendedException
	 */
	public int changePin(String custId, String custNum, String encCombinedPin, String pinCheckSum) {
		return SystemStatusCode.SSC_NORMAL;

	} // changePin

	// begin Project School -->
	/**
	 * Perform login operation via the VerifyKidPinAgent
	 * 
	 * @param userId   login id
	 * @param epin     encrypted pin
	 * @param checksum checksum of pin
	 * @param kidType  kid type (e.g. KID for Sesame street, KIT for Thomas &
	 *                 friends
	 * @return Return system status indicating wrong password, consecutive
	 *         unsuccessful or successful
	 * @throws ExtendedException
	 */
	public int kidLogin(String userId, String epin, String checksum, String kidType) {
		return SystemStatusCode.SSC_NORMAL;
	}// kidLogin

	/**
	 * Perform kid pin change operation via the ChangeKidPinAgent
	 * 
	 * @param userId      login ID
	 * @param encOldPin   encrypted current pin
	 * @param encNewPin   encrypted new pin
	 * @param pinCheckSum check sum of pin
	 * @param kidType     kid type (e.g. KID for Sesame street, KIT for Thomas &
	 *                    friends
	 * @return Return system status code
	 * @throws ExtendedException
	 */
	public int kidChangePin(String userId, String encOldPin, String encNewPin, String pinCheckSum, String kidType) {
		return SystemStatusCode.SSC_NORMAL;

	} // kidChangePin
		// <-- end Project School
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	public void setRandomNum(String randomNum) {
		this.randomNum = randomNum;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("Random Number : " + randomNum + "\n");
		sb.append("Key Index     : " + keyIndex + "\n");
		sb.append("RSA Key       : " + rsaKey + "\n");
		return sb.toString();
	}
	
	public int initPin(String custID, String pki, String message, String pinCheckSum, String webPinDate) throws Exception {
		return initPin(custID, pki, message, pinCheckSum, webPinDate, false);
	}

	public int initPin(String custID, String pki, String message, String pinCheckSum, String webPinDate, Boolean isMbank) throws Exception {
		ThalesInitPinRequest request = new ThalesInitPinRequest();
		ThalesInitPinResponse response;
		int returnCode = SystemStatusCode.SSC_NORMAL;
		Handle_emsSOALogon handle = new Handle_emsSOALogon();
		if(isMbank)
		{
			handle.setChannelID("MO");
			handle.setServiceID("MB");
		}

		request.setPBID(custID);
		request.setPKI(pki);
		request.setMessage(message);
		request.setPINCheckSum(Integer.valueOf(pinCheckSum));
		request.setPINAssignedDate(webPinDate);
		try {
			response = handle.invoke(request);
			if (response != null) {
				returnCode = Integer.valueOf(response.getEmsHeader().getReturnCode());
				if (returnCode == SystemStatusCode.SSC_NORMAL_EMS_RESPONE) {
					return SystemStatusCode.SSC_NORMAL;
				} else {
					throw new SystemException(returnCode);
				}

			} else {
				throw new SystemException(SystemStatusCode.SSC_NO_AGENT_AVAILABLE);
			}

		} catch (SystemException ex) {
			logger.error(ex.getMessage(),ex);
			throw ex;
		} catch (Exception e) {
			throw e;
		}
	}
}
