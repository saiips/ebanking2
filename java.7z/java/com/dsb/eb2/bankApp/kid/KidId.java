/*
 * KidId.java
 *
 * Created on May 29, 2005, 9:31 AM
 */
 
package com.dsb.eb2.bankApp.kid;

import java.util.*;

/** 
 * @author  Lam Chi Kai
 * @version 0.0
 */
public class KidId extends Object {
  public static final String PREFIX = "KID";
  public static final String TNF_PREFIX = "KIT";
  public static final String ROBOT_PREFIX = "KIR";
  public static final String TOOL_PREFIX = "KIB";
  public static final String SESAME_STREET = "S";
  public static final String THOMAS_N_FRIENDS = "T";
  public static final String ROBOT = "R";
  public static final String TOOL = "B";
  
  protected Date createDate;
  protected String kidCustName; 
  protected String kidCustId;
  protected String kidLoginId;
  protected String parentCustId;
  protected String kidType;
  protected String webPin;  
  
  public Date   getCreateDate() { return createDate; } 
  public String getKidCustName() { return kidCustName; } 
  public String getKidCustId() { return kidCustId; }
  public String getKidLoginId() { return kidLoginId; }
  public String getParentCustId() { return parentCustId; }
  public String getKidType() { return kidType; }
  public boolean getIsWebPin() {   
    if  (webPin.equals("1"))
		return true;
    else return false;
  }
  
  public void setCreateDate(Date _createDate) { createDate = _createDate; }
  public void setKidCustName(String _kidCustName) { kidCustName = _kidCustName; }
  public void setKidCustId(String _kidCustId) { kidCustId = _kidCustId; }
  public void setKidLoginId(String _kidLoginId) { kidLoginId = _kidLoginId; }
  public void setParentCustId(String _parentCustId) { parentCustId = _parentCustId; }
  public void setKidType(String _kidType) { kidType = _kidType; }
  //HSM SCR-12270
  public void setWebPin(String _webPin) { webPin = _webPin; }
  
  public String toString() {
  	return "[Parent Cust ID=" + parentCustId + "][Kid Cust Name=" + kidCustName + "][Kid Cust ID=" + kidCustId + "][Kid Login ID=" + kidLoginId + "][Kid Type=" + kidType + "]";
  }

  public static boolean isValidPrefix(String idPrefix) {
  	if (idPrefix == null)
  	    return false;
    return (idPrefix.equals(PREFIX)	|| idPrefix.equals(TNF_PREFIX) || idPrefix.equals(ROBOT_PREFIX) || idPrefix.equals(TOOL_PREFIX));
  }
  
  public String getKidIdPrefix() {
        if (kidType.equals(SESAME_STREET))
            return PREFIX;
        else if (kidType.equals(THOMAS_N_FRIENDS))
            return TNF_PREFIX;
        else if (kidType.equals(ROBOT))
        	return ROBOT_PREFIX;
        else if (kidType.equals(TOOL))
        	return TOOL_PREFIX;
        return PREFIX;
  }

  public static String getKidIdPrefix(String kidType) {
        if (kidType.equals(SESAME_STREET))
            return PREFIX;
        else if (kidType.equals(THOMAS_N_FRIENDS))
            return TNF_PREFIX;
        else if (kidType.equals(ROBOT))
        	return ROBOT_PREFIX;
        else if (kidType.equals(TOOL))
        	return TOOL_PREFIX;
        return PREFIX;
  }

  public static String getKidType(String idPrefix) {
        if (idPrefix.equals(PREFIX))
            return SESAME_STREET;
        else if (idPrefix.equals(TNF_PREFIX))
            return THOMAS_N_FRIENDS;
        else if (idPrefix.equals(ROBOT_PREFIX))
        	return ROBOT;
        else if (idPrefix.equals(TOOL_PREFIX))
        	return TOOL;
        return SESAME_STREET;
  }

  public KidId() {
  	kidCustName = ""; 
  	kidCustId = "";
  	kidLoginId = "";
  	parentCustId = "";
  	kidType = "";
  }
  
}