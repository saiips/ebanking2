/*
 * CardActServiceImpl.java
 *
 */
//SCR-PDM10588  
package com.dsb.eb2.bankApp.massagedMobileNo.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dsb.eb2.backOffice.connect.EMSQueueConnector;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsMsgFactory;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsRepMsg;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsReqMsg;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmHdr;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1524.NF1524RepData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1524.NF1524ReqData;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.System.exeption.SystemException;
import com.dsb.eb2.bankApp.massagedMobileNo.mode.CreditCardmode;

/**
 * @author
 * @version 0.0
 */
public class CreditCardEnqProcessor implements CreditCardEnqService {

	private static Logger logger = LoggerFactory.getLogger(CreditCardEnqService.class);
	
	private CreditCardmode r;
	
	public CreditCardEnqProcessor() {
	}

	public CreditCardmode getCreditCardMtce() {
		return r;
	}

	public int place(CreditCardmode r) throws SystemException {
		this.r = r;
		return SystemStatusCode.SSC_NORMAL;
	}

	public int process() throws Exception {
		logger.debug("CreditCardEnqProcessor.process   strat");
		if (r == null) {
//      ErrorLog el = new ErrorLog(SystemStatusCode.SSC_REQ_EMPTY_OR_INVALID,
//                                 "attempt to process invalid or empty ATM Card Activation");
//      el.record();
			throw new SystemException(SystemStatusCode.SSC_REQ_EMPTY_OR_INVALID);
		}
		try {
			int result = makeBackOfficeRequest();
			if (result == SystemStatusCode.SSC_NORMAL_EMS_RESPONE) {
			} else {
			}
			return result;
		} catch (SystemException ex) {
			throw ex;
		}
	}

	private int makeBackOfficeRequest() throws Exception {
		/* wait for HUB implementation */
		try {
			// call NF1524 start
			NF1524ReqData requestData = new NF1524ReqData();
			requestData.setCustomerNumber(r.getCustNum());
			requestData.setOrgNumber(r.getCustOrgNum());
			
			
			NF1524ReqData reqData = new NF1524ReqData();
			EmsReqMsg emsReqMsg = EmsMsgFactory.createEmsReqMsg(reqData, r.getCustId());
			EMSQueueConnector connector = new EMSQueueConnector();
			EmsRepMsg emsRepMsg = connector.invoke(emsReqMsg, new NF1524RepData());
			NF1524RepData respondData = (NF1524RepData) emsRepMsg.getFrmData();
			FrmHdr frmHdr = emsRepMsg.getFrmHdr();
			
			String returnCode=frmHdr.getReturnCode();
			if (returnCode != "900000") {
				throw new SystemException(99999, "call NF1524 fail");
			}
			

//			EmsReqMsg emsReqMsg = EmsMsgFactory.createEmsReqMsg(requestData, r.getCustId());// "BR21860755 000", ""
//			EMSQueueConnector connector = new EMSQueueConnector();
//			EmsRepMsg emsRepMsg = connector.invoke(emsReqMsg, requestData);
//			NF1524RepData respondData = (NF1524RepData) emsRepMsg.getFrmData();
//			FrmHdr frmHdr = emsRepMsg.getFrmHdr();
			// call NF1524 end
			
			// returnCode

			r.setAddressLine1(respondData.getAddressLine1());
			r.setAddressLine2(respondData.getAddressLine2());
			r.setAddressLine3(respondData.getAddressLine3());
			r.setAddressLine4(respondData.getAddressLine4());
			r.setZipCode(respondData.getZipCode());
			r.setEmployerName(respondData.getEmployerName());
			r.setHomePhone(respondData.getHomePhoneNumber());
			r.setWorkNumber(respondData.getWorkNumber());
			r.setPosition(respondData.getPos());
			r.setMobilePhone(respondData.getMobilePhoneNumber());
			r.setPagerNumber(respondData.getPagerNumber());
			r.setEmailAddress(respondData.getEmailAddress());
			r.setBillingCycle(respondData.getBillingCycle());
			r.setMemoLine1(respondData.getMemoLine1());
			r.setMemoLine2(respondData.getMemoLine2());
			r.setSuppressFlag(respondData.getSuppressStatementFlag());

			return Integer.parseInt(returnCode);
		} catch (NullPointerException ex) {
			return 90000;
		}
	}
}
