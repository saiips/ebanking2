/*
 * CardActService.java
 *
 */
 
package com.dsb.eb2.bankApp.massagedMobileNo.service;

import org.springframework.stereotype.Service;

import com.dsb.eb2.bankApp.System.exeption.SystemException;
import com.dsb.eb2.bankApp.massagedMobileNo.mode.CreditCardmode;
/**
 * @author
 * @version 0.0
 */
@Service
public interface CreditCardEnqService {

  public int place(CreditCardmode r) throws SystemException;
  public int process() throws SystemException, Exception;
  public CreditCardmode getCreditCardMtce();
  
}
