package com.dsb.eb2.bankApp.massagedMobileNo;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.transaction.SystemException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSONObject;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1108.NF1108RepData;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.dao.ccAcctInfo.CreditCardDAO;
import com.dsb.eb2.bankApp.massagedMobileNo.mode.CreditCardmode;
import com.dsb.eb2.bankApp.massagedMobileNo.service.CreditCardEnqService;
import com.dsb.eb2.sso.controller.LoginController;

public class EbppAcctUtil {

	@Autowired
	private static CreditCardDAO creditCardDAO;

	@Autowired
	private static CreditCardEnqService rs;

	@Autowired
	private static CreditCardmode creditMtce;

	private static Logger log = LoggerFactory.getLogger(EbppAcctUtil.class);

	public static CreditCardmode getCreditCardContactDetail(NF1108RepData nF1108RepData, String custOrgNum,
			String custID) throws IOException, Exception {
		String functionName = "getCreditCardContactDetail";
		if (nF1108RepData != null && custID != null) {
			String pbBkID = null;
		}
		creditMtce.setCustId(custID);
		log(custID, functionName, "customer ID :" + custID);
		if (custOrgNum.equals("004"))
			creditMtce.setCustNum("pbBkID"); // 没有pbBkID
		else {
			String custNum="";
			try {
				
				Map map = new HashMap<>();
				map.put("CUST_ID", creditMtce.getCustId());
				
				JSONObject custNumObject = creditCardDAO.getCustNumByCustId(map);
				custNum=String.valueOf(custNumObject.getString("CUST_NUM"));

				if (custNum != null && !custNum.equals("")) {
					log.info("CreditCardMtce.java:findCustNum():cust_cc_acct_info...:" + creditMtce.getCustId());
					creditMtce.setCustNum(custNum);
					log.info("CreditCardMtce.java1:findCustNum():get:" + creditMtce.getCustNum());
				}
			} catch (IOException e) {
				e.printStackTrace();
				log.error(e.getMessage());
				throw new SystemException();
			} catch (Exception e) {
				e.printStackTrace();
				log.error(e.getMessage());
				throw new SystemException();
			}
		}
		log(custID, functionName, "customer acct number: " + creditMtce.getCustNum());
		creditMtce.setCustOrgNum(custOrgNum);
		log(custID, functionName, "customer organization number : " + custOrgNum);
		if (creditMtce.getCustNum() == null || creditMtce.getCustNum().equals("")) {
			return null;
		}
		try {
			int placeStatus = rs.place(creditMtce);
			if (placeStatus != SystemStatusCode.SSC_NORMAL) {
				throw new SystemException(placeStatus);
			}
			int processStatus = rs.process();
			log(custID, functionName, "response status: " + processStatus);
			if (processStatus != SystemStatusCode.SSC_NORMAL_EMS_RESPONE) {
				throw new SystemException(processStatus);
			}
			creditMtce = rs.getCreditCardMtce();
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
			throw new SystemException();
		}
		return creditMtce;
	}

	protected static void log(String custID, String functionName, String msg) {
		log.info("[cust ID]:" + custID + " [functionName]: " + functionName + " [msg]: " + msg);
	}

}
