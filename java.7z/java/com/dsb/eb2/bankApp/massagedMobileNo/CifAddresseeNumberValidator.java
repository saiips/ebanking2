package com.dsb.eb2.bankApp.massagedMobileNo;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class CifAddresseeNumberValidator {

	private String inputNumber;
	private boolean errFound = true;
	private boolean iddReq;
	private String addresseeNum;

	// -------------------------------------------------------------------------
	// Constants

	// -- NUMBER PATTERN
	private static final String CIF_ADDRESSEE_DELIMITER = "[,|/]";
	private static final String NUMERIC_FILTER = "[^\\d]";
	private static final String EMPTY_STR = "";

	private static final int NUMBER_MIN_LEN = 8;
	private static final int NUMBER_MIN_INL_LEN = NUMBER_MIN_LEN + 1;
	private static final int NUMBER_MIN_LEN_WITH_PREFIX = 11;
	private static final String LOCAL_AREA_CODE = "852";
	private static final String[] VALID_LOCAL_PREIX = { "4", "5", "6", "7", "8", "9" };

	// -------------------------------------------------------------------------
	// Constructors
	public CifAddresseeNumberValidator(String inputNumber) {
		this.inputNumber = inputNumber;
		validate();
	}

	// -------------------------------------------------------------------------
	// public methods
	public boolean IsIddReq() {
		return iddReq;
	}

	public String getAddresseeNum() {
		return addresseeNum;
	}

	public boolean IsErrFound() {
		return errFound;
	}

	// -------------------------------------------------------------------------
	// private methods

	// Main method to validate the addressee number
	private void validate() {
		boolean isProcessComplete = false;
		List addresseeList = Arrays.asList(inputNumber.split(CIF_ADDRESSEE_DELIMITER));

		Iterator it = addresseeList.iterator();

		// Check pattern for local SMS
		while (it.hasNext() && !isProcessComplete) {
			isProcessComplete = validateForLocalNbr((String) it.next());
		}

		// Terminate the checking when a local addressee number is found
		if (isProcessComplete) {
			return;
		}

		// If not, continue the checking for international SMS
		it = addresseeList.iterator();

		while (it.hasNext() && !isProcessComplete) {
			isProcessComplete = validateForItlNbr((String) it.next());
		}

		// Return error if both local / international SMS numbers not found
		if (!isProcessComplete) {
			validateError();
		}
	}

	private boolean validateForLocalNbr(String addresseeNum) {
		String numToCheck = addresseeNum.replaceAll(NUMERIC_FILTER, EMPTY_STR);

		// FS Rule #4a. Min length of 8 digits
		if (numToCheck.length() < NUMBER_MIN_LEN) {
			return false;

			// FS Rule #4b. Length of exactly 8 digits
		} else if (numToCheck.length() == NUMBER_MIN_LEN) {

			String phonePrefix = numToCheck.substring(0, 1);
			// FS Rule #4c. Check if the number has a valid mobile prefix
			if (checkLocalPrefix(phonePrefix)) {

				// Validate success for local number
				validateSuccessWithLocalNbr(numToCheck);
				return true;
			}

			return false;

			// For cases that the phone length more than 8 digits
		} else {

			// FS Rule #4d. Check number with 852 preix
			if (numToCheck.startsWith(LOCAL_AREA_CODE)) {

				// FS Rule #4e. Min length of 11 digits containing prefix
				if (numToCheck.length() < NUMBER_MIN_LEN_WITH_PREFIX) {
					return false;
				} else {
					String phonePrefix = numToCheck.substring(3, 4);

					// FS Rule #4f. Check if the number has a valid mobile prefix
					if (checkLocalPrefix(phonePrefix)) {
						// Validate success for local number
						validateSuccessWithLocalNbr(numToCheck.substring(0, 11));
						return true;
					}
					return false;
				}
			} else {
				return false;
			}
		}
	}

	private boolean validateForItlNbr(String addresseeNum) {
		String numToCheck = addresseeNum.replaceAll(NUMERIC_FILTER, EMPTY_STR);

		// FS Rule #5a. Min length of 9 digits
		if (numToCheck.length() < NUMBER_MIN_INL_LEN) {
			return false;
		} else {
			validateSuccessWithItlNbr(numToCheck);
			return true;
		}
	}

	private boolean checkLocalPrefix(String prefix) {
		for (int i = 0; i < VALID_LOCAL_PREIX.length; i++) {
			if (VALID_LOCAL_PREIX[i].equalsIgnoreCase(prefix)) {
				return true;
			}
		}
		return false;
	}

	// the method is called when the validation failed
	private void validateError() {
		errFound = true;
		iddReq = false;
		addresseeNum = null;
	}

	// the method is called when the validation passed, and a local mobile number
	// will be returned
	private void validateSuccessWithLocalNbr(String number) {
		errFound = false;
		iddReq = false;
		addresseeNum = number;
	}

//	 the method is called when the validation passed, and an IDD mobile number will be returned
	private void validateSuccessWithItlNbr(String number) {
		errFound = false;
		iddReq = true;
		addresseeNum = number;
	}

}
