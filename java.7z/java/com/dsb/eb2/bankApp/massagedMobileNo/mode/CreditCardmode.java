package com.dsb.eb2.bankApp.massagedMobileNo.mode;

import org.springframework.stereotype.Component;

import com.dsb.eb2.framework.controller.BaseObject;

import lombok.Getter;
import lombok.Setter;


@Component
@Getter @Setter
public class CreditCardmode extends BaseObject {
	
	private String custId;
	private String bankCode;
	private String custNum;
	private String custOrgNum;
	private String suppressFlag;
	private String addressLine1;
	private String addressLine2;
	private String addressLine3;
	private String addressLine4;
	private String zipCode;
	private String employerName;
	private String homePhone;
	private String workNumber;
	private String position;
	private String mobilePhone;
	private String pagerNumber;
	private String emailAddress;
	private String billingCycle;
	private String memoLine1;
	private String memoLine2;
	private String maintainDate;
	private String maintainTime;
	private String channelCode;
	private String statementCycle;
	private String userName;
	private String updateEmail;
	private String updateEdmFlag;
	private String edmOptoutFlag;
	
	
	public CreditCardmode() {
		super();
	}
}
