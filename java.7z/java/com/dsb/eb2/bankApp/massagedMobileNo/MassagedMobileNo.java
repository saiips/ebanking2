package com.dsb.eb2.bankApp.massagedMobileNo;

import java.io.IOException;

import javax.transaction.SystemException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dsb.eb2.backOffice.connect.EMSQueueConnector;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsMsgFactory;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsRepMsg;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsReqMsg;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmHdr;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1108.NF1108RepData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1108.NF1108ReqData;
import com.dsb.eb2.bankApp.massagedMobileNo.mode.CreditCardmode;

public class MassagedMobileNo {

	private static Logger log = LoggerFactory.getLogger(MassagedMobileNo.class);

	public static String getMassagedMobileNo(String custID) throws IOException, Exception {

		boolean isCarkLinkPhoneNo = false;

		String massagedNo = null;
		String emsMassagedNo = null;

		try {
			// call 1108 start
			NF1108ReqData reqData = new NF1108ReqData();
			EmsReqMsg emsReqMsg = EmsMsgFactory.createEmsReqMsg(reqData, custID);
			EMSQueueConnector connector = new EMSQueueConnector();
			EmsRepMsg emsRepMsg = connector.invoke(emsReqMsg, new NF1108RepData());
			NF1108RepData frmData = (NF1108RepData) emsRepMsg.getFrmData();
			FrmHdr frmHdr = emsRepMsg.getFrmHdr();

			String mobileNo = frmData.getMobileNum();
			massagedNo = mobileNo;
			log.info("massagedNo:" + massagedNo);

			// call 1108 end
			String returnCode = frmHdr.getReturnCode();
			if (!returnCode.equals("900000")) {
				log.error(returnCode);
				return "";
			} else {
				if (custID != null && !custID.equals("")) {
					log.debug("custID length=" + custID.length());
					if (custID.length() != 16) // pbBkID
					{
						massagedNo = mobileNo;
					} else {
						// funtion:call HUB NF1524 msg and DB
						CreditCardmode obj;
						try {
							obj = EbppAcctUtil.getCreditCardContactDetail(frmData, "004", custID);

							if (obj != null && obj.getMobilePhone() != null
									&& !"".equals(obj.getMobilePhone().trim())) {
								massagedNo = obj.getMobilePhone().trim();
								isCarkLinkPhoneNo = true;
							} else {
								massagedNo = mobileNo;
								log.debug("getMassagedMobileNo(Get From CIF with card PBID) massagedNo=[" + massagedNo
										+ "]");
							}
						} catch (IOException e) {
							e.printStackTrace();
							log.error(e.getMessage());
							throw new SystemException();
						} catch (Exception e) {
							e.printStackTrace();
							log.error(e.getMessage());
							throw new SystemException();
						}
					}
				} else {
					return "";
				}
				log.debug("massagedNo=[" + massagedNo + "]");
				log.debug("isCarkLinkPhoneNo=" + isCarkLinkPhoneNo);
				if (massagedNo != null && !"".equals(massagedNo.trim())) {
					// EMS CIF no. Validator
					CifAddresseeNumberValidator cifNo = new CifAddresseeNumberValidator(massagedNo);
					if (cifNo.IsErrFound() == false) {
						emsMassagedNo = cifNo.getAddresseeNum();
						log.debug("massagedNo after filter =[" + emsMassagedNo + "]");
						return emsMassagedNo;
					} else {
						if (isCarkLinkPhoneNo && frmData.getMobileNum() != null && !"".equals(frmData.getMobileNum())) {
							cifNo = new CifAddresseeNumberValidator(frmData.getMobileNum());
							if (cifNo.IsErrFound() == false) {
								emsMassagedNo = cifNo.getAddresseeNum();
								log.debug("massagedNo from CIF after filter =[" + emsMassagedNo + "]");
								return emsMassagedNo;
							}
						}
						return "";
					}
				}
			}
		} catch (IOException e1) {
			e1.printStackTrace();
			log.error(e1.getMessage());
			throw new SystemException();

		} catch (Exception e1) {
			e1.printStackTrace();
			log.error(e1.getMessage());
			throw new SystemException();
		}
		return "";
	}
}
