package com.dsb.eb2.bankApp.System.exeption;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExtendedException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static Logger logger = LoggerFactory.getLogger(ExtendedException.class);

	public static final String E_BANKING = "EB";
	public static final String HUB = "HUB";
	public static final String DATABASE = "DB";
	public static final String PHONE_BANKING = "PB";
	public static final String COMM_OBJ_INTF = "COI";
	public static final String FRAMEWORK = "FW";
	public static final String UNKNOWN = "UNKNOWN";
	public static final int ENV_TYPE = 0;
	public static final int APP_TYPE = 1;
	private int type;
	private String source;
	private String code;
	private String desc;
	private Map details;
	private Exception chainedEx;

	public ExtendedException() {
		this.details = new Hashtable();
		this.chainedEx = null;
	}

	public ExtendedException(int type, String source, String code, String desc) {
		super("<" + ((type == 0) ? "ENV" : "APP") + ">[" + source + "] " + code + " : " + desc);
		this.type = type;
		this.source = source;
		this.code = code;
		this.desc = desc;
		this.details = new Hashtable();
		this.chainedEx = null;
	}

	public ExtendedException(int type, String source, int code, String desc) {
		super("<" + ((type == 0) ? "ENV" : "APP") + ">[" + source + "] " + code + " : " + desc);
		this.type = type;
		this.source = source;
		this.code = String.valueOf(code);
		this.desc = desc;
		this.details = new Hashtable();
		this.chainedEx = null;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getType() {
		return this.type;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getSource() {
		return this.source;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCode() {
		return this.code;
	}

	public int getErrorCode() {
		return Integer.parseInt(this.code);
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getDesc() {
		return this.desc;
	}

	public Map getDetails() {
		return this.details;
	}

	public void addDetails(String key, String value) {
		this.details.put(key, value);
	}

	public void setChainedEx(Exception ex) {
		this.chainedEx = ex;
	}

	public Exception getChainedEx() {
		return this.chainedEx;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("<" + ((this.type == 0) ? "ENV" : "APP") + ">[" + this.source + "] " + this.code + " : " + this.desc
				+ "\n");
		Iterator i = null;
		String k = null;
		String v = null;
		if (this.details != null) {
			Set s = this.details.keySet();
			i = s.iterator();
			while (i.hasNext()) {
				k = (String) i.next();
				v = (String) this.details.get(k);
				sb.append(k + " = " + v + "\n");
			}
		}

		if (this.chainedEx != null) {
			sb.append(this.chainedEx.toString() + "\n");
		}
		return sb.toString();
	}

	public static void main(String[] args) throws Exception {
		try {
			Hashtable d = new Hashtable();
			Vector l = new Vector();
			l.add(new Exception("Invalid input 1"));
			l.add(new Exception("Invalid input 2"));
			d.put("mandatory_field", "null");
			d.put("numeric_field", "abcd");
			ExtendedException e = new ExtendedException(1, "WEB", "ERR-1234", "Form Input Error");
			throw e;
		} catch (ExtendedException e) {
			logger.error("Exception Details...", e);
		}
	}
}