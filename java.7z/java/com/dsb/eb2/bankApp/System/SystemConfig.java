/**
 * SystemConfig.java
 *
 */

package com.dsb.eb2.bankApp.System;
 
import java.io.FileInputStream;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;

import javax.crypto.CipherInputStream;


/*import dsb.eBanking.bankApp.*;
import dsb.eBanking.bankApp.system.maintenance.*;
import dsb.util.*;
*/
/** 
 *
 * @author  Ricky Wong
 * @version 
 */
public class SystemConfig {
	// Class variables
	private static Properties props;
	private static boolean classInitOk;
	private static Hashtable loadedParams = new Hashtable();
	
	private static Properties envProps;
	private static String env="";
	
	// Define the algorithm for encryption and padding
//	public static final String EncryptionAlgorithm ="DES/ECB/PKCS5Padding";
	// Define the algorithm for storing keys
//	public static final String KeyAlgorithm ="DES";
	// Master key
//	private static final String KeyString = "g3HPk7qE";
	// Full path filename of the encrypted properties file
	private static final String encryptedConfigFile ="";
	// Full path filename of the un-encrypted properties file
	private static final String configFile ="";
	
	private static final String envFile = "";
	
  static {
	  try {
			loadParams();
			loadEnv();
		  classInitOk = true;
	  }
	  catch (Exception ex) {
		  classInitOk = false;
	  }
	}

	static private synchronized void loadEnv() throws Exception {
		String pFile = "";
		FileInputStream fis = new FileInputStream(pFile);		
		envProps = new Properties();
		envProps.load(fis);
		fis.close();
		env=(String)envProps.get("env");
	}
	
	static private synchronized void loadParams() throws Exception {
		// load the encrypted properties file into the hashtable
		String epFile ="";
		FileInputStream fis2 = new FileInputStream(epFile);
		CipherInputStream cis2 = new CipherInputStream(fis2, KeysManager.getMasterKeyCipher());
		props = new Properties();
		props.load(cis2);
		cis2.close();    
		fis2.close();
		loadPropertiesIntoHashtable(props);

		/* load the un-encrypted properties file into the hashtable,
		 * values in the encrypted file will have higher priority
		 */
		String pFile = "";
		fis2 = new FileInputStream(pFile);
		props.clear();
		props.load(fis2);
		fis2.close();
		loadPropertiesIntoHashtable(props);
	}

	static private synchronized void loadPropertiesIntoHashtable(Properties props) {
		Enumeration e = props.propertyNames();
		while (e.hasMoreElements()) {
			String propertyName = (String)e.nextElement();
			if (!loadedParams.containsKey(propertyName))
				loadedParams.put(propertyName, props.getProperty(propertyName));
		}
	}

  static public Hashtable getAllSystemParameters() {
    if (classInitOk)
      return loadedParams;
    else
      return null;
  }

/*	public Enumeration parameterNames() {
	}*/

	/** Get the value of a system parameter from the memory
	 * @param key Key value of the parameter
	 */
	static public String getSystemParameter(String key) {
		String result="";
		if (classInitOk) {
			result = "";
			if (result == null) {
				result = "";
			}

			return result;
		}
		else
			return null;
	}

	/** Get the value of a system parameter from the memory
	 * @param key key value of the parameter
	 * @defaultValue default value returned when the key is not found
	 */
	static public String getSystemParameter(String key, String defaultValue) {
		String keyValue = getSystemParameter(key);
		if (keyValue == null)
			return defaultValue;
		else
			return keyValue;
	}

	/**
	 * Reload all system parameters from configuration files
	 */
	static public synchronized void reloadParams() throws Exception {
		loadedParams.clear();	// remarks : Hashtable is synchronized
		loadParams();
	}
	
	static public synchronized void setSystemParameter(String key, String value) {
	}

	public static void main(String[] args) {

	  try {
		  Enumeration e = (SystemConfig.getAllSystemParameters()).keys();
		  while (e.hasMoreElements()) {
	  		String propertyName = (String)e.nextElement();
		  }

/*	    String colorScheme = SystemConfig.getSystemParameter("ebank_db_pool_name"); 
	    */
	  }
	  catch (Exception e) {
	  }
	} 
}