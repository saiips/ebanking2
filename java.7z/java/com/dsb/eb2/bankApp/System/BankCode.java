package com.dsb.eb2.bankApp.System;

import java.util.*;

/** 
 * Static class representing the bank codes
 * as well as the code applied to the system.
 * In addition, it provides the bank name 
 * corresponding to a bank code.
 *
 * @author  Mike Chan
 * @version 0.0
 */
  public class BankCode extends Object {

    public static final String BC_DAH = "3";
    public static final String BC_DSB = "6";
    public static final String BC_JSB = "7";
    public static final String BC_SYS = BC_DSB;
    
    private static final Hashtable bankNameDef = getBankNameDef(); 
        
    public static String getBankName(String code) {
      return (String)(bankNameDef.get(code));
    }
    
    private static final Hashtable getBankNameDef() {
      Hashtable h = new Hashtable(3);
      h.put(BC_DAH,"DAH");
      h.put(BC_DSB,"DSB");
      h.put(BC_JSB,"JSB");
      return h;
    }

}