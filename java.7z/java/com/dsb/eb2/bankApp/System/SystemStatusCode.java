package com.dsb.eb2.bankApp.System;

/**
 * Static class which defines a comprehensive
 * set of symbolic reference for all status
 * code returned from the ebanking system
 * (status code for ebanking is 99xxxx)
 *
 * @author  Mike Chan
 * @version 0.0
 */
  public class SystemStatusCode extends Object {
    public static final int SSC_UNAUTH_ACCESS               = 600001;

    public static final int SSV_UI_NORMAL 		    = 700000;
    public static final int SSV_TXT_REQUIRED 		    = 700001;
    public static final int SSV_TXT_LEN_BELOW_LIMIT	    = 700002;
    public static final int SSV_TXT_LEN_EXCEED_LIMIT	    = 700003;
    public static final int SSV_TXT_INVALID		    = 700004;
    public static final int SSV_EMAIL_EMPTY                 = 700010;
    public static final int SSV_EMAIL_INVALID               = 700011;    
    public static final int SSV_DATE_REQUIRED 		    = 700020;
    public static final int SSV_DATE_INVALID		    = 700021;
    public static final int SSV_DATE_LESS_THEN_MIN	    = 700022;
    public static final int SSV_DATE_GREATER_THEN_MAX	    = 700023;
    public static final int SSV_DATE_REL_VIOLATE	    = 700024;
    public static final int SSV_PWD_OLD_PIN_INVALID         = 700027;
    public static final int SSV_PWD_NEW_PIN_INVALID         = 700028;     
    public static final int SSV_PWD_NEW_PIN_SAME_AS_OLD     = 700029;     
    public static final int SSV_USERID_INVALID		    = 700030;
    public static final int SSV_NON_PB_USERID		    = 700031;
    public static final int SSV_LOGIN_NAME_EMPTY            = 700032;
    public static final int SSV_LOGIN_NAME_INVALID          = 700033;
    public static final int SSV_PWD_EMPTY                   = 700034;
    public static final int SSV_PWD_LEN_INVALID             = 700035;
    public static final int SSV_PWD_NEW_EMPTY               = 700036;
    public static final int SSV_PWD_NEW_LEN_INVALID         = 700037;
    public static final int SSV_PWD_RETYPE_LEN_EMPTY        = 700038;
    public static final int SSV_PWD_RETYPE_NOT_MATCH        = 700039;    
    public static final int SSV_HKID_PREF_EMPTY             = 700040;
    public static final int SSV_HKID_PREF_INVALID           = 700041;
    public static final int SSV_HKID_NUM_LESS_THAN_MIN      = 700042;
    public static final int SSV_HKID_NUM_INVALID            = 700043;
    public static final int SSV_HKID_SUF_EMPTY              = 700044;
    public static final int SSV_HKID_SUF_INVALID            = 700045;
    public static final int SSV_CARD_NUM_EMPTY              = 700050;
    public static final int SSV_CARD_LEN_LESS_THAN_MIN      = 700051;
    public static final int SSV_CARD_NUM_INVALID            = 700052;

    public static final int SSV_STOCK_CODE_EMPTY            = 700060;
    public static final int SSV_STOCK_CODE_INVALID          = 700061;
    public static final int SSV_STOCK_CODE_EXCL             = 700062;
    public static final int SSV_ORD_PRICE_EMPTY             = 700063;
    public static final int SSV_ORD_PRICE_INVALID           = 700064;
    public static final int SSV_ORD_PRICE_LESS_THAN_ZERO    = 700065;
    public static final int SSV_ORD_PRICE_INT_MORE_THAN_MAX = 700066;
    public static final int SSV_ORD_PRICE_FRA_MORE_THAN_MAX = 700067;
    public static final int SSV_ORD_QTY_EMPTY               = 700068;
    public static final int SSV_ORD_QTY_INVALID             = 700069;
    public static final int SSV_ORD_QTY_LESS_THAN_ZERO      = 700070;
    public static final int SSV_ORD_QTY_MORE_THAN_EXI_QTY   = 700071;
    public static final int SSV_ORD_QTY_MORE_THAN_MAX_LOTS  = 700072;
    public static final int SSV_ORD_QTY_NOT_MULT_LOTS       = 700073;
    public static final int SSV_ACTION_EMPTY                = 700074;
    public static final int SSV_SCH_DATE_INVALID            = 700080;
    public static final int SSV_SCH_EMAIL_EMPTY             = 700081;
    public static final int SSV_MI_TENOR_EMPTY              = 700090;
    public static final int SSV_MI_CR_ACCT_EMPTY            = 700091;
    public static final int SSV_MI_CR_CCY_EMPTY             = 700092;
    public static final int SSV_MI_CCY_MISMATCH             = 700093;

    public static final int SSV_FT_DR_ACCT_EMPTY            = 700100;
    public static final int SSV_FT_CR_ACCT_EMPTY            = 700101;
    public static final int SSV_FT_TRD_PARTY_ACCT_EMPTY     = 700102;
    public static final int SSV_FT_SAME_DR_CR_ACCT          = 700103;
    public static final int SSV_FT_NOT_SAME_DR_OWN_CURR     = 700104;
    public static final int SSV_FT_NOT_SAME_DR_THR_CURR     = 700105;
    public static final int SSV_FT_TXF_AMT_INVALID          = 700106;
    public static final int SSV_FT_TXF_AMT_NOT_2DP          = 700107;
    
    public static final int SSV_FX_FT_SAME_DR_CR_CURR       = 700110;
    public static final int SSV_FX_FT_NOT_DR_CR_CURR        = 700111;

    public static final int SSV_FD_CR_ACCT_EMPTY            = 700201;
    public static final int SSV_FD_CR_ACCT_CCY_EMPTY        = 700202;
    public static final int SSV_FD_PCP_CCY_MISMATCH_CR_CCY  = 700203;    
 
    public static final int SSV_ED_TRF_FROM_OTH_BANK_ACCT_EMPTY = 700301;    
    public static final int SSV_ED_TRF_TO_BANK_ACCT_EMPTY       = 700302; 
    public static final int SSV_ED_TRF_AMT_EMPTY                = 700303;
    public static final int SSV_ED_TRF_AMT_INVALID              = 700304;
    public static final int SSV_ED_TRF_AMT_LIMIT_EXCEEDED       = 700305;    

    public static final int SSV_ED_SETUP_FROM_OTH_BANK_BK_CODE_EMPTY	= 700330;    
    public static final int SSV_ED_SETUP_INV_FROM_OTH_BANK_BR_CODE	= 700331;
    public static final int SSV_ED_SETUP_INV_FROM_OTH_BANK_ACCT 	= 700332;
    public static final int SSV_ED_SETUP_INV_PAYEE			= 700333;
    public static final int SSV_ED_SETUP_INV_LIMIT			= 700334;
    public static final int SSV_ED_SETUP_LESS_THAN_MIN_LIMIT		= 700335;
    public static final int SSV_ED_SETUP_MORE_THAN_ED_MAX_LIMIT		= 700336;
    public static final int SSV_ED_SETUP_EXCEED_AMT_4_SERVICE		= 700337;
    public static final int SSV_ED_SETUP_INV_EXPIRY_DATE		= 700338;
    public static final int SSV_ED_SETUP_DSB_ACCT_EMPTY			= 700339;
            
    public static final int SSV_STOPCQ_ACCT_EMPTY            = 700500;
    public static final int SSV_STOPCQ_INV_START_CQ_NO       = 700501;
    public static final int SSV_STOPCQ_EMPTY_CQ_NO           = 700502;
    public static final int SSV_STOPCQ_INV_CQ_NO             = 700503;
    public static final int SSV_STOPCQ_INV_AMT_AS_CNT_EXIST  = 700504;
    public static final int SSV_STOPCQ_INV_DATE_AS_CNT_EXIST = 700505;
    public static final int SSV_STOPCQ_INV_CQ_AMT            = 700506;
    public static final int SSV_STOPCQ_INV_CQ_AMT_DP         = 700507;
    public static final int SSV_STOPCQ_INV_CQ_DATE           = 700508;
    public static final int SSV_STOPCQ_OLD_CQ_DATE           = 700509;
    public static final int SSV_STOPCQ_OUT_SERVICE_TIME		 = 910039;
    public static final int SSV_STOPCQ_NO_ACCT				 = 910038;
    
    public static final int SSV_CHQ_BK_ACCT_EMPTY           = 700990;
    
    public static final int SSC_BILL_TYPE_REQUIRED 	    = 710001;
    public static final int SSC_BILL_NUM_REQUIRED 	    = 710002;
    public static final int SSC_BILL_NUM_INVALID 	    = 710003;
    public static final int SSC_BILL_LABEL_INVALID 	    = 710004;
    public static final int SSC_DEBIT_ACCT_EMPTY            = 710005;
    public static final int SSC_PAYT_AMT_INVALID            = 710006;
    public static final int SSC_PAYT_AMT_NOT_2DP            = 710007;
    public static final int SSC_EMPTY_PLACE_ORDER 	    = 710010;    
    public static final int SSC_OBT_DEBIT_ACCT_EMPTY        = 710020;
    public static final int SSC_TF_AMT_INVALID              = 710021;
    public static final int SSC_TF_AMT_NOT_INT              = 710022;
    public static final int SSC_TF_AMT_LESS_THAN_MIN        = 710023;
    public static final int SSC_INTER_TF_AMT_INVALID        = 710030;
    public static final int SSC_INTER_TF_AMT_NOT_2DP        = 710031;
    public static final int SSC_INTER_TF_AMT_LESS_THAN_MIN  = 710032;
    public static final int SSC_INTER_TF_REG_BENE_EMPTY     = 710033;
    public static final int SSC_INTER_TF_BNF_NAME_EMPTY     = 710034;
    public static final int SSC_INTER_TF_BNF_NAME_INVALID   = 710035;
    public static final int SSC_INTER_TF_BNK_CD_INVALID     = 710036;
    public static final int SSC_INTER_TF_BNK_CD_LEN_INVALID = 710037;
    public static final int SSC_INTER_TF_BCH_CD_LEN_INVALID = 710038;
    public static final int SSC_INTER_TF_BNF_BNK_EMPTY      = 710039;
    public static final int SSC_INTER_TF_ACC_NO_EMPTY       = 710040;
    public static final int SSC_INTER_TF_ACC_NO_INVALID     = 710041;
    public static final int SSC_INTER_TF_ACC_NO_LEN_INVALID = 710042;
    public static final int SSC_INTER_TF_DAY_TEL_EMPTY      = 710043;
    public static final int SSC_INTER_TF_DAY_TEL_INVALID    = 710044;
    public static final int SSC_INTER_TF_ACC_REGISTERED     = 710045; //CVM09032
    public static final int SSC_FX_DR_ACCT_EMPTY            = 710050;
    public static final int SSC_FX_CR_ACCT_EMPTY            = 710051;
    public static final int SSC_FX_SAME_CCY                 = 710052;
    public static final int SSC_FX_TXF_CCY_INVALID          = 710053;
    public static final int SSC_FX_AMT_INVALID              = 710054;
    public static final int SSC_FX_AMT_LESS_THAN_MIN        = 710055;
    public static final int SSC_FX_AMT_NOT_2DP              = 710056;
    public static final int SSC_FD_PCP_CCY_EMPTY            = 710060;
    public static final int SSC_FD_PCP_AMT_EMPTY            = 710061;
    public static final int SSC_FD_TENOR_EMPTY              = 710062;
    public static final int SSC_FD_DR_ACCT_EMPTY            = 710063;
    public static final int SSC_FD_DR_CCY_EMPTY             = 710064;
    public static final int SSC_FD_PCP_AMT_INVALID          = 710065;
    public static final int SSC_FD_PCP_AMT_NOT_2DP          = 710066;
    public static final int SSC_FD_DR_CCY_INVALID           = 710067;
    public static final int SSC_FD_MI_CR_ACCT_EMPTY         = 710068;
    public static final int SSC_FD_MI_CR_CCY_EMPTY          = 710069;
    public static final int SSC_FD_MI_CR_CCY_INVALID        = 710070;
    public static final int SSC_FD_DR_CCY_EMPTY_1           = 710071;
    public static final int SSC_FD_DAYTIME_TEL_EMPTY        = 710072;
    public static final int SSC_FD_DAYTIME_TEL_INVALID      = 710073;
    public static final int SSC_FD_MI_CR_ACCT_EMPTY_1       = 710074;
    public static final int SSC_FD_MI_CR_CCY_EMPTY_1        = 710075;
    public static final int SSC_FD_MI_CR_CCY_INVALID_1      = 710076;
    public static final int SSC_FD_MI_CR_ACCT_EMPTY_2       = 710077;
    public static final int SSC_FD_MI_CR_CCY_EMPTY_2        = 710078;
    public static final int SSC_FD_MI_CR_CCY_INVALID_2      = 710079;
    public static final int SSC_FD_PFD_UNAVAILABLE			= 710080;
    public static final int SSC_FD_CROSS_CCY_NOT_IN_HOUR	= 710081; // PDM11153 item 6
    public static final int SSC_FD_UPLIFT_CCY_OUTSIDE_SERVICE_HOUR	= 710082; // PDM11153 item 6


    public static final int SSC_FX_DEBIT_ACCT               = 710100;
    public static final int SSC_FX_CREDIT_ACCT              = 710101;
    public static final int SSC_FX_TRD_PRT_CR_ACCT          = 710102;
    
    //payroll card
    public static final int SSC_SS_NUM_INVALID          	= 710110;
    public static final int SSC_CARD_NUM_NOT_MATCH_SSN     	= 710111;

    //Remittance agreement
    public static final int SSV_AGREEMENT_EMPTY          	= 710120;
	
	public static final int SSC_CIF_MOBILE_NO_EMPTY         = 710130;
	public static final int SSC_CIF_MOBILE_NO_INVALID       = 710131;

    //gift card
    public static final int SSC_GC_CARD_INCOMPLETE 	= 996601;
    public static final int SSC_GC_CARD_INVALID 	= 996602;
    public static final int SSC_GC_EXPIRY_INCOMPLETE 	= 996603;
    public static final int SSC_GC_EXPIRY_NOT_FUTURE 	= 996604;
    public static final int SSC_GC_EXPIRY_NOT_MATCH 	= 996605;
    public static final int SSC_GC_CARD_BLOCKED 	= 996606;



	//PDM04259 Lucky Draw
	public static final int SSC_RMI_NORMAL = 800000;
	public static final int SSC_RMI_NO_ITEM = 810006;// No Item Available
	public static final int SSC_RMI_UPDATE_STOCK_STATUS_FAIL = 810007;// Update Stock Status Fail
	public static final int SSC_RMI_DB_ERROR = 810099; //General Error (Database)
	public static final int SSC_RMI_UNEXPECTED = 888888;

    /* normal/sucessful status */
    public static final int SSC_NORMAL = 990000;
    public static final int SSC_NORMAL_EMS_RESPONE = 900000;
    /* error status (application level) */
    // generic
    public static final int SSC_NO_SUCH_ACCT = 990001;
    public static final int SSC_ACCT_TYPE_MISMATCH = 990002;
    public static final int SSC_INVALID_CCY = 990003;
    // fund transfer related
    public static final int SSC_TF_RATE_NOT_FOUND = 990100;
    public static final int SSC_TF_FOREX_ONLY_FOR_OWN_RETAIL_ACCT = 990101;
    public static final int SSC_TF_CC_PAYMENT_NOT_IN_HKD = 990102;
    public static final int SSC_TF_DECIMAL_NOT_FOR_GIVEN_CCY = 990103;
    public static final int SSC_FT_DB_CCY_NOT_IN_ACCT = 990104;
    public static final int SSC_FT_CR_CCY_NOT_IN_ACCT = 990105;
    public static final int SSC_FT_REMITTANCE_DAILY_LIMIT_EXCEEDED = 990106;
    public static final int SSC_FT_FOREX_TX_LIMIT_EXCEEDED = 990107;
    public static final int SSC_TX_OUTSIDE_SERVICE_HOUR = 990108;
    public static final int SSC_FT_FOREX_EXCH_RATE_EXPIRED = 990109;
    public static final int SSC_FT_FROM_OT_BK_DAILY_LIMIT_EXCEEDED = 990110;

    public static final int SSC_FT_REMITTANCE_BENE_LIMIT_EXCEEDED = 990111;
    public static final int SSC_FT_REMITTANCE_BENE_LIMIT_EXCEEDED_REG = 990112;
    public static final int SSC_FT_REMITTANCE_INSUFFICIENT_FUND = 990113;
    public static final int SSC_FT_REMITTANCE_CUST_REQUEST = 990114;
    public static final int SSC_FT_REMITTANCE_TEST = 990115;
    public static final int SSC_FT_REMITTANCE_OTHER = 990116;

    public static final int SSC_FT_FROM_OT_BK_PER_TXN_LOWER_LIMIT_EXCEEDED = 990117;
    public static final int SSC_FT_FROM_OT_BK_PER_TXN_UPPER_LIMIT_EXCEEDED = 990118;


	/* System Status Code for weekly limit exceed message. */
    public static final int SSC_FT_REG_WK_AMT_LIMIT_EXCEEDED  = 990119;
	public static final int SSC_FT_UREG_WK_AMT_LIMIT_EXCEEDED = 990120;
    public static final int SSC_FT_UREG_WK_CNT_LIMIT_EXCEEDED = 990121;
    public static final int SSC_FD_OUTSIDE_SERVICE_HOUR = 990122;

    public static final int SSC_TF_FX_CNY_TO_NONHKD = 990123;
    public static final int SSC_FX_CNY_TO_NONHKID = 990124;
    public static final int SSC_FT_CCY_MISMATCH = 990125;

    //modified by hang
    public static final int SSC_FT_HIGH_RISK_NO_REG_PAYEE = 990126;
    public static final int SSC_FT_IS_NOT_REGISTERED = 990127;
    public static final int SSC_FT_BANK_CODE_IS_EXCLUDED = 990128;
    //modified by hang
    //CVM09032
    public static final int SSC_FT_NON_REG_REJECT = 990129;
	//PDM12180
    public static final int SSC_FT_NON_REG_HR_BILL_REJECT = 990130;
    
    //SCR-OPD14002 START
    public static final int SSC_FDFC_OUTSIDE_SERVICE_HOUR = 990131;
    //SCR-OPD14002 END
    
    // login related
    public static final int SSC_INCORRECT_PWD = 990201;
    public static final int SSC_MULTIPLE_LOGIN = 990202;
    public static final int SSC_TOO_MANY_SESSIONS = 990203;
    public static final int SSC_ALREADY_LOGIN = 990204;
    public static final int SSC_BUS_USER_NOT_SUPPORT = 990205;
    public static final int SSC_USER_ALREADY_HALTED = 990206;
    public static final int SSC_SESSION_TIME_OUT = 990207;
	public static final int SSC_CERT_LOGIN_ONLY = 990208;
	public static final int SSC_WEB_SESSION_TIME_OUT = 990209;

	public static final int SSC_LOGIN_REQUIRED = 990210;
	public static final int SSC_INVALID_USER_ID = 990211;
	public static final int SSC_VERIFICATION_ERROR = 990212;
	public static final int SSC_HSM_ERROR = 990213;
	public static final int SSC_DB_ERROR = 990214;
	public static final int SSC_LOGIN_DISABLED = 990215;
	public static final int SSC_INIT_PIN_ERROR = 990216;
	public static final int SSC_FIRST_TIME_LOGIN = 990217;
	public static final int SSC_FIRST_TIME_LOGIN_TO_SECURITIES = 990218;	
	public static final int SSC_NO_SECURITIES_ACCOUNT = 990219;
	public static final int SSC_TO_SECURITIES = 990220;
	public static final int SSC_SECURITIES_MAINTAINANCE = 990221;
	public static final int SSC_SECURITIES_SERVER_BUSY = 990223;

    // fixed deposit\
    public static final int SSC_INVALID_FD_TYPE = 990301;
    public static final int SSC_INVALID_FD_DEP_TERM = 990302;
    public static final int SSC_FD_DEP_TERM_NOT_ALLOWED = 990303;
    public static final int SSC_FD_CCY_ONLY_IN_PCP_HKD = 990304;
    public static final int SSC_FD_INT_ACCT_ONLY_FOR_MONTH_GAIN = 990305;
    public static final int SSC_FD_INT_ACCT_REQ_FOR_MONTH_GAIN = 990306;
    public static final int SSC_FD_AUTO_REN_NOT_FOR_MONTH_GAIN = 990307;
    public static final int SSC_FD_INT_ACCT_ONLY_FOR_P = 990308;
    public static final int SSC_FD_INT_ACCT_REQ_FOR_P = 990309;
    public static final int SSC_FD_DB_CCY_NOT_IN_ACCT = 990310;
    public static final int SSC_FD_INT_CCY_NOT_IN_ACCT = 990311;
    public static final int SSC_FD_MIN_DEP_AMT_LIMIT_EXCEEDED = 990312;
    public static final int SSC_FD_MI_CANCEL_NOT_ALLOWED = 990313;
    public static final int SSC_FD_CNY_TO_NONHKID = 990314;
    public static final int SSC_FD_CNY_NOEXCH = 990315;
    public static final int SCC_FD_HOLDER_NAME_EMPTY = 990316;
    //SCR-OPD14002 START
    public static final int SSC_FD_FIRST_CREATION_NOT_AVAILABLE = 990317;
    public static final int SSC_FD_FATCA_DECLARATION_NOT_AVAILABLE = 990318;
    public static final int SSC_FD_CUSTOMER_REQUIRE_PERFORM_FATCA = 990319;
    public static final int SSC_FD_REAL_TIME_MISMATCH_SCENARIO = 990320;
    public static final int SSC_FD_JOINT_ACCOUNT_CANNOT_BE_SELECTED = 990321;
    public static final int SSC_FD_INVALID_TIN_NUMBER = 990322;
    public static final int SSC_FD_US_DISCLAIMER_IS_NOT_TICKED = 990323;
    
    public static final int SSC_REAL_TIME_MISMATCH_SCENARIO = 24900;
    //SCR-OPD14002 END
    public static final int SSC_STAFF_FD_NOT_ALLOWED = 22492;

    // account profolio and details
    public static final int SSC_ACCT_PROFOLIO_NOT_FOUND = 990401;
    public static final int SSC_NO_OWNER_FOUND = 990402;
    public static final int SSC_NO_BALANCE_FOUND = 990403;
    public static final int SSC_CC_SUB_CARD = 990404;
    public static final int SSC_CC_NO_ACCESS = 990405;
    public static final int SSC_PROBLEM_ACCT_FOUND = 990406;

    //PDM04217 Automated Personal Revolving Loan
    public static final int SSC_PLRV_INVALID_PIN          = 990501;   //PhoneBanking Status: IP
    public static final int SSC_PLRV_HOT_INV_PIN          = 990502;	  //PhoneBanking Status: IPH
    public static final int SSC_PLRV_HOT_ID               = 990503;	  //PhoneBanking Status: PH
    public static final int SSC_PLRV_HOT_ID_STATUS        = 990504;	  //PhoneBanking Status: HI
    public static final int SSC_PLRV_INV_ID_STATUS        = 990505;   //PhoneBanking Status: IS
    public static final int SSC_PLRV_PL_ACCT_FULL_SETTLED = 990506;   //PhoneBanking Status: AC
    public static final int SSC_PLRV_NOT_REPAY_INS        = 990507;   //PhoneBanking Status: NYR
    public static final int SSC_PLRV_BELOW_MIN            = 990508;   //PhoneBanking Status: BM
    public static final int SSC_PLRV_PL_NOT_READY         = 990509;   //PhoneBanking Status: PLD
    public static final int SSC_PLRV_NO_R_HOLDCODE        = 990510;   //PhoneBanking Status: NRH
    public static final int SSC_PLRV_HOLDCODE_EXISTED     = 990511;   //PhoneBanking Status: HCE
    public static final int SSC_PLRV_BAD_REPAY            = 990512;   //PhoneBanking Status: BRR
    public static final int SSC_PLRV_TENOR_ERR			  = 990513;   //PhoneBanking Status: LTE
    public static final int SSC_PLRV_CR_ACCT_NOT_FOUND    = 990514;   //PhoneBanking Status: AN2
    public static final int SSC_PLRV_CR_ACCT_CLOSED       = 990515;   //PhoneBanking Status: AC2

    public static final int SSC_PLRV_NO_USERID            = 990516;
    public static final int SSC_PLRV_INVALID_USERID       = 990517;
    public static final int SSC_PLRV_NO_PIN               = 990518;

    public static final int SSV_PLRV_NEW_PIN_LEN_INVALID  = 990519;
    public static final int SSV_PLRV_NEW_PIN_INVALID      = 990523;    
    public static final int SSV_PLRV_USER_ID_EMPTY        = 990524;
    public static final int SSV_PLRV_USER_ID_INVALID      = 990525;
    public static final int SSV_PLRV_USER_ID_NON_DSB      = 990526;
    public static final int SSV_PLRV_PIN_EMPTY            = 990527;
    public static final int SSV_PLRV_PIN_LEN_INVALID      = 990528;
    public static final int SSV_PLRV_PIN_INVALID          = 990529;
    
    public static final int SCC_PLRV_OUTSIDE_SERVICE_HOUR = 990520;
    public static final int SCC_PLRV_APP_RE_SUBMISSION_TODAY = 990521;
    public static final int SSC_PLRV_LOAN_AMOUNT_EMPTY = 990530;
    public static final int SSC_PLRV_LOAN_AMOUNT_INVALID = 990531;
    public static final int SSC_PLRV_LOAN_AMOUNT_EXCEED_MAXIMUM = 990532;
    public static final int SSC_PLRV_REV_TNR_EMPTY = 990533;
    public static final int SCC_PLRV_LOAN_AMOUNT_BELOW_MINIMUM = 990534;

    /* error status (system level) */
    public static final int SSC_DBMS_GENERAL = 991001;
    public static final int SSC_DBMS_POOL = 991002;

    // properties files related error
    public static final int SSC_CANNOT_READ_INI_FILE = 991003;
    public static final int SSC_TERMINAL_PARAM_NOT_FOUND = 991004;
    public static final int SSC_TERMINAL_POOL_PARAM_NOT_FOUND = 991005;
    public static final int SSC_OPERATOR_PARAM_NOT_FOUND = 991006;
    public static final int SSC_SESSIONMGMT_PARAM_NOT_FOUND = 991007;
    public static final int SSC_DB_POOL_PARAM_NOT_FOUND = 991008;

    /** The following status codes are used by the phone banking
     *  interface module (for verify or change PB PIN).
     */

    // low level TN3270 error
    public static final int SSC_3270_CANNOT_CONNECT_AFTER_RETRIES = 991010;
    public static final int SSC_3270_OPEN_TERMINAL_ERROR = 991011;
    public static final int SSC_3270_WRITE_TERMINAL_ERROR = 991012;
    public static final int SSC_3270_CLOSE_TERMINAL_ERROR = 991013;
    public static final int SSC_3270_RESET_TERMINAL_ERROR = 991014;
    public static final int SSC_3270_ERROR_GET_SCREEN = 991015;

    // Terminal pool error
    public static final int SSC_NO_FREE_TERMINAL = 991016;
    public static final int SSC_ERROR_IN_GETTING_HOST_SESSION = 991017;

    public static final int SSC_3270_FAILURE = 991018;

    // screen scaping error
    public static final int SSC_EXPECTED_SCREEN_NOT_FOUND = 991020;
    public static final int SSC_ERROR_SENDING_MESSAGES_TO_HOST =  991021;
    public static final int SSC_DISRUPTED_WHILE_WAITING_HOST = 991022;

    // errors for signing on  CICS
    public static final int SSC_CANNOT_CLS_BEFORE_SIGNON_CICS = 991030;
    public static final int SSC_CANNOT_REACH_CICS_SIGNON = 991031;
    public static final int SSC_CANNOT_ENTER_CSSN_NUM = 991032;
    public static final int SSC_CANNOT_GET_CONFIRMATION_AFTER_SIGNON_CICS = 991033;
    public static final int SSC_CANNOT_CLS_AFTER_SIGNON_CICS = 991034;
    public static final int SSC_CANNOT_REACH_VTAM_MENU = 991035;
    public static final int SSC_CANNOT_CLS_BEFORE_TRX = 991036;

    // phone banking related errors
    public static final int SSC_PB_DID_NOT_REPLY = 991040;
    public static final int SSC_PB_REPLY_UNEXPECTED_MSG = 991041;
    public static final int SSC_PB_RETURN_ERROR = 991042;
    public static final int SSC_CANNOT_CLS_AFTER_PB_SESSION = 991043;
    //		public static final int SSC_PB_PROMPT_FOR_HKID = 991044;
    public static final int SSC_PB_CHANGE_PASSWORD_ERROR = 991045;
    public static final int SSC_PB_PIN_ENCRYPT_ERROR = 991046;
    public static final int SSC_PB_INVALID_CHAR = 991047;
    public static final int SSC_PB_INVALID_INT = 991048;

    public static final int SSC_PB_PASSWORD_NOT_6_DIGITS = 991049;

    // phone banking error code
    public static final int SSC_PB_INVALID_USER_ID = 991050;
    public static final int SSC_PB_INVALID_PIN = 991051;
    public static final int SSC_PB_INVALID_PIN_TO_BE_HOT = 991052;
    public static final int SSC_PB_INVALID_STATUS = 991053;
    public static final int SSC_PB_JOINT_AC = 991054;
    public static final int SSC_PB_ID_CHANGE_TO_HOT = 991055;
    public static final int SSC_PB_HOT_ID = 991056;
    public static final int SSC_PB_INVALID_ID_STATUS = 991057;
    public static final int SSC_PB_TIME_OUT = 991058;
    public static final int SSC_PB_SYSTEM_SHUT_DOWN = 991059;
    public static final int SSC_PB_SYSTEM_NOT_INIT = 991060;
    public static final int SSC_PB_SYSTEM_SUSPENDED = 991061;
    public static final int SSC_PB_SYSTEM_ERROR = 991062;
    public static final int SSC_PB_CIF_NOT_READY = 991063;

    public static final int SSC_PB_CHANGE_PIN_FAIL = 991064;
    public static final int SCC_PB_FIRST_LOGIN = 991065;
    public static final int SSC_PB_TRANSFER_ID = 991066;
    public static final int SSC_COI_CHANGE_PIN_ERR = 991067;
    public static final int SSC_COI_RESET_PIN_ERR = 991068;
    public static final int SSC_COI_WRONG_PIN = 991069;

    // CIF related errors
    public static final int SSC_CIF_DID_NOT_REPLY = 991070;
    public static final int SSC_CIF_REPLY_UNEXPECTED_MSG = 991071;
    public static final int SSC_CIF_RETURN_ERROR = 991072;
    public static final int SSC_CANNOT_CLS_AFTER_CIF_SESSION = 991073;
    public static final int SSC_CIF_ACCT_REF_NOT_FOUND = 991074;
    //public static final int SSC_CIF_NOT_READY = 991075;

    //  database related errors
    // The row count for INSERT, UPDATE or DELETE is zero
    public static final int SSC_DBMS_ZERO_ROW = 991080;
    // The row count for INSERT, UPDATE or DELETE is greater than one
    public static final int SSC_DBMS_MORE_THAN_ONE_ROWS = 991081;

    /* encryption related errors */
    public static final int SSC_CANNOT_GET_MASTER_KEY = 992000;
    public static final int SSC_CANNOT_GET_RSA_PRIV_KEY = 992001;
    public static final int SSC_CANNOT_GET_MODULUS = 992002;
    public static final int SSC_CANNOT_GET_PUBLIC_EXPONENT = 992003;
	
	public static final int SSC_EBID_INVALID_ID = 992004;
	public static final int SSC_EBID_USING_PBID = 992005;

    // HUB related
    public static final int SSC_HUB_COMM_ERROR = 993000;
    public static final int SSC_HUB_CONNECT_ERROR_UNEXPECTED = 993010;
    public static final int SSC_HUB_CONNECT_ERROR_CONNECT_DB = 993011;
    public static final int SSC_HUB_CONNECT_ERROR_WRITE_KEY = 993012;
    public static final int SSC_HUB_CONNECT_ERROR_CONNECT_HUB = 993013;
    public static final int SSC_HUB_CONNECT_ERROR_NO_REPLY = 993014;
    public static final int SSC_HUB_CONNECT_ERROR_DELETE_KEY = 993015;
    public static final int SSC_HUB_CONNECT_ERROR_CLOSE_DB = 993016;
    public static final int SSC_HUB_MSG_RESP_ERROR = 993001;


    // iSecurities related
    public static final int SSC_NO_ISEC_AC = 993100;
    public static final int SSC_CONN_ERR_WITH_ETRADE = 993101;
    public static final int SSC_INACTIVE_ISEC_AC = 993102;
    public static final int SSC_INVALID_ISEC_AC = 993103;
    // eIPO in iSecurities
    public static final int SSC_EIPO_HOLD_CODE = 993189;
    public static final int SSC_EIPO_GENERAL_ERROR = 993190;
    public static final int SSC_EIPO_OUT_OF_SUB_PERIOD = 993191;
    public static final int SSC_EIPO_ACCOUNT_SUSPENDED = 993192;
    public static final int SSC_EIPO_INVALID_STOCK = 993193;
    public static final int SSC_EIPO_INVALID_SUB_QTY = 993194;
    public static final int SSC_EIPO_DUPLICATED_SUB = 993195;
    public static final int SSC_EIPO_INSUFFICIENT_FUND = 993196;
    public static final int SSC_EIPO_DORMANT_ACCT = 993197;
    public static final int SSC_EIPO_DR_ACCT_HOLD_CODE = 993198;
    public static final int SSC_EIPO_CR_ACCT_HOLD_CODE = 993199;

    // New iSecurities
    public static final int SSC_SUPP_INFO_INCOMPLETE = 993201;
    public static final int SSC_IP_NOT_MATCH = 993202;
    public static final int SSC_SESSION_INFO_NOT_FOUND = 993203;
    public static final int SSC_INVALID_SUBSYSTEM_STATUS = 993204;
    public static final int SSC_RAN_HASH_NOT_MATCH = 993205;

    // Bill Payment errors
    public static final int SSC_BP_INVALID_LENGTH = 994020;
    public static final int SSC_BP_INVALID_DATA_TYPE = 994021;
    public static final int SSC_BP_INVALID_PATTERN_FROM_DB = 994022;
    public static final int SSC_BP_INVALID_CHECK_DIGIT = 994023;
    public static final int SSC_BP_BILL_RECORD_ALREADY_EXIST = 994024;
    public static final int SSC_BP_BILL_RECORD_NOT_EXIST = 994025;
    public static final int SSC_BP_TX_LIMIT_EXCEEDED_L = 994026;
    public static final int SSC_BP_MERCHANT_NOT_PAYABLE = 994027;
    public static final int SSC_BP_TX_LIMIT_EXCEEDED_U = 994028;
    public static final int SSC_BP_PATTERN_INPUT_FORMAT_ERROR = 994029;
    public static final int SSC_BP_BILL_TYPE_NOT_PAYABLE = 994030;
    public static final int SSC_BP_CC_NOT_PAYABLE = 994031;
    public static final int SSC_BP_CC_MTH_TX_LIMIT_EXCEEDED = 994032;
    public static final int SSC_BP_INVALID_PATTERN_FROM_AGENT = 994033;
    public static final int SSC_BP_EXEC_DATE_OUT_OF_RANGE = 994034;
	//modified by hang
    public static final int SSC_BP_HIGH_RISK_NOT_REGISTERED = 994035;
	public static final int SSC_BP_HIGH_RISK_ECERT_NOT_ADDED = 994036;
	//modified by hang

	public static final int SSC_PER_TXN_LIMIT_EXCEED = 994060;
	public static final int SSC_DAILY_TXN_LIMIT_EXCEED = 994061;
	//For SMCDSB043926-20101122 Double Check The Registed Payment Bill No.    
	public static final int SSC_REGISTERED_BILL_UNMATCH = 994062;

    // Data File Reader errors
    public static final int SSC_READER_DATABASE_ERROR     = 994101;
    public static final int SSC_READER_CONNECTION_ERROR   = 994102;
    public static final int SSC_READER_FILE_ACCESS_ERROR  = 994103;
    public static final int SSC_READER_FILE_ERROR         = 994104;
    public static final int SSC_READER_INTERNAL_ERROR     = 994105;

    // I-Account
    // General
    public static final int SSC_IAC_DBCONN_FAIL           = 995001;
    public static final int SSC_IAC_DBCONN_ROLLBACK       = 995002;
    public static final int SSC_IAC_DBCONN_COMMIT         = 995003;
    public static final int SSC_IAC_SQLEX_ERROR           = 995004;
    public static final int SSC_IAC_POOLMGR_CLOSED        = 995005;
    public static final int SSC_IAC_DBCONN_CLOSED         = 995006;
    public static final int SSC_IAC_RAWFILE_NOT_FOUND     = 995007;
    public static final int SSC_IAC_SCREENEDFILE_NOT_FOUND= 995008;
    public static final int SSC_IAC_NO_ACCOUNT_FOUND      = 995009;
    public static final int SSC_VIA_NO_ACCOUNT_FOUND      = 995100;
    public static final int SSC_IAC_NO_STMT_FOUND         = 995101;
    public static final int SSC_VIA_NO_STMT_FOUND         = 995102;

    //Batch Side
    //Info
    public static final int SSC_IAC_CUTMESG_SPEC_CHAR_FOUND= 995201;
    public static final int SSC_IAC_UPLOAD_SCREEN_COMPLETED= 995202;
    public static final int SSC_IAC_UPLOAD_CAPTURE_COMPLETE= 995203;

    //Error
    public static final int SSC_IAC_PURGE_STMT_FAIL        = 995301;
    public static final int SSC_IAC_PURGE_EXCH_RATE_FAIL   = 995302;
    public static final int SSC_IAC_PURGE_CUST_NAME_FAIL   = 995303;
    public static final int SSC_IAC_PURGE_CUST_ADDR_FAIL   = 995304;
    public static final int SSC_IAC_PURGE_MS_TX_FAIL       = 995305;
    public static final int SSC_IAC_PURGE_MS_CCY_FAIL      = 995306;
    public static final int SSC_IAC_PURGE_CA_TX_FAIL       = 995307;
    public static final int SSC_IAC_PURGE_FD_TX_FAIL       = 995308;
    public static final int SSC_IAC_PURGE_LIFE_FAIL        = 995309;
    public static final int SSC_IAC_PURGE_FAIL             = 995310;
    public static final int SSC_IAC_UPLOAD_STMT_FAIL       = 995311;
    public static final int SSC_IAC_UPLOAD_EXCH_RATE_FAIL  = 995312;
    public static final int SSC_IAC_UPLOAD_CUST_NAME_FAIL  = 995313;
    public static final int SSC_IAC_UPLOAD_CUST_ADDR_FAIL  = 995314;
    public static final int SSC_IAC_UPLOAD_MS_TX_FAIL      = 995315;
    public static final int SSC_IAC_UPLOAD_MS_CCY_FAIL     = 995316;
    public static final int SSC_IAC_UPLOAD_CA_TX_FAIL      = 995317;
    public static final int SSC_IAC_UPLOAD_FD_TX_FAIL      = 995318;
    public static final int SSC_IAC_UPLOAD_LIFE_FAIL       = 995319;
    public static final int SSC_IAC_CUTMESG_STMT_FAIL      = 995320;
    public static final int SSC_IAC_CUTMESG_EXCH_RATE_FAIL = 995321;
    public static final int SSC_IAC_CUTMESG_CUST_NAME_FAIL = 995322;
    public static final int SSC_IAC_CUTMESG_CUST_ADDR_FAIL = 995323;
    public static final int SSC_IAC_CUTMESG_MS_TX_FAIL     = 995324;
    public static final int SSC_IAC_CUTMESG_MS_CCY_FAIL    = 995325;
    public static final int SSC_IAC_CUTMESG_CA_TX_FAIL     = 995326;
    public static final int SSC_IAC_CUTMESG_FD_TX_FAIL     = 995327;
    public static final int SSC_IAC_CUTMESG_LIFE_FAIL      = 995328;
    public static final int SSC_IAC_CUTMESG_KEY_FAIL       = 995329;
    public static final int SSC_IAC_CUTMESG_HEADER_FAIL    = 995330;
    public static final int SSC_IAC_CUTMESG_RECORDSIZE_ERROR=995331;

    //IAC Client Side
    public static final int SSC_IAC_DBPOOL_COM_ERROR	   = 995500;
    public static final int SSC_IAC_SQL_ERROR    	   = 995501;
    public static final int SSC_IAC_CLOSE_ERROR    	   = 995502;
    public static final int SSC_IAC_PAGE_FORWARD_ERROR	   = 995503;
	
	public static final int SSC_IAC_STMT_FOOTER_MSG = 995504;
	public static final int SSC_IAC_STMT_INTRO_MSG = 995505;
	public static final int SSC_IAC_STMT_LIFE_FOOTER_MSG_1 = 995506;
	public static final int SSC_IAC_STMT_LIFE_FOOTER_MSG_2 = 995507;
	public static final int SSC_IAC_STMT_LIFE_FOOTER_MSG_3 = 995508;
	public static final int SSC_IAC_STMT_INTRO_MSG_2 = 995509;
	
	public static final int SSC_BOND_FOOTER_MESSAGE = 995510;
	public static final int SSC_IAC_BOND_FOOTER_MESSAGE = 995511;
	public static final int SSC_BOND_IAC_FOOTER_MESSAGE = 999971;
	//WMD17081 Start
	public static final int SSC_BOND_FOOTER_MESSAGE_2 = 995525;
	//WMD17081 End
	
	public static final int SSC_IAC_STMT_MULT_CCY_MSG_1 = 995512;
	public static final int SSC_IAC_STMT_MULT_CCY_MSG_2 = 995513;
	public static final int SSC_IAC_STMT_WHOLE_MSG_1 = 995514;
	public static final int SSC_IAC_STMT_WHOLE_MSG_2 = 995515;
	//E2011003 Start
    public static final int SSC_IAC_STMT_WHOLE_MSG_3 = 995523;
    //E2011003 End
	public static final int SSC_IAC_STMT_LIFE_FOOTER_MSG_4 = 995516;
	public static final int SSC_IAC_STMT_LIFE_FOOTER_MSG_5 = 995517;
	
	public static final int SSC_IAC_BOND_FOOTER_MESSAGE_2 = 995518;
	public static final int SSC_IAC_BOND_FOOTER_MESSAGE_3 = 995519;
	public static final int SSC_IAC_BOND_FOOTER_MESSAGE_4 = 995520;
	
	public static final int SSC_IAC_STMT_PRODUCT_RISK_LEVEL_MESSAGE = 995521;
	public static final int SSC_IAC_STMT_PRODUCT_RISK_LEVEL_CHANGE_MESSAGE = 995522;
    //E2011003 Start
    //public static final int SSC_IAC_STMT_FOOTER_MSG_2 = 995523;
    //E2011003 End
	
	//PDM15121 Start
	public static final int SSC_IAC_STMT_FOOTER_MSG_3 = 995524;
	//PDM15121 End
	
    //PIN REGENERATION ERRORS created at 18 Oct 2002 by Franky Cheung
    public static final int SSC_PIN_REGEN_PBID_ERROR = 995600;
    public static final int SSC_PIN_REGEN_PBID_RETRY_FAIL = 995601;
    public static final int SSC_PIN_REGEN_ID_DOB_RETRY_FAIL = 995602;
    public static final int SSC_PIN_REGEN_NON_CARD_BANKING_USER = 995603;
    public static final int SSC_PIN_REGEN_ID_DOB_NOT_MATCH_ERROR = 995604;
    public static final int SSC_PIN_REGEN_ID_DOB_FORMAT_ERROR = 995605;
    public static final int SSC_PIN_REGEN_NON_PERSONAL_BANKING_USER = 995606;
    public static final int SSC_PIN_REGEN_HKID_FORMAT_ERROR = 995607;
    public static final int SSC_PIN_REGEN_PASSPORT_FORMAT_ERROR = 995608;
    public static final int SSC_PIN_REGEN_DOB_FORMAT_ERROR = 995609;
    public static final int SSC_PIN_REGEN_OT_NUMBER_FORMAT_ERROR = 995610;
    public static final int SSC_PIN_REGEN_INVALID_PBID_STATUS = 995611;
    public static final int SSC_PIN_REGEN_RECENT_ADDR_MTCE = 995612;

    //HIGH RISK AUTHENTICATION ERRORS created at 4 Feb 03 by Franky Cheung
    public static final int SSC_HIGH_RISK_AUTH_FAILURE = 995700;
    public static final int SSC_HIGH_RISK_AUTH_LOCKED = 995701;
    public static final int SSC_HIGH_RISK_AUTH_EMPTY_DIGIT = 995702;

    // e-Cert related errors
    public static final int SSC_EMPTY_CERTIFICATE = 996000;
    public static final int SSC_EXPIRED_CERTIFICATE = 996001;
    public static final int SSC_REVOKED_CERTIFICATE = 996002;
    public static final int SSC_LOCKED_CERTIFICATE = 996003;
    public static final int SSC_INVALID_CERTIFICATE = 996004;
    public static final int SSC_INVALID_HKID_HASH = 996005;
    public static final int SSC_INVALID_SIGNATURE = 996006;
    public static final int SSC_CUSTOMERID_NOT_SET = 996007;
    public static final int SSC_NO_REGISTER_CERT = 996008;
    public static final int SSC_ALREADY_REGISTER_CERT = 996009;
    public static final int SSC_FATAL_ERROR_VALIDATE_CERT = 996010;
    public static final int SSC_FATAL_ERROR_VALIDATE_SIG = 996011;
    public static final int SSC_FATAL_ERROR_PARSE_CERT = 996012;
    public static final int SSC_CUSTOMER_NOT_FOUND = 996013;
    public static final int SSC_HKID_NOT_MATCH = 996014;
    public static final int SSC_CERT_NOT_REGISTER = 996015;
    public static final int SSC_UNRECOGNIZED_CA = 996016;
    public static final int SSC_CRL_UPDATE_FAILURE = 996017;
          //LAM CHI KAI : e-Cert related errors added for bankCert system
          //LAM CHI KAI : LDAP lookup and CRL checking
    public static final int SSC_HKP_LDAP_CONNECTION_FAILURE = 996018;
    public static final int SSC_HKP_LDAP_QUERY_FAILURE = 996019;
    public static final int SSC_HKP_LDAP_ECERT_NOT_FOUND = 996020;
    public static final int SSC_CRL_FILE_NOT_FOUND = 996021;
    public static final int SSC_CRL_FORMATION_FAILURE = 996022;
    public static final int SSC_CRL_NOT_INITIALIZED = 996023;
    public static final int SSC_ECERT_FORMATION_FAILURE = 996024;


	// Customer Profile Maintenance:
	public static final int SSC_ADDR_EMPTY = 996100;
	public static final int SSC_PAGERFAX_REQ = 996101;
	public static final int SSC_PAGER_NUM_EMPTY = 996102;
	public static final int SSC_FAX_NUM_EMPTY = 996103;
	public static final int SSC_SPEC_ACCT1_EMPTY = 996104;
	public static final int SSC_SPEC_ACCT_NOT_EMPTY = 996105;
	public static final int SSC_SAFE_BOX_NO_EMPTY = 996106;
	public static final int SSC_SAFE_BOX_BRCH_REQ = 996107;
	public static final int SSC_HOME_TEL_INVALID = 996108;
	public static final int SSC_MOBILE_INVALID = 996109;
	public static final int SSC_OFF_TEL_INVALID = 996110;
	public static final int SSC_INVALID_CHAR = 996111;
	public static final int SSC_NON_NUMERIC = 996112;
	public static final int SSC_EFF_DATE_TYPE_REQ = 996113;
	public static final int SSC_ACCT_TYPE_REQ = 996114;
	public static final int SSC_NO_CHANGE = 996115;
	public static final int SSC_EFF_DATE_REQ = 996116;

	// Customer Email Maintenance
	public static final int SSC_EMAIL1_INCOMPLETE = 996117;
	public static final int SSC_EMAIL2_INCOMPLETE = 996118;
	public static final int SSC_EMAIL_INVALID = 996119;
	public static final int SSC_EMAIL_NOT_IN_SEQ = 996120;

	//Credit Card Online Payment, front-end errors -- eBPP Enhancement (SP02132), 2003/02/21
	public static final int SSC_EMPTY_EMAIL_ADDR = 996121;
	public static final int SSC_INVALID_EMAIL_ADDR = 996122;
	public static final int SSC_EMPTY_PAYMENT_AMOUNT = 996123;
	public static final int SSC_INVALID_PAYMENT_AMOUNT = 996124;
	public static final int SSC_EMPTY_DEBIT_ACCT = 996125;
	public static final int SSC_EMPTY_CREDIT_ACCT = 996126;
	public static final int SCC_CREDIT_BALANCE = 996127;

	//MGM Loan Programme 2004/04/15
	public static final int SSC_MGM_LOAN_EMPTY_NAME = 996151;
	public static final int SSC_MGM_LOAN_EMPTY_REFEREE_NAME = 996152;
	public static final int SSC_MGM_LOAN_EMPTY_REFEREE_EMAIL = 996153;
	public static final int SSC_MGM_LOAN_INVALID_REFEREE_EMAIL = 996154;
	public static final int SSC_MGM_LOAN_DUPLICATE_REFEREE_EMAIL = 996155;
	public static final int SSC_MGM_LOAN_EMPTY_EMAIL = 996156;
	public static final int SSC_MGM_LOAN_INVALID_EMAIL = 996157;
	//MGM Loan Programme 2004/06/16
	public static final int SSC_MGM_LOAN_EMPTY_CARDNO = 996159;
	public static final int SSC_MGM_LOAN_INVALID_CARDNO = 996160;


	//In-money and Express momney online form
	public static final int SSC_EXP_EMPTY_LOAN_AMOUNT = 996161;
	public static final int SSC_EXP_INVALID_LOAN_AMOUNT = 996162;
	public static final int SSC_EXP_RANGE_LOAN_AMOUNT = 996163;
	public static final int SSC_EXP_EMPTY_DISBURSEMENT_METHOD = 996164;
	public static final int SSC_EXP_EMPTY_DIS_BANK_ACCOUNT_NO = 996165;
	public static final int SSC_EXP_EMPTY_DIS_BRANCH = 996166;
	public static final int SSC_EXP_EMPTY_NAME = 996167;
	public static final int SSC_EXP_EMPTY_IDENTITY_NO = 996168;
	public static final int SSC_EXP_EMPTY_DATE_OF_BIRTH = 996169;
	public static final int SSC_EXP_INVALID_DATE_OF_BIRTH = 996170;
	public static final int SSC_EXP_INVALID_EMPLOYER_NAME = 996171;
	public static final int SSC_EXP_EMPTY_CONTACT_NO = 996172;
	public static final int SSC_EXP_INVALID_ADDRESS = 996173;
	public static final int SSC_EXP_INVALID_REPAY_BANK_BRANCH = 996174;
	public static final int SSC_EXP_EMPTY_REPAY_BANK_CODE = 996175;
	public static final int SSC_EXP_EMPTY_REPAY_BRANCH_CODE = 996176;
	public static final int SSC_EXP_EMPTY_REPAY_ACC_NO = 996177;
	public static final int SSC_EXP_EMPTY_REPAY_ACC_NAME = 996178;
	public static final int SSC_EXP_EMPTY_EMPLOYER_NAME = 996179;
	public static final int SSC_EXP_EMPTY_ADDRESS = 996180;
	public static final int SSC_EXP_INVALID_REPAY_BANK_CODE = 996181;
	public static final int SSC_EXP_INVALID_REPAY_BRANCH_CODE = 996182;
	public static final int SSC_EXP_INVALID_REPAY_ACC_NO = 996183;
	public static final int SSC_IN_MONEY_RANGE_LOAN_AMOUNT = 996184;
	public static final int SSC_IN_MONEY_EMPTY_DISBUR_BRANCH_CODE = 996185;
	public static final int SSC_IN_MONEY_INVALID_DISBUR_BRANCH_CODE = 996186;
	public static final int SSC_IN_MONEY_DISBUR_BANK_NAME_EMPTY = 996187;
	public static final int SSC_IN_MONEY_DISBUR_ACCT_EMPTY = 996188;
	public static final int SSC_IN_MONEY_DISBUR_ACCT_NAME_EMPTY = 996189;
	public static final int SSC_LOAN_WELCOME_GIFT_EMPTY = 996192;
	public static final int SSC_LOAN_WELCOME_GIFT_NOT_AVAILABLE = 996193;
	public static final int SSC_LOAN_AMOUNT_RANGE_INVALID = 996195;
	
	// Rewards Redemption
	public static final int SSC_CARD_RULE_FAILED = 996200;
	public static final int SSC_INVALID_ACCT_NUM = 996201;
	public static final int SSC_EMPTY_DAY_PHONE = 996202;
	public static final int SSC_INVALID_DAY_PHONE = 996203;
	public static final int SSC_NO_ITEM_SELECTED = 996204;
	public static final int SSC_INVALID_ITEM_QTY = 996205;
	public static final int SSC_ITEM_QTY_TOO_LARGE = 996206;
	public static final int SSC_ITEM_QTY_TOO_SMALL = 996207;
	public static final int SSC_EMPTY_ENG_NAME = 996208;
	public static final int SSC_INVALID_ENG_NAME = 996209;
	public static final int SSC_EMPTY_ID_TYPE = 996210;
	public static final int SSC_EMPTY_ID_NUM = 996211;
	public static final int SSC_INVALID_HKID = 996212;
	public static final int SSC_INVALID_PASSPORT = 996213;
	public static final int SSC_EMPTY_REDEEM_ACCT_LIST = 996214;
	public static final int SSC_INVALID_NIGHT_PHONE = 996215;
	public static final int SSC_EMPTY_FFC_REDEEM_ACCT_LIST = 996216;
    public static final int SSC_ORDER_QTY_EXCEED_LIMIT = 996217;
	public static final int SSC_INVALID_ITEM_CCY = 996218;

    // Tax Loan Application
	public static final int SSC_TAX_REPAYMENT_PERIOD_EMPTY = 996301;
	public static final int SSC_TAX_DISBURSEMENT_EMPTY = 996302;
	public static final int SSC_TAX_TAX_DEMAND_NOTE_AMT_EMPTY = 996303;
	public static final int SSC_TAX_PAYMENT_METHOD_EMPTY = 996304;
	public static final int SSC_TAX_NO_OF_DEPENDENTS_INVALID = 996305;
	public static final int SSC_TAX_HOME_ADDRESS_FLAT_EMPTY = 996306;
	public static final int SSC_TAX_HOME_ADDRESS_ESTATE_EMPTY = 996307;
	public static final int SSC_TAX_HOME_ADDRESS_DISTRICT_EMPTY = 996308;
	public static final int SSC_TAX_HOME_ADDRESS_AREA_EMPTY = 996309;
	public static final int SSC_TAX_YEARS_THERE_INVALID = 996310;
	public static final int SSC_TAX_MONTHLY_INCOME_EMPTY = 996311;
	public static final int SSC_TAX_MONTHLY_INCOME_INVALID = 996312;
	public static final int SSC_TAX_OFFICE_TEL_EMPTY = 996313;
	public static final int SSC_TAX_HOME_TEL_EMPTY = 996314;
	public static final int SSC_TAX_RENT_INVALID = 996315;
	public static final int SSC_TAX_SELF_EMPLOYED_EMPTY = 996316;
	public static final int SSC_TAX_BUS_ADDRESS_FLAT_EMPTY = 996317;
	public static final int SSC_TAX_BUS_ADDRESS_ESTATE_EMPTY = 996318;
	public static final int SSC_TAX_BUS_ADDRESS_DISTRICT_EMPTY = 996319;
	public static final int SSC_TAX_BUS_ADDRESS_AREA_EMPTY = 996320;
	public static final int SSC_TAX_BUS_ADDRESS_EMPTY = 996321;
	public static final int SSC_TAX_YEARS_OF_SERVICE_INVALID = 996322;
	public static final int SSC_TAX_OTHER_INCOME_SRC_INVALID = 996323;
	public static final int SSC_TAX_JOINT_ENG_NAME_EMPTY = 996324;
	public static final int SSC_TAX_JOINT_ID_TYPE_EMPTY = 996325;
	public static final int SSC_TAX_JOINT_ID_EMPTY = 996326;
	public static final int SSC_TAX_JOINT_ID_INVALID = 996327;
	public static final int SSC_TAX_REPAY_BANK_NAME_EMPTY = 996328;
	public static final int SSC_TAX_REPAY_BRANCH_NAME_EMPTY = 996329;
	public static final int SSC_TAX_REPAY_ACCT_EMPTY = 996330;
	public static final int SSC_TAX_EMAIL_EMPTY = 996331;
	public static final int SSC_TAX_REPAY_ACCT_NAME_EMPTY = 996332;
	public static final int SSC_TAX_DIS_BANK_ACCOUNT_NO_INVALID = 996333;
	public static final int SSC_TAX_JOINT_ENG_NAME_INVALID = 996334;
	public static final int SSC_TAX_HAVE_APPLIED_DSB = 996335;
	public static final int SSC_TAX_HAVE_APPLIED_MEVAS = 996336;
	public static final int SCC_TAX_INVALID_CHARACTERS = 996337;
	public static final int SSC_E_CASH_GROUP_ID_EMPTY = 996338;
	public static final int SSC_E_CASH_GROUP_ID_INVALID = 996339;
	public static final int SSC_E_CASH_GROUP_ENG_NAME_EMPTY = 996340;
	public static final int SSC_E_CASH_GROUP_ENG_NAME_INVALID = 996341;
	public static final int SSC_E_CASH_RANGE_LOAN_AMOUNT = 996342;
	public static final int SCC_TAX_INELIGIBLE_PAYMENT_HOLIDAY = 996343;
	public static final int SCC_TAX_POSITION_EMPTY = 996344;
	public static final int SCC_TAX_BUS_NATURE_EMPTY = 996345;
	public static final int SSC_TAX_RANGE_LOAN_AMOUNT = 996346; //PDM10383 TXOCT10 15/10/2010

	//FlexiMoney Application
	public static final int SSC_EXP_EMPTY_CREDIT_LIMIT = 996350;
	public static final int SSC_EXP_INVALID_CREDIT_LIMIT = 996351;
	public static final int SSC_EXP_RANGE_CREDIT_LIMIT = 996352;

	//Lucky Draw 2006 Online Application
	public static final int SSC_LUCKY_DRAW_CONTACT_TEL_EMPTY = 996360;
	public static final int SSC_LUCKY_DRAW_CONTACT_TEL_INVALID = 996361;
	public static final int SSC_LUCKY_DRAW_DUPLICATE_EMIAL = 996362;

	//Express momney interest free online form
	public static final int SSC_EMIF_EMPTY_LOAN_CUST_TYPE = 996370;
	public static final int SSC_EMIF_NJS_RANGE_LOAN_AMOUNT = 996371;
	public static final int SSC_EMIF_NJS_RANGE_REPAYMENT_TENOR = 996372;

	//YouBuy Cash (PDM09182)
	public static final int SSC_EMPTY_DISBURSE_BANK_NAME = 996380;
	public static final int SSC_EMPTY_DISBURSE_BRANCH_CODE = 996381;
	public static final int SSC_INVALID_DISBURSE_BRANCH_CODE = 996382;
	public static final int SSC_EMPTY_DISBURSE_ACCT = 996383;
	public static final int SSC_INVALID_DISBURSE_ACCT = 996384;
	public static final int SSC_EMPTY_DISBURSE_ACCT_NAME = 996385;
	public static final int SSC_INVALID_DISBURSE_ACCT_NAME = 996386;
	public static final int SSC_EMPTY_DISBURSE_METHOD = 996387;

	//Special Purpose Loan (PDM10206)
	public static final int SSC_EM_EMPTY_LOAN_PURPOSE = 996390;
	public static final int SSC_EM_SP_LOAN_AMT_RANGE_INVALID = 996391;

    //Project Mark Lucky Draw
    public static final int SCC_CARD_NUM_NOT_FOUND       = 996400;
    public static final int SCC_NOT_VALID_CARD_TYPE      = 996401;
    public static final int SCC_ALREADY_DRAW             = 996402;
    public static final int SCC_EXCEED_ENTITLE_DAY_LIMIT = 996403;
    public static final int SCC_EXCEED_PROGRAM_PERIOD    = 996404;
    public static final int SCC_EXCEED_ENTITLE_PERIOD    = 996405;
    public static final int SCC_BELOW_MIN_AMOUNT         = 996406;
    public static final int SCC_NO_ITEM_AVAILABLE        = 996407;
    public static final int SCC_STOCK_STATUS_UPDATE_FAIL = 996408;
    public static final int SCC_SP_GENERAL_ERROR         = 996409;
	public static final int SCC_MULD_NAME_EMPTY            = 996410;
	public static final int SCC_MULD_CC_NUM_EMPTY          = 996411;
	public static final int SCC_MULD_CC_NUM_LENGTH         = 996412;
	public static final int SCC_MULD_CC_NUM_INVALID        = 996413;
	public static final int SCC_MULD_TX_DATE_INVALID       = 996414;
	public static final int SCC_MULD_TX_AMOUNT_EMPTY       = 996415;
	public static final int SCC_MULD_TX_AMOUNT_INVALID     = 996416;
	public static final int SCC_MULD_APPROVAL_CODE_EMPTY   = 996417;
	public static final int SCC_MULD_APPROVAL_CODE_LENGTH  = 996418;
	public static final int SCC_MULD_APPROVAL_CODE_INVALID = 996419;
	public static final int SCC_MULD_NAME_INVALID          = 996420;
	public static final int SCC_MULD_TX_DATE_EXCEEDED      = 996421;
	public static final int SCC_MULD_TX_DATE_ENT_EXCEEDED  = 996422;


    //Credit Card Online Instalment
    public static final int SSC_CCOI_QUANTITY_EXCEED = 997000;
    public static final int SSC_CCOI_DELIVERY_DETAILS_MISSING = 997001;
    public static final int SSC_CCOI_CONTACT_MISSING = 997002;
    public static final int SSC_CCOI_SUB_PROD_OUT_OF_STOCK = 997003;
    
    //YOU Point Redeem
    public static final int SSC_YB_NOT_SERVICE_TIME = 997210;
    public static final int SSC_YB_NON_SERVICE_HOUR_PAGE = 997211;
    
    // eIPO Application
    public static final int SSC_EIPO_APPLY_BEGIN = 998000;
    public static final int SSC_EIPO_APPLY_END   = 998001;
    public static final int SSC_EIPO_CANCEL_BEGIN= 998002;
    public static final int SSC_EIPO_CANCEL_END= 998003;
    public static final int SSC_EIPO_ENQ_BEGIN= 998004;
    public static final int SSC_EIPO_ENQ_END= 998005;
    public static final int SSC_EIPO_OUTPUT_NOT_FOUND= 998006;

    // eIPO Payment
    public static final int SSC_EIPO_PAYMENT_AMOUNT_NOT_MATCH = 997101;
    public static final int SSC_EIPO_APPL_NUM_NOT_MATCH = 997102;
    public static final int SSC_EIPO_STOCK_CODE_NOT_MATCH = 997103;
    public static final int SSC_EIPO_PAID_ALREADY = 997104;

    public static final int SSC_IPO_PAYMENT_AMOUNT_NOT_MATCH = 997101;
    public static final int SSC_IPO_APPL_NUM_NOT_MATCH = 997102;
    public static final int SSC_IPO_STOCK_CODE_NOT_MATCH = 997103;
    public static final int SSC_IPO_PAID_ALREADY = 997104;

    public static final int SSC_UT_GRAND_FUND_PORT_ERROR = 997200;
    public static final int SSC_UT_INVESTMENT_FUND_ERROR = 997201;
    public static final int SSC_UT_FUND_HOLDING_DETAIL_ERROR = 997202;
    public static final int SSC_UT_ACCT_TXN_ERROR = 997203;

	//for Securities:
    public static final int SSC_SEC_ACCT_DETAIL_ERROR = 997300;
    public static final int SSC_SEC_TXN_HIST_ERROR = 997301;
	public static final int SSC_SEC_ACCT_UPD_ERROR = 997302;

	//for Retail Bond/ Notes
    public static final int SSC_RB_HOLDING_DETAIL_ERROR = 997400;
    public static final int SSC_RB_ACCT_TXN_ERROR = 997401;

	//PDM04259 Lucky Draw
	public static final int SSC_LD_TXN_SAVE_FAIL = 997500;
	public static final int SSC_LD_PRIZE_SAVE_FAIL = 997501;
	public static final int SSC_LD_CONTACT_SAVE_FAIL = 997502;
	public static final int SSC_LD_NO_CHANCE_LEFT = 997503;
	public static final int SSC_LD_CANT_USE_OTHERS_CHANCE = 997504;
	public static final int SSC_LD_UNKNOWN_TXN_ID = 997505;
	public static final int SSC_LD_PRIZE_COUNT_MISMATCH = 997506;

    // Phase 2c
    // Pending Instructions Management
    //public static final int SSC_INSTR_ALREADY_EXECUTED = 998800;
    //public static final int SSC_INSTR_NOT_EXIST = 998801;
    public static final int SSC_EJB_CREATION_ERROR = 998802;
    public static final int SSC_EJB_GENERAL_ERROR = 998803;
    public static final int SSC_EJB_NOT_FOUND = 998804;
    public static final int SSC_DDA_RECORD_NOT_FOUND = 998805;
    public static final int SSC_INSTR_STATUS_ALTER_FAILURE = 998806;
    public static final int SSC_INSTR_BATCH_TERMINATE = 998814;
    public static final int SSC_ED_INSTR_WITH_NO_DDA_RECORD = 998816;
    public static final int SSC_SCHED_ON_SATURDAY = 998817;

    // scheduling
    public static final int SSC_SCHED_DATE_NORMAL = 998807;
    public static final int SSC_SCHED_DATE_NOT_EXIST = 998808;
    public static final int SSC_SCHED_ON_PUBLIC_HOLIDAY = 998809;
    public static final int SSC_SCHED_ON_SUNDAY = 998810;
    public static final int SSC_SCHED_OUT_OF_DATE_RANGE = 998811;
    public static final int SSC_SCHED_NO_VALID_ADJUSTABLE_DATE = 998812;
    public static final int SSC_SCHED_DATE_PAST = 998813;
    public static final int SSC_SCHED_POST_INSTR_EXIST = 998815;

    // WMD16067
    public static final int SSC_INSTR_ALREADY_EXECUTED = 22270;
    public static final int SSC_FX_PW_OUTSIDE_SERVICE_HOUR = 998820;
    public static final int SSC_FX_PW_DEBIT_CREDIT_ACCT_IS_EMPTY = 998821;
    public static final int SSC_FX_PW_ORDER_CREATE_FAILED = 998822;
    public static final int SSC_FX_PW_ORDER_CREATE_ALERT_SMS_FLAG_UPDATE_FAILED = 998823;
    //public static final int SSC_FX_PW_ORDER_CREATE_ERROR = 998824;
    public static final int SSC_FX_PW_ORDER_CANCEL_ALREADY_EXECUTED = 998825;
    //public static final int SSC_FX_PW_ORDER_CANCEL_ERROR = 998826;
    public static final int SSC_FX_PW_ORDER_CANCEL_FAILED = 998827;
    public static final int SSC_FX_PW_ORDER_MODIFY_ALERT_SMS_FLAG_UPDATE_FAILED = 998828;
    public static final int SSC_FX_PW_ORDER_MODIFY_ALREADY_EXECUTED = 998829;
    public static final int SSC_FX_PW_ORDER_MODIFY_CANCEL_FAILED = 998830;
    public static final int SSC_FX_PW_ORDER_MODIFY_CREATE_FAILED = 998831;
    //public static final int SSC_FX_PW_ORDER_MODIFY_ERROR = 998832;
    public static final int SSC_FX_PW_FOREX_EXCH_RATE_EXPIRED = 998833;
    //public static final int SSC_FX_PW_ORDER_MODIFY_CREATE_AND_ALERT_SMS_FLAG_UPDATE_FAILED = 998834;

	// fund search
	public static final int SSC_IO_READ_DBPROP_ERR = 999001;
	public static final int SSC_DB_INS_FUND_ERR	= 999002;
	public static final int SSC_IO_READ_CSV_FILE_ERR = 999003;
	public static final int SSC_NO_CSV_FILE_ERR = 999004;
	public static final int SSC_DB_SRCH_ERR = 999005;
	public static final int SSC_DB_SEL_COL_ERR = 999006;
	public static final int SSC_IO_READ_FDPROP_ERR = 999007;
	public static final int SSC_DB_ERR = 999008;
	public static final int SSC_UNEXP_ECPT = 999009;
	public static final int SSC_WRONG_FILE_FRMT = 999010;
	public static final int SSC_EMPTY_FILE = 999011;
	public static final int SSC_TOO_MANY_COL = 999012;
	public static final int SSC_FILE_TOO_BIG = 999013;

	// opt out hash
	public static final int SSC_FILE_IO_EXCP = 999101;
	public static final int SSC_KEY_FILE_NOT_FOUND = 999102;
	public static final int SSC_SIGN_ALG_NOT_FOUND = 999103;
	public static final int SSC_INVALID_KEY = 999104;
	public static final int SSC_INVALID_KEY_SPEC = 999105;
	public static final int SSC_SIGN_EXCP = 999106;

	//IDD03032 Customer CRM Info Capture
	public static final int SSC_INVALID_CUST_NAME     = 999150;
	public static final int SSC_INVALID_ID            = 999151;
	public static final int SSC_INVALID_PPORT         = 999152;
	public static final int SSC_INVALID_EMAIL         = 999153;
	public static final int SSC_INVALID_MOBILE_PHONE  = 999154;
	public static final int SSC_DUPLICATE_CRM_ENTRY   = 999155;
	public static final int SSC_INVALID_CUST_TITLE    = 999156;
	public static final int SSC_TXN_RESUBMIT          = 999157;

    public static final int SSC_HR_INV_PHONE_LENGTH = 999200;
    public static final int SSC_HR_EMPTY_ACCT_NUM = 999201;
    public static final int SSC_HR_INV_BENE_NAME = 999202;
    public static final int SSC_HR_EMPTY_BANK_CODE = 999203;
    public static final int SSC_HR_INV_BRANCH_CODE = 999204;
    public static final int SSC_HR_INV_ACCT_NUM = 999205;
    public static final int SSC_HR_INV_DAILY_LIMIT = 999206;
    public static final int SSC_HR_EXCEED_DAILY_LIMIT = 999207;
    public static final int SSC_HR_DUPLICATE_RECORD = 999208;
    public static final int SSC_NO_RECORD_INPUT = 999209;
    public static final int SSC_EMPTY_CATEGORY = 999210;
    public static final int SSC_EMPTY_MERCHANT = 999211;
    public static final int SSC_EMPTY_BILLTYPE = 999212;
    public static final int SSC_EMPTY_BILLNUM  = 999213;
    public static final int SSC_HR_NO_ACCT_REG_BBP = 999214;
    public static final int SSC_HR_NO_ACCT_REG_FT = 999215;
	//modified by hang
    public static final int SSC_HR_INV_HKID_LENGTH = 999216;
	//modified by hang

	//PDM05217 Kiddie e-banking service
	public static final int SSC_EK_EMPTY_CUST_ID  		= 999217;
	public static final int SSC_EK_EMPTY_LOGIN_ID   	= 999218;
	public static final int SSC_EK_EMPTY_LOGIN_NAME		= 999219;
	public static final int SSC_EK_INVALID_LOGIN_ID_LEN	= 999220;
	public static final int SSC_EK_INVALID_LOGIN_ID_CHAR  	= 999221;
	public static final int SSC_EK_EMPTY_PWD   		= 999222;
	public static final int SSC_EK_INVALID_PWD_LENGTH	= 999223;
	public static final int SSC_EK_INVALID_PWD_CHAR  	= 999224;
	public static final int SSC_EK_EMPTY_CFM_PWD   		= 999225;
	public static final int SSC_EK_EMPTY_EMAIL_ADD  	= 999226;
	public static final int SSC_EK_INVALID_EMAIL_ADD  	= 999227;
	public static final int SSC_EK_PWD_NOT_MATCH  		= 999228;
	public static final int SSC_EK_EXIST_KID_ID  		= 999229;
	public static final int SSC_EK_EXIST_LOGIN_ID  		= 999230;
	public static final int SSC_EK_LOGIN_ID_NOT_FOUND       = 999231;
	public static final int SSC_EK_LOGIN_ID_DELETED         = 999232;
	public static final int SSC_KID_ACCT_PROFOLIO_NOT_FOUND	= 999233;
	public static final int SSC_KID_SEND_ECARD_ERROR	= 999234;

	public static final int SSC_TK_EXIST_KID_ID             = 999239;
	public static final int SSC_TK_LOGIN_ID_DELETED         = 999242;
	public static final int SSC_TKID_ACCT_PROFOLIO_NOT_FOUND = 999243;
	public static final int SSC_RK_EXIST_KID_ID             = 999251;
	public static final int SSC_RK_LOGIN_ID_DELETED         = 999252;
	public static final int SSC_RKID_ACCT_PROFOLIO_NOT_FOUND = 999253;
	public static final int SSC_BK_EXIST_KID_ID             = 999255;
	public static final int SSC_BK_LOGIN_ID_DELETED         = 999256;
	public static final int SSC_BKID_ACCT_PROFOLIO_NOT_FOUND = 999257;

	//COI
	public static final int SCC_COI_COMM_ERROR =    999301;

	//Credit Mastermind Instalment Loan Application
	public static final int SSC_CMI_RANGE_LOAN_AMOUNT = 999311;
	public static final int SSC_CMI_EMPTY_CREDIT_LIMIT = 999312;
	public static final int SSC_CMI_INVALID_CREDIT_LIMIT = 999313;
	public static final int SSC_CMI_EMPTY_OUSTANDING_AMT = 999314;
	public static final int SSC_CMI_INVALID_OUSTANDING_AMT = 999315;
	public static final int SSC_CMI_EMPTY_INSTAL_AMT = 999316;
	public static final int SSC_CMI_INVALID_INSTAL_AMT = 999317;

	// DSB Credit Card Application Form
	public static final int SSC_CARD_TYPE_EMPTY = 999400;
	public static final int SSC_APPLICANT_NAME_EMPTY = 999401;
	public static final int SSC_TITLE_EMPTY = 999402;
	public static final int SSC_SURNAME_ERROR = 999403;
	public static final int SSC_GIVEN_NAME_ERROR = 999404;
	public static final int SSC_ID_TYPE_EMPTY = 999405;
	public static final int SSC_ID_NUM_EMPTY = 999406;
	public static final int SSC_ID_NUM_INVALID = 999407;
	public static final int SSC_DATE_EMPTY = 999408;
	public static final int SSC_DATE_INVALID = 999409;
	public static final int SSC_MARITAL_STATUS_EMPTY = 999410;
	public static final int SSC_NATIONALITY_EMPTY = 999411;
	public static final int SSC_EDUCATION_EMPTY = 999412;
	public static final int SSC_RESIDENCE_TEL_EMPTY = 999413;
	public static final int SSC_RESIDENCE_TEL_INVALID = 999414;
	public static final int SSC_RESIDENCE_EMPTY = 999415;
	public static final int SSC_MOBILE_TEL_INVALID = 999416;
	public static final int SSC_NUM_OF_DEPENDENTS_EMPTY = 999417;
	public static final int SSC_EMAIL_ADDR_INVALID = 999418;
	public static final int SSC_RESIDENTIAL_ADDR_EMPTY = 999419;
	public static final int SSC_ADDR_BUILDING_OR_STREET_EMPTY = 999420;
	public static final int SSC_SUPP_DATE_OF_BIRTH_EMPTY = 999421;
	public static final int SSC_ADDR_COUNTRY_EMPTY = 999422;
	public static final int SSC_ADDR_DISTRICT_EMPTY = 999423;
	public static final int SSC_ADDR_REGION_EMPTY = 999424;
	public static final int SSC_ATM_LANG_EMPTY = 999425;
	public static final int SSC_OCCUPATION_EMPTY = 999426;
	public static final int SSC_OTHER_OCCUPATION_EMPTY = 999427;
	public static final int SSC_COMPANY_NAME_EMPTY = 999428;
	public static final int SSC_COMPANY_ADDR_EMPTY = 999429;
	public static final int SSC_COMPANY_TEL_INVALID = 999430;
	public static final int SSC_YEARS_OF_SERVICE_INVALID = 999431;
	public static final int SSC_INCOME_INVALID = 999432;
	public static final int SSC_OTHER_INCOME_INVALID = 999433;
	public static final int SSC_SUPP_APPLICANT_NAME_EMPTY = 999434;
	public static final int SSC_SUPP_TITLE_EMPTY = 999435;
	public static final int SSC_SUPP_SURNAME_ERROR = 999436;
	public static final int SSC_SUPP_GIVEN_NAME_ERROR = 999437;
	public static final int SSC_SUPP_ID_TYPE_EMPTY = 999438;
	public static final int SSC_SUPP_ID_NUM_EMPTY = 999439;
	public static final int SSC_SUPP_ID_NUM_INVALID = 999440;
	public static final int SSC_SUPP_NATIONALITY_EMPTY = 999441;
	public static final int SSC_SUPP_HOME_TEL_EMPTY = 999442;
	public static final int SSC_SUPP_HOME_TEL_INVALID = 999443;
	public static final int SSC_SUPP_COMP_TEL_INVALID = 999444;
	public static final int SSC_SUPP_MOBILE_INVALID = 999445;
	public static final int SSC_SUPP_ATM_LANG_EMPTY = 999446;
	public static final int SSC_OCTOPUS_PREFERENCE_UNCHECK = 999447;
	public static final int SSC_OCTOPUS_NUM_EMPTY = 999448;
	public static final int SSC_SUPP_DATE_OF_BIRTH_INVALID = 999449;
	public static final int SSC_OCTOPUS_COLLECT_VENUE_EMPTY = 999450;
	public static final int SSC_TERM_AND_CONDITION_UNCHECK = 999451;
	public static final int SSC_DSB_APPLY_TIMEOUT = 999452;

	public static final int SSC_DSB_CASH_IN_PLAN_NO_BANKCODE = 999453;
	
	public static final int SSC_DSB_CASH_IN_PLAN_MANDATORY = 999454;
	public static final int SSC_DSB_CASH_IN_PLAN_VALID_INPUT = 999455;
	public static final int SSC_DSB_CASH_IN_PLAN_NUMERIC_LENGTH = 999456;
	public static final int SSC_DSB_CASH_IN_PLAN_NUMERIC = 999457;
	public static final int SSC_DSB_CASH_IN_PLAN_INVALID_CC = 999458;
	public static final int SSC_DSB_CASH_IN_PLAN_LT_AMT = 999459;
	public static final int SSC_DSB_CASH_IN_PLAN_VALID_ENG_INPUT = 999460;
	public static final int SSC_DSB_CASH_IN_PLAN_MANDATORY_SEL = 999461;
	public static final int SSC_DSB_CASH_IN_PLAN_VALID_ENG_INPUT_2 = 999462;
	
	public static final int SSC_DSB_ACCA_SELECT_MEMBER_TYPE_EMPTY = 999463;
	public static final int SSC_DSB_ACCA_MEMBER_NO_EMPTY = 999464;
	public static final int SSC_DSB_UA_SELECT_EMPTY = 999465;
	public static final int SSC_DSB_UA_MEMBER_NO_EMPTY = 999466;
	public static final int SSC_DSB_MTR_SELECT_EMPTY = 999467;
	public static final int SSC_DSB_MTR_ACC_NO_EMPTY = 999468;
	public static final int SSC_DSB_HKCS_MEMBER_NO_EMPTY = 999469;
	public static final int SSC_DSB_HKCS_CHECKBOX_EMPTY = 999470;
	public static final int SSC_DSB_AUTOTOLL_SELECT_EMPTY = 999471;
	
	public static final int SSC_DSB_ACCA_MEMBER_NO_EXCEED_LEN = 999472;
	public static final int SSC_DSB_UA_MEMBER_NO_EXCEED_LEN = 999473;
	public static final int SSC_DSB_MTR_ACC_NO_EXCEED_LEN = 999474;
	public static final int SSC_DSB_HKCS_MEMBER_NO_EXCEED_LEN = 999475;
	
	public static final int SSC_DSB_EMAIL_EMPTY = 999476;
	public static final int SSC_DSB_BA_MEMBER_NO_EXCEED_LEN = 999477;
	public static final int SSC_MOBILE_TEL_DETAIL_INVALID = 999478;
	

	public static final int SSC_DSB_FATCA_TIN_INVALID = 999479;
	public static final int SSC_DSB_FATCA_US_PERSON_INVALID = 999480;
	public static final int SSC_DSB_FATCA_COUNTRY_OF_BIRTH_INVALID = 999481;
	public static final int SSC_DSB_FATCA_MOBILE_NUM_INVALID_FOR_US_INDICATOR  = 999482;
	public static final int SSC_DSB_FATCA_COMPANY_TEL_INVALID_FOR_US_INDICATOR = 999483;

	public static final int SSC_EMAIL_ADDR_INVALID_V2 = 999484;
	
	// Mortgage Loan Error Code
	public static final int SSC_MORTGAGE_TYPE_EMPTY = 999501;
	public static final int SSC_OUTSTANDING_LOAN_AMT_EMPTY = 999502;
	public static final int SSC_OUTSTANDING_LOAN_AMT_NUMERIC = 999503;
	public static final int SSC_ORIGINAL_BANK_EMPTY = 999504;
	public static final int SSC_PURCHASE_PRICE_EMPTY = 999505;
	public static final int SSC_PURCHASE_PRICE_NUMERIC = 999506;
	public static final int SSC_LOAN_AMT_EMPTY = 999507;
	public static final int SSC_LOAN_AMT_NUMERIC = 999508;
	public static final int SSC_REPAYMENT_PERIOD_EMPTY = 999509;
	public static final int SSC_REPAYMENT_PERIOD_NUMERIC = 999510;
	public static final int SSC_SEC_MORTGAGE_SELECT1_EMPTY = 999511;
	public static final int SSC_SEC_MORTGAGE_SELECT2_EMPTY = 999512;
	public static final int SSC_OTHER_INSTITUTION_EMPTY = 999513;
	public static final int SSC_SECOND_LOAN_AMT_EMPTY = 999514;
	public static final int SSC_SECOND_LOAN_AMT_NUMERIC = 999515;
	public static final int SSC_SECOND_MORTGAGE_TENOR_EMPTY = 999516;
	public static final int SSC_SECOND_MORTGAGE_TENOR_NUMERIC = 999517;
	public static final int SSC_SECOND_INSTAL_AMT_EMPTY = 999518;
	public static final int SSC_SECOND_INSTAL_AMT_NUMERIC = 999519;
	public static final int SSC_PROPERTY_TYPE_EMPTY = 999520;
	public static final int SSC_PROPERTY_USAGE_EMPTY = 999521;
	public static final int SSC_PROPERTY_ADDRESS_EMPTY = 999522;
	public static final int SSC_EMPLOYMENT_TYPE_EMPTY = 999523;
	public static final int SSC_OTHER_EMPLOYMENT_TYPE_EMPTY = 999524;
	public static final int SSC_MONTHLY_INCOME_EMPTY = 999525;
	public static final int SSC_MONTHLY_INCOME_NUMERIC = 999526;
	public static final int SSC_MONTHLY_INCOME_ON_DEBT_NUMERIC = 999527;
	public static final int SSC_TEL_EMPTY = 999528;
	public static final int SSC_TEL_INVALID = 999529;
	public static final int SSC_BRANCH_EMPTY = 999530;
	public static final int SSC_MORTGAGE_LOAN_TERM_AND_CONDITION_UNCHECK = 999531;
	public static final int SSC_REPAYMENT_PERIOD_MAX = 999532;
	public static final int SSC_OCCUPATION_POSITION_EMPTY = 999533;
	public static final int SSC_PROPADDR_BUILD_COURT_STREET_EMPTY = 999534;
	public static final int SSC_PROPADDR_DISTRICT_EMPTY = 999535;
	public static final int SSC_OUTSTANDING_LOAN_AMT_DP = 999536;
	public static final int SSC_PURCHASE_PRICE_DP = 999537;
	public static final int SSC_LOAN_AMT_DP = 999538;
	public static final int SSC_REPAYMENT_PERIOD_DP = 999539;
	public static final int SSC_SECOND_LOAN_AMT_DP = 999540;
	public static final int SSC_SECOND_MORTGAGE_TENOR_DP = 999541;
	public static final int SSC_MONTHLY_INCOME_DP = 999542;
	public static final int SSC_MONTHLY_INCOME_ON_DEBT_DP = 999543;
	public static final int SSC_ORIGINAL_BANK_INVALID = 999544;
	public static final int SSC_PROPERTY_ADDRESS_INVALID = 999545;
	public static final int SSC_OCCUPATION_POSITION_INVALID = 999546;
	public static final int SSC_OTHER_EMPLOYMENT_TYPE_INVALID = 999547;
	public static final int SSC_EMAILADDR_INVALID = 999548;
	public static final int SSC_OTHER_INSTITUTION_INVALID = 999549;
	public static final int SSC_LOAN_AMT_MIN = 999550;
	public static final int SSC_APP_NAME_EMPTY = 999551;
	public static final int SSC_APP_TITLE_EMPTY = 999552;
	public static final int SSC_APP_SURNAME_INVALID = 999553;
	public static final int SSC_APP_GIVEN_NAME_INVALID = 999554;
	public static final int SSC_APP_ID_TYPE_EMPTY = 999555;
	public static final int SSC_APP_ID_NUM_EMPTY = 999556;
	public static final int SSC_APP_ID_NUM_INVALID = 999557;
	public static final int SSC_APP_DATE_EMPTY = 999558;
	public static final int SSC_APP_DATE_INVALID = 999559; 
	
	//SCR-CCD15019 
	public static final int SSC_BUSINESS_NATURE_INVALID = 999560;
	
	//SCR-CCD15102 - DSB Credit Card Application Form Enhancement
	public static final int SSC_SUPP_OTHER_RELATIONSHIP_EMPTY = 999561;
	public static final int SSC_SUPP_RESIDENTIAL_ADDR_EMPTY = 999562;
	public static final int SSC_SUPP_ADDR_BUILDING_OR_STREET_EMPTY = 999563;
	public static final int SSC_SUPP_ADDR_COUNTRY_EMPTY = 999564;
	public static final int SSC_SUPP_ADDR_DISTRICT_EMPTY = 999565;
	public static final int SSC_SUPP_ADDR_REGION_EMPTY = 999566;
	public static final int SSC_SUPP_CREDIT_LIMIT_EMPTY = 999567;
	public static final int SSC_SUPP_CREDIT_LIMIT_AMT_EMPTY = 999568;
	public static final int SSC_SUPP_CREDIT_LIMIT_AMT_INVALID = 999569;
	public static final int SSC_SUPP_CREDIT_LIMIT_AMT_ERROR = 999570;
	public static final int SSC_ACCOUNT_NO_EMPTY = 999571;
	public static final int SSC_ACCOUNT_NO_INVALID = 999572;
	public static final int SSC_AGE_INVALID = 999573;
	public static final int SSC_AGE_ERROR = 999574;
	public static final int SSC_SUPP_RELATIONSHIP_EMPTY = 999575;
	public static final int SSC_SUPP_AGE_INVALID = 999576;
	public static final int SSC_SUPP_AGE_ERROR = 999577;
	public static final int SSC_SUPP_CREDIT_LIMIT_AMT_INVALIDVAL = 999578;
	
	public static final int SSC_MFM_SELECT = 999600;
	public static final int SSC_MFM_PROMOTION = 999601;
	public static final int SSC_MFM_NO_CARD = 999602;
	public static final int SSC_MFM_ONLY_COUNT_MERCHANT = 999603;
	public static final int SSC_MFM_SELECT_MERCHANT = 999604;
	public static final int SSC_MFM_SELECT_IMAGE_NOT_LATEST = 999605;
	public static final int SCC_MFM_ENDED = 997629;  //PDM13587 (Suspend My Favorite Merchant)

	public static final int SSC_CREDIT_CARD_LOGIN_CC_INVALID = 999606;
	public static final int SSC_CREDIT_CARD_LOGIN_CC_INVALID_LEN = 999607;
	public static final int SSC_CREDIT_CARD_LOGIN_INPUT_CC = 999608;
	public static final int SSC_CREDIT_CARD_LOGIN_INPUT_CC_2 = 999609;
	public static final int SSC_CREDIT_CARD_LOGIN_CVV_INVALID = 999610;
	public static final int SSC_CREDIT_CARD_LOGIN_CVV_INVALID_LEN = 999611;
	public static final int SSC_CREDIT_CARD_LOGIN_HKID_INVALID = 999612;
	public static final int SSC_CREDIT_CARD_LOGIN_HKID_INVALID_LEN = 999613;
	
	public static final int SSC_CREDIT_CARD_THREE_TIME_RETRY = 999619;
	
	public static final int SSC_CREDIT_CARD_NOT_CONFIRM_T_AND_C = 999620;
	
	public static final int SSC_CREDIT_CARD_MORTGAGE_RENT_EMPTY = 999621;
	public static final int SSC_CREDIT_CARD_MORTGAGE_RENT_INVALID = 999622;

	public static final int SSC_CC_CASH_REBATE_REG_INVALID_LEN = 999650;
	public static final int SSC_CC_CASH_REBATE_REG_INVALID = 999651;
	public static final int SSC_CC_CASH_REBATE_REG_AGREE_UNCHECK = 999652;
	public static final int SSC_CC_CASH_REBATE_REG_DUPLICATE_REG = 999653;
    public static final int SSC_CC_CASH_REBATE_REG_DUPLICATE_REG_2011 = 999654; 
	//PDM11752 - Credit Card Cash Rebate Promotion
	public static final int SSC_CC_CASH_REBATE_PROMO_EXP = 999655; 
	
	public static final int SSC_CREDIT_CARD_MC_INVALID_CARD = 23018;
	public static final int SSC_CREDIT_CARD_MC_INVALID_ID_NO = 22295;
	public static final int SSC_CREDIT_CARD_MC_EXPIRED_CARD = 22493;
	public static final int SSC_CREDIT_CARD_MC_INVALID_CVV2_OLD = 22494;
	public static final int SSC_CREDIT_CARD_MC_INVALID_CVV2 = 22484;
	public static final int SSC_CREDIT_CARD_MC_INVALID_CARDHOLDER_STATUS = 22379;

	// DRD09025 - Securities Account Opening
	public static final int SSC_SEC_ACCT_OPEN_STAFF = 999701;
	public static final int SSC_SEC_ACCT_OPEN_TEMP_CUSTOMER = 999702;
	public static final int SSC_SEC_ACCT_OPEN_AML_CUSTOMER = 999703;
	public static final int SSC_SEC_ACCT_OPEN_INCORRECT_ID_TYPE = 999704;
	public static final int SSC_SEC_ACCT_OPEN_INCORRECT_AGE = 999705;
	public static final int SSC_SEC_ACCT_OPEN_INCORRECT_SCC = 999706;
	public static final int SSC_SEC_ACCT_OPEN_INCORRECT_MASTER_TNC = 999707;
	public static final int SSC_SEC_ACCT_OPEN_INCORRECT_RESIDENCE = 999708;
	public static final int SSC_SEC_ACCT_OPEN_AVAILABLE_SETT_ACCT = 999709;
    public static final int SSC_SEC_ACCT_OPEN_FAILURE_READ_AML = 999710;
    public static final int SSC_SEC_ACCT_OPEN_VULNERABLE_CUSTOMER = 999711;
    public static final int SSC_SEC_ACCT_OPEN_US_CUSTOMER = 999712;
    public static final int SSC_SEC_ACCT_OPEN_INCORRECT_INCOME_NET_WORTH = 999713;
	public static final int SSC_SEC_ACCT_OPEN_INCORRECT_AGE_2 = 999714;

	public static final int SSC_SEC_ACCT_OPEN_ACTIVE_ACC_EXIST = 999715;
	public static final int SSC_SEC_ACCT_OPEN_CLOSE_ACC_EXIST= 999716;
	public static final int SSC_SEC_ACCT_OPEN_DAY_END_BATCH = 999717;
	public static final int SSC_SEC_ACCT_ITRADE_ERROR = 999718;
	public static final int SSC_SEC_ACCT_HOST_ERROR = 999719;
	
	public static final int SSC_SEC_ACCT_SFC_PAGE_ERROR = 999720;
	public static final int SSC_SEC_ACCT_SFC_REGISTER_COMPANY_ERROR = 999721;
	public static final int SSC_SEC_ACCT_SENSITIVE_COMPANY_ERROR = 999722;
	public static final int SSC_SEC_ACCT_SENSITIVE_OCCUPTION_ERROR = 999723;
	public static final int SSC_SEC_ACCT_DK_CONFIRM_ERROR = 999724;
	public static final int SSC_SEC_ACCT_DK_AGREE_ITEM_ERROR = 999725;
	public static final int SSC_SEC_ACCT_DK_AGREE_SUBITEM_ERROR = 999726;

	// DRD11083 - Timeout Handling on Online Securities Account Opening
	public static final int SSC_SEC_ACCT_OPEN_OUTSIDE_SERVICE_HOUR = 999727;
	public static final int SSC_SEC_ACCT_OPEN_ITRADE_GENERIC_ERROR = 999728;
	// DRD13041 - validation check for address in p.5 start
	public static final int SSC_SEC_ACCT_OPEN_ADDR_EMPTY = 999729;
	// DRD13041 - validation check for address in p.5 end
	// OPD12002 - FATCA start
	public static final int SSC_SEC_ACCT_OPEN_FATCA_US_NATIONALITY = 999730;
	public static final int SSC_SEC_ACCT_OPEN_FATCA_US_DOC_ISSUE_COUNTRY = 999731;
	public static final int SSC_SEC_ACCT_OPEN_FATCA_CHAPTER4STATUS_US_PERSON = 999732;
	public static final int SSC_SEC_ACCT_OPEN_FATCA_CHAPTER4STATUS_RECALCITRANT = 999733;
	public static final int SSC_SEC_ACCT_OPEN_FATCA_NEW_CUST_WITH_INDICIA = 999734;
	public static final int SSC_SEC_ACCT_OPEN_FATCA_OLD_CUST_WITH_INDICIA= 999735;
	public static final int SSC_SEC_ACCT_OPEN_FATCA_PLACE_OF_BIRTH = 999736;
	// OPD12002 - FATCA end
	
	//SCR-DRD14058 START
	public static final int SSC_SEC_ACCT_OPEN_COUNTRY_AML_CHECK = 999737;
	public static final int SSC_SEC_ACCT_HIT_KEYWORD_CHECK = 999738;
	public static final int SSC_SEC_ACCT_UNACCEPTABLE_LIST_CHECK = 999739;
	public static final int SSC_SEC_ACCT_DATE_OPEN_CHECK = 999740;
	public static final int SSC_SEC_ACCT_OPEN_NAME_AML_CHECK = 999741;
	//SCR-DRD14058 END
	
	//SCR-DRD18022 / DRD17081 START
	public static final int SSC_SEC_ACCT_DATE_OPEN_CHECK_2 = 999742;
	public static final int SSC_SEC_ACCT_OPEN_TAX_CRIME_CUSTOMER = 999743;
	//SCR-DRD18022 / DRD17081 END
	
    // miscellaneous
    public static final int SSC_ACCT_NUM_DECODE_ERROR = 999901;
    public static final int SSC_ID_TYPE_DECODE_ERROR = 999902;
    public static final int SSC_FD_TERMS_DEF_MISMATCH = 999903;
    public static final int SSC_REQ_EMPTY_OR_INVALID = 999904;
    public static final int SSC_BOA_RESP_ERROR = 999905;
    public static final int SSC_INVALID_ACCT_TYPE = 999906;
    public static final int SSC_FILTER_NOT_FOUND = 999907;
    public static final int SSC_ACCT_DESC_NOT_FOUND = 999908; // cannot match acct_type and prod_sub_code in acct_desc table
    public static final int SSC_FUNCT_TYPE_NOT_SUPPORTED = 999909;
    public static final int SSC_TF_TXTYPE_NOT_SET = 999910;
    public static final int SSC_NO_AGENT_AVAILABLE = 999911;
    public static final int SSC_BRANCH_CODE_LOOKUP_ERROR = 999912;
	public static final int SSC_MAIL_SENDING_ERROR = 999913;
	public static final int SSC_CHANNEL_NOT_SUPPORTED = 999914;
    public static final int SSC_ACCT_NOT_IN_PICKLIST = 999915;
    public static final int SSC_NO_TX_RESUBMIT = 999916;
    public static final int SSC_DELETED_BANK_CODE = 999917;
    public static final int SSC_BENEFICIARY_RECORD_NOT_FOUND = 999918;
    public static final int SSC_STATISTIC_COUNT_RECORD_NOT_FOUND = 999919;//Add 20050928 for Tax Loan Oct 2005 (PDM05493)
    public static final int SSC_PARSE_DATE_ERROR = 999920;
	
	public static final int SSC_CUST_THREE_MONTH_NO_CC_STMT = 999921;
	public static final int SSC_CUST_SPEC_MONTH_NO_CC_STMT = 999922;
	public static final int SSC_CC_STMT_SYS_EXCEPTION = 999923;
	public static final int SSC_CUST_CC_SUPP_CARD_ONLY = 999924;

	public static final int SSC_QUESTIONNAIRE_EMPTY = 999925; 
	public static final int SSC_CONFIRM_UNCHECK = 999926;
	public static final int SSC_AGE_OUT_OF_RANGE = 999927;
	public static final int SSC_RISK_ASSESSMENT_TIMEOUT = 999928;

	public static final int SSC_ISC_AGREE_EMPTY = 999929;
	public static final int SSC_ISC_STUDENT_ID_EMPTY = 999930;
	public static final int SSC_ISC_YEAR_OF_GRADUATION_EMPTY = 999931;
	public static final int SSC_ISC_YEAR_OF_STUDY_EMPTY = 999932;
	public static final int SSC_ISC_UNI_NAME_EMPTY = 999933;
	public static final int SSC_ISC_UNI_ADDRESS_EMPTY = 999934;
	public static final int SSC_ISC_FACULTY_EMPTY = 999935;	
	public static final int SSC_ITC_POSITION_EMPTY = 999936;
	
	public static final int SSC_VIP_FORM_TITLE_EMPTY = 999937;
	public static final int SSC_VIP_FORM_NAME_EMPTY = 999938;
	public static final int SSC_VIP_FORM_CONTACT_EMPTY = 999939;
	public static final int SSC_VIP_FORM_BRANCH_EMPTY = 999940;
	public static final int SSC_VIP_FORM_CONTACT_ENIGHT_DIGITS = 999941;
	public static final int SSC_VIP_FORM_CONTACT_INVALID = 999942;
	public static final int SSC_VIP_FORM_SUBMIT_ALREADY = 999943;
	public static final int SSC_VIP_FORM_EXCESS_LIMIT = 999944;
	public static final int SSC_VIP_NO_PERMISSION = 999945;

	public static final int SSC_IAC_DATE_RANGE_EXCEED_MAX = 999946;
	public static final int SSC_CA_DATE_RANGE_EXCEED_MAX = 999947;
    public static final int SSC_DATE_FORM_FROM_DATE_ERROR = 999948;
    public static final int SSC_DATE_FORM_TO_DATE_ERROR = 999949;
    public static final int SSC_DATE_FORM_FROM_TO_DATE_ERROR = 999950;
    public static final int SSC_DATE_FORM_INVALID_DATES_ERROR = 999951;
	
	public static final int SSC_DATE_RANGE_OUT_OF_RANGE = 999956;
	
	public static final int SSC_CPS_NO_PERMISSION = 999960;
	public static final int SSC_CPS_DUPLICATE_REC = 999961;
	public static final int SSC_CPS_NO_ACCOUNT = 999962;
	public static final int SSC_CPS_ACCEPT_TC_1 = 999963;
	public static final int SSC_CPS_SELECT_ACCT = 999964;
	public static final int SSC_CPS_ACCEPT_TC_2 = 999965;
	public static final int SSC_SERVICE_UNAVAILABLE = 999966;

    
    public static final int SSC_UNI_ABBR_ERROR = 999970; 

    public static final int SSC_CARD_PHONE_NUMBER_NOT_AVAIL = 22503;
    public static final int SSC_CARD_LAST_CVV_NOT_AVAIL = 22504;
    public static final int SSC_CARD_PHONE_INVALID = 23139;
	
	public static final int DK_TRAINING_CONFIRM_ERROR = 999974;
	public static final int DK_TRAINING_VIDEO_NOT_WATCHED = 999975;
	public static final int DK_EBANKING_ERROR = 999976;
	public static final int DK_CSS_ERROR = 999977;
	
	public static final int SSC_NO_INVEST_ACCOUNTS = 999978;
	
	public static final int SSC_MT_PIN_CREATION_MSG = 999979;
	public static final int SSC_MT_PIN_RESET_MSG = 999980;
	public static final int SSC_MT_CREATION_ERR01 = 997020;
	public static final int SSC_MT_CREATION_ERR02 = 997021;

		
	public static final int SSC_EDU_LEVEL_EMPTY = 999981;
	public static final int SSC_RISK_ASSESS_EMPTY = 999982;
	public static final int SSC_RISK_ASSESS_ZERO = 999983;
	public static final int SSC_DERI_KNOWLEDGE_DASH = 999984;
	public static final int SSC_INVALID_DOB = 999985;

	public static final int SSC_INVALID_ADDITIONAL_FIELD = 999986;

	public static final int SSC_FUND_SUBSCRIBE_RISK_CONFIRM_UNCHECK = 999987;	
	public static final int SSC_FUND_SUITABILITY_UNMATCH = 999988; 
	public static final int SSC_FUND_SUITABILITY_UNCHECK = 999989;
	public static final int SSC_FUND_INVEST_ACCOUNT_NOT_SELECT = 999991;
	public static final int SSC_FUND_SETTLE_ACCOUNT_NOT_SELECT = 999990;
	public static final int SSC_FUND_MIN_AMOUNT_NOT_INPUT = 999992;
	public static final int SSC_FUND_CODE_NOT_FOUND = 999993;
	public static final int SSC_FUND_NOT_CHOSEN = 999994;
	public static final int SSC_FUND_NOT_SELECT = 999995;
	public static final int SSC_FUND_NOT_INPUT = 999996;
	public static final int SSC_FUND_NOT_FOUND = 999997;
	public static final int SSC_NO_SETTLE_ACCT_MATCHED_CCY = 999998;

	public static final int SSC_CANNOT_CREATE_SEM_RECORD = 997004;
	public static final int SSC_CANNOT_HOLD_FUND = 997005;
	public static final int SSC_CANNOT_SUBSCRIBE_IN_HI_TRUST = 997006;
	public static final int SSC_DERI_KNOWLEDGE_UNMATCH = 997007;
	public static final int SSC_REDEEM_UNIT_EMPTY = 997008;
	public static final int SSC_REDEEM_UNIT_INVALID = 997009;
	public static final int SSC_SETTLE_CCY_EMPTY = 997010;
	public static final int SCC_REDEEM_OPTION_EMPTY = 997011;
	public static final int SSC_CANNOT_REDEEM_IN_HI_TRUST = 997012;
	public static final int SSC_DERI_KNOWLEDGE_DECLARATION_EMPTY = 997013;
	public static final int SSC_RISK_LEVEL_UNMATCH = 997014;
	public static final int SSC_SETTLE_ACCOUNT_BALANCE_NOT_ENOUGH = 997015;
	public static final int SSC_SETTLE_ACCOUNT_BALANCE_NOT_ENOUGH_NO_OTHERS = 997016;
	public static final int SSC_DECLARATION_NOT_CONFIRMED = 997017;
	public static final int SSC_REDEEM_SETTLE_AC_EMPTY = 997018;
	public static final int SSC_REDEEM_CCY_LIST_EMPTY = 997019;
	public static final int SSC_REDEEM_UNIT_EXCEED = 997022;
	public static final int SSC_IPO_FUND_NOT_AVAILABLE = 997120;
	
	//WMD13100  iBond/Sovereign Bonds
	public static final int SSC_BOND_NOT_FOUND = 998901;
	public static final int SSC_BOND_NO_HKID = 998902;
	public static final int SSC_BOND_NO_INVEST_ACCT = 998903;
	public static final int SSC_BOND_NO_SETTLE_ACCT_MATCHED_CCY = 998904;
	public static final int SSC_BOND_IS_TYPHOON = 998905;
	public static final int SSC_BOND_SUITABILITY_UNMATCH = 998907;
	public static final int SSC_BOND_SUBSCRIBE_CONFIRM1_UNCHECK=998908;
	public static final int SSC_BOND_SUBSCRIBE_CONFIRM2_UNCHECK=998909;
	public static final int SSC_BOND_SUBSCRIBE_CONFIRM3_UNCHECK=998910;
	public static final int SSC_BOND_SUBSCRIBE_CONFIRM4_UNCHECK=998911;
	public static final int SSC_BOND_DUPLICATE_ORDERS_CHECK=998912;
	public static final int SSC_BOND_CONFIRM_FAILED=998913;
	public static final int SSC_BOND_SUBSCRIBE_RISK_CONFIRM_UNCHECK=998914;
	public static final int SSC_BOND_AMOUNT_NOT_INPUT=998915;
	public static final int SSC_BOND_LESS_MIN_AMOUNT_INPUT=998916;
	public static final int SSC_BOND_BOTH_TO_SIGIN=998917;
	public static final int SSC_BOND_SAME_ACCT=998918;
	public static final int SSC_BOND_INVEST_ACCT_PRIMARY=998920;
	public static final int SSC_BOND_SETTLE_ACCOUNT_NOT_ENOUGH=998921;
	public static final int SSC_BOND_SETTLE_ACCOUNT_NOT_MULITIPLES=998922;
	public static final int SSC_BOND_INVEST_ACCOUNT_NOT_SELECT=998923;
	public static final int SSC_BOND_ENQUIRY_NO_RECORD=998924;
	public static final int SSC_BOND_PERIOD_END=998925;
	public static final int SSC_BOND_REJECT_HOLD_CODE_EXIST=998926;
	public static final int SSC_BOND_HOLD_FUND_FAILED=998927;
	public static final int SSC_BOND_ORDER_SUBMISSION_FAILED=998928;
	public static final int SSC_BOND_RELEASE_HOLD_FUND_FAILED=998929;

	//WMD14137 Fatca checking begin
	public static final int SSC_FATCA_REJECT_ACCT_HOLDER = 998906;
	public static final int SSC_FATCA_REJECT_APPLICANT =998919;
	//WMD14137 Fatca cheking end
	
	// PDM11365 PDF E-STATEMENT
	public static final int PDF_ESTMT_TRANSMIT_ERROR = 997023;
	public static final int PDF_ESTMT_ERROR = 997024;
	// PDM11365 PDF E-STATEMENT
	public static final int SSC_CONNECTION_ERROR = 997025;
	public static final int SSC_HITRUST_CUT_OFF_TIME_MISSING_ERROR = 997026;
	public static final int SSC_PAYT_NREG_OR_EXCEED_12_MTH = 997027;
	public static final int SSC_ADD_HIGH_RISK_NOT_REG = 997028;
	public static final int SSC_ADD_HR_FLAG_NOT_ALLOW = 997029;
	public static final int SSC_SEC_ACCT_OPEN_ACCT_TYPE_NOT_ALLOW = 997030;
		
	// WMD11067 Online CLPD
	public static final int SCC_NOT_TRADING_HOUR = 997031;
	public static final int SCC_NO_VALID_SETTLEMENT_ACCOUNT = 997032;
	public static final int SCC_NO_VALID_SEM_RECORD = 997033;
	public static final int SCC_INVALID_RTL = 997034;
	public static final int SCC_IS_FTB = 997035;
	public static final int SCC_CLPD_WS_ERROR = 997036;
	public static final int SSC_RISK_ASSESS_JOINT_INVALID = 997037;
	public static final int SCC_CHECKBOX_NOT_CHECKED = 997038;
	public static final int SCC_RTL_PRR_NOT_MATCH = 997039;
	public static final int SCC_NOT_SUITABLE = 997040;
	public static final int SCC_RATE_CHANGED = 997041;
	public static final int SCC_OPT_OUT_PICOP = 997042;
	public static final int SSC_SETTLE_ACCT_NOT_CHOSEN = 997043;
	public static final int SCC_SUITABILITY_Q_NOT_ANSWERED = 997044;
	public static final int SCC_CCY_NOT_CHOSEN = 997045;
	public static final int SCC_RATE_TYPE_NOT_SELECTED = 997046;
	public static final int SCC_STD_ALT_CCY_NOT_SELECTED = 997047;
	public static final int SCC_STD_ALT_TENOR_NOT_SELECTED = 997048;
	public static final int SCC_SPEC_ALT_CCY_NOT_SELECTED = 997049;
	public static final int SCC_SPEC_ALT_TENOR_NOT_SELECTED = 997050;
	public static final int SCC_INVALID_CONVERSION_RATE = 997051;
	public static final int SCC_STRIKE_NOT_AVAILABLE = 997052;
	public static final int SCC_DEP_EXCEED_MAX = 997053;
	public static final int SCC_DEP_BELOW_MIN = 997054;
	public static final int SCC_NO_INTEREST_AVAILABLE = 997055;
	public static final int SCC_INSUFFICIENT_FUND = 997056;
	public static final int SCC_INVALID_DEP_AMT = 997057;
	public static final int SCC_TRADING_SUSPEND = 997058;
	public static final int SCC_CLPD_TYPHOON = 997059;
	public static final int SCC_NEED_PICOP = 997060;
	public static final int SSC_CLPD_RISK_ASSESS_EMPTY = 997061;
	public static final int SSC_CLPD_RISK_ASSESS_ZERO = 997062;
	public static final int SSC_CLPD_CANNOT_HOLD_FUND = 997063;
	public static final int SSC_CLPD_CANNOT_CREATE_SEM = 997064;
	public static final int SSC_CLPD_PLACE_ORDER_ERROR = 997065;
	public static final int SCC_SUITABILITY_Q1_NOT_ANSWERED = 997066;
	public static final int SCC_SUITABILITY_Q2_NOT_ANSWERED = 997067;
	public static final int SCC_SUITABILITY_Q3_NOT_ANSWERED = 997068;
	public static final int SCC_SUITABILITY_Q4_NOT_ANSWERED = 997069;
	public static final int SCC_INVOLVE_TRADING_Q_NOT_ANSWERED = 997070;
	public static final int SCC_RELEASE_HOLD_FUND_FAIL = 997072;
	//DRD12083
	public static final int SSC_SEC_ACCT_OPEN_SERVICE_SUSPEND = 997073;
	public static final int SSC_CLPD_ENQUIRY_ERROR = 997074;
	// end WMD11067
	
	public static final int SSC_SEC_ACCT_INVALID = 997077;
	public static final int SSC_CUST_NAME_INVALID = 997078;
	public static final int SSC_HSI_INVALID = 997079;
	public static final int SSC_MOBILE_NO_INVALID = 997080;
	public static final int SSC_PROMO_EMAIL_INVALID = 997081;        
	public static final int SSC_MORE_THAN_THREE_REG = 997082;
	public static final int SSC_RAND_NUM_GEN_ERR = 997083;
	public static final int SSC_WEBPIN_NULL_ERR = 997075;
	public static final int SSC_WEBPIN_NONZERO_ERR = 997076;

	public static final int SCC_SCC_FD_INSTRUCTION_ONLY = 997071;

	
	//SCR-OPC12002 Start
	public static final int SSC_NOT_IACCOUNT_ERR = 997084;
	public static final int SSC_NOT_IN_CN_LIST = 997085;
	public static final int SSC_NO_REG_CN_ACCT = 997086;
	//SCR-OPC12002 End
	
	// WMD12038
	public static final int SSC_SUITABILITY_Q5_NOT_ANSWERED = 997087;
	// WMD12038
	
	
	//SCR-PDM12676 Ploan Mobile Form
	public static final int SSC_INPUT_LENGTH_TOO_LONG = 997088; 
	public static final int SSC_CONTACT_NUM_INVALID = 997089;
	public static final int SSC_LOAN_AMOUNT_EMPTY = 997090;
	public static final int SSC_LOAN_AMOUNT_INVALID = 997091;
	public static final int SSC_LOAN_AMOUNT_TOO_SMALL = 997092;
	public static final int SSC_REPAYMENT_TENOR_EMPTY = 997093;
	public static final int SSC_AGREEMENT_UNCHECK = 997094;
	//SCR-PDM12676 Ploan Mobile Form
	
	//PDM12658 PLoan Form Update
	public static final int SSC_HAS_OTHER_NAME_EMPTY = 999967;
	public static final int SSC_OTHER_NAME_EMPTY = 999968;
	public static final int SSC_IS_PERMANENT_ADDR_EMPTY = 999969;
	
	//PDM12270
	public static final int SSC_APPLET_REQUIRED_ERR = 997096;
	public static final int SSC_WEBPIN_REQUIRED_ERR = 997095;
	public static final int SSC_EK_INVALID_PWD_FORMAT = 997098;
	public static final int SSC_WEBPIN_REQUIRED_ERR_KID = 997099;
	public static final int SSC_LANDING_MSG_CAT1 = 997100;
	public static final int SSC_LANDING_MSG_CAT2 = 997101; 
	public static final int SSC_LANDING_MSG_CAT3 = 997102;
	public static final int SSC_LANDING_MSG_CAT4 = 997103; 
	public static final int SSC_IS_NEW_NEW_CUSTOMER = 999973;
	
	// CC Apply Form
	public static final int SSC_CARD_GIFT_EMPTY = 997097;
	
	// PDM12829 Alipay Project
	public static final int SSC_NO_MOBILE_PHONE = 997104;
    public static final int SSC_NO_CHANGE_TO_ALIPAY_LIST = 997107;
    public static final int SSC_NO_VALID_ACCT_FOR_ALIPAY = 997108;

    // PDM12237 Online Document Submission
    public static final int SSC_INVALID_PRODUCT = 997105;
    public static final int SSC_INVALID_CHANNEL = 997106;
    public static final int SSC_INVALID_CC_PRODUCT = 997109;
    public static final int SSC_DOC_SUB_INVALID_HKID = 997110;
    public static final int SSC_DOC_SUB_INVALID_PHONE = 997111;
    public static final int SSC_DOC_SUB_INVALID_EMAIL = 997112;
    public static final int SSC_DOC_SUB_INVALID_NAME = 997113;
    public static final int SSC_DOC_SUB_INVALID_BRANCH = 997114;
    public static final int SSC_DOC_SUB_INVALID_FILE_TYPE = 997115;
    public static final int SSC_DOC_SUB_EXCEED_MAX_SIZE = 997116;
    public static final int SSC_VALIDATE_CAPTCHA_ERROR = 997117;
    public static final int SSC_CAPTCHA_FAIL = 997118;
    public static final int SSC_DOC_SUB_ID_TYPE_EMPTY = 997121;
    public static final int SSC_DOC_SUB_INVALID_CARD_NO = 997122;
    public static final int SSC_DOC_SUB_INVALID_REFERENCE = 997629;
	
	//WMD13023 RAQ Enhancement
    public static final int SSC_RISK_ASSESS_WRONG_SEM = 997123;
    public static final int SSC_RISK_ASSESS_WRONG_RAQ = 997124;
    public static final int SSC_RISK_ASSESS_OTHER = 997125;
    public static final int SSC_RISK_ASSESS_TIME_LAG = 997126;
	public static final int SSC_SUITABILITY_Q6_NEEDED = 997127;
	
	//Ebpp Jack Wong Begin 
	public static final int SSC_ICL_PAYABLE = 997128;
	public static final int SSC_EPS_PAYABLE = 997129;
	public static final int SSC_EPS_BILL_TYPE_NOT_PAYABLE = 997130;
	public static final int SSC_ICL_BILL_TYPE_NOT_PAYABLE = 997131;
	public static final int SSC_CURRENCY_NOT_PAYABLE = 997132;
	public static final int SSC_INVALID_DONOR_NAME = 997133;
	public static final int SSC_UNKNOWN_CLEAR_HOUSE = 997134;
	public static final int SSC_UNKNOWN_ICL_MERCHANT_OR_BILL_TYPE = 997135;
	public static final int SSC_UNKNOWN_ICL_ACCT_NO = 997136;
	public static final int SSC_MERCHANT_CAT_REQUIRED = 997137;
	public static final int SSC_MERCHANT_REQUIRED = 997138;
	public static final int SSC_ENROL_BILL_OWNER_NAME_REQUIRED = 997139;
	public static final int SSC_ENROL_BILL_SUBSCRIPTION_CODE_REQUIRED = 997140;
	public static final int SSC_ENROL_BILL_UNKNOWN_TEMPLATE_ID = 997141;
	public static final int SSC_ENROL_BILL_PARTIAL_ID_REQUIRED = 997142;
	public static final int SSC_ENROL_BILL_PARTIAL_ID_INVALID = 997143;
	public static final int SSC_ENROL_BILL_DOBY_REQUIRED = 997144;
	public static final int SSC_ENROL_BILL_DOBM_REQUIRED = 997145;
	public static final int SSC_INVALID_INSTRUCTION_SCHEDULE_PAYMENT = 997146;
	public static final int SSC_INVALID_CURRENCY = 997147;
	public static final int SSC_SESSION_OBJ_NULL_POINTER = 997148;
	public static final int SSC_INVALID_INSTRUCTION_RECURING_PAYMENT = 997149;
	public static final int SSC_ENROL_NOT_AVAILDABLE_DUE_TO_INVALID_MERCHANT = 997150;
	public static final int SSC_ENROL_NOT_AVAILDABLE_DUE_TO_INVALID_BILL_TYPE = 997151;
	public static final int SSC_ENROL_NOT_AVAILDABLE_DUE_TO_ENROLMENT_NOT_FOUND = 997152;
	public static final int SSC_ENROL_NOT_AVAILDABLE_DUE_TO_RECORD_IS_ALREADY_EXIST = 997153;
	public static final int SSC_ENROL_NOT_AVAILDABLE_DUE_TO_INVALID_ICL_MERCHANT_CODE_FORMAT = 997154;
	public static final int SSC_ENROL_BILL_DOB_NOT_MATCH = 997155;
	public static final int SSC_ENROL_BILL_ID_NOT_MATCH = 997156;
	public static final int SSC_ENROL_DB_UPDATE_ERROR = 997157;
	public static final int SSC_INVALID_DSB_BANK_CODE = 997158;
	public static final int SSC_EBPS_REF_NUM_REQUIRED = 997159;
	public static final int SSC_ENROL_NOT_AVAILDABLE_DUE_TO_ENROLID_NOT_FOUND = 997160;
	public static final int SSC_ENROL_ID_REQUIRED = 997161;
	public static final int SSC_CANNOT_DEL_MYBILLLIST_DUE_TO_ENROLMENT_EXISTS_OR_OS_INSTR_OCCUR = 997162;
	public static final int SSC_DEL_ONLY_ONE_HIGH_RISK_BILL = 997163;
	public static final int SSC_CANNOT_DEL_MYBILLLIST = 997164;
	public static final int SSC_INVALID_INSTRUCTION_MONTHLY_RECURRING_PAYMENT = 997165;
	public static final int SSC_INVALID_INSTRUCTION_DUE_DATE_RECURRING_PAYMENT = 997166;
	public static final int SSC_INVALID_INSTRUCTION_NON_FURTURE_NEXT_EXEC_DATE = 997167;
	public static final int SSC_INVALID_INSTRUCTION_INVALID_RANGE_OF_DATE = 997168;
	public static final int SSC_PAID_DUE_DAY_RECURRING_ALREADY_EXISTS = 997169;
	public static final int SSC_INVALID_INSTRUCTION_DUE_TO_ANY_AVAILABLE_EXE_DATE_TO_PAY = 997170;
	public static final int SSC_INBOX_ALERT_MESSAGE = 997171;
	public static final int SSC_INVALID_DONAR_ID = 997172;
	public static final int SSC_INVALID_DONAR_RCPT = 997173;
	public static final int SSC_DONAR_ID_REQUIRED = 997174;
	public static final int SSC_DONAR_EMAIL_REQUIRED = 997175;
	public static final int SSC_ENROL_BILL_INVALID_DOB = 997176;
	public static final int SSC_EBPP_ERR_RET_NO_ACCT = 997177;	
	public static final int SSC_EBPP_ERR_RET_NAME_UNMATCHED = 997178;	
	public static final int SSC_EBPP_ERR_RET_INSUFFICIENT= 997179;	
	public static final int SSC_EBPP_ERR_RET_OTHER = 997180;	
	public static final int SSC_EBPP_ERR_ORI_BANK_NO = 997181;	
	public static final int SSC_EBPP_ERR_ORI_BRANCH_NO= 997182;
	public static final int SSC_EBPP_ERR_TRA_CODE = 997183;	
	public static final int SSC_EBPP_ERR_AMT_FIELD = 997184;
	public static final int SSC_EBPP_ERR_MERCHANT_ID = 997185;
	public static final int SSC_EBPP_ERR_BILL_TYPE = 997186;
	public static final int SSC_EBPP_ERR_MERCHANT_BANK_ACCT = 997187;
	public static final int SSC_EBPP_ERR_BILL_ACCT_NO = 997188;
	public static final int SSC_EBPP_ERR_PAYT_REF = 997189;	
	public static final int SSC_ENROL_EDONATE_RECEIPT = 997190;
	public static final int SSC_ENROL_ANONYMOUS_DONATE_FLAG = 997191;
	public static final int SSC_ENROL_ORG_ACCT_NO = 997192;
	public static final int SSC_EBPP_INVALID_BILL_NO = 997193;
	public static final int SSC_DEL_BILL_FOR_HIGH_RISK_BILL_MERCHANT = 997194;
	public static final int SSC_BILL_OWNER_NAME_MISMATCH = 997195;
	public static final int SSC_SUBSCRIPTION_CODE_MISMATCH = 997196;
	public static final int SSC_BANKSIDE_ENROLMENT_EXIST = 997197;
	public static final int SSC_CANNOT_CREATE_INSTR_DUE_TO_OS_INSTR = 997198;
	public static final int SSC_INVALID_BILL_NO_FOR_2FA = 997199;
	public static final int SSC_EPS_CURRENCY_CONFLICT = 995000;
	public static final int SSC_ADD_HIGH_RISK_NOT_REG_EBPP = 999979;
	//EBPP Phase 2 enhancement
	public static final int SSC_EBILL_PAYT_AMT_LESS_THAN_MIN_PAYT_AMT = 910000;
	public static final int SSC_EBILL_PAYT_AFT_DUE_DATE = 910002;
	public static final int SSC_EBILL_NOT_ALLOW_FOR_PARTIAL_PAID = 910003;
	//Ebpp Jack Wong End 20131007
	//EBPP Phase 2.5 enhancement Begin
	public static final int SSC_PAYER_NAME_REQUIRED = 910004;
	public static final int SSC_PAYER_NAME_INVALID = 910005;
	public static final int SSC_PAYER_RCPT_EMAIL_REQUIRED = 910006;
	public static final int SSC_PAYER_RCPT_EMAIL_INVALID = 910007;
	public static final int SSC_CSV_NO_OF_REC_OVR_MAX = 910008;
	public static final int SSC_CSV_NO_OF_COLUMN_NOT_MATCH = 910009;
	public static final int SSC_UNKNOWN_CSV_COLUMN_TYPE = 910010;
	public static final int SSC_CSV_COLUMN_TYPE_NOT_MATCH = 910011;
	public static final int SSC_CSV_COLUMN_CONTENT_OVR_MAX_SIZE = 910012;
	public static final int SSC_CSV_COLUMN_CONTENT_OVR_MIN_SIZE = 910013;
	public static final int SSC_CHECKER_MAKER_ARE_THE_SAME_PERSON = 910014;
	public static final int SSC_NO_OF_PARAM_NOT_MATCH_WITH_CONTENT = 910015;
	public static final int SSC_BLAST_OUT_DATE_EXPIRED = 910016;
	public static final int SSC_INVALID_CSV_FILE_FORMAT = 910018;
	public static final int SSC_INVALID_INWARD_FILE_FORMAT = 910019;
	public static final int SSC_INCORRECT_CSV_SEPERATOR = 910020;
	public static final int SSC_NO_NEED_TO_UPD_BP = 910021;
	public static final int SSC_INVALID_VERSION_NO = 910022;
	public static final int SSC_INVALID_PROCESS_DATE = 910023;
	public static final int SSC_INVALID_BATCH_DATE = 910024;
	public static final int SSC_INVALID_BANK_CODE = 910025;
	public static final int SSC_INVALID_BLAST_INBOX_CHECKER = 910026;
	public static final int SSC_DUPLICATE_CUSTOMERS_IN_CUSTOMER_LIST = 910027;
	public static final int SSC_CIPER_ID_NOT_FOUND = 910028;
	//EBPP Phase 2.5 enhancement End
	//EBPP Phase 3.0 Begin
	public static final int JSP_ICL_BILL_OWNER_EMAIL_ADDR = 910029;
	public static final int JSP_INVALID_DONOR_ID = 910030;
	public static final int SSC_INVALID_DONOR_INFO = 910031;
	public static final int JSP_INVALID_DONOR_ID_OR_NAME = 910032;
	public static final int JSP_EMPTY_ICL_BILL_OWNER_EMAIL_ADDR = 910034;
	public static final int JSP_INVALID_PRES_REF_NUM = 910033;
	public static final int JSP_EMPTY_PRES_REF_NUM = 910035;
	public static final int JSP_EMPTY_DONOR_ID = 910036;
	public static final int JSP_DEBIT_CURRENCY_NOT_MATCH = 910037;
	//EBPP Phase 3.0 End
	
	//2FA
	public static final int SSC_TOKEN_NO_TOKEN = 997600;
	public static final int SSC_TOKEN_IS_ACTIVE = 997601;
	public static final int SSC_TOKEN_TC_ACCEPT = 997602;
    public static final int SSC_TOKEN_NO_TAGNO = 997603;
	public static final int SSC_TOKEN_WRONG_TAGNO = 997604;
	public static final int SSC_TOKEN_NO_SECCODE = 997605;
	public static final int SSC_TOKEN_WRONG_SECCODE = 997606;
	public static final int SSC_TOKEN_WRONG_TAGNO_LOG = 997607;
    public static final int SSC_TOKEN_WRONG_SECCODE_LOG = 997608;
    public static final int SSC_TOKEN_RESYC_FAIL_LOG = 997609;
    public static final int SSC_TOKEN_SAME_STATUS_LOG = 997610;
    public static final int SSC_TOKEN_RESYC_SUCC_LOG = 997611;
    public static final int SSC_TOKEN_LOCK_TKN_ERROR = 997612;
	public static final int SSC_TOKEN_NO_ACTIVE_TOKEN = 997613;
	public static final int SSC_TOKEN_SAME_STATUS = 997614;
	public static final int SSC_TOKEN_RESYNC_FAIL = 997615;
	public static final int SSC_TOKEN_NO_ACTIVE_MSS = 997616;
	public static final int SSC_TOKEN_MORE_30_MSS = 997617;
    public static final int SSC_TOKEN_NO_RESYNCCODE = 997618; 
    public static final int SSC_ECERT_HAS_TKN = 997619;
    public static final int SSC_ECERT_REG_NOT_ALLOW = 997620;
    public static final int SSC_TOKEN_SAME_STATUS_LOG_DE = 997622;
    public static final int SSC_TOKEN_LOCK_TKN_ERROR_LOGIN = 997623;
    public static final int SSC_TOKEN_WRONG_SECCODE_LOGIN = 997624;
    public static final int SSC_TOKEN_NO_SECCODE_LOGIN = 997625;
	public static final int SA_SERVER_ERROR = 997626;
    public static final int SSC_TOKEN_OTP_SUCC_LOG = 997627;




    //SCR-PDM12706
    public static final int SSC_CARDLINK_CUSTOMER_NUM_NOT_FOUND = 997621;
    
    
    //ITD 16001 start
    public static final int SCC_ENTER_SMSOTP_ERROR_MAX = 998700;
    public static final int SCC_NO_MOBILE_AND_ACTIVE_TOKEN = 998701;
    //ITD 16001 end
    
    //SCR-PDM12540
    public static final int SSC_FT_REMITTANCE_NON_REG_DAILY_LIMIT_EXCEEDED = 997628;
    //SCR-PDM12540-2
    public static final int SSC_BILL_PAY_HIGH_RISK_DAILY_LIMIT_EXCEEDED = 997630;
    public static final int SSC_BILL_PAY_NON_HIGH_RISK_DAILY_LIMIT_EXCEEDED = 997631;
    public static final int SSC_BILL_PAY_HIGH_RISK_DAILY_LIMIT_ZERO = 997632;
    public static final int SSC_BILL_PAY_NON_HIGH_RISK_DAILY_LIMIT_ZERO = 997633;
    //SCR-PDM12540-3
    public static final int SSC_FT_LIMIT_INVALID = 997634;
    public static final int SSC_HRISK_LIMIT_INVALID = 997635;
    public static final int SSC_NHRISK_LIMIT_INVALID = 997636;
    public static final int SSC_DAILY_LIMIT_INVALID = 997637;
    public static final int SSC_ALL_LIMIT_INVALID = 997638;
    
    //SAR WMD15053 - Revise the message/screen regarding watching DK video for online CLPD
    public static final int SSC_CLPD_DK_ERROR = 997639;
    
    //Payroll Services message
    public static final int SSC_PAYROLL_AVAILABLE_TIME = 997701; //Access Online Payroll function after the Service Available time
    public static final int SSC_PAYROLL_FUNCTION_NOT_FALL = 997702; //Access Online Payroll function if NOT Fall in the Payroll promotion period
    public static final int SSC_PAYROLL_DO_NOT_MATCH_CIF = 997703; //Customer's information do not match CIF database record.
    public static final int SSC_PAYROLL_CUSTOMER_DO_NOT_HAVE_SINGLE_NAME = 997704; //Customer do NOT have single name or either to sign i-AC
    public static final int SSC_PAYROLL_ACCOUNT_DO_NOT_HAVE_SINGLE_NAME = 997705; //Customer input account number is NOT a single name or either to sign i-AC in Bank record
    public static final int SSC_PAYROLL_INVALID_MOBILE = 997706; //Customer do NOT have valid mobile phone number in CIF
    public static final int SSC_PAYROLL_ALREADY_HAVE_PAYROLL = 997707; //Customer already have Payroll Services Application already 
    public static final int SSC_PAYROLL_HIT_OCCUPATION = 997708; //Occupation of customer hit the list of occupation that is not applicable to Payroll service. 
    public static final int SSC_PAYROLL_ATM_ALREADY_ENROLLED = 997709; //Customer input ATM Card Number already enrolled Octopus application
    public static final int SSC_PAYROLL_ATM_NOT_VALID = 997710; //Customer input ATM Card Number is NOT Valid / Not applicable to apply Octopus 
    public static final int SSC_PAYROLL_INVALID_EMAIL = 997711; //Invalid Email Address provided
    public static final int SSC_PAYROLL_AMOUNT_NOT_FULFIL = 997712; //Input Salary credit amount not fulfil the minimum credit requirement
    public static final int SSC_PAYROLL_HOLDING_AN_NORMAL_ACCOUNT = 997713; //Customer choose to apply for Octopus ATM Cards (Holding an normal i-Account ATM Card only)
    public static final int SSC_PAYROLL_NOT_APPLICABLE_TO_APPLY_OCTOPUS = 997714; //The ATM Card Number being inputted is not available for applying for Dah Sing Octopus App Card. Please input other ATM card number or call our Customer Service Hotline at 2828 8000 during office hours for enquiries. 
    public static final int SSC_PAYROLL_IS_APPLICABLE_TO_INTEGRATED_ACCOUNT = 997715; //Sorry, Dah Sing Octopus App Card is applicable to Integrated Account ATM Card only  (exclude Hello Kitty / Doraemon i-Account ATM Card). Please input again. 
    public static final int SSC_PAYROLL_CAN_NOT_CONTINUE = 997716; //Customer has no current account, can not continue.
    //log#811
    public static final int SSC_PAYROLL_CUSTOMER_DO_NOT_HAVE_SINGLE_NAME_WITHOUT_HYPERLINK = 997717; //Customer do NOT have single name or either to sign i-AC
    public static final int SSC_PAYROLL_INVALID_MOBILE_WITHOUT_HYPERLINK = 997718; //Customer do NOT have valid mobile phone number in CIF
    public static final int SSC_PAYROLL_HIT_OCCUPATION_WITHOUT_HYPERLINK = 997719; //Occupation of customer hit the list of occupation that is not applicable to Payroll service.
    
    //Online Appointment
    public static final int SSC_YBPRE_OUTOF_SERVICE_HOUR = 997725;	//Out of Online Appointment Service Hour
    public static final int SSC_YBPRE_MSG_UPGRADE_TO_YB = 997726;	//Please click here to upgrade to YOU Banking.
    public static final int SSC_YBPRE_EXISTS_VIP_ACCT = 997727;		//You already had Dah Sing VIP i-Account.
    
    //Upgrade to YBanking (YBanking phase2)
    public static final int SSC_UP2YB_SUPPRESS_MCMSG_FAIL = 997729;	//Account upgrade successful but "suppress paper statement flag" update process failed
    public static final int SSC_UP2YB_AVAILABLE_TIME = 997730;	//Access Upgrade to YOU Banking function after the service available time
    public static final int SSC_UP2YB_DO_NOT_MATCH_CIF = 997731; //Customer's information do not match CIF database record.
    public static final int SSC_UP2YB_CUSTOMER_DO_NOT_HAVE_SINGLE_NAME = 997732; //Customer do not have single name i-Account or without Dah Sing e-Banking Services
    public static final int SSC_UP2YB_INVALID_MOBILE = 997733; //Customer do not have valid mobile phone number in CIF
    public static final int SSC_UP2YB_INVALID_ATMCARD = 997734; //Customer do not have valid ATM card

    //MFM 
    public static final int SSC_MFM_CORRECT_REF = 997740;//Please fill in the correct Reference No.
    public static final int SSC_MFM_COR_ADDRESS_EMPTY = 997741;//Please select the correspondence address.
    public static final int SSC_MFM_EXT_EMPTY = 997742;//Please fill in your Ext.
    public static final int SSC_MFM_CORRECT_EXT = 997743;//Ext must be numeric.
    public static final int SSC_MFM_NATURE_EMPTY = 997744;//Please specify your nature of business.
    public static final int SSC_MFM_YEAR_AND_MONTH = 997745;//Please specify year and month in service.
    public static final int SSC_MFM_TAX_NUMBER = 997746;//Please fill in your correct Taxpayer Identification Number.	
    public static final int SSC_MFM_MONTHLY = 997747;//Please fill in your correct monthly income.
    public static final int SSC_MFM_AVAILABLE_TIME = 997748;//System maintenance, please try again later.
    public static final int SSC_MFM_YEAR = 997749;//Please specify year and month in service (year)
    public static final int SSC_MFM_MONTH = 997750;//Please specify year and month in service (month)
    public static final int SSC_MFM_INVALID_PROMOTION_PERIOD = 997751;//promotion not available
    public static final int SSC_MFM_INVALID_PROMOTION_CODE = 997752;//Invalid promotion code
    public static final int SSC_MFM_EMPTY_PROMOTION_CODE = 997753;//Invalid promotion code
    public static final int SSC_MFM_EMPTY_CREDIT_CARD = 997754;//Invalid CREDIT CARD
    public static final int SSC_MFM_INVALID_CARD = 22202;
    
    //SCR-WMD14132
    public static final int SSC_IAC_STMT_LIFE_FOOTER_MSG_6 = 997735;
    
    //High risk transaction monitor begin
    public static final int SSC_HIGH_RISK_IP_ADDRESS = 930000;
    public static final int SSC_HIGH_RISK_BILL_NUMBER = 930001;
    public static final int SSC_HIGH_RISK_FUND_TRANSFER_ACCOUNT = 930002;
    public static final int SSC_HIGH_RISK_BP_IP_ADDRESS = 930003;
    public static final int SSC_HIGH_RISK_FT_IP_ADDRESS = 930004;
    //High risk transaction monitor end
	
	//WMD14137 FATCA checking begin
    public static final int SSC_FATCA_CUST_REJECT = 997755;
    public static final int SSC_FATCA_OWNER_REJECT = 997756;
    //WMD14137 FATCA checking end
	
    //WMD14204 begin
  	public static final int SSC_RAQ_SELECTION_CONTRADICTION = 997736;
  	public static final int SSC_CLPD_INVESTOBJ_EMPTY = 997737;
  	public static final int SSC_CLPD_INVESTOBJ_UNMATCH = 997757;
  	//WMD14204 end
    
    public static final int SSC_UNEXPECTED = 999999;
    
    //PDM15118 Begin
    public static final int SSC_YBANK_INVALID_ACCT = 997800;
    public static final int SSC_YBANK_DUBPICATE_REWARD_REGISTATION_RECORD = 997801;
    public static final int SSC_YBANK_ACCOUNT_AND_ID_NOT_MATCH = 997802;
    public static final int SSC_HKID_IS_REQUIRED_OR_PASSPORD_IS_REQUIRED = 997803;
    public static final int SSC_REWARD_IS_REQUIRED = 997804;
    public static final int SSC_YOU_BANK_ACCT_IS_REQUIRED = 997805;
    public static final int SSC_INVALID_PARTIAL_HKID = 997807;
    //PDM15118 End
    
    //PDM15219 Begin
    public static final int SSC_UPDATE_E_STMT_ADVICE_PARTIAL_FAIL = 997808;
    public static final int SSC_UPDATE_E_STMT_ADVICE_ALL_FAIL = 997809;
    //PDM15219 End
    
    //PDM16036 Begin
    public static final int SSC_YOU_YBANK_INVALID_ACCT = 997832;
    public static final int SSC_YOU_YBANK_DUBPICATE_REWARD_REGISTATION_RECORD = 997833;
    public static final int SSC_YOU_YBANK_ACCOUNT_AND_ID_NOT_MATCH = 997834;
    public static final int SSC_YOU_HKID_IS_REQUIRED_OR_PASSPORD_IS_REQUIRED = 997835;
    public static final int SSC_YOU_HKID_IS_INVALID_OR_PASSPORD_IS_INVALID = 997836;
    public static final int SSC_YOU_YOU_BANK_ACCT_IS_REQUIRED = 997837;
    public static final int SSC_YOU_INVALID_PARTIAL_HKID = 997838;
    public static final int SSC_YOU_INVALID_OPTOUT = 997839;
    public static final int SSC_YOU_YBANK_ACCOUNT_NOT_REG_DURING_PROMOTION = 997847;
    //PDM16036 End

    //PDM18336 Begin
    public static final int SSC_VIP_BANK_ACCT_IS_REQUIRED = 997848;
	public static final int SSC_VIP_ACCOUNT_NOT_IN_SELECTED_LIST = 997849;
    //PDM18336 End
    
    //E-CHEQUE OSD14109 and PDM14453 BEG
    public static final int SSC_ECHEQUE_NO_CHOOSE_ACCOUNT_TYPE = 997810;
    public static final int SSC_ECHEQUE_NO_SELECT_ACCOUNT_TYPE = 997811;
    public static final int SSC_ECHEQUE_NO_SELECT_ACCOUNT = 997812;
    public static final int SSC_ECHEQUE_INVALID_THIRD_ACCOUNT = 997813;
    public static final int SSC_ECHEQUE_INVALID_ACCOUNT = 997814;
    public static final int SSC_ECHEQUE_INVALID_EMAIL = 997815;
    public static final int SSC_ECHEQUE_NO_UPLOAD_FILE = 997816;
    public static final int SSC_ECHEQUE_MAX_FILES_SIZE = 997817;
    public static final int SSC_ECHEQUE_INVALIDE_FILE = 997818;
    public static final int SSC_ECHEQUE_RETRY_TO_UPLOAD = 997819;
    public static final int SSC_ECHEQUE_MAX_FILE_NAME = 997820;
    public static final int SSC_ECHEQUE_DUPLICATE_FILE = 997821;
    public static final int SSC_ECHEQUE_INVALID_DATE_RANGE = 997822;
    public static final int SSC_ECHEQUE_REMARKS_TOO_LONG = 997823;
    public static final int SSC_ECHEQUE_INVALID_ECHEQUES = 997824;
    public static final int SSC_ECHEQUE_POST_DATED_ECHEQUE = 997825;
    public static final int SSC_ECHEQUE_OUT_OF_DATE_ECHEQUE = 997826;
    public static final int SSC_ECHEQUE_INVALID_ECHEQUE_CCY = 997827;
    public static final int SSC_ECHEQUE_DUPLICATE_ECHEQUE = 997828;
    public static final int SSC_ECHEQUE_MAX_ONE_FILE_SIZE = 997829;
    public static final int SSC_ECHEQUE_FILE_FORMAT_INCORRECT = 997830;
    public static final int SSC_ECHEQUE_SYSTEM_ERROR = 997831;
    public static final int SSC_ECHEQUE_STATUS_1101 = 998300;
    public static final int SSC_ECHEQUE_STATUS_1102 = 998301;
    public static final int SSC_ECHEQUE_STATUS_1103 = 998302;
    public static final int SSC_ECHEQUE_STATUS_0101 = 998303;
    public static final int SSC_ECHEQUE_STATUS_0102 = 998304;
    public static final int SSC_ECHEQUE_STATUS_0103 = 998305;
    public static final int SSC_ECHEQUE_STATUS_0104 = 998306;
    public static final int SSC_ECHEQUE_STATUS_0105 = 998307;
    public static final int SSC_ECHEQUE_STATUS_0201 = 998308;
    public static final int SSC_ECHEQUE_STATUS_0202 = 998309;
    public static final int SSC_ECHEQUE_STATUS_0203 = 998310;
    public static final int SSC_ECHEQUE_STATUS_1201 = 998311;
    public static final int SSC_ECHEQUE_STATUS_1202 = 998312;
    public static final int SSC_ECHEQUE_STATUS_1203 = 998313;
    public static final int SSC_ECHEQUE_STATUS_0301 = 998314;
    public static final int SSC_ECHEQUE_STATUS_0302 = 998315;
    public static final int SSC_ECHEQUE_STATUS_0401 = 998316;
    public static final int SSC_ECHEQUE_STATUS_1104 = 998317;
    public static final int SSC_ECHEQUE_STATUS_1204 = 998318;
    public static final int SSC_ECHEQUE_STATUS_1205 = 998319;
    
    public static final int SCC_ECHEQUE_ACTIVITY_LOG_REJECT = 998320;
    
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_01 = 998321; 
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_03 = 998322;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_04 = 998323;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_06 = 998324;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_07 = 998325;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_08 = 998326;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_26 = 998351;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_27 = 998327;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_28 = 998328;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_29 = 998329;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_30 = 998330;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_51 = 998331;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_52 = 998332;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_53 = 998333;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_54 = 998334;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_55 = 998335;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_56 = 998336;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_57 = 998337;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_58 = 998338;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_61 = 998339;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_62 = 998340;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_63 = 998341;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_64 = 998342;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_65 = 998343;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_71 = 998344;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_72 = 998345;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_73 = 998346;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_74 = 998347;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_75 = 998348;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_76 = 998349;
    public static final int SSC_ECHEQUE_SUB_ERROR_CODE_99 = 998350;

    // PDM15125 Email Consolidation BEG
    public static final int SSC_NO_EMAIL_UPDATE = 997841;
    public static final int SSC_CIF_REJECT = 997842;
    public static final int SSC_NO_TEMP_EMAIL_IS_FOUND  = 997843;
    public static final int SSC_EMAIL_IS_EXPIRED = 997844;
    public static final int SSC_EMAIL_DOES_NOT_MATCH = 997845;
    public static final int SSC_FREEZE_PERIOD_ERR  = 997850;
    public static final int SSC_EBANK_EMAIL_IS_EMPTY  = 997851;
    public static final int SSC_MBANK_EMAIL_IS_EMPTY  = 997852;
    // PDM15125 Email Consolidation END

    // WMD16067 
    public static final int SSC_EBANK_EMAIL_IS_EMPTY_2  = 997853;
    
    //JtetcoP2PService error code
    public static final int SCC_SVTS_SD_OTP_AUTH_SUCCESS = 998410;	//SD OTP Authentication - Success
    public static final int SCC_SVTS_SD_OTP_AUTH_FAILED = 998411;	//SD OTP Authentication - Failed
    public static final int SCC_SVTS_SMS_OTP_AUTH_SUCCESS = 998412;	//SMS OTP Authentication - Success
    public static final int SCC_SVTS_SMS_OTP_AUTH_FAILED = 998413;	//SMS OTP Authentication - Failed
    public static final int SCC_SVTS_SMS_ERROR_FROM_BOSS = 998418;
    public static final int SCC_JETCO_SMS_ERROR_FROM_BOSS = 998419;
    public static final int SCC_JETCO_NO_MODIFY_STATUS = 998421;
    public static final int SCC_JETCO_SECURITYCODE_NOCONFIRM = 998422;
    public static final int SCC_JETCO_NO_SECURITYCODE = 998423;
    public static final int SCC_JETCO_MOBIN_LOCK=998424;
    public static final int SCC_JETCO_NO_SELECT = 998425;
    public static final int SCC_JETCO_NO_REGISTER = 998426;
    public static final int SCC_JETCO_NO_SMSCODE = 998427;
    public static final int SCC_JETCO_SMSCODE_ERROR = 998428;
    public static final int SCC_SV_TRANS_LIMIT_EXCEEDED = 998429;
    public static final int SCC_JETCO_SMSCODE_RESEND = 998432;
    public static final int SCC_RESEND_EXCEED_MAX = 998431;
    public static final int SCC_TRANSFER_IS_EMPTY = 998430;
    public static final int SCC_JETCO_ACTCODE_RESEND = 998433;
    public static final int SCC_EMPTY_DEPOSIT_ACCOUNT = 998434;
    public static final int SCC_EMPTY_EMAIL = 998435;
    public static final int SCC_EMPTY_PHONENO = 998436;
    public static final int SCC_JETCO_SMSCODE_LOSE_EFFICACY=998437;
    
    public static final int SCC_JETCO_P2P_NO_REGISTER = 998438;
    public static final int SCC_JETCO_P2P_TERMINATED = 998439;
    
    //temp Code
    public static final int SCC_JETCO_MC_COMMON_ERR_CODE = 998460;
    
    public static final int SCC_JETCO_NO_REGISTER_LOGSTATUS = 998440;
    public static final int SCC_JETCO_LIMIT_EXCEEDED_LOGSTATUS = 998441;
    
    //SecureLoginSMSOTP (SMS OTP DRD16050)
    public static final int SCC_RESEND_OTP_EXCEED_MAX = 998442;
    public static final int SCC_ENTER_OTP_ERROR_MAX = 998443;
    public static final int SCC_MOBILE_ENTER_OTP_ERROR_MAX = 998444;
    public static final int SCC_SMSCODE_RESEND_MSG = 998445;
    public static final int SCC_ISECURE_SMSCODE_EXPRIE=998446;
    public static final int SCC_ISECURE_SMSCODE_EXPRIE_RESEND=998447;
    public static final int SCC_MOBILE_SMSCODE_EXPRIE_RESEND=998448;
    public static final int SCC_INVALID_MOBILEPHNO_SMSOTP=998449;
    
    public static final int SCC_MOBILE_DEVICE_NOCHANGE = 998450;
    
    //DRD17081
    public static final int SCC_ISEC_CUST_CONSENT_STATUS_INVALID = 998451;
    public static final int SCC_ISEC_CUST_CONSENT_STATUS_UPDATE_ERROR = 998452;
    public static final int SCC_ISEC_CUST_CONSENT_STATUS_NOT_FOUND = 998453;
    
    //eAdvice error code PDM15125
    public static final int SSC_EADVICE_NO_FIX_DEP = 998501;
    public static final int SSC_EADVICE_NO_SECURITIES = 998502;
    public static final int SSC_MBANK_NO_SECURITIES = 998503;
    public static final int SSC_EADVICE_NO_EADVICE = 998504;
    public static final int SSC_ESTATEMENT_NO_STMT = 998505;
    
    //PDM15125 eStatement 
    public static final int SSC_ESTATEMENT_NO_DEPOSIT_ACCOUNT = 998510;
    public static final int SSC_ESTATEMENT_NO_CREDITCARD_ACCOUNT = 998511;
    public static final int SSC_ESTATEMENT_NO_SECURITY_ACCOUNT = 998512;
    
    
    //SeaLandAir error code PDM16223
    
    public static final int SSC_SEALANDAIR_NO_CARDNUMBER = 998520;
    public static final int SSC_SEALANDAIR_NO_REWARD = 998521;
    public static final int SSC_SEALANDAIR_CARDNUMBER_EXIST = 998522;
    public static final int SSC_SEALANDAIR_NO_RECORD = 998523;
    public static final int SSC_SEALANDAIR_NOT_IN_ENQUIRY_LIST = 998524;
    public static final int SSC_SEALANDAIR_NOT_IN_REG_LIST = 998525;
    public static final int SSC_SEALANDAIR_NOT_REGISTER_YET = 998526;
    public static final int SSC_SEALANDAIR_NOT_IN_INCLUDE_LIST = 998527;
    public static final int SSC_SEALANDAIR_IN_EXCLUDE_LIST = 998528;
    
    //PDM18233 Online Account Opening
    public static final int SSC_SMSOTP_EXCEEDED_MAX_DAILY_COUNT = 998540;
    public static final int SSC_SMSOTP_EXCEEDED_MAX_FAIL_COUNT = 998541;
    public static final int SSC_SMSOTP_INCORRECT_VALUE = 998542;
    public static final int SSC_SMSOTP_TIMEOUT_EXPIRED = 998543;
    
    //PDM15024 Revoling Loan Topup error code START
    public static final int SCC_REVOL_TOPUP_CALL_SUCCESS = 998550;					//000000 - call WebService Interface Successed!
    //public static final int SCC_REVOL_TOPUP_CALL_DEFAULT_ERR = 999999;			//999999 - call WebService Interface default error!
    public static final int SCC_REVOL_TOPUP_DATETIME_ERR = 998551;					//000001 - Date Time Validation Error
    public static final int SCC_REVOL_TOPUP_FIELD_LENGTH_ERR = 998552;				//000002 - Field Length Validation Error
    public static final int SCC_REVOL_TOPUP_INVALID_FIELD_ERR = 998553;				//000003 - Invalid field value
    public static final int SCC_REVOL_TOPUP_INVALID_CUSTID_ERR = 998554;			//000004 - Invalid Customer ID
    public static final int SCC_REVOL_TOPUP_INVALID_REQCHANNEL_ERR = 998555;		//000005 - Invalid Requested Channel
    public static final int SCC_REVOL_TOPUP_INVALID_ACCNUM_ERR = 998556;			//000006 - Invalid Account Number
    public static final int SCC_REVOL_TOPUP_INVALID_REQ_LOANAMOUNT_ERR = 998557;	//000016 - Invalid Requested Loan Amount
    public static final int SCC_REVOL_TOPUP_INVALID_REQ_TENOR_ERR = 998558;			//000017 - Invalid Requested Tenor
    public static final int SCC_REVOL_TOPUP_INVALID_SURNAME_ERR = 998559;			//000020 - Invalid Surname
    public static final int SCC_REVOL_TOPUP_INVALID_OTHERNAME_ERR = 998560;			//000021 - Invalid Other Name
    public static final int SCC_REVOL_TOPUP_INVALID_MOBILENUM_ERR = 998561;			//000041 - Invalid Mobile No
    public static final int SCC_REVOL_TOPUP_INVALID_TU_CONSENT_ERR = 998562;		//000042 - Invalid Tu Consent
    public static final int SCC_REVOL_TOPUP_ELIGIBLE_CHECK_FAILED_ERR = 998563;		//000043 - Eligible Check Failed
    public static final int SCC_REVOL_TOPUP_TU_REVIEW_CHECK_FAILED_ERR = 998564;	//000045 - TU Review Check Failed
    public static final int SCC_REVOL_TOPUP_TU_ENQUIRY_ERR = 998565;				//100001 - TU Enquiry Error (Follow up by Direct Channels)
    public static final int SCC_REVOL_TOPUP_TU_INCOME_PRROF_REQUIRED = 998566;		//100002 - Income Proof Required (Follow up by Direct Channels)
    public static final int SCC_REVOL_TOPUP_APPL_NOT_FOUND_ERR = 998567;			//000034 - Application Not Found [TOP04+TOP05] 
    public static final int SCC_REVOL_TOPUP_INVALID_DISBURSE_ACC_ERR = 998568;		//000046 - Invalid Disbursement Account [TOP04]
    public static final int SCC_REVOL_TOPUP_INVALID_DISBURSE_ACC_OWNER_ERR = 998569;//000047 - Invalid Disbursement Account Owner [TOP04]
    public static final int SCC_REVOL_TOPUP_INVALID_DISBURSE_ACC_TYPE_ERR = 998570;	//000048 - Invalid Disbursement Account Type[TOP04]
    public static final int SCC_REVOL_TOPUP_INVALID_CANCEL_REASONCODE_ERR = 998571;	//000049 - Invalid Cancel Reason Code [TOP05]
    public static final int SCC_REVOL_TOPUP_APP_REJ_BY_INTERMEDIARIES = 998572;		//200001 - Application is rejected because of intermediaries
    //PDM15024 Revoling Loan Topup error code END
    
    /*
     * webservice error message
     * 5.	Return Code Table (FROM 998100 TO 998199)
     * 8.	Confirm Presentment Return Code(FROM 998200 TO 998299)
     * 6.	Status table(FROM 998300 TO 998399)
    */
    //E-CHEQUE OSD14109 and PDM14453 END
    
    //pin verification and pin change reminder
    public static final int SSC_VERIFY_PIN_SUCCESS_NEEDS_PIN_CHANGE = 900001;
    public static final int SCC_VIOLATE_PIN_CHANGE_HIST = 900002;
    //PDM17230
    public static final int SSC_NEW_INIT_PWD_ALPHANUMERIC = 900003;
    //PDM17230
    
    //For WeChat
	public static final int SSC_WC_BLINDING_FAIL =  997303;
	public static final int SSC_WC_KYC_BLINDING_FAIL_ACCOUNT_NAME =  997304;
	public static final int SSC_WC_KYC_BLINDING_FAIL_CUSTOMER_ID =  997305;
	public static final int SSC_WC_KYC_BLINDING_FAIL_DATE_OF_BIRTH =  997306;
	
	//PDM16443 SME BEG
	public static final int SSC_RETRY_TO_UPLOAD = 997310;
	public static final int SSC_INVALIDE_FILE_TYPE = 997311;
	public static final int SSC_MAX_FILE_NAME_LENGTH = 997312;
	public static final int SSC_MAX_ONE_FILE_SIZE = 997313;
	public static final int SSC_MAX_FILES_SIZE = 997314;
	public static final int SSC_MAX_FILES_COUNT = 997315;
	public static final int SSC_SME_STANDALONE_PROMOTION_PERIOD = 997316;
	//PDM16443 SME END
    
	
	//PDM16259 Gift Card Enhancement
	public static final int SSC_INVALIDE_GIFT_CARDNUM= 996607;
	public static final int SSC_INVALIDE_GIFTPWD_BLANK = 996608;
	public static final int SSC_INVALIDE_PWD_SETUP = 996609;
	public static final int SSC_GIFTPWD_RETRY_LIMIT = 996610;
	public static final int SSC_INVALIDE_GIFT_CARDNUMBLANK = 996611;
	public static final int SSC_INVALIDE_GIFT_CARDNUMINVAILD = 996612;
	public static final int SSC_INVALIDE_GIFT_CVV2BLANK = 996613;
	public static final int SSC_INVALIDE_GIFT_CVV2INVAILD = 996614;
	public static final int SSC_INVALIDE_GIFT_CARDNOFOUND = 996615;
	public static final int SSC_INVALIDE_GIFT_PWDBLANK = 996616;
	public static final int SSC_INVALIDE_GIFT_PWDINVAILD = 996617;
	public static final int SSC_INVALIDE_GIFT_REPWDBLANK = 996618;
	public static final int SSC_CONFIRMPWD_NOT_MATCH = 996619;
	public static final int SSC_GIFTPWD_BLOCKED = 996620;
	public static final int SSC_INVALIDE_GIFTDATE = 996621;
	public static final int SSC_PWD_SETUP_REQUIRED = 996622;
	public static final int SSC_VERIFY_PIN_FAILED = 996623;
	public static final int SSC_GIFTPWD_REACHBLOCKED = 996624;
	//PDM16259 Gift Card Enhancement
	
	//RSD14013 START
	public static final int SSC_INSUFFICIENT_FUND = 997320;
	public static final int SSC_INTER_CHATS_NEXT_DAY_EXEC = 997321;
	public static final int SSC_INTER_INVALIDE_BANK_CODE = 997322;
	public static final int SSC_INTER_INVALIDE_ACCOUNT_TYPE = 997323;
    //RSD14013 END
	
	//PDM17141 START
	public static final int SSC_CCPROMO_CARDNO_EMPTY = 996625;
	public static final int SSC_CCPROMO_HKID_EMPTY = 996626;
	public static final int SSC_CCPROMO_CARDNO_INVALID = 996627;
	public static final int SSC_CCPROMO_CUSTID_NOT_FOUND = 996628;
	public static final int SSC_CCPROMO_CARDNO_INVALID_BIN = 996629;
	public static final int SSC_CCPROMO_CUSTID_NOT_MATCH = 996630;
	public static final int SSC_CCPROMO_HKID_INVALID = 996631;
	public static final int SSC_CCPROMO_NOT_PRINCIPAL_CARD = 996632;
    //PDM17141 END
	
	//PDM17221 START
	public static final int SSC_CCPROMO_GIFT_EMPTY = 996633;
	public static final int SSC_CCPROMO_GIFT_INVALID = 996634;
	public static final int SSC_CCPROMO_GIFT_NOT_AVAILABLE = 996635;
	public static final int SSC_CCPROMO_CARDNO_NOT_IN_REG_LIST = 996636;
	public static final int SSC_CCPROMO_REG_DATE_ERROR = 996637;
	public static final int SSC_CCPROMO_CAMPAIGN_CODE_ERROR = 996638;
	public static final int SSC_CCPROMO_CUST_TYPE_EMPTY = 996639;
	public static final int SSC_CCPROMO_CUST_TYPE_INVALID = 996640;
	public static final int SSC_CCPROMO_PROMO_NOT_AVAILABLE_CARDNO_IN_EXCLUDE_LIST = 996642;
	
	//PDM17378 START
	public static final int SSC_CCPROMO_CARDNO_IN_EXCLUDE_LIST = 996641;
	public static final int SSC_CCPROMO_CARDNO_NOT_FOUND = 996643;
	public static final int SSC_CCPROMO_CARDNO_IN_EXCLUDE_LIST_FOR_ENQUIRY = 996644;
	
	//PDM18035 START
    public static final int SSC_CCPROMO_BEFORE_PROMOTION_PERIOD = 996645;
    public static final int SSC_CCPROMO_AFTER_PROMOTION_PERIOD = 996646;
    public static final int SSC_CCPROMO_CUST_REGISTERED = 996647;
    public static final int SSC_CCPROMO_CUST_NOT_IN_ENQUIRY_LIST = 996648;
    
	//PDM16430 START
	public static final int SSC_IPAY_SUMMARY_ALL_NORECORD = 996701;
	public static final int SSC_IPAY_SUMMARY_FILTER_NORECORD = 996702;
	public static final int SSC_IPAY_HISTORY_ALL_NORECORD = 996703;
	public static final int SSC_IPAY_HISTORY_FILTER_NORECORD = 996704;
	public static final int SSC_IPAY_HISTORY_ERROR_DATERANGE = 996705;
	public static final int SSC_IPAY_FROMDATE_AFTER_ENDDATE = 996706;
	//PDM16430 START
	
	//PDM16601 eMGM START
	public static final int SCC_EMGM_REFEREE_REG_PROMO_UNAVAILABLE = 999750;
	public static final int SCC_EMGM_PROMO_UNAVAILABLE = 999770;
	public static final int SCC_EMGM_REF_CODE_INVALID = 999751;
	public static final int SCC_EMGM_CREDIT_CARD_NUM_INCORRECT = 999752;
	public static final int SCC_EMGM_CREDIT_CARD_NUM_HKID_UNMATCH = 999753;
	public static final int SCC_EMGM_CREDIT_CARD_NUM_PP_UNMATCH = 999754;
	public static final int SCC_EMGM_PROMO_ID_INVALID = 999755;
	public static final int SCC_EMGM_REFERRER_EAMIL_INVALID = 999756;
	public static final int SCC_EMGM_REFERRER_CC_NUM_NOT_FOUND = 999757;
	
	//WMD17113 eMGM Start 
	public static final int SCC_EMGM_ID_TYPE_EMPTY = 996801;
	public static final int SCC_EMGM_HKID_EMPTY = 996802;
	public static final int SCC_EMGM_PASSPORT_EMPTY = 996803;
	public static final int SCC_EMGM_APPOINTMENT_DATE_EMPTY = 996804;
	public static final int SCC_EMGM_APPOINTMENT_TIME_EMPTY = 996805;
	public static final int SCC_EMGM_REFERRER_CODE_ERROR = 996806;
	public static final int SCC_EMGM_HKID_INVALID = 996807;
	public static final int SCC_EMGM_PASSPORT_INVALID = 996808;
	public static final int SCC_EMGM_EXCEED_ENQUIRY_PERIOD = 996809;
	public static final int SCC_EMGM_CARD_NOT_MATCH_CUST  = 996810;
	//WMD17113 eMGM End 
	
	//PDM17657
	public static final int SSC_CCPROMO_CARDNO_NOT_IN_BA_LIST = 996811;
	public static final int SSC_CCPROMO_CARDNO_NOT_IN_UA_LIST = 996812;
	public static final int SSC_CCPROMO_CARDNO_REGISTERED_ALREADY = 996813;
	public static final int SSC_CCPROMO_CARDNO_NOT_IN_INACTIVE_LIST = 996814;
	public static final int SSC_CCPROMO_CARDNO_REGISTERED_INACTIVE_ALREADY = 996815;
	public static final int SSC_CCPROMO_CARDNO_SOLO_SANRIO_REGISTERED = 996816;
	public static final int SSC_CCPROMO_CARDNO_INACTIVE_REGISTERED = 996817;
	public static final int SSC_CCPROMO_CARDNO_AFTER_INACTIVE_PROGRAM = 996818;
	public static final int SSC_CCPROMO_AFTER_PROMOTION_SIMPLE = 996819;
	public static final int SSC_CCPROMO_CUST_WINNER_EXCLUDE_LIST = 996820;
	public static final int SSC_CCPROMO_CARDNO_NOT_IN_ANA_LIST = 996821;
	public static final int SSC_CCPROMO_CARDNO_NOT_IN_YOU_LIST = 996822;
	public static final int SSC_CCPROMO_CUST_NOT_IN_TAX_LIST = 996823;
	public static final int SSC_CCPROMO_CARDNO_SOLO_FESTIVE_REGISTERED = 996824;
	public static final int SSC_CCPROMO_CUST_NOT_IN_REVOLVER_LIST = 996825;

	//PDM15468 eMGM Start 
	public static final int CC_EMGM_DSB_ACCOUNT_NUM_NOT_FOUND = 999758;
	public static final int SCC_EMGM_DSB_ACCOUNT_NUM_INCORRECT = 999759;
	public static final int SCC_EMGM_DSB_ACCOUNT_NUM_HKID_UNMATCH = 999760;
	public static final int SCC_EMGM_DSB_ACCOUNT_NUM_PP_UNMATCH = 999761;
	public static final int SCC_EMGM_DSB_ACCOUNT_NUM_HKID_UNMATCH_IND = 999762;
	public static final int SCC_EMGM_DSB_ACCOUNT_NUM_PP_UNMATCH_IND = 999763;
	public static final int SCC_EMGM_DSB_CUSTOMER_NOT_VIP = 999764;
	public static final int SCC_EMGM_DSB_CUSTOMER_CHARACTER_TYPE_NOT_KIT = 999765;
	public static final int SCC_EMGM_DSB_ACCOUNT_STATUS_ERROR = 999766;
	//PDM15468 eMGM End
	
	//DRD11079 START
	public static final int SSC_SM_BOND_IS_TYPHOON = 997901;
	public static final int SSC_SM_TX_OUTSIDE_SERVICE_HOUR = 997902;
	public static final int SSC_SM_NO_DEBIT_ACCT = 997903;
	public static final int SSC_SM_NO_CREDIT_ACCT = 997904;
	public static final int SSC_SM_NO_SELECT_DEBIT_ACCT = 997905;
	public static final int SSC_SM_NO_SELECT_CREDIT_ACCT = 997906;
	public static final int SSC_SM_NO_TF_AMOUNT = 997907;
	public static final int SSC_SM_INVALIDE_AMOUNT = 997908;
	public static final int SSC_SM_AMOUNT_MORETHAN_2PLACES = 997909;
	public static final int SSC_SM_SAME_SMACCOUNT_TYPE= 997910;
	public static final int SSC_SM_SIGNED_CASAACCT_NOT_ALLOWED= 997911;
	public static final int SSC_SM_SAME_ACCOUNT_TYPE= 997912;
	public static final int SSC_SM_NO_SMACCOUNT_TYPE= 997913;
	public static final int SSC_SM_INVALIDE_CURRENCY = 997914;
	public static final int SSC_SM_CURRENCY_DIFF = 997915;
	public static final int SSC_SM_COMMON_REJ_ONE=997916;
	public static final int SSC_SM_CASA_ACCOUNT_BALANCE_INSUFFICIENT=997917;
	public static final int SSC_SM_NO_HKD_STOCKS=997918;
	public static final int SSC_SM_DRAWAl_EXCEED=997919;
	public static final int SSC_SM_DRAWAl_LESSTHAN_PERCENTAGE=997920;
	public static final int SSC_SM_COMMON_REJ_SECOND=997921;
	public static final int SSC_SM_SECOND_INTERFACE_REJ=997924;
	public static final int SSC_SM_SUCCESS=997922;
	public static final int SSC_SM_FAILURE=997923;
	//DRD11079 End
	
	//PDM17230 Biometric Authentication
    public static final int SCC_BIO_SEND_SMS_OTP_ERROR = 998470;
    public static final int SCC_BIO_SD_OTP_AUTH_SUCCESS = SCC_SVTS_SD_OTP_AUTH_SUCCESS;	//SD OTP Authentication - Success
    public static final int SCC_BIO_SD_OTP_AUTH_FAILED = SCC_SVTS_SD_OTP_AUTH_FAILED;	//SD OTP Authentication - Failed
    public static final int SCC_BIO_SMS_OTP_AUTH_SUCCESS = SCC_SVTS_SMS_OTP_AUTH_SUCCESS;	//SMS OTP Authentication - Success
    public static final int SCC_BIO_SMS_OTP_AUTH_FAILED = SCC_SVTS_SMS_OTP_AUTH_FAILED;	//SMS OTP Authentication - Failed
    
    //For IOS device
    public static final int SCC_BIO_IOS_FINGER_FACE_SUCCESS = 998480;	//(i) Success - (Push) (Fingerprint/Face ID)
    //For both IOS and Android
    public static final int SCC_BIO_PASSCODE_SUCCESS = 998481;		//(ii)Success - (Push) Passcode
    //For Android device
    public static final int SCC_BIO_ANDROID_FINGER_SUCCESS = 998482;	//(i) Success - (Push) Fingerprint
    public static final int SCC_BIO_ANDROID_FACIAL_SUCCESS = 998483;	//(iii). Success - (Push) Facial Recognition
    //For both IOS and Android
    public static final int SCC_BIO_REJECT = 998484;	//Rejected
    public static final int SCC_BIO_PASSCODE_REJECT = 998485;	//Rejected - (Push) Passcode
    public static final int SCC_BIO_FACIAL_REJECT = 998486;	//Rejected - (Push) Facial Recognition
    
    public static final int SCC_BIO_ISEC_LOGIN_QRCODE_REJECT  =998490;	//isec_Login_QRCODE_Reject
    
    //For IOS device
    public static final int SCC_BIO_IOS_FINGER_FACE_SUCCESS_SAME_DEVICE = 998580;	//(i) Success - (Fingerprint/Face ID)
    //For both IOS and Android
    public static final int SCC_BIO_PASSCODE_SUCCESS_SAME_DEVICE = 998581;		//(ii)Success - Passcode
    //For Android device
    public static final int SCC_BIO_ANDROID_FINGER_SUCCESS_SAME_DEVICE = 998582;	//(i) Success - Fingerprint
    public static final int SCC_BIO_ANDROID_FACIAL_SUCCESS_SAME_DEVICE = 998583;	//(iii). Success - Facial Recognition
    //For both IOS and Android
    public static final int SCC_BIO_PASSCODE_REJECT_SAME_DEVICE = 998585;	//Rejected - Passcode
    public static final int SCC_BIO_FACIAL_REJECT_SAME_DEVICE = 998586;	//Rejected - Facial Recognition
    
    
    //WMD12103 Fund Switch
    public static final int SCC_SWITCH_INVESTMENT_UNMATCH = 998930; //Investment objective is unmatched
    public static final int SCC_SWITCH_FUND_NO_FUND = 998931;	//Fund code not found
    public static final int SCC_SWITCH_NOT_AVAIL_IN = 998932;	//Fund code not available to switch in
    public static final int SCC_SWITCH_UNIT_INVALID = 998933;	//Switch out unit invalid
    public static final int SCC_SWITCH_UT_REJECT = 998934;	//UT rejected switching order
    public static final int SCC_SWITCH_NO_FUND_CAN_IN = 998935;	//No fund can be shown on switch in pop up page
    public static final int SCC_SWITCH_RISK_ASSESS_EMPTY = 998936;	//no valid rtl
    public static final int SCC_SWITCH_FUND_CODE_NO_INPUT = 998937;	//Fund no fund
	public static final int SSC_SWITCH_DECLARATION_NOT_CONFIRMED = 998938; //Declaration not confirmed
	public static final int SSC_SWITCH_ALL_NO_SUITABILITY_QUESTIONS = 998939; //suitability questions.
	public static final int SSC_SWITCH_CLPD_DK_ERROR = 998940; ////Customer do not have record of derivative knowledge.

    
    //PDM17517 Start
    public static final int SCC_SEND_SMS_OTP_ERROR = SCC_SVTS_SMS_OTP_AUTH_FAILED;
    
    public static final int SCC_SD_OTP_AUTH_SUCCESS = SCC_SVTS_SD_OTP_AUTH_SUCCESS;	//SD OTP Authentication - Success
    public static final int SCC_SD_OTP_AUTH_FAILED = SCC_SVTS_SD_OTP_AUTH_FAILED;	//SD OTP Authentication - Failed
    public static final int SCC_SMS_OTP_AUTH_SUCCESS = SCC_SVTS_SMS_OTP_AUTH_SUCCESS;	//SMS OTP Authentication - Success
    public static final int SCC_SMS_OTP_AUTH_FAILED = SCC_SVTS_SMS_OTP_AUTH_FAILED;	//SMS OTP Authentication - Failed
    
    
    //addressing 
    public static final int SCC_FPS_ADDRESSING_NOT_HAS_EMAIL_MOBILE = 998650;
    public static final int SCC_FPS_ADDRESSING_CANCEL_ERROR = 998651;
    public static final int SCC_FPS_ADDRESSING_AMEND_ERROR = 998652;
    public static final int SCC_FPS_ADDRESSING_REG_ERROR = 998653;
    public static final int SCC_FPS_ADDRESSING_NOT_EMAIL_MOBILE = 998654;
    //PDM17517 End
    
    //PDM17517 Faster Payment Transfer BEG
    public static final int SCC_FPS_TRANSFER_ACCT_EMPTY = 998610;
    public static final int SCC_FPS_TRANSFER_TO_INVALID = 998611;
    public static final int SCC_FPS_TRANSFER_EMAIL_INVALID = 998612;
    public static final int SCC_FPS_TRANSFER_MOBILE_INVALID = 998613;
    public static final int SCC_FPS_TRANSFER_RECENT_CONTACTS_EMPTY = 998614;
    public static final int SCC_FPS_TRANSFER_AMOUNT_INVALID = 998615;
    public static final int SCC_FPS_TRANSFER_TYPE_INVALID = 998616;
    public static final int SCC_FPS_TRANSFER_ACCT_TYPE_INVALID = 998617;
    public static final int SCC_FPS_TRANSFER_BENFCY_ACCT_EMPTY = 998618;
    public static final int SCC_FPS_TRANSFER_BENFCY_NAME_INVALID = 998619;
    public static final int SCC_FPS_TRANSFER_BENFCY_BANK_INVALID = 998620;
    public static final int SCC_FPS_TRANSFER_BENFCY_BRANCH_INVALID = 998621;
    public static final int SCC_FPS_TRANSFER_BENFCY_ACNO_INVALID = 998622;
    
    public static final int SCC_FPS_TRANSFER_NO_ACCT_LIST = 998623;
    public static final int SCC_FPS_TRANSFER_MAX_TEMPLATE_CNT = 998624;
    public static final int SCC_FPS_TRANSFER_MIN_AMOUNT = 998625;
    public static final int SCC_FPS_TRANSFER_MAX_AMOUNT = 998626;
    public static final int SCC_FPS_TRANSFER_NON_REG_PAYEE = 998627;
    public static final int SCC_FPS_TRANSFER_ALREADY_IN_THE_REG_ACCT = 998628;
    public static final int SCC_FPS_TRANSFER_DATE_INVALID = 998629;
    public static final int SCC_FPS_TRANSFER_REALLY_TIME_ONLY = 998630;
    public static final int SCC_FPS_TRANSFER_INVALID_BENEFICIARY_BANK = 998631;
    public static final int SCC_FPS_TRANSFER_INVALID_REMARKS = 998633;
    public static final int SCC_FPS_TRANSFER_P00024_ERROR_001 = 998724;

    //PDM17517 Faster Payment Transfer END
    
    //PDM17517 EDDA
    public static final int SSC_FPS_EDDA_NO_MOBILE_NO_EMAIL = 998710;
    public static final int SSC_FPS_EDDA_NO_SECURITY_DEVICE = 998711;
    public static final int SSC_FPS_EDDA_MERCHANT_CCY_INVALID = 998712;
    public static final int SSC_FPS_EDDA_DEBIT_ACCT_INVALID = 998731;
    public static final int SSC_FPS_EDDA_MERCHANT_CATEGORY_INVALID = 998732;
    public static final int SSC_FPS_EDDA_MERCHANT_NAME_INVALID = 998733;
    public static final int SSC_FPS_EDDA_MERCHANT_BILLNUM_INVALID = 998734;
    public static final int SSC_FPS_EDDA_TRANSFER_AMOUNT_INVALID = 998735;
    public static final int SSC_FPS_EDDA_EFFECTIVE_DATE_INVALID = 998736;
    public static final int SSC_FPS_EDDA_EXPIRY_DATE_INVALID = 998737;
    public static final int SSC_FPS_EDDA_PERIODICITY_INVALID = 998738;
    
    //WMD18047
    public static final int SSC_WMD18047_NO_EMAIL = 998720;
    public static final int SSC_WMD18047_NO_EMAIL_NO_HYPE_LINK = 998721;
    public static final int SSC_WMD18047_CHANGE_PWD_NO_EMAIL = 998722;
    
    //PDM18300 Transaction limit add 2FA
    public static final int SSC_TRAN_LIMIT_NO_MOBILE = 997660;
    public static final int SSC_TRAN_LIMIT_NO_EMAIL = 997661;
    //PDM18300 Transaction limit add 2FA 

    
    // PDM18348 - fade out of hardware token Start
    public static final int SSC_TOKEN_NOACTIVE_STATUS_LOG = 999318;
    public static final int SSC_TRANSACTION_NOT_SECURITY = 999319;
    // PDM18348 - fade out of hardware token End
    
    public static final int SSC_CASA_CSS_NOT_CONFIRM = 998723;
    
    // 20181105	Kwok Yat Hong	PDM18223	Sales Code Landing page
    public static final int SSC_SALES_CODE_INVALID = 999800;
    // End 20181105	Kwok Yat Hong	PDM18223	Sales Code Landing page
    
    public static final int SSC_IS_EXISTING_CUSTOMER = 999972;
 }
