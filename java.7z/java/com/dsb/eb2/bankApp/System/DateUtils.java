package com.dsb.eb2.bankApp.System;

import java.text.SimpleDateFormat;

public class DateUtils {

	public static String getCurrentEmsTsStr()
    {
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		String formattedDate = sdf.format(new java.util.Date());
		return formattedDate;
    }
	
	public static String getCurrentEmsTimeStr()
    {
    	SimpleDateFormat sdf = new SimpleDateFormat("HHmmss");
		String formattedDate = sdf.format(new java.util.Date());
		return formattedDate;
    }
}
