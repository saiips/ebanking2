package com.dsb.eb2.bankApp.System;

import java.util.*;
import java.io.*;
import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.*;

import com.dsb.eb2.util.FileUtils;
import com.dsb.eb2.util.SystemEnvironment;
import com.dsb.eb2.util.Base64;


//import sun.misc.*;

public class KeysManager {

	private static final String DESKeyString = "g3HPk7qE";
//	private static final String DESedeKeyString = "GX767wb2d+x669TcAf961Pz/9G3aPx89";
	private static String DESedeKeyString = "";
	private static final String encryptedEBPPConfigFile =
    SystemEnvironment.getHome() + "config/ebpp/ebpp.ini";
  private static String DbContentKey = null;

  KeysManager()
  {
	}

  static synchronized private void readEBPPConfigFile() throws Exception {
		// load the encrypted properties file into the hashtable
		String epFile = FileUtils.translate(encryptedEBPPConfigFile);
		FileInputStream fis2 = new FileInputStream(epFile);
		CipherInputStream cis2 = new CipherInputStream(fis2, KeysManager.getMasterKeyCipher());
		Properties props = new Properties();
		props.load(cis2);
		cis2.close();
		fis2.close();
		DbContentKey = props.getProperty("DBCONTENTKEY");
  }

  static public final byte[] getDbContentKey() {
    try {
      if (DbContentKey == null)
        readEBPPConfigFile();
    }
    catch (Exception e) {
      // whenever error occurs, the DbContentKey will remain empty
    }

    return DbContentKey.getBytes();
  }

	static public final byte[] getDESMasterKey() {
		byte result[];

/*		try {
			BASE64Decoder decoder = new BASE64Decoder();
			result = decoder.decodeBuffer(DESKeyString);
		}
		catch (Exception e)	{
			result = null;
		}*/
		result = DESKeyString.getBytes();

		return (result);
	}

	static public final byte[] getMasterKey() {
		return getDESMasterKey();
	}

	static public final String getMasterKeyEncryptionAlgorithm() {
		return "DES/ECB/PKCS5Padding";
	}

	static public final String getMasterKeyKeyAlgorithm() {
		return "DES";
	}

	static public final Cipher getMasterKeyCipher() throws Exception {
		byte[] keyBytes = KeysManager.getMasterKey(); // a byte array containing the key data
		SecretKeyFactory myKeyFac = SecretKeyFactory.getInstance(KeysManager.getMasterKeyKeyAlgorithm());
		DESKeySpec myKeySpec = new DESKeySpec(keyBytes);
		Key mykey = myKeyFac.generateSecret(myKeySpec);

		// generate Cipher for decryption
		Cipher cipher2 = Cipher.getInstance(KeysManager.getMasterKeyEncryptionAlgorithm());
		cipher2.init(Cipher.DECRYPT_MODE, mykey);

		return cipher2;
	}

	static public final byte[] getMasterSessionKey() {
//		return getDESMasterKey();
		return getDESedeMasterKey();
	}

	static public final byte[] getDESedeMasterKey() {
		byte result[];

		try {
			if (DESedeKeyString.equals(""))
			{
				// read tripleDES key from file
				FileInputStream inFile;
        String DESedeMasterKeyStore = SystemConfig.getSystemParameter("DESedeMasterKey");
				inFile = new FileInputStream(DESedeMasterKeyStore);
				result  = new byte[inFile.available()];
				inFile.read(result);
				DESedeKeyString = new String(result);
			}

//			BASE64Decoder decoder = new BASE64Decoder();
//			result = decoder.decodeBuffer(DESedeKeyString);
			result = Base64.decode(DESedeKeyString);
		}
		catch (Exception e)	{
      e.printStackTrace();
			result = null;
		}

		return (result);
	}

	// for unit testing
	public static void main(String[] args) {
		try {
		}
		catch (Exception e) {
		}
	}

}