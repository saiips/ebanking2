package com.dsb.eb2.bankApp.System;

/**
 * Static class which defines a comprehensive
 * set of symbolic reference for all operation
 * performed by the ebanking system
 *
 * @author  Mike Chan
 * @version 0.0
 */
public class FunctionType extends Object {

  // main type
  public static final int MF_LOGIN = 0;
  public static final int MF_LOGOUT = 1;
  public static final int MF_ACCT_PROFOLIO = 2;
  public static final int MF_ACCT_DETAIL_ENQ = 3;
  public static final int MF_FIN_ACT_ENQ = 4;
  public static final int MF_NON_FIN_ACT_ENQ = 5;
  public static final int MF_ONLINE_STMT = 6;
  public static final int MF_FUND_TRANSFER = 7;
  public static final int MF_FOREIGN_EXCH = 8;
  public static final int MF_PAYMENT = 9;
  public static final int MF_FIXED_DEPOSIT = 10;
  public static final int MF_RATE_ENQ = 11;
  public static final int MF_STMT_REQ = 12;
  public static final int MF_CHEQ_BOOK_REQ = 13;
  public static final int MF_STOP_CHEQ_REQ = 14;
  public static final int MF_CASHIER_ORDER = 15;
  public static final int MF_DEMAND_DRAFT = 16;
  public static final int MF_ACCT_OPENING = 17;
  public static final int MF_PROFILE_MTCE = 18;
  public static final int MF_PIN_CHANGE = 19;
  public static final int MF_CARD_ACT = 20;  // Card activiation, added by Eric 2000/07/27
  public static final int MF_BILL_MGMT = 21;
  public static final int MF_BILL_HIST_ENQ = 22;
  public static final int MF_ACT_TX_HIST_ENQ = 23;
  public static final int MF_CC_INSTALLMENT = 24;
  public static final int MF_IPO = 25;
  public static final int MF_PENDING_INST = 26;
  public static final int MF_SUPERLOW = 27;
  public static final int MF_PIN_REGEN = 28;
  public static final int MF_OBT = 29;
  public static final int MF_SPL_MCD = 30; //special price merchanise
  public static final int MF_LIVERPOOL = 31; //LiverPool FootBall Priority Booking
  public static final int MF_BNS_PT_REDEEM = 32;
  
  public static final int MF_PL_REVOLVING_LOAN = 33;  //PDM04217 - Automated Personal Revolving Loan Service
  public static final int MF_TAXLOAN = 34; // PDM04328 Tax Loan Application Transaction
  public static final int MF_SECURITIES = 35; //PDM04259 Lucky Draw
  public static final int MF_LUCKY_DRAW = 36; //PDM04259 Lucky Draw

  public static final int MF_SCHOOL = 38; //PDM05217 Project School
  public static final int MF_TNF_KID = 39; //PDM07079 Thomas & Friends
  public static final int MF_ROBOT_KID = 40; //PDM07550 Robot Kid
  public static final int MF_TOOL_KID = 41; // PDM08148 Project Tools
  public static final int MF_MFM = 42; // PDM09073 Generic MasterCard
  public static final int MF_MFM_PUBLIC = 43; // PDM09524 - MFM Card Revamp
  public static final int MF_CASH_IN_PLAN_LOGIN = 44; // PDM10099 - 2010 Specific Merchant Installment (1st round)
  public static final int MF_SELF_ASG_ID = 45;
  public static final int MF_CASH_PAYOUT = 46;
  public static final int MF_DERI_KNOWLEDGE = 47;
  public static final int MF_ATM_CARD_ACT = 48; //PDM10588 ATM Card Activation
  public static final int MF_MOBILE_TRADING = 49; //DRD11080 Mobile Trading Registration
  public static final int MF_ATM_CARD_ACT_DEACT = 50; //PDM10588 ATM Card Activation
  public static final int MF_CREDIT_CARD_ACT_DEACT = 51; //PDM10588 ATM Card Activation

  public static final int MF_ATM_CARD_OPT = 52; //SCR-PDM10588-2B
  public static final int MF_ALIPAY_REG = 53; // SCR-PDM12829 Alipay Registration Service
  
  public static final int MF_TOKEN_SERVICE = 54; 
  public static final int MF_MOBILE_BANKING = 55;
 
   //PDM13057 EBPP Begin
  public static final int MF_EBILL = 56;
  public static final int MF_EBILL_ENROLMENT_MGMT = 57;
  public static final int MF_EMAIL_ALERT_SETTING = 58;
  public static final int MF_MY_INBOX = 59;
  //PDM13057 EBPP End
  
  public static final int MF_TU_SERVICE = 60;	//TU Online Application Form
  
  public static final int MF_E_RECEIPT = 61; // ATM e-Receipt

  public static final int MF_PAYROLL_SERVICE = 62; // Online Payroll Services
  
  public static final int MF_E_STATEMENT = 63; // e-Statement
  
  public static final int MF_UPGRADE_TO_YBANKING = 65; // upgrade to YOU Banking
  
  public static final int MF_CCY_SERVICE = 66;//Foreign Currency Note Order Services
  
  public static final int MF_PRE_REGISTRATION = 70;
  
  public static final int MF_CUST_INFO_MTCE = 71;
  
  public static final int MF_YBANK_BONUS_PT_REDEEM = 72; //YOU Bonus Point Redeem
  
  public static final int MF_MFM_SERVICE = 73; // MFM Cardholder Handling
  
  public static final int MF_Y_BANK_ACQ_SERVICE = 74; // YOU Acquisition Promotion
  
  public static final int MF_CASH_CARD = 75; //PDM15106
  
  public static final int MF_E_STMT_ADVICE = 76; // PDM15219
  
  public static final int MF_ECHEQUE_PRESENTMENT = 77; // PDM14453 e-Cheque
  
  public static final int MF_Y_BANK_REW_SERVICE = 78; // PDM16036 YOU Banking Rewards Scheme Registration
  
  public static final int MF_EMAIL_CONVERSION = 79;	// PDM15125 email conversion
  
  public static final int MF_ONLINE_SERVICE_SETTINGS = 80;	//Online Service Settings
  public static final int MF_JETCO_PAY_APP = 81;	//JETCO Pay App
  
  public static final int MF_SMS_OTP = 82;//SMS OTP
  
  public static final int MF_REVOL_LOAN_TOPUP_APP = 83;		//PDM15024 	Revolving Loan Top-up Application
  
  // sub type
  public static final int SF_ID_PIN = 1000;
  public static final int SF_ECERT = 1001;
  public static final int SF_JCERT = 1002;
  public static final int SF_LO_USER = 1003;
  public static final int SF_LO_TIMEOUT = 1004;
  public static final int SF_SAME_CIF = 1005;
  public static final int SF_THRID_PARTY = 1006;
  public static final int SF_INTER_BANK_CHATS = 1007;
  public static final int SF_FX_FT = 1008;
  public static final int SF_PAY_CARD_FT = 1009;
  public static final int SF_FD_CREATION = 1010;
  public static final int SF_FD_UPLIFT = 1011;
  public static final int SF_FD_RENEWAL = 1012;
  public static final int SF_PLACEMENT = 1013;
  public static final int SF_AMENDMENT = 1014;
  public static final int SF_REMOVAL = 1015;
  public static final int SF_ENQUIRY = 1016;
  public static final int SF_SAVING_RATE = 1017;
  public static final int SF_FX_RATE = 1018;
  public static final int SF_LOAN_RATE = 1019;
  public static final int SF_SAVINGS = 1020;
  public static final int SF_MCY_SAVINGS = 1021;
  public static final int SF_TARGET_SAVINGS = 1022;
  public static final int SF_FIXED_DEPOSIT = 1023;
  public static final int SF_CURRENT = 1024;
  public static final int SF_EASI_CASH = 1025;
  public static final int SF_FLEXI_MONEY = 1026;
  public static final int SF_CREDIT_CARD = 1027;
  public static final int SF_CASH = 1028;
  public static final int SF_P_LOAN = 1030;
  public static final int SF_MORTGAGE_LOAN = 1031;
  public static final int SF_CC_CASH_REWARD = 1032;
  public static final int SF_CREATION = 1033;
  public static final int SF_UPDATE = 1034;
  public static final int SF_DELETION = 1035;
  public static final int SF_PAY_BILL = 1036;
  public static final int SF_IPO_PAYMENT = 1037;
  public static final int SF_RETAIL_ACCT = 1038;
  public static final int SF_IPO_APPLY   = 1039;
  public static final int SF_IPO_CANCEL  = 1040;
  public static final int SF_IPO_ENQUIRY = 1041;
  public static final int SF_IPO_UPDATE  = 1042;
  public static final int SF_HISTORY_ENQ = 1043;
  public static final int SF_INTER_BANK_AUTOPAY = 1044;
  public static final int SF_FROM_OT_BK_DDA_GEN = 1045;
  public static final int SF_FROM_OT_BK_ONLINE = 1046;
  public static final int SF_ONLINE_BT = 1047;
  public static final int SF_UT_ACCT = 1048;
  public static final int SF_FD_HKD_NF_CREATION = 1049; //NORMAL FIXED(HKD) DEPOSIT CREATION
  public static final int SF_FD_FCY_NF_CREATION = 1050; //NORMAL FIXED(FCY) DEPOSIT CREATION
  public static final int SF_FD_HKD_PF_CREATION = 1051; //PRIVILEGE FIXED(HKD) DEPOSIT CREATION
  public static final int SF_FD_FCY_PF_CREATION = 1052; //PRIVILEGE FIXED(FCY) DEPOSIT CREATION
  public static final int SF_FD_HKD_MG_CREATION = 1053; //MONTHLY GAIN DEPOSIT CREATION
  public static final int SF_FD_HKD_NF_RENEWAL = 1054; //NORMAL FIXED(HKD) DEPOSIT MATURITY INSTRUCTION
  public static final int SF_FD_FCY_NF_RENEWAL = 1055; //NORMAL FIXED(FCY) DEPOSIT MATURITY INSTRUCTION
  public static final int SF_FD_HKD_PF_RENEWAL = 1056; //PRIVILEGE FIXED(HKD) DEPOSIT MATURITY INSTRUCTION
  public static final int SF_FD_FCY_PF_RENEWAL = 1057; //PRIVILEGE FIXED(FCY) DEPOSIT MATURITY INSTRUCTION
  public static final int SF_FD_HKD_MG_RENEWAL = 1058; //MONTHLY GAIN DEPOSIT MATURITY INSTRUCTION
  public static final int SF_OBT = 1059; // Online BT
  public static final int SF_PAY_CREDIT_CARD_FT = 1060;
  public static final int SF_LOGIN_OPTION = 1063; //CHANGE OF LOGIN PREFERENCE
  public static final int SF_ADDRESS_MTCE = 1064; //ADDRESS MANAGEMENT REQUEST
  public static final int SF_EMAIL_ADDR_MTCE = 1065; //EMAIL ADDRESS MANAGEMENT REQUEST
  public static final int SF_SMID = 1066; //SMART HKID
  public static final int SF_OTHER_DEVICE_CERT_LOGIN = 1067; //OTHER DEVICE DIGITAL CERTIFICATE LOGIN
  public static final int SF_FFC_PRG = 1068; //Fun Fun Club merchandise redemption
  public static final int SF_OTHER_PRG = 1069; // Rewards Redemption
  public static final int SF_GENERAL_RATE = 1070; // General Rate Enquiry
  public static final int SF_RETAIL_BOND = 1071; // Retail Bond
  public static final int SF_SECURITIES = 1072; // Securities

  public static final int SF_PL_RV_LOGIN = 1073;
  public static final int SF_PL_RV_LOGOUT = 1074;
  public static final int SF_PL_RV_PIN_CHANGE = 1075;
  public static final int SF_PL_RV_APP = 1076;

  public static final int SF_SEC_PLACE_ORDER = 1077; // Securities Place Order
  public static final int SF_SEC_CHG_ORDER = 1078; // Securities Change/Cancel Order
  public static final int SF_LUCKY_DRAW_DRAW = 1079; //Lucky Draw

  public static final int SF_NEW_ID = 1080; //PDM05217 Assign login
  public static final int SF_RESET_PIN = 1081; //PDM05217 PIN reset
  public static final int SF_CHANGE_PIN = 1082; //PDM05217 PIN change
  public static final int SF_CHANGE_EMAIL = 1083; //PDM05217 PIN change
  public static final int SF_SEND_ECARD = 1084; //PDM05217 eCard sending
  
  public static final int SF_SECURITIES_EXPRESS_LOGIN = 1084;	// iSecurities Express Login

  public static final int SF_MFM_REGISTER = 1085;	// iSecurities Express Login
  public static final int SF_MFM_UNREGISTER = 1086;	// iSecurities Express Login

  public static final int SF_SELF_ASG_ID_REG  = 1087;
  public static final int SF_SELF_ASG_ID_DISPLAY = 1088;
  public static final int SF_SELF_ASG_ID_PIN = 1089;

  public static final int SF_CASH_PAYOUT_REG = 1090;
  
  public static final int SF_DERI_KNOWLEDGE_DEC = 1091;

  public static final int SF_ATM_CARD = 1092; //PDM10588 ATM Card Activation
 
  public static final int SF_FUND_SUBSCRIPTION = 1093;

  public static final int SF_FUND_REDEMPTION = 1094;

  public static final int SF_ONLINE_RISK_ASSESSMENT = 1095;
 
  //SCR-OPC12002 Start
  public static final int SF_INTER_BANK_CROSS = 1101;
  //SCR-OPC12002 END
 
  //SCR-PDM10588-2B start
  public static final int SF_ATM_CARD_OPT = 1106;
  //SCR-PDM10588-2B End
  
  public static final int SF_ANY = 1999;

  public static final int SF_ADD_PRE_REGISTRATION = 2015;
  
  //WMD13100 start
  public static final int SF_BOND_SUBSCRIPTION = 2016;
  public static final int SF_BOND_SUBSCRIPTION_ENQUIRY = 2017;
 //WMD13100 End
  
  // PDM15219 Start
  public static final int SF_UPDATE_E_STMT_ADVICE = 2018;
  // PDM15219 End
  
  public static final int SF_REQUEST_OTP = 2022;    //Request OTP
  public static final int SF_OTP_VALIDATION = 2023; //OTP Validation
  
  //first time login
  public static final int SF_ATMCARD_AUTHEN = 3000;
  public static final int SF_CCARD_AUTHEN = 3001;
  
  // Extended Type
  public static final int ET_NOT_APPLICABLE = 0;
  public static final int ET_NOW = 5000;
  public static final int ET_OBT = 5001;

  public static final int ET_SCHED_ONCE_CREATE = 6000;
  public static final int ET_SCHED_ONCE_MODIFY = 6001;
  public static final int ET_SCHED_ONCE_DELETE = 6002;
  public static final int ET_SCHED_ONCE_EXECUTE = 6003;

  public static final int ET_MONTHLY_TF_CREATE = 7000;
  public static final int ET_MONTHLY_TF_MODIFY = 7001;
  public static final int ET_MONTHLY_TF_DELETE = 7002;
  public static final int ET_MONTHLY_TF_EXECUTE = 7003;
  
  public static final int ET_ISEC_LOGIN = 7004;//i-Sec Login
  public static final int ET_MOBILE_DEVICE_ACTIVATION= 7005;//Mobile Device Activation

   public static final int SF_MOBILE_TRADING_REG_STATUS = 1098; //DRD11080 Mobile Trading Registration 
  public static final int SF_MOBILE_TRADING_PWD_CREATION = 1096;
  public static final int SF_MOBILE_TRADING_RESET_PWD = 1097; 
  
  public static final int SF_CLPD_SUBSCRIPTION = 1099;
  public static final int SF_CLPD_ENQUIRY = 1100; 

  //SCR-PDM10588 Start
  public static final int SF_ATM_CARD_ENQ = 1102;
  public static final int SF_ATM_CARD_ACT = 1103;
  public static final int SF_ATM_CARD_DEACT = 1105;
  //SCR-PDM10588 End
  public static final int SF_CHANGE_WEBPIN = 1104;
  
  // SCR-PDM12829 Start
  public static final int SF_REGISTRATION = 1107;
  public static final int SF_UNREGISTRATION = 1108;
  // SCR-PDM12829 End
  
  //2FA
  public static final int SF_TOKEN_ACTIVATION = 1109;
  public static final int SF_TOKEN_LGOINSETTING = 1110;
  public static final int SF_EBID_TKN_LOGIN = 1114;
  public static final int SF_PBID_TKN_LOGIN = 1113; 
  public static final int SF_TOKEN_BANKSIDE_REACTIVATE_RESYNC = 1115; 

  //2FA
  
  // PDM12146 Mobile Banking start
  public static final int SF_ACTIVATION = 1111;
  public static final int SF_DEACTIVATION = 1112;
  // PDM12146 Mobile Banking end
 
  //PDM13057 EBPP Begin
  public static final int SF_EBILL_ENROLMENT = 2000;
  public static final int SF_CANCEL_EBILL_REG = 2001;
  public static final int SF_DEL_REG_BILL = 2002;
  public static final int SF_DEL_AND_REMOVE_REG = 2003;
  public static final int SF_EMAIL_ALERT_UPD = 2004;
  public static final int SF_READ_EMAIL = 2005;
  public static final int SF_DEL_EMAIL = 2006;
  //EBPP Phase 2.5 Begin
  public static final int SF_CREATE_BY_ENROLMENT = 2007;
  //EBPP Phase 2.5 End
  
  public static final int SF_UPDATE_E_STATEMENT_EMAIL1 = 2012; // update e-Statement email1 .
  
  public static final int SF_UPDATE_E_RECEIPT_STATUS = 2010; // Update e-Receipt Status
  
  public static final int SF_YBANK_BONUS_PT_REDEEM = 2014;// YOU Bonus Point Redeem
 //Monthly recurring 
  public static final int ET_RECUR_DUE_DATE_CREATE = 8004;
  public static final int ET_RECUR_DUE_DATE_MODIFY = 8005;
  public static final int ET_RECUR_DUE_DATE_DELETE = 8006;
  public static final int ET_RECUR_DUE_DATE_EXECUTE = 8007;
  //PDM13057 EBPP End
  
  //WMD13100 start
  public static final int ET_BOND_SUBSCRIPTION_ORDER_INPUT = 8008;
  public static final int ET_BOND_SUBSCRIPTION_ORDER_CONFIRM= 8009;
  public static final int ET_BOND_SUBSCRIPTION_ORDER_ACKNOWLEDGE = 8010;
  public static final int ET_BOND_SUBSCRIPTION_RISK_DISCLOSURE = 8011;
  public static final int ET_BOND_SUBSCRIPTION_BOND_SELECTION = 8012;
  //WMD13100 end
  
  //PDM15416 ET Start
  public static final int ET_AMEND_SVTS_LIMIT = 8020;	//Amend Small Value Transfer Service Limit
  public static final int ET_TERMINATE_JETCO_PAY_SERVICE = 8021;	//Terminate JETCO Pay Service
  public static final int ET_RESET_MOBILE_PIN = 8022;	//Reset the Mobile PIN
  public static final int ET_GEN_ACTIVATE_CODE = 8023;	//Generate the Activation Code
  
  public static final int ET_JETCO_PAY_APP = 8030;	//Not Applicable
  //PDM15416 ET End
  
  //PDM12540-3 Transaction Limit Start
  public static final int SF_AMEND_3PTY = 1115;
  public static final int SF_AMEND_HRISK = 1116;
  public static final int SF_AMEND_NHRISK = 1117;
  //PDM12540-3 Transaction Limit End

  public static final int SF_TU_SERVICE = 1118;	//TU Online Application Form
  
  public static final int SF_PAYROLL_SERVICE = 1119; // Online Payroll Services
  public static final int SF_UPGRADE_TO_YBANKING = 1121; // Upgrade to YOU Banking
 
  public static final int SF_CUST_INFO_MTCE = 1122;
  
  public static final int SF_CCY_SERVICE = 1123;//Foreign Currency Note Order Services
  
  //SCR-OPD14002 START
  public static final int SF_FD_FIRST_CREATION = 1124; //First Time Create Fixed Deposit Placement
  //SCR-OPD14002 END
  
  public static final int SF_MFM_SERVICE = 1125; //MFM Cardholder Handling
  
  public static final int SF_Y_BANK_ACQ_SERVICE = 1126; // YOU Acquisition Promotion
  
  public static final int SF_CASH_CARD = 1127; //PDM15106
  
  public static final int SF_Y_BANK_REW_SERVICE = 1128; // PDM16036 YOU Banking Rewards Scheme Registration
  
  public static final int RESEND_VERIFICATION_EMAIL = 1129;//PDM15125 Email Consolidation
  public static final int SKIP_ADD_CHANGE_EMAIL_ADDRESS = 1130;//PDM15125 Email Consolidation
  public static final int EDM_OPT_OUT_MAINTANENCE = 1131;//PDM15125 Email Consolidation
  
  public static final int SF_ECHEQUE_PRESENTMENT = 2019; // PDM14453 e-Cheque
  
  //DRD11079 begin
  public static final int SF_MARGIN_TRANSFER_SERVICE = 2020;
  //DRD11079 end
  
  public static final int SF_EMAIL_CONVERSION = 2021; // PDM15125 email conversion
  
  //PDM13057 start
  //Bill Payment Debit Account List for EBPP project. Use SF_PAY_BILL if no need to co-exist existing and new features.
  public static final int SF_EBPP_PAY_BILL=1113;
  //PDM13057 end
  public static final boolean isEnquiryType(int mainType, int subType) {
    return ((mainType == MF_ACCT_PROFOLIO)||
            (mainType == MF_ACCT_DETAIL_ENQ)||
            (mainType == MF_FIN_ACT_ENQ)||
            (mainType == MF_NON_FIN_ACT_ENQ)||
            (mainType == MF_ONLINE_STMT)||
            (mainType == MF_RATE_ENQ)||
            (mainType == MF_BILL_HIST_ENQ) ||
            (mainType == MF_ACT_TX_HIST_ENQ) ||
            (subType == SF_HISTORY_ENQ) ||
            (subType == SF_ENQUIRY));
  }
  
	//PDM15416 JETCO SF START 
	public static final int SF_SV_TRANSAFER_SETTINGS = 2030;//Small-Value Transfer Settings
	public static final int SF_JETCO_P2P_SETTINGS = 2031;//JETCO Pay Settings
	public static final int SF_ONLINE_TRANS_LIMIT = 2032;	//Online Transaction Limit
	
	public static final int SF_JETCO_PAY_APP_REG = 2040;	//Registration
	public static final int SF_JETCO_PAY_APP_SM = 2041;		//Send Money
	public static final int SF_JETCO_PAY_APP_CM = 2042;		//Collect Money
	public static final int SF_JETCO_PAY_APP_RF_CCBYSD = 2043;	//Refund - Cancel Payment by Sender (DSB)
	public static final int SF_JETCO_PAY_APP_RF_RJBYCL = 2044;	//Refund - Reject Payment by Collector (DSB)
	public static final int SF_JETCO_PAY_APP_CHG_TXNACCT = 2045;	//Change Transaction Account
	public static final int SF_JETCO_PAY_APP_TERM_PAYACCT = 2046;	//Terminate JETCO Pay Account
	public static final int SF_JETCO_PAY_APP_CHG_PIN = 2047;	//Change Mobile PIN
	public static final int SF_JETCO_PAY_APP_VER_PIN_FAILED = 2048;	//Mobile PIN Verification - Incorrect Mobile PIN
	public static final int SF_JETCO_PAY_APP_VER_PIN_LOCKED	= 2049;	//Incorrect Mobile PIN, Mobile PIN locked
	public static final int SF_JETCO_PAY_APP_EXPIRED_FOR_7DAYS = 2050;//Refund - Expired for 7 days
	public static final int SF_JETCO_PAY_APP_TERM_RJBYCL = 2051;      //Refund - Jetco App Terminate
	public static final int SF_JETCO_PAY_APP_TERM_PAYACCT_SYS= 2052;  //Terminate JETCO Pay Account by sys
	public static final int SF_JETCO_PAY_APP_RF_MERCHANTVOID=2053;    //Refund Merchant Void
	//PDM15416 JETCO SF END 
	
	//PDM15024 REVOL_LOAN_TOPUP SF START
	public static final int SF_REVOL_LOAN_TOPUP_APPL_REQ = 2207;		//Submit Loan Request
	public static final int SF_REVOL_LOAN_TOPUP_REC_CRE = 2208;			//LOS record Created
	public static final int SF_REVOL_LOAN_TOPUP_REC_CONF = 2209;		//LOS record Confirmed
	public static final int SF_REVOL_LOAN_TOPUP_REC_CANC = 2210;		//LOS record Cancelled
	public static final int SF_REVOL_LOAN_TOPUP_REC_ADJ = 2211;			//LOS record Adjustment
	//PDM15024 REVOL_LOAN_TOPUP SF END
	
	//WeChat Pay START
	public static final int MT_WECHAT_PAY_APP = 84; // WeChat Main Type
	public static final int SF_WECHAT_ACCOUNT_BINDING = 2212;
	public static final int SF_WECHAT_CANCEL_ACCOUNT_BINDING = 2213;
	public static final int SF_WECHAT_RESET_PIN = 2214;
	public static final int SF_WECHAT_TRANSACTION = 2215; // WeChat Transaction Sub Type
	public static final int SF_WECHAT_SALES = 2216; // WeChat Transaction Sub Type - Sales
	public static final int SF_WECHAT_REFUND = 2217; // WeChat Transaction Sub Type - Refund
	//WeChat Pay End
	
	//PDM16443 beg
	public static final int MF_SME_STAND_ALONE = 86;	//SME Standalone Function
	public static final int SF_SME_STAND_ALONE = 2024; 	//SME Standalone Function
	//PDM16443 end
	
	//PDM17141 Credit Card Online Spending Promotion Registration beg
	public static final int MF_CC_ONLINE_SPENDING_REG_A = 87;
	public static final int SF_CC_ONLINE_SPENDING_REG_A = 2025;
	public static final int MF_CC_ONLINE_SPENDING_REG_B = 88;
	public static final int SF_CC_ONLINE_SPENDING_REG_B = 2026;
	//PDM17141 Credit Card Online Spending Promotion Registration end
	
	//WMD16067 price watch beg
	public static final int SF_FX_PRICE_WATCH = 8801;
	public static final int ET_FX_PRICE_WATCH_CREATE = 8802;
	public static final int ET_FX_PRICE_WATCH_DELETE = 8803;
	public static final int ET_FX_PRICE_WATCH_MODIFY_CREATE = 8804;
	public static final int ET_FX_PRICE_WATCH_MODIFY_DELETE = 8805;
	//WMD16067 price watch end
	
	//PDM17230 Biometric Authentication Settings
	public static final int SF_BIOMETRIC_AUTH_SETTINGS = 2027;	//Biometric Authentication Settings
	public static final int FINGERPRINT_FACEID_LOGIN = 1132;	//PDM17230 Biometric Authentication
	public static final int PASSCODE_LOGIN = 1133;	//PDM17230 Biometric Authentication
	
	//WMD12103 
	public static final int SF_ONLINE_FUND_SWITCH = 1135;  //WMD12103 Online Fund Switch
	
	//PDM17230 Biometric Authentication Settings
	public static final int QR_FINGERPRINT_FACEID_LOGIN = 1140;	//(QR Code)Fingerprint / Face ID
	public static final int QR_PASSCODE_LOGIN = 1141;		//(QR Code)Passcode
	public static final int QR_FACE_LOGIN = 1142;			//(QR Code)Facial Recognition
	public static final int PUSH_FINGERPRINT_FACEID_LOGIN = 1143;	//(PUSH)Fingerprint / Face ID
	public static final int PUSH_PASSCODE_LOGIN = 1144;		//(PUSH)Passcode
	public static final int PUSH_FACE_LOGIN = 1145;			//(PUSH)Facial Recognition
	
	public static final int FINGERPRINT_LOGIN = 1146;			//Fingerprint
	public static final int QR_FINGERPRINT_LOGIN = 1147;		//(QR Code)Fingerprint
	public static final int PUSH_FINGERPRINT_LOGIN = 1148;	//(PUSH)Fingerprint
	
	//add for: Investment Services
	public static final int SF_FUND_PORTFOLIO = 1160;	//Fund Portfolio
	public static final int SF_FUND_ENQUIRY = 1161;		//Fund Enquiry (Transaction Record)
	
	//PDM17517 Faster Payment Transfer Beg
	public static final int SF_FPS_TRANSFER_P2P_MOBILE = 2240;
	public static final int SF_FPS_TRANSFER_P2P_EMAIL= 2241;
	public static final int SF_FPS_TRANSFER_A2A_REG = 2242;
	public static final int SF_FPS_TRANSFER_A2A_NONREG = 2243;
	public static final int SF_FPS_TRANSFER_P2P_FPSID = 2244;
	
	public static final int FASTER_PAYMENT_ADDRESSING = 90;
	public static final int FASTER_PAYMENT_ADDRESSING_REG = 2220;
	public static final int FASTER_PAYMENT_ADDRESSING_CANCEL = 2221;
	public static final int FASTER_PAYMENT_ADDRESSING_AMEND = 2222;
	//PDM17517 Faster Payment Transfer End

	//PDM17517 Faster Payment EDDA Start
	public static final int FASTER_PAYMENT_EDDA = 91;
	public static final int FASTER_PAYMENT_EDDA_REG = 2230;
	public static final int FASTER_PAYMENT_EDDA_CANCEL = 2231;
	public static final int FASTER_PAYMENT_EDDA_AMEND = 2232;
	public static final int FASTER_PAYMENT_EDDA_ACCEPT = 2233;
	public static final int FASTER_PAYMENT_EDDA_SETTINGS = 2234;
	public static final int FASTER_PAYMENT_EDDA_REJECT = 2235;
	//PDM17517 Faster Payment EDDA End
	
	//PDM18300 Transfer Limit 
	public static final int ET_TRANSFER_LIMIT_2FA = 8040;
	public static final int ET_AMEND_FT_LIMIT = 8041;
	public static final int ET_AMEND_BILL_HRISK_LIMIT = 8042;
	public static final int ET_AMEND_BILL_NHRISK_LIMIT = 8043;
	
	//PDM18300 Transfer Limit

}
