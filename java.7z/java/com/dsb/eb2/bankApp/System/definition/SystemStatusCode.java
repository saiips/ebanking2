package com.dsb.eb2.bankApp.System.definition;

/*
 * SystemStatusCode.java
 *
 * Created on May 19, 2000, 10:37 AM
 */


/**
 * Static class which defines a comprehensive
 * set of symbolic reference for all status
 * code returned from the ebanking system
 * (status code for ebanking is 99xxxx)
 *
 * @author  Mike Chan
 * @version 0.0
 */
  public class SystemStatusCode extends Object {

    public static final int SSC_RMI_NORMAL = 800000;
    public static final int SSC_RMI_NO_ITEM = 810006;// No Item Available
    public static final int SSC_RMI_UPDATE_STOCK_STATUS_FAIL = 810007;// Update Stock Status Fail
    public static final int SSC_RMI_DB_ERROR = 810099; //General Error (Database)
    public static final int SSC_RMI_UNEXPECTED = 888888;
    
    /* normal/sucessful status */
    public static final int SSC_NORMAL = 990000;
    /* error status (application level) */
    // generic
    public static final int SSC_NO_SUCH_ACCT = 990001;
    public static final int SSC_ACCT_TYPE_MISMATCH = 990002;
    public static final int SSC_INVALID_CCY = 990003;
    // fund transfer related
    public static final int SSC_TF_RATE_NOT_FOUND = 990100;
    public static final int SSC_TF_FOREX_ONLY_FOR_OWN_RETAIL_ACCT = 990101;
    public static final int SSC_TF_CC_PAYMENT_NOT_IN_HKD = 990102;
    public static final int SSC_TF_DECIMAL_NOT_FOR_GIVEN_CCY = 990103;
    public static final int SSC_FT_DB_CCY_NOT_IN_ACCT = 990104;
    public static final int SSC_FT_CR_CCY_NOT_IN_ACCT = 990105;
    public static final int SSC_FT_REMITTANCE_DAILY_LIMIT_EXCEEDED = 990106;
    public static final int SSC_FT_FOREX_TX_LIMIT_EXCEEDED = 990107;
    public static final int SSC_TX_OUTSIDE_SERVICE_HOUR = 990108;
    public static final int SSC_FT_FOREX_EXCH_RATE_EXPIRED = 990109;
    public static final int SSC_FT_FROM_OT_BK_DAILY_LIMIT_EXCEEDED = 990110;

    public static final int SSC_FT_REMITTANCE_BENE_LIMIT_EXCEEDED = 990111;
    public static final int SSC_FT_REMITTANCE_BENE_LIMIT_EXCEEDED_REG = 990112;
    public static final int SSC_FT_REMITTANCE_INSUFFICIENT_FUND = 990113;
    public static final int SSC_FT_REMITTANCE_CUST_REQUEST = 990114;
    public static final int SSC_FT_REMITTANCE_TEST = 990115;
    public static final int SSC_FT_REMITTANCE_OTHER = 990116;

    public static final int SSC_FT_FROM_OT_BK_PER_TXN_LOWER_LIMIT_EXCEEDED = 990117;
    public static final int SSC_FT_FROM_OT_BK_PER_TXN_UPPER_LIMIT_EXCEEDED = 990118;

	/* System Status Code for weekly limit exceed message. */
    public static final int SSC_FT_REG_WK_AMT_LIMIT_EXCEEDED  = 990119;
	public static final int SSC_FT_UREG_WK_AMT_LIMIT_EXCEEDED = 990120;
    public static final int SSC_FT_UREG_WK_CNT_LIMIT_EXCEEDED = 990121;
    public static final int SSC_FD_OUTSIDE_SERVICE_HOUR = 990122;
    
    public static final int SSC_TF_FX_CNY_TO_NONHKD = 990123;
    
    // login related
    public static final int SSC_INCORRECT_PWD = 990201;
    public static final int SSC_MULTIPLE_LOGIN = 990202;
    public static final int SSC_TOO_MANY_SESSIONS = 990203;
    public static final int SSC_ALREADY_LOGIN = 990204;
    public static final int SSC_BUS_USER_NOT_SUPPORT = 990205;
    public static final int SSC_USER_ALREADY_HALTED = 990206;
    public static final int SSC_SESSION_TIME_OUT = 990207;
	public static final int SSC_CERT_LOGIN_ONLY = 990208;
	public static final int SSC_WEB_SESSION_TIME_OUT = 990209;
	public static final int SSC_LOGIN_REQUIRED = 990210;
	public static final int SSC_INVALID_USER_ID = 990211;
	public static final int SSC_VERIFICATION_ERROR = 990212;
	public static final int SSC_HSM_ERROR = 990213;
	public static final int SSC_DB_ERROR = 990214;
	public static final int SSC_LOGIN_DISABLED = 990215;
	public static final int SSC_INIT_PIN_ERROR = 990216;
	public static final int SSC_FIRST_TIME_LOGIN = 990217;
	public static final int SSC_FIRST_TIME_LOGIN_TO_SECURITIES = 990218;	
	public static final int SSC_NO_SECURITIES_ACCOUNT = 990219;
	public static final int SSC_TO_SECURITIES = 990220;
	public static final int SSC_SECURITIES_MAINTAINANCE = 990221;
	public static final int SSC_SECURITIES_SERVER_BUSY = 990223;
	


    // fixed deposit
    public static final int SSC_INVALID_FD_TYPE = 990301;
    public static final int SSC_INVALID_FD_DEP_TERM = 990302;
    public static final int SSC_FD_DEP_TERM_NOT_ALLOWED = 990303;
    public static final int SSC_FD_CCY_ONLY_IN_PCP_HKD = 990304;
    public static final int SSC_FD_INT_ACCT_ONLY_FOR_MONTH_GAIN = 990305;
    public static final int SSC_FD_INT_ACCT_REQ_FOR_MONTH_GAIN = 990306;
    public static final int SSC_FD_AUTO_REN_NOT_FOR_MONTH_GAIN = 990307;
    public static final int SSC_FD_INT_ACCT_ONLY_FOR_P = 990308;
    public static final int SSC_FD_INT_ACCT_REQ_FOR_P = 990309;
    public static final int SSC_FD_DB_CCY_NOT_IN_ACCT = 990310;
    public static final int SSC_FD_INT_CCY_NOT_IN_ACCT = 990311;
    public static final int SSC_FD_MIN_DEP_AMT_LIMIT_EXCEEDED = 990312;
    public static final int SSC_FD_MI_CANCEL_NOT_ALLOWED = 990313;
    // account profolio and details
    public static final int SSC_ACCT_PROFOLIO_NOT_FOUND = 990401;
    public static final int SSC_NO_OWNER_FOUND = 990402;
    public static final int SSC_NO_BALANCE_FOUND = 990403;
    public static final int SSC_CC_SUB_CARD = 990404;
    public static final int SSC_CC_NO_ACCESS = 990405;
    public static final int SSC_PROBLEM_ACCT_FOUND = 990406;

    /* error status (system level) */
    public static final int SSC_DBMS_GENERAL = 991001;
    public static final int SSC_DBMS_POOL = 991002;

    // properties files related error
    public static final int SSC_CANNOT_READ_INI_FILE = 991003;
    public static final int SSC_TERMINAL_PARAM_NOT_FOUND = 991004;
    public static final int SSC_TERMINAL_POOL_PARAM_NOT_FOUND = 991005;
    public static final int SSC_OPERATOR_PARAM_NOT_FOUND = 991006;
    public static final int SSC_SESSIONMGMT_PARAM_NOT_FOUND = 991007;
    public static final int SSC_DB_POOL_PARAM_NOT_FOUND = 991008;

    /** The following status codes are used by the phone banking
     *  interface module (for verify or change PB PIN).
     */

    // low level TN3270 error
    public static final int SSC_3270_CANNOT_CONNECT_AFTER_RETRIES = 991010;
    public static final int SSC_3270_OPEN_TERMINAL_ERROR = 991011;
    public static final int SSC_3270_WRITE_TERMINAL_ERROR = 991012;
    public static final int SSC_3270_CLOSE_TERMINAL_ERROR = 991013;
    public static final int SSC_3270_RESET_TERMINAL_ERROR = 991014;
    public static final int SSC_3270_ERROR_GET_SCREEN = 991015;

    // Terminal pool error
    public static final int SSC_NO_FREE_TERMINAL = 991016;
    public static final int SSC_ERROR_IN_GETTING_HOST_SESSION = 991017;

    public static final int SSC_3270_FAILURE = 991018;

    // screen scaping error
    public static final int SSC_EXPECTED_SCREEN_NOT_FOUND = 991020;
    public static final int SSC_ERROR_SENDING_MESSAGES_TO_HOST =  991021;
    public static final int SSC_DISRUPTED_WHILE_WAITING_HOST = 991022;

    // errors for signing on  CICS
    public static final int SSC_CANNOT_CLS_BEFORE_SIGNON_CICS = 991030;
    public static final int SSC_CANNOT_REACH_CICS_SIGNON = 991031;
    public static final int SSC_CANNOT_ENTER_CSSN_NUM = 991032;
    public static final int SSC_CANNOT_GET_CONFIRMATION_AFTER_SIGNON_CICS = 991033;
    public static final int SSC_CANNOT_CLS_AFTER_SIGNON_CICS = 991034;
    public static final int SSC_CANNOT_REACH_VTAM_MENU = 991035;
    public static final int SSC_CANNOT_CLS_BEFORE_TRX = 991036;

    // phone banking related errors
    public static final int SSC_PB_DID_NOT_REPLY = 991040;
    public static final int SSC_PB_REPLY_UNEXPECTED_MSG = 991041;
    public static final int SSC_PB_RETURN_ERROR = 991042;
    public static final int SSC_CANNOT_CLS_AFTER_PB_SESSION = 991043;
    //		public static final int SSC_PB_PROMPT_FOR_HKID = 991044;
    public static final int SSC_PB_CHANGE_PASSWORD_ERROR = 991045;
    public static final int SSC_PB_PIN_ENCRYPT_ERROR = 991046;
    public static final int SSC_PB_INVALID_CHAR = 991047;
    public static final int SSC_PB_INVALID_INT = 991048;

    public static final int SSC_PB_PASSWORD_NOT_6_DIGITS = 991049;

    // phone banking error code
    public static final int SSC_PB_INVALID_USER_ID = 991050;
    public static final int SSC_PB_INVALID_PIN = 991051;
    public static final int SSC_PB_INVALID_PIN_TO_BE_HOT = 991052;
    public static final int SSC_PB_INVALID_STATUS = 991053;
    public static final int SSC_PB_JOINT_AC = 991054;
    public static final int SSC_PB_ID_CHANGE_TO_HOT = 991055;
    public static final int SSC_PB_HOT_ID = 991056;
    public static final int SSC_PB_INVALID_ID_STATUS = 991057;
    public static final int SSC_PB_TIME_OUT = 991058;
    public static final int SSC_PB_SYSTEM_SHUT_DOWN = 991059;
    public static final int SSC_PB_SYSTEM_NOT_INIT = 991060;
    public static final int SSC_PB_SYSTEM_SUSPENDED = 991061;
    public static final int SSC_PB_SYSTEM_ERROR = 991062;
    public static final int SSC_PB_CIF_NOT_READY = 991063;

    public static final int SSC_PB_CHANGE_PIN_FAIL = 991064;
    public static final int SCC_PB_FIRST_LOGIN = 991065;
    public static final int SSC_PB_TRANSFER_ID = 991066;
    public static final int SSC_COI_CHANGE_PIN_ERR = 991067;
    public static final int SSC_COI_RESET_PIN_ERR = 991068;
    public static final int SSC_COI_WRONG_PIN = 991069;

    // CIF related errors
    public static final int SSC_CIF_DID_NOT_REPLY = 991070;
    public static final int SSC_CIF_REPLY_UNEXPECTED_MSG = 991071;
    public static final int SSC_CIF_RETURN_ERROR = 991072;
    public static final int SSC_CANNOT_CLS_AFTER_CIF_SESSION = 991073;
    public static final int SSC_CIF_ACCT_REF_NOT_FOUND = 991074;
    //public static final int SSC_CIF_NOT_READY = 991075;

    //  database related errors
    // The row count for INSERT, UPDATE or DELETE is zero
    public static final int SSC_DBMS_ZERO_ROW = 991080;
    // The row count for INSERT, UPDATE or DELETE is greater than one
    public static final int SSC_DBMS_MORE_THAN_ONE_ROWS = 991081;

    /* encryption related errors */
    public static final int SSC_CANNOT_GET_MASTER_KEY = 992000;
    public static final int SSC_CANNOT_GET_RSA_PRIV_KEY = 992001;
    public static final int SSC_CANNOT_GET_MODULUS = 992002;
    public static final int SSC_CANNOT_GET_PUBLIC_EXPONENT = 992003;

    // HUB related
    public static final int SSC_HUB_COMM_ERROR = 993000;
    public static final int SSC_HUB_CONNECT_ERROR_UNEXPECTED = 993010;
    public static final int SSC_HUB_CONNECT_ERROR_CONNECT_DB = 993011;
    public static final int SSC_HUB_CONNECT_ERROR_WRITE_KEY = 993012;
    public static final int SSC_HUB_CONNECT_ERROR_CONNECT_HUB = 993013;
    public static final int SSC_HUB_CONNECT_ERROR_NO_REPLY = 993014;
    public static final int SSC_HUB_CONNECT_ERROR_DELETE_KEY = 993015;
    public static final int SSC_HUB_CONNECT_ERROR_CLOSE_DB = 993016;
    public static final int SSC_HUB_MSG_RESP_ERROR = 993001;

    
    // iSecurities related
    public static final int SSC_NO_ISEC_AC = 993100;
    public static final int SSC_CONN_ERR_WITH_ETRADE = 993101;
    public static final int SSC_INACTIVE_ISEC_AC = 993102;
    public static final int SSC_INVALID_ISEC_AC = 993103;
    
    // Bill Payment errors
    public static final int SSC_BP_INVALID_LENGTH = 994020;
    public static final int SSC_BP_INVALID_DATA_TYPE = 994021;
    public static final int SSC_BP_INVALID_PATTERN_FROM_DB = 994022;
    public static final int SSC_BP_INVALID_PATTERN_FROM_AGENT = 994033;
    public static final int SSC_BP_INVALID_CHECK_DIGIT = 994023;
    public static final int SSC_BP_EXEC_DATE_OUT_OF_RANGE = 994034;
    public static final int SSC_BP_BILL_RECORD_ALREADY_EXIST = 994024;
    public static final int SSC_BP_BILL_RECORD_NOT_EXIST = 994025;
    public static final int SSC_BP_TX_LIMIT_EXCEEDED_L = 994026;
    public static final int SSC_BP_TX_LIMIT_EXCEEDED_U = 994028;
    public static final int SSC_BP_MERCHANT_NOT_PAYABLE = 994027;
    public static final int SSC_BP_BILL_TYPE_NOT_PAYABLE = 994030;
    public static final int SSC_BP_CC_NOT_PAYABLE = 994031;
    public static final int SSC_BP_CC_MTH_TX_LIMIT_EXCEEDED = 994032;
    public static final int SSC_BP_PATTERN_INPUT_FORMAT_ERROR = 994029;

    // Data File Reader errors
    public static final int SSC_READER_DATABASE_ERROR     = 994101;
    public static final int SSC_READER_CONNECTION_ERROR   = 994102;
    public static final int SSC_READER_FILE_ACCESS_ERROR  = 994103;
    public static final int SSC_READER_FILE_ERROR         = 994104;
    public static final int SSC_READER_INTERNAL_ERROR     = 994105;

    // I-Account
    // General
    public static final int SSC_IAC_DBCONN_FAIL           = 995001;
    public static final int SSC_IAC_DBCONN_ROLLBACK       = 995002;
    public static final int SSC_IAC_DBCONN_COMMIT         = 995003;
    public static final int SSC_IAC_SQLEX_ERROR           = 995004;
    public static final int SSC_IAC_POOLMGR_CLOSED        = 995005;
    public static final int SSC_IAC_DBCONN_CLOSED         = 995006;
    public static final int SSC_IAC_RAWFILE_NOT_FOUND     = 995007;
    public static final int SSC_IAC_SCREENEDFILE_NOT_FOUND= 995008;
    public static final int SSC_IAC_NO_ACCOUNT_FOUND      = 995009;
    public static final int SSC_VIA_NO_ACCOUNT_FOUND      = 995100;
    public static final int SSC_IAC_NO_STMT_FOUND         = 995101;
    public static final int SSC_VIA_NO_STMT_FOUND         = 995102;

    //Batch Side
    //Info
    public static final int SSC_IAC_CUTMESG_SPEC_CHAR_FOUND= 995201;
    public static final int SSC_IAC_UPLOAD_SCREEN_COMPLETED= 995202;
    public static final int SSC_IAC_UPLOAD_CAPTURE_COMPLETE= 995203;

    //Error
    public static final int SSC_IAC_PURGE_STMT_FAIL        = 995301;
    public static final int SSC_IAC_PURGE_EXCH_RATE_FAIL   = 995302;
    public static final int SSC_IAC_PURGE_CUST_NAME_FAIL   = 995303;
    public static final int SSC_IAC_PURGE_CUST_ADDR_FAIL   = 995304;
    public static final int SSC_IAC_PURGE_MS_TX_FAIL       = 995305;
    public static final int SSC_IAC_PURGE_MS_CCY_FAIL      = 995306;
    public static final int SSC_IAC_PURGE_CA_TX_FAIL       = 995307;
    public static final int SSC_IAC_PURGE_FD_TX_FAIL       = 995308;
    public static final int SSC_IAC_PURGE_LIFE_FAIL        = 995309;
    public static final int SSC_IAC_PURGE_FAIL             = 995310;
    public static final int SSC_IAC_UPLOAD_STMT_FAIL       = 995311;
    public static final int SSC_IAC_UPLOAD_EXCH_RATE_FAIL  = 995312;
    public static final int SSC_IAC_UPLOAD_CUST_NAME_FAIL  = 995313;
    public static final int SSC_IAC_UPLOAD_CUST_ADDR_FAIL  = 995314;
    public static final int SSC_IAC_UPLOAD_MS_TX_FAIL      = 995315;
    public static final int SSC_IAC_UPLOAD_MS_CCY_FAIL     = 995316;
    public static final int SSC_IAC_UPLOAD_CA_TX_FAIL      = 995317;
    public static final int SSC_IAC_UPLOAD_FD_TX_FAIL      = 995318;
    public static final int SSC_IAC_UPLOAD_LIFE_FAIL       = 995319;
    public static final int SSC_IAC_CUTMESG_STMT_FAIL      = 995320;
    public static final int SSC_IAC_CUTMESG_EXCH_RATE_FAIL = 995321;
    public static final int SSC_IAC_CUTMESG_CUST_NAME_FAIL = 995322;
    public static final int SSC_IAC_CUTMESG_CUST_ADDR_FAIL = 995323;
    public static final int SSC_IAC_CUTMESG_MS_TX_FAIL     = 995324;
    public static final int SSC_IAC_CUTMESG_MS_CCY_FAIL    = 995325;
    public static final int SSC_IAC_CUTMESG_CA_TX_FAIL     = 995326;
    public static final int SSC_IAC_CUTMESG_FD_TX_FAIL     = 995327;
    public static final int SSC_IAC_CUTMESG_LIFE_FAIL      = 995328;
    public static final int SSC_IAC_CUTMESG_KEY_FAIL       = 995329;
    public static final int SSC_IAC_CUTMESG_HEADER_FAIL    = 995330;
    public static final int SSC_IAC_CUTMESG_RECORDSIZE_ERROR=995331;

    //IAC Client Side
    public static final int SSC_IAC_DBPOOL_COM_ERROR	   = 995500;
    public static final int SSC_IAC_SQL_ERROR    	   = 995501;
    public static final int SSC_IAC_CLOSE_ERROR    	   = 995502;
    public static final int SSC_IAC_PAGE_FORWARD_ERROR	   = 995503;

    //PIN REGENERATION ERRORS created at 18 Oct 2002 by Franky Cheung
    public static final int SSC_PIN_REGEN_PBID_ERROR = 995600;
    public static final int SSC_PIN_REGEN_PBID_RETRY_FAIL = 995601;
    public static final int SSC_PIN_REGEN_ID_DOB_RETRY_FAIL = 995602;
    public static final int SSC_PIN_REGEN_NON_CARD_BANKING_USER = 995603;
    public static final int SSC_PIN_REGEN_ID_DOB_NOT_MATCH_ERROR = 995604;
    public static final int SSC_PIN_REGEN_ID_DOB_FORMAT_ERROR = 995605;
    public static final int SSC_PIN_REGEN_NON_PERSONAL_BANKING_USER = 995606;
    public static final int SSC_PIN_REGEN_HKID_FORMAT_ERROR = 995607;
    public static final int SSC_PIN_REGEN_PASSPORT_FORMAT_ERROR = 995608;
    public static final int SSC_PIN_REGEN_DOB_FORMAT_ERROR = 995609;
    public static final int SSC_PIN_REGEN_OT_NUMBER_FORMAT_ERROR = 995610;
    public static final int SSC_PIN_REGEN_INVALID_PBID_STATUS = 995611;
    public static final int SSC_PIN_REGEN_RECENT_ADDR_MTCE = 995612;

    //HIGH RISK AUTHENTICATION ERRORS created at 4 Feb 03 by Franky Cheung
    public static final int SSC_HIGH_RISK_AUTH_FAILURE = 995700;
    public static final int SSC_HIGH_RISK_AUTH_LOCKED = 995701;
    public static final int SSC_HIGH_RISK_AUTH_EMPTY_DIGIT = 995702;

    // e-Cert related errors
    public static final int SSC_EMPTY_CERTIFICATE = 996000;
    public static final int SSC_EXPIRED_CERTIFICATE = 996001;
    public static final int SSC_REVOKED_CERTIFICATE = 996002;
    public static final int SSC_LOCKED_CERTIFICATE = 996003;
    public static final int SSC_INVALID_CERTIFICATE = 996004;
    public static final int SSC_INVALID_HKID_HASH = 996005;
    public static final int SSC_INVALID_SIGNATURE = 996006;
    public static final int SSC_CUSTOMERID_NOT_SET = 996007;
    public static final int SSC_NO_REGISTER_CERT = 996008;
    public static final int SSC_ALREADY_REGISTER_CERT = 996009;
    public static final int SSC_FATAL_ERROR_VALIDATE_CERT = 996010;
    public static final int SSC_FATAL_ERROR_VALIDATE_SIG = 996011;
    public static final int SSC_FATAL_ERROR_PARSE_CERT = 996012;
    public static final int SSC_CUSTOMER_NOT_FOUND = 996013;
    public static final int SSC_HKID_NOT_MATCH = 996014;
    public static final int SSC_CERT_NOT_REGISTER = 996015;
    public static final int SSC_UNRECOGNIZED_CA = 996016;
    public static final int SSC_CRL_UPDATE_FAILURE = 996017;
          //LAM CHI KAI : e-Cert related errors added for bankCert system
          //LAM CHI KAI : LDAP lookup and CRL checking
    public static final int SSC_HKP_LDAP_CONNECTION_FAILURE = 996018;
    public static final int SSC_HKP_LDAP_QUERY_FAILURE = 996019;
    public static final int SSC_HKP_LDAP_ECERT_NOT_FOUND = 996020;
    public static final int SSC_CRL_FILE_NOT_FOUND = 996021;
    public static final int SSC_CRL_FORMATION_FAILURE = 996022;
    public static final int SSC_CRL_NOT_INITIALIZED = 996023;
    public static final int SSC_ECERT_FORMATION_FAILURE = 996024;


// Customer Profile Maintenance:
public static final int SSC_ADDR_EMPTY = 996100;
public static final int SSC_PAGERFAX_REQ = 996101;
public static final int SSC_PAGER_NUM_EMPTY = 996102;
public static final int SSC_FAX_NUM_EMPTY = 996103;
public static final int SSC_SPEC_ACCT1_EMPTY = 996104;
public static final int SSC_SPEC_ACCT_NOT_EMPTY = 996105;
public static final int SSC_SAFE_BOX_NO_EMPTY = 996106;
public static final int SSC_SAFE_BOX_BRCH_REQ = 996107;
public static final int SSC_HOME_TEL_INVALID = 996108;
public static final int SSC_MOBILE_INVALID = 996109;
public static final int SSC_OFF_TEL_INVALID = 996110;
public static final int SSC_INVALID_CHAR = 996111;
public static final int SSC_NON_NUMERIC = 996112;
public static final int SSC_EFF_DATE_TYPE_REQ = 996113;
public static final int SSC_ACCT_TYPE_REQ = 996114;
public static final int SSC_NO_CHANGE = 996115;
public static final int SSC_EFF_DATE_REQ = 996116;

// Customer Email Maintenance
public static final int SSC_EMAIL1_INCOMPLETE = 996117;
public static final int SSC_EMAIL2_INCOMPLETE = 996118;
public static final int SSC_EMAIL_INVALID = 996119;
public static final int SSC_EMAIL_NOT_IN_SEQ = 996120;

//Credit Card Online Payment, front-end errors -- eBPP Enhancement (SP02132), 2003/02/21
public static final int SSC_EMPTY_EMAIL_ADDR = 996121;
public static final int SSC_INVALID_EMAIL_ADDR = 996122;
public static final int SSC_EMPTY_PAYMENT_AMOUNT = 996123;
public static final int SSC_INVALID_PAYMENT_AMOUNT = 996124;
public static final int SSC_EMPTY_DEBIT_ACCT = 996125;
public static final int SSC_EMPTY_CREDIT_ACCT = 996126;
public static final int SCC_CREDIT_BALANCE = 996127;

//MGM Loan Programme 2004/04/15
public static final int SSC_MGM_LOAN_EMPTY_NAME = 996151;
public static final int SSC_MGM_LOAN_EMPTY_REFEREE_NAME = 996152;
public static final int SSC_MGM_LOAN_EMPTY_REFEREE_EMAIL = 996153;
public static final int SSC_MGM_LOAN_INVALID_REFEREE_EMAIL = 996154;
public static final int SSC_MGM_LOAN_DUPLICATE_REFEREE_EMAIL = 996155;
public static final int SSC_MGM_LOAN_EMPTY_EMAIL = 996156;
public static final int SSC_MGM_LOAN_INVALID_EMAIL = 996157;
//MGM Loan Programme 2004/06/16
public static final int SSC_MGM_LOAN_EMPTY_CARDNO = 996159;
public static final int SSC_MGM_LOAN_INVALID_CARDNO = 996160;


	//In-money and Express momney online form
	public static final int SSC_EXP_EMPTY_LOAN_AMOUNT = 996161;
	public static final int SSC_EXP_INVALID_LOAN_AMOUNT = 996162;
	public static final int SSC_EXP_RANGE_LOAN_AMOUNT = 996163;
	public static final int SSC_EXP_EMPTY_DISBURSEMENT_METHOD = 996164;
	public static final int SSC_EXP_EMPTY_DIS_BANK_ACCOUNT_NO = 996165;
	public static final int SSC_EXP_EMPTY_DIS_BRANCH = 996166;
	public static final int SSC_EXP_EMPTY_NAME = 996167;
	public static final int SSC_EXP_EMPTY_IDENTITY_NO = 996168;
	public static final int SSC_EXP_EMPTY_DATE_OF_BIRTH = 996169;
	public static final int SSC_EXP_INVALID_DATE_OF_BIRTH = 996170;
	public static final int SSC_EXP_INVALID_EMPLOYER_NAME = 996171;
	public static final int SSC_EXP_EMPTY_CONTACT_NO = 996172;
	public static final int SSC_EXP_INVALID_ADDRESS = 996173;
	public static final int SSC_EXP_INVALID_REPAY_BANK_BRANCH = 996174;
	public static final int SSC_EXP_EMPTY_REPAY_BANK_CODE = 996175;
	public static final int SSC_EXP_EMPTY_REPAY_BRANCH_CODE = 996176;
	public static final int SSC_EXP_EMPTY_REPAY_ACC_NO = 996177;
	public static final int SSC_EXP_EMPTY_REPAY_ACC_NAME = 996178;
	public static final int SSC_EXP_EMPTY_EMPLOYER_NAME = 996179;
	public static final int SSC_EXP_EMPTY_ADDRESS = 996180;
	public static final int SSC_EXP_INVALID_REPAY_BANK_CODE = 996181;
	public static final int SSC_EXP_INVALID_REPAY_BRANCH_CODE = 996182;
	public static final int SSC_EXP_INVALID_REPAY_ACC_NO = 996183;
	public static final int SSC_IN_MONEY_RANGE_LOAN_AMOUNT = 996184;

	// Rewards Redemption
	public static final int SSC_CARD_RULE_FAILED = 996200;
	public static final int SSC_INVALID_ACCT_NUM = 996201;
	public static final int SSC_EMPTY_DAY_PHONE = 996202;
	public static final int SSC_INVALID_DAY_PHONE = 996203;
	public static final int SSC_NO_ITEM_SELECTED = 996204;
	public static final int SSC_INVALID_ITEM_QTY = 996205;
	public static final int SSC_ITEM_QTY_TOO_LARGE = 996206;
	public static final int SSC_ITEM_QTY_TOO_SMALL = 996207;
	public static final int SSC_EMPTY_ENG_NAME = 996208;
	public static final int SSC_INVALID_ENG_NAME = 996209;
	public static final int SSC_EMPTY_ID_TYPE = 996210;
	public static final int SSC_EMPTY_ID_NUM = 996211;
	public static final int SSC_INVALID_HKID = 996212;
	public static final int SSC_INVALID_PASSPORT = 996213;
	public static final int SSC_EMPTY_REDEEM_ACCT_LIST = 996214;
	public static final int SSC_INVALID_NIGHT_PHONE = 996215;
	public static final int SSC_EMPTY_FFC_REDEEM_ACCT_LIST = 996216;
    public static final int SSC_ORDER_QTY_EXCEED_LIMIT = 996217;

    //Credit Card Online Instalment
    public static final int SSC_CCOI_QUANTITY_EXCEED = 997000;
    public static final int SSC_CCOI_DELIVERY_DETAILS_MISSING = 997001;
    public static final int SSC_CCOI_CONTACT_MISSING = 997002;
    public static final int SSC_CCOI_SUB_PROD_OUT_OF_STOCK = 997003;

    // eIPO Application
    public static final int SSC_EIPO_APPLY_BEGIN = 998000;
    public static final int SSC_EIPO_APPLY_END   = 998001;
    public static final int SSC_EIPO_CANCEL_BEGIN= 998002;
    public static final int SSC_EIPO_CANCEL_END= 998003;
    public static final int SSC_EIPO_ENQ_BEGIN= 998004;
    public static final int SSC_EIPO_ENQ_END= 998005;
    public static final int SSC_EIPO_OUTPUT_NOT_FOUND= 998006;

    // eIPO Payment
    public static final int SSC_EIPO_PAYMENT_AMOUNT_NOT_MATCH = 997101;
    public static final int SSC_EIPO_APPL_NUM_NOT_MATCH = 997102;
    public static final int SSC_EIPO_STOCK_CODE_NOT_MATCH = 997103;
    public static final int SSC_EIPO_PAID_ALREADY = 997104;

    public static final int SSC_IPO_PAYMENT_AMOUNT_NOT_MATCH = 997101;
    public static final int SSC_IPO_APPL_NUM_NOT_MATCH = 997102;
    public static final int SSC_IPO_STOCK_CODE_NOT_MATCH = 997103;
    public static final int SSC_IPO_PAID_ALREADY = 997104;

    public static final int SSC_UT_GRAND_FUND_PORT_ERROR = 997200;
    public static final int SSC_UT_INVESTMENT_FUND_ERROR = 997201;
    public static final int SSC_UT_FUND_HOLDING_DETAIL_ERROR = 997202;
    public static final int SSC_UT_ACCT_TXN_ERROR = 997203;

	//for Securities:
    public static final int SSC_SEC_ACCT_DETAIL_ERROR = 997300;
    public static final int SSC_SEC_TXN_HIST_ERROR = 997301;
	public static final int SSC_SEC_ACCT_UPD_ERROR = 997302;

	//for Retail Bond/ Notes
    public static final int SSC_RB_HOLDING_DETAIL_ERROR = 997400;
    public static final int SSC_RB_ACCT_TXN_ERROR = 997401;
    
    // ISEC LOGIN
    public static final int SCC_ISEC_CUST_CONSENT_STATUS_INVALID = 998451;
    
    // Phase 2c
    // Pending Instructions Management
    //public static final int SSC_INSTR_ALREADY_EXECUTED = 998800;
    //public static final int SSC_INSTR_NOT_EXIST = 998801;
    public static final int SSC_EJB_CREATION_ERROR = 998802;
    public static final int SSC_EJB_GENERAL_ERROR = 998803;
    public static final int SSC_EJB_NOT_FOUND = 998804;
    public static final int SSC_DDA_RECORD_NOT_FOUND = 998805;
    public static final int SSC_INSTR_STATUS_ALTER_FAILURE = 998806;
    public static final int SSC_INSTR_BATCH_TERMINATE = 998814;

    // scheduling
    public static final int SSC_SCHED_DATE_NORMAL = 998807;
    public static final int SSC_SCHED_DATE_NOT_EXIST = 998808;
    public static final int SSC_SCHED_ON_PUBLIC_HOLIDAY = 998809;
    public static final int SSC_SCHED_ON_SUNDAY = 998810;
    public static final int SSC_SCHED_OUT_OF_DATE_RANGE = 998811;
    public static final int SSC_SCHED_NO_VALID_ADJUSTABLE_DATE = 998812;
    public static final int SSC_SCHED_DATE_PAST = 998813;
    public static final int SSC_SCHED_POST_INSTR_EXIST = 998815;

	// fund search
	public static final int SSC_IO_READ_DBPROP_ERR = 999001;
	public static final int SSC_DB_INS_FUND_ERR	= 999002;
	public static final int SSC_IO_READ_CSV_FILE_ERR = 999003;
	public static final int SSC_NO_CSV_FILE_ERR = 999004;
	public static final int SSC_DB_SRCH_ERR = 999005;
	public static final int SSC_DB_SEL_COL_ERR = 999006;
	public static final int SSC_IO_READ_FDPROP_ERR = 999007;
	public static final int SSC_DB_ERR = 999008;
	public static final int SSC_UNEXP_ECPT = 999009;
	public static final int SSC_WRONG_FILE_FRMT = 999010;
	public static final int SSC_EMPTY_FILE = 999011;
	public static final int SSC_TOO_MANY_COL = 999012;
	public static final int SSC_FILE_TOO_BIG = 999013;

	// opt out hash
	public static final int SSC_FILE_IO_EXCP = 999101;
	public static final int SSC_KEY_FILE_NOT_FOUND = 999102;
	public static final int SSC_SIGN_ALG_NOT_FOUND = 999103;
	public static final int SSC_INVALID_KEY = 999104;
	public static final int SSC_INVALID_KEY_SPEC = 999105;
	public static final int SSC_SIGN_EXCP = 999106;

        //IDD03032 Customer CRM Info Capture
        public static final int SSC_INVALID_CUST_NAME     = 999150;
        public static final int SSC_INVALID_ID            = 999151;
        public static final int SSC_INVALID_PPORT         = 999152;
        public static final int SSC_INVALID_EMAIL         = 999153;
        public static final int SSC_INVALID_MOBILE_PHONE  = 999154;
        public static final int SSC_DUPLICATE_CRM_ENTRY   = 999155;
        public static final int SSC_INVALID_CUST_TITLE    = 999156;
        public static final int SSC_TXN_RESUBMIT          = 999157;


       //PDM05217 Kiddie e-banking service
        public static final int SSC_EK_EMPTY_CUST_ID            = 999217;
        public static final int SSC_EK_EMPTY_LOGIN_ID           = 999218;
        public static final int SSC_EK_EMPTY_LOGIN_NAME         = 999219;
        public static final int SSC_EK_INVALID_LOGIN_ID_LEN     = 999220;
        public static final int SSC_EK_INVALID_LOGIN_ID_CHAR    = 999221;
        public static final int SSC_EK_EMPTY_PWD                = 999222;
        public static final int SSC_EK_INVALID_PWD_LENGTH       = 999223;
        public static final int SSC_EK_INVALID_PWD_CHAR         = 999224;
        public static final int SSC_EK_EMPTY_CFM_PWD            = 999225;
        public static final int SSC_EK_EMPTY_EMAIL_ADD          = 999226;
        public static final int SSC_EK_INVALID_EMAIL_ADD        = 999227;
        public static final int SSC_EK_PWD_NOT_MATCH            = 999228;
        public static final int SSC_EK_EXIST_KID_ID             = 999229;
        public static final int SSC_EK_EXIST_LOGIN_ID           = 999230;
	public static final int SSC_EK_LOGIN_ID_NOT_FOUND       = 999231;
	public static final int SSC_EK_LOGIN_ID_DELETED         = 999232;

        public static final int SSC_TK_EXIST_KID_ID             = 999239;
        public static final int SSC_TK_LOGIN_ID_DELETED         = 999242;
        public static final int SSC_TKID_ACCT_PROFOLIO_NOT_FOUND = 999243;

        public static final int SSC_RK_EXIST_KID_ID             = 999251;
        public static final int SSC_RK_LOGIN_ID_DELETED         = 999252;
        public static final int SSC_RKID_ACCT_PROFOLIO_NOT_FOUND = 999253;
        
        public static final int SSC_BK_EXIST_KID_ID             = 999255;
        public static final int SSC_BK_LOGIN_ID_DELETED         = 999256;
        public static final int SSC_BKID_ACCT_PROFOLIO_NOT_FOUND = 999257;

	//COI
	public static final int SCC_COI_COMM_ERROR = 	999301;
    public static final int SCC_COI_TIMEOUT_ERROR =    999302;

    // miscellaneous
    public static final int SSC_ACCT_NUM_DECODE_ERROR = 999901;
    public static final int SSC_ID_TYPE_DECODE_ERROR = 999902;
    public static final int SSC_FD_TERMS_DEF_MISMATCH = 999903;
    public static final int SSC_REQ_EMPTY_OR_INVALID = 999904;
    public static final int SSC_BOA_RESP_ERROR = 999905;
    public static final int SSC_INVALID_ACCT_TYPE = 999906;
    public static final int SSC_FILTER_NOT_FOUND = 999907;
    public static final int SSC_ACCT_DESC_NOT_FOUND = 999908; // cannot match acct_type and prod_sub_code in acct_desc table
    public static final int SSC_FUNCT_TYPE_NOT_SUPPORTED = 999909;
    public static final int SSC_TF_TXTYPE_NOT_SET = 999910;
    public static final int SSC_NO_AGENT_AVAILABLE = 999911;
    public static final int SSC_BRANCH_CODE_LOOKUP_ERROR = 999912;
	public static final int SSC_MAIL_SENDING_ERROR = 999913;
	public static final int SSC_CHANNEL_NOT_SUPPORTED = 999914;
    public static final int SSC_ACCT_NOT_IN_PICKLIST = 999915;
    public static final int SSC_NO_TX_RESUBMIT = 999916;
    public static final int SSC_DELETED_BANK_CODE = 999917;
    public static final int SSC_UNEXPECTED = 999999;

    public static final int SSC_IS_EXISTING_CUSTOMER = 999972;
    public static final int SSC_IS_NEW_NEW_CUSTOMER = 999973;


}
