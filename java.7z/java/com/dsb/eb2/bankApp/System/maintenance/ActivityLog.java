package com.dsb.eb2.bankApp.System.maintenance;

import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dsb.eb2.bankApp.System.FunctionType;
import com.dsb.eb2.bankApp.dao.activityLog.ActivityLogBean;
import com.dsb.eb2.bankApp.dao.activityLog.ActivityLogRepository;

@Service
public class ActivityLog {
	
  
  @Autowired
  ActivityLogRepository activityLogRepository ;
	
  private static Logger log = LoggerFactory.getLogger(ActivityLog.class);

   /* logs record to summary and/or activity table based on normal flow:-
     enquiry based - only to summary table
     txn based - to both summary and activty table
   */
  public final static int NORMAL_LOG_TYPE = 0;
  // logs record to summary table only
  public final static int SUMMARY_LOG_TYPE = 1;
  // logs record to activity table only
  public final static int ACTIVITY_LOG_TYPE = 2;
  // logs record to both table
  public final static int BOTH_LOG_TYPE = 3;
  
  private java.util.Date logDateTime=new java.util.Date();

  public synchronized void  record(ActivityLogBean bean) {
    record(NORMAL_LOG_TYPE,bean);
  }

  public synchronized void record(int logType,ActivityLogBean bean) {
      oldRecord(logType,bean);
  }
  
  private String getLogDetails(String iString,ActivityLogBean bean) {
    StringBuffer sbActLogDtls = new StringBuffer();
    sbActLogDtls.append(""+ iString).append(" - ");
    sbActLogDtls.append("[").append(bean.getCustId()).append("]");
    sbActLogDtls.append("[").append(logDateTime).append("]");
    sbActLogDtls.append("mainType=[").append(bean.getMainType()).append("]");
    sbActLogDtls.append("subType=[").append(bean.getSubType()).append("]");
    sbActLogDtls.append("extType=[").append(bean.getExtendedType()).append("]");
    sbActLogDtls.append("returnCode=[").append(bean.getReturnCode()).append("]");
    sbActLogDtls.append("channelCode=[").append(bean.getChannelCode()).append("]");
    sbActLogDtls.append("dtls=[").append(bean.getDetails()).append("]");
    sbActLogDtls.append("sessionId=[").append(bean.getSessionId()).append("]");
    log.error(sbActLogDtls.toString());
    return sbActLogDtls.toString();
  }

  public void oldRecord(int logType,ActivityLogBean bean){
	try {
	  switch (logType) {
		case NORMAL_LOG_TYPE:  {
			recordSummary();
			if (!FunctionType.isEnquiryType(bean.getMainType(),bean.getSubType())) {
				log.debug(getLogDetails("Logging2"+FunctionType.isEnquiryType(bean.getMainType(),bean.getSubType()),bean));
				recordActivity(bean);
			}
			break;
		}
		case SUMMARY_LOG_TYPE: {
			recordSummary();
			break;
		}
		case ACTIVITY_LOG_TYPE: {
			recordActivity(bean);
			break;
		}
		default: {
			recordSummary();
			recordActivity(bean);
			break;
		}
	  }
    } catch (SQLException ex) {
		log.error(getLogDetails("UpdateLog3b",bean));
	}
  }

  private void recordSummary() throws SQLException {

  }

  private void recordActivity(ActivityLogBean bean) throws SQLException {
	  logDateTime = new java.util.Date();
	  activityLogRepository.insertActivityLogBean(bean.getCustId(),bean.getMainType(),bean.getSubType(),bean.getExtendedType(),
    		  bean.getReturnCode(),bean.getChannelCode(),bean.getDetails(),new java.sql.Timestamp(logDateTime.getTime()),bean.getSessionId());
  }

  public void setLogDateTime(java.util.Date logDateTime) {
      this.logDateTime = logDateTime;
  }
  
  public void insertActivityLog(String custId,String details,int returnCode){
	  try {
		ActivityLogBean bean = new ActivityLogBean();
		  bean.setCustId(custId);
		  bean.setMainType(FunctionType.MF_PIN_REGEN);
		  bean.setSubType(FunctionType.SF_REMOVAL);
		  bean.setDetails(details);
		  bean.setReturnCode(returnCode);
		  record(bean);
	} catch (Exception e) {
		log.error(e.getMessage(),e);
	}
  }
  
  private ActivityLogBean bean;

  public ActivityLogBean getBean() {
	return bean;
  }
  public void setBean(ActivityLogBean bean) {
	this.bean = bean;
  }
  public synchronized void record() {
	 record(NORMAL_LOG_TYPE,bean);
  }

}