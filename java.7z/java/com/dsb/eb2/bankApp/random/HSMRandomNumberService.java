package com.dsb.eb2.bankApp.random;


import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;


@Service
public class HSMRandomNumberService {
	
	private static Logger logger = LoggerFactory.getLogger(HSMRandomNumberService.class);
	
	public static final String CONST_CORRECT = "00";
	public static final String CONST_IS_EXPIRED = "01";
	public static final String CONST_INVALID_SRING_FORMAT = "02";
	public static final String CONST_INVALID_OTHER_ERROR = "99";
	
	private int expriedAfternMinutes = 60; 
	
	private BigInteger weighting = new BigInteger("10000000000");
	private SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyyHHmm");

	public String validHSMRandomNumber(String inputNumber)
	{
		String 		realTimeStamp;
		Calendar 	issueDate;
		HSMRandomNumber r = new HSMRandomNumber(inputNumber); 
		
		try 
		{
			if (!r.isValidFormat()) throw new Exception();
			if (isInavlidCheckSum(r)) throw new Exception();				
			
			realTimeStamp = getRealTimStamp(r.getRandomNumber(), r.getTimeStamp());
			issueDate = timeStamp2Calendar(realTimeStamp);
			
			logger.info(issueDate.getTime().toString());
			
		} catch (Exception c)
		{
			return CONST_INVALID_SRING_FORMAT;
		}
		
		String skip_Verify_timestamp = com.dsb.eb2.bankApp.System.SystemConfig.getSystemParameter("skip_random_num_verify_timestamp");
		if(!"true".equals(skip_Verify_timestamp))
		{
			try
			{
				if (isTimeStampExpired(issueDate)) return CONST_IS_EXPIRED;
			} catch (Exception c)
			{
				return CONST_INVALID_OTHER_ERROR ;
			}
		}
		return CONST_CORRECT;
	}

    private String getRealTimStamp(String randomNumber, String timeStamp) {
        
        BigInteger randomNumberB = new BigInteger (randomNumber);
        BigInteger timeStampB    = new BigInteger (timeStamp);

    	String resultString = "";
        
        if (timeStampB.compareTo(randomNumberB) <= 0) 
               resultString = timeStampB.add(weighting).subtract(randomNumberB).toString();
        else
               resultString = timeStampB.subtract(randomNumberB).toString();

        // left pad "0" to cater missing "0" during string-to-BigInteger conversion
        resultString = "0000000000".concat(resultString);
        return resultString.substring(resultString.length()-10);
    }

	private boolean isInavlidCheckSum(HSMRandomNumber r) throws Exception {

		int sumOfTimpStamp = 0;
		
		for (int i = 0, n = r.getHsmRandomNumber().length()-1; i < n; i++)
			sumOfTimpStamp+= Integer.parseInt(r.getHsmRandomNumber().substring(i, i+1));
		
		return  ((sumOfTimpStamp%10)!=Integer.parseInt(r.getCheckDight()));
		
	}

	private Calendar timeStamp2Calendar(String realTimeStamp) throws Exception 
	{
		Calendar c = Calendar.getInstance();
		StringBuffer adjTimeStamp = new StringBuffer(realTimeStamp);
		adjTimeStamp.insert(4, "20");   
		c.setTime(sdf.parse(adjTimeStamp.toString()));
		return c;
	}

	private boolean isTimeStampExpired(Calendar timeStampC) {
		Calendar now = Calendar.getInstance();
		now.add(Calendar.MINUTE, expriedAfternMinutes *-1 );
		return now.after(timeStampC);
	}

}
