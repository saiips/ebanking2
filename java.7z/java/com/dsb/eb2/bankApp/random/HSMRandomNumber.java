package com.dsb.eb2.bankApp.random;

public class HSMRandomNumber {

		public static final int CONST_HSM_STRING_LENGHT = 21;

		private String randomNumber;
		private String timeStamp;
		private String checkDight;
		private String hsmRandomNumber;

		public HSMRandomNumber(String hsmRandomNumber) {
			
			this.hsmRandomNumber	= hsmRandomNumber;
			
			if (hsmRandomNumber != null)
			{	
				if (hsmRandomNumber.length()==CONST_HSM_STRING_LENGHT )
				{	
					this.randomNumber 		= hsmRandomNumber.substring(0,10);
					this.timeStamp 			= hsmRandomNumber.substring(10, 20);
					this.checkDight      	= hsmRandomNumber.substring(20);
				}
			}	
		}
		
		public String getRandomNumber() {
			return randomNumber;
		}

		public String getTimeStamp() {
			return timeStamp;
		}

		public String getCheckDight() {
			return checkDight;
		}

		public String getHsmRandomNumber() {
			return hsmRandomNumber;
		}
		
		public boolean isValidFormat()
		{
			return ((hsmRandomNumber.length()==CONST_HSM_STRING_LENGHT) && hsmRandomNumber.matches("^[0-9]*$"));
		}
}
