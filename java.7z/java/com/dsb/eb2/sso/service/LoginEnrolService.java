package com.dsb.eb2.sso.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.dsb.eb2.backOffice.connect.emsMsg.nf1108.NF1108ReqData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1618.EAlertDetails;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1625.NF1625ReqData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1625.SuppressFlagDetails;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.sso.constant.FirstTimeLoginConstant;

@Service
public class LoginEnrolService {

	public void serviceEnrol(String eFlag, String svtsLimit)
	{
		if(FirstTimeLoginConstant.OPTIN_YES.equals(eFlag))
		{
			NF1625ReqData nF1625ReqData = new NF1625ReqData();
			
			List<SuppressFlagDetails> SuppressFlagDetailsList = new ArrayList<SuppressFlagDetails>();
			
			SuppressFlagDetails suppressFlagDetails = new SuppressFlagDetails();
			suppressFlagDetails.setType(FirstTimeLoginConstant.TYPE_STMT);
			suppressFlagDetails.setProductType(FirstTimeLoginConstant.DEPOSIT_STATEMENT);
			suppressFlagDetails.setSuppressFlag(FirstTimeLoginConstant.OPTIN_YES);
			SuppressFlagDetailsList.add(suppressFlagDetails);
			
			suppressFlagDetails = new SuppressFlagDetails();
			suppressFlagDetails.setType(FirstTimeLoginConstant.TYPE_STMT);
			suppressFlagDetails.setProductType(FirstTimeLoginConstant.CREDIT_CARD_STATEMENT);
			suppressFlagDetails.setSuppressFlag(FirstTimeLoginConstant.OPTIN_YES);
			SuppressFlagDetailsList.add(suppressFlagDetails);
			
			suppressFlagDetails = new SuppressFlagDetails();
			suppressFlagDetails.setType(FirstTimeLoginConstant.TYPE_STMT);
			suppressFlagDetails.setProductType(FirstTimeLoginConstant.SECURITIES_TRADING_STATEMENT);
			suppressFlagDetails.setSuppressFlag(FirstTimeLoginConstant.OPTIN_YES);
			SuppressFlagDetailsList.add(suppressFlagDetails);
			
			suppressFlagDetails = new SuppressFlagDetails();
			suppressFlagDetails.setType(FirstTimeLoginConstant.TYPE_STMT);
			suppressFlagDetails.setProductType(FirstTimeLoginConstant.FIXED_DEPOSIT_ADVICE);
			suppressFlagDetails.setSuppressFlag(FirstTimeLoginConstant.OPTIN_YES);
			SuppressFlagDetailsList.add(suppressFlagDetails);
			
			suppressFlagDetails = new SuppressFlagDetails();
			suppressFlagDetails.setType(FirstTimeLoginConstant.TYPE_STMT);
			suppressFlagDetails.setProductType(FirstTimeLoginConstant.REMITTANCE_ADVICE);
			suppressFlagDetails.setSuppressFlag(FirstTimeLoginConstant.OPTIN_YES);
			SuppressFlagDetailsList.add(suppressFlagDetails);
			
			suppressFlagDetails = new SuppressFlagDetails();
			suppressFlagDetails.setType(FirstTimeLoginConstant.TYPE_STMT);
			suppressFlagDetails.setProductType(FirstTimeLoginConstant.SECURITIES_TRADING_ADVICE);
			suppressFlagDetails.setSuppressFlag(FirstTimeLoginConstant.OPTIN_YES);
			SuppressFlagDetailsList.add(suppressFlagDetails);
			
			nF1625ReqData.setNumOfItems("06");
			nF1625ReqData.setSuppressFlagDetails(SuppressFlagDetailsList);
			
			
			
			
			
			
		}
	}
	
	
	private int CallNF1618()
	{
		NF1108ReqData nF1108ReqData = new NF1108ReqData();
		EAlertDetails eAlertDetails = new EAlertDetails();
		eAlertDetails.setType(FirstTimeLoginConstant.Service_InwardRemittance);
		eAlertDetails.setOptInFlag("Y");
		
		
		return SystemStatusCode.SSC_NORMAL;
	}
}
