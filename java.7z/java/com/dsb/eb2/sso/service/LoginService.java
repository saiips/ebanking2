package com.dsb.eb2.sso.service;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dsb.eb2.api.services.CustomerService;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1108.NF1108RepData;
import com.dsb.eb2.bankApp.dao.cusSession.CusSessionRepository;
import com.dsb.eb2.bankApp.dao.customer.CustomerBean;
import com.dsb.eb2.bankApp.dao.customer.CustomerRepository;
import com.dsb.eb2.framework.controller.RequestCorrelation;
import com.dsb.eb2.util.DateUtils;
import com.dsb.eb2.util.StringUtils;

@Service
public class LoginService {
	private static Logger logger = LoggerFactory.getLogger(LoginService.class);

	@Autowired
	private CusSessionRepository cusSessionRepository;
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@Autowired
	private CustomerService customerService;

	
	public void saveCusSession() throws Exception {
		logger.info("RequestCorrelation.getSessionUUID()=" + RequestCorrelation.getSessionUUID());
		if (RequestCorrelation.getSessionUUID() == null) return;
		cusSessionRepository.insertCusSession(RequestCorrelation.getSessionUUID(),"login",0L);
	}

	public void saveCustomerBean(String custId) throws Exception {
		CustomerBean customerBean = new CustomerBean();
		customerBean.setCustId(custId);
		customerBean.setEbankId(custId);
		customerBean.setEbankIdStatus("A");
		setCustomerAttrFormNF1108(customerBean,custId);
		customerBean.setVersion(0L);
		customerBean.setFirstRegDate(new Date());
		customerRepository.save(customerBean);
	}

	public void setCustomerAttrFormNF1108(CustomerBean customerBean, String custId) throws Exception {
		NF1108RepData resp1108 = customerService.loadCustDetailsFromAgent(custId);
		customerBean.setFullName(resp1108.getCustNameLine1()+resp1108.getCustNameLine2());
		customerBean.setTitle(resp1108.getTitle());
		customerBean.setSex(resp1108.getSex());
		String dateOfBirth = resp1108.getDateOfBirth();
		if(!StringUtils.isBlank(dateOfBirth)) {
			customerBean.setDateOfBirth(DateUtils.parse(dateOfBirth, "yyyyMMdd"));
		}
		customerBean.setStaffInd(resp1108.getStaffInd());
	}
	
}