package com.dsb.eb2.sso.service;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dsb.eb2.api.custPerEmail.CustPerEmailService;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.System.exeption.ExtendedException;
import com.dsb.eb2.bankApp.random.HSMRandomNumberService;
import com.dsb.eb2.sso.model.CustomerInfo;
import com.dsb.eb2.util.StringUtils;

@Service
public class LoginValidateService {
	private static final String logCategory = "EBANK";
	private static Logger log = LoggerFactory.getLogger(LoginValidateService.class);

	@Autowired
	private HSMRandomNumberService hsmRandomNumberService;

	@Autowired
	private CustPerEmailService custPerEmailService;

	public int validatePinRetrunAndRandom(String retrunMsg, String randomNum,
			String biometricLogin) {
		int result = SystemStatusCode.SSC_NORMAL;

		String eBankLoginMedium = com.dsb.eb2.bankApp.System.SystemConfig.getSystemParameter("eBank_login_medium");
		if (!"webPin".equals(eBankLoginMedium) || "Y".equals(biometricLogin)) {
			log.info("nShield login");
			return result;
		}

		if ( StringUtils.isEmpty(retrunMsg) || StringUtils.isEmpty(randomNum)) {
			log.info("returnCode / retrunMsg/ randomNum is empty");
			result = SystemStatusCode.SSC_INCORRECT_PWD;
		} else {
			if (retrunMsg.startsWith("E")) {
				result = SystemStatusCode.SSC_INCORRECT_PWD;
			}
			String validRandomNumResult = hsmRandomNumberService.validHSMRandomNumber(randomNum);
			log.info("validRandomNumResult = " + validRandomNumResult);
			if (!HSMRandomNumberService.CONST_CORRECT.equals(validRandomNumResult)) {
				result = SystemStatusCode.SSC_INCORRECT_PWD;
			}
		}
		log.info("validatePinRetrunAndRandom resullt = " + result);
		return result;
	}

	public void resetSeesion(HttpServletRequest request) {
		HttpSession session = request.getSession();
		HashMap<String, Object> old = new HashMap<String, Object>();
		Enumeration keys = (Enumeration) session.getAttributeNames();
		while (keys.hasMoreElements()) {
			String key = (String) keys.nextElement();

			if (!key.equals("session_listener") && !"mode".equals(key)) {
				old.put(key, session.getAttribute(key));
			}
			session.removeAttribute(key);
		}
		session.invalidate();
		session = request.getSession(true);
		for (Map.Entry entry : old.entrySet()) {
			session.setAttribute((String) entry.getKey(), entry.getValue());
		}
	}

	public String getPerEmailStatus(HttpSession session, CustomerInfo customer) throws ExtendedException {
		boolean requireDesignatedEmailReminder = false;
		try {
			session.setAttribute("customer_session", customer);
			requireDesignatedEmailReminder = custPerEmailService.isNeedToAddChgEmailAddr(customer);
		} catch (Exception e) {
			throw new ExtendedException(ExtendedException.APP_TYPE, ExtendedException.E_BANKING,
					SystemStatusCode.SSC_UNEXPECTED, e.getMessage());
		}
		if (!requireDesignatedEmailReminder) {
			return String.valueOf(SystemStatusCode.SSC_EMAIL2_INCOMPLETE);
		}
		return String.valueOf(SystemStatusCode.SSC_NORMAL);
	}

	/**
	 * 校驗8-15位字符和數字的字符串
	 * @param str
	 * @return
	 */
	public boolean validatePsw(String str){
		String regEx = "^(?![0-9]+$)(?![A-Za-z]+$)[A-Za-z\\d]{8,15}$";
		return regexMatch(str,regEx);
	}
	
	/**
	 * 校驗6-20位字符或數字的字符串
	 * @param str
	 * @return
	 */
	public boolean validateEbid(String str){
		String regEx = "^[A-Za-z0-9]{6,20}$";
		return regexMatch(str,regEx);
	}
	
	public boolean regexMatch(String str,String regEx){
		Pattern pattern = Pattern.compile(regEx);
		Matcher matcher = pattern.matcher(str);
		return matcher.matches();
	}
	
}