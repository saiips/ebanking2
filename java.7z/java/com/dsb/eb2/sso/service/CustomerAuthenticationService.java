package com.dsb.eb2.sso.service;

import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dsb.eb2.api.services.CustomerService;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1108.NF1108RepData;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.System.exeption.ExtendedException;
import com.dsb.eb2.bankApp.System.exeption.SystemException;
import com.dsb.eb2.bankApp.dao.custHaltList.CustHaltListBean;
import com.dsb.eb2.bankApp.dao.custHaltList.CustHaltListService;
import com.dsb.eb2.bankApp.dao.customer.CustomerBean;
import com.dsb.eb2.bankApp.dao.customer.CustomerDaoImpl;
import com.dsb.eb2.bankApp.dao.customer.CustomerRepository;
import com.dsb.eb2.bankApp.pinServer.PinServer;
import com.dsb.eb2.sso.model.CustomerInfo;
import com.dsb.eb2.util.StringUtils;

@Service
public class CustomerAuthenticationService {

	private static Logger log = LoggerFactory.getLogger(CustomerAuthenticationService.class);

	@Autowired
	private CustHaltListService custHaltListService;
	
	@Autowired
	private CustomerService customerService;
	
	@Autowired
	private CustomerDaoImpl customerDaoImpl;
	
	@Autowired
	private CustomerRepository customerRepository;

	public int validate(String pin, String pinChkSum, String publicKeyIndex, String randomNumber, boolean subSysSwitch, boolean fromNewRegFrom,
			String biometricLogin, PinServer pinServer, String sWebPin, String sCustId)
			throws ExtendedException {
		int iRet = SystemStatusCode.SSC_NORMAL;
		CustomerBean customerBean = null;
		try {
			customerBean = queryEBID(sCustId);
		} catch (Exception e) {
			log.error("query queryEBID() error msg:" + e.toString(), e);
			return SystemStatusCode.SSC_UNEXPECTED;
		}
		if(null != customerBean) {
			String ebidStatus = customerBean.getEbankIdStatus();
			if(!StringUtils.isEmpty(ebidStatus) && "A".equals(ebidStatus)) {
				iRet = SystemStatusCode.SSC_NORMAL;
			}else{
				iRet = SystemStatusCode.SSC_UNEXPECTED;
			}
		} else {
			// TODO insert into Customer
			iRet = SystemStatusCode.SCC_PB_FIRST_LOGIN;
		}
		
		if ((iRet == SystemStatusCode.SSC_NORMAL) && (fromNewRegFrom == false))
			iRet = pinVerification(customerBean.getCustId(),pin, pinChkSum, publicKeyIndex, randomNumber, subSysSwitch, biometricLogin, pinServer, sWebPin);

		if ((iRet == SystemStatusCode.SSC_NORMAL) && (fromNewRegFrom == true))
			iRet = SystemStatusCode.SSC_IS_EXISTING_CUSTOMER;

		if (isHalted(sCustId)) {
			iRet = SystemStatusCode.SSC_PB_HOT_ID;
		}
		return iRet;
	}

	public int pinVerification(String custId, String sPin, String sPinChkSum, String publicKeyIndex, String randomNumber, boolean subSysSwitch, String biometricLogin,
			PinServer pinServer, String sWebPin) throws ExtendedException {
		try {
			int verifyPinReturnCode = VerifyPin(custId, subSysSwitch, biometricLogin, pinServer, sWebPin,
					sPinChkSum, publicKeyIndex, randomNumber);
			if (verifyPinReturnCode != SystemStatusCode.SSC_NORMAL) {
				if (verifyPinReturnCode != com.dsb.eb2.bankApp.System.SystemStatusCode.SSC_VERIFY_PIN_SUCCESS_NEEDS_PIN_CHANGE) {
					return verifyPinReturnCode;
				} else {
					verifyPinReturnCode = SystemStatusCode.SSC_NORMAL;
				}
			}
			return verifyPinReturnCode;
		} catch (Exception ex) {
			throw new ExtendedException(ExtendedException.APP_TYPE, ExtendedException.E_BANKING,
					SystemStatusCode.SSC_UNEXPECTED, "Exception in Pin Verification");
		}
	}

	private int VerifyPin(String custId, boolean subSysSwitch, String biometricLogin, PinServer pinServer,
			String sWebPin, String sPinChkSum, String publicKeyIndex, String randomNumber) {
		int verifyPinReturnCode = 0;
		try {
			if (!subSysSwitch && !"Y".equals(biometricLogin)) {
				verifyPinReturnCode = pinServer.webPinLogin(custId, sWebPin, sPinChkSum, publicKeyIndex, randomNumber);
			} else {
				verifyPinReturnCode = SystemStatusCode.SSC_NORMAL;
			}
		} catch (Exception e) {
			log.error(e.toString(), e);
			verifyPinReturnCode = SystemStatusCode.SSC_UNEXPECTED;
		}
		return verifyPinReturnCode;
	}

	/**
	 * check the user is halted or not and call CheckHalt.java input: userid , login
	 * type (it is stored as a hidden value in the HTML form, it can be ECERT or
	 * PHONEBANKING type) output: if user is halted, the resultset is not empty or
	 * vice versa.
	 */
	private boolean isHalted(String sCustId) throws ExtendedException {
		boolean halted = false;
		if (sCustId != null) {
			String custId = sCustId.trim();
			try {
				List<CustHaltListBean> haltlist = custHaltListService.checkhalt(custId);
				for (int i = 0; i < haltlist.size(); i++) {
					CustHaltListBean haltListBean = haltlist.get(i);
					String suspendStatus = haltListBean.getSuspendStatus();
					if (!StringUtils.isEmpty(suspendStatus) && suspendStatus.equals("S")) {
						halted = true;
						break;
					}
				}
			} catch (Exception e) {
				throw new ExtendedException(ExtendedException.APP_TYPE, ExtendedException.E_BANKING,
						SystemStatusCode.SSC_UNEXPECTED, "Exception in CustomerAuthentication isHalted");
			}
		}
		return halted;
	}
	
	private ExtendedException transformException(SystemException se) {
		return new ExtendedException(ExtendedException.APP_TYPE, ExtendedException.E_BANKING,
				Integer.toString(se.getErrorCode()), se.getMessage());
	}

	public CustomerBean queryEBID(String ebankId) throws Exception {
		if (!StringUtils.isEmpty(ebankId)) {
			List<CustomerBean> custoemreb = customerRepository.findByEbankIdReturnSteam(ebankId);
			if (custoemreb.size() == 1) {
				return custoemreb.get(0);
			} else if (custoemreb.size() < 1) {
				List<CustomerBean> custoemrCs = customerRepository.findByCustomerIdReturnSteam(ebankId);
				if (custoemrCs.size() == 1) {
					return custoemrCs.get(0);
				} else if (custoemrCs.size() > 1) {
					throw new ExtendedException(ExtendedException.APP_TYPE, ExtendedException.E_BANKING,
							SystemStatusCode.SSC_UNEXPECTED, "Exception in CustomerAuthentication isHalted");
				}
				return null;
			} else {

				throw new ExtendedException(ExtendedException.APP_TYPE, ExtendedException.E_BANKING,
						SystemStatusCode.SSC_UNEXPECTED, "Exception in CustomerAuthentication isHalted");
			}

		} else {
			log.debug("Both ebankId");
			throw new ExtendedException(ExtendedException.APP_TYPE, ExtendedException.E_BANKING,
					SystemStatusCode.SSC_UNEXPECTED, "Exception in CustomerAuthentication ebankId  is null");
		}
	}
	
	public CustomerInfo getCustomerInstance(boolean isMtceModeOn,String userId) throws Exception {
		CustomerInfo cust;
		try {
			if (isMtceModeOn) {
				cust = new CustomerInfo(userId, "", false, false, ""); // avoid connecting hub!
			} else {
				cust = new CustomerInfo(userId, "", "");
			}
			// TODO Vector securitiesAccounts =	getSecuritiesAccounts
			//cust.setSecuritiesAccounts(securitiesAccounts);
		} catch (SystemException se) {
			throw transformException(se);
		}
		return cust;
	}
	
	public CustomerInfo getCustomerInstance(String userId) throws Exception {
		return getCustomerInstance(false,userId);
	}
	
	public boolean isValidPartialHKID(String hkidPartial) {
		boolean flag = false;
		//verify hkidPartial
		return flag;
	}
	
	public void firstSyncCustProfilo(String custId) throws Exception{
		
		CustomerBean customer = getCustByCallNF1108(custId);
		if(null != customer) {
			customerRepository.save(customer);
		}		
	}
	
	public CustomerBean getCustByCallNF1108(String custId) throws IOException, Exception {
		CustomerBean customer = new CustomerBean();
		NF1108RepData response = customerService.loadCustDetailsFromAgent(custId);
		if (response != null) {
			//transform
		}
		return null;
	}
}
