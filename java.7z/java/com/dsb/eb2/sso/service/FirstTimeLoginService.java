package com.dsb.eb2.sso.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dsb.eb2.backOffice.connect.EMSQueueConnector;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsMsgFactory;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsRepMsg;
import com.dsb.eb2.backOffice.connect.emsMsg.EmsReqMsg;
import com.dsb.eb2.backOffice.connect.emsMsg.FrmHdr;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1120.AccountOwners;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1120.NF1120RepData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1120.NF1120ReqData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1122.AcctOwnerInfo;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1122.NF1122RepData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1122.NF1122ReqData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1150.NF1150RepData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1150.NF1150ReqData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1530.NF1530RepData;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1530.NF1530ReqData;
import com.dsb.eb2.bankApp.System.FunctionType;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.System.exeption.SystemException;
import com.dsb.eb2.bankApp.System.maintenance.ActivityLog;
import com.dsb.eb2.bankApp.dao.activityLog.ActivityLogBean;
import com.dsb.eb2.framework.controller.ApiGateway;
import com.dsb.eb2.framework.log.Loggable;
import com.dsb.eb2.framework.sessions.UserSession;
import com.dsb.eb2.sso.constant.FirstTimeLoginConstant;
import com.dsb.eb2.sso.constant.PbPinValidateUtil;
import com.dsb.eb2.util.StringUtils;

@Service
@Loggable
public class FirstTimeLoginService extends ApiGateway{

	private static Logger logger = LoggerFactory.getLogger(FirstTimeLoginService.class);

	private static final char CPBLOGNNormalRtn = '0';
	private static final char realSpace = ' ';
	private static final char hostSpace = ' ';
	private static final char CCifNormalRtn = '0';


	@Autowired
	private EMSQueueConnector emsQueueConnector;	
	
	@Autowired
	private ActivityLog activityLog;

	public int callNF1530(String cardNum, String idNum, String cvv2,String custId) throws Exception {
		logger.info("start FirstTimeLoginService.callNF1530");
		int excCode = SystemStatusCode.SSC_UNEXPECTED;
		String responseCode = "";
		logger.info("FirstTimeLoginService.callNF1530 : the cardno is [" + cardNum + "], the cvv2 is [" + cvv2 + "], the cust_id is [" + "]");
		try{
			//call nf1530
			NF1530ReqData reqData = new NF1530ReqData();
			reqData.setCardNum(cardNum);
			reqData.setCVV2(cvv2);
			reqData.setIDNum(idNum);	    	
	    	EmsReqMsg reqMsg = EmsMsgFactory.createEmsReqMsg(reqData, custId);
	    	EMSQueueConnector connctor = new EMSQueueConnector();
	    	
	    	EmsRepMsg response = connctor.invoke(reqMsg, new NF1530RepData());
	    	FrmHdr header = response.getFrmHdr();	    	
	    	NF1530RepData data = (NF1530RepData)response.getFrmData();			
	    	responseCode = header.getReturnCode();
	    	excCode = Integer.parseInt(responseCode);
	    	if(SystemStatusCode.SSC_NORMAL_EMS_RESPONE == excCode) {
	    		excCode = SystemStatusCode.SSC_NORMAL;
	    		if(null == data) {
	    			excCode = SystemStatusCode.SSC_UNEXPECTED;
	    		}else {
	    			if(!cardNum.equals(data.getCardNum())) {
	    				excCode = SystemStatusCode.SSC_UNEXPECTED;
	    			}
	    		}
	    	}
			logger.info("FirstTimeLoginService callNF1530 : the responseCode is [" + responseCode + "]");
			
		}catch(Exception e)
		{
			logger.error("FirstTimeLoginService callNF1530 error!");
			throw new SystemException(SystemStatusCode.SSC_UNEXPECTED);			
		}
		return excCode;

	}
	
	
	public String getCustIdFromNF1122(String pbid) throws Exception {
		if (StringUtils.isBlank(pbid)) {
			throw new Exception("pbid is null");
		}
		NF1122ReqData req1122 = new NF1122ReqData();
		req1122.setTeleUserID(pbid);
		NF1122RepData resp1122 = new NF1122RepData();
		EmsRepMsg emsRepMsg = emsQueueConnector.getEmsRepMsg(req1122, resp1122);
		resp1122 = (NF1122RepData) emsRepMsg.getFrmData();
		List<AcctOwnerInfo> accList = resp1122.getAcctOwnerInfo();
		String custId = null;
		if (accList != null && accList.size() > 0) {
			AcctOwnerInfo acctOwnerInfo = accList.get(0);
			custId = acctOwnerInfo.getCustID();
		} else {
			throw new Exception("call osb NF1122RepData AcctOwnerInfo is null");
		}
		logger.info("call NF1122,custId is "+custId);
		return custId;
	}

	public String getCustIdFromNF1120(String cardNumber) throws Exception {
		if (StringUtils.isBlank(cardNumber)) {
			throw new Exception("cardNumber is null");
		}
		NF1120ReqData req1120 = new NF1120ReqData();
		req1120.setCardNumber(cardNumber);
		req1120.setSequenceNumber(FirstTimeLoginConstant.NF1120_SEQUENCE_NUMBER);
		NF1120RepData resp1120 = new NF1120RepData();
		EmsRepMsg emsRepMsg = emsQueueConnector.getEmsRepMsg(req1120, resp1120);
		resp1120 = (NF1120RepData) emsRepMsg.getFrmData();
		List<AccountOwners> accList = resp1120.getAccountOwners();
		String custId = null;
		if (accList != null && accList.size() > 0) {
			AccountOwners acc = accList.get(0);
			custId = acc.getCustId();
		} else {
			throw new Exception("call osb NF1120RepData AccountOwners is null");
		}
		logger.info("call NF1122,custId is "+custId);
		return custId;
	}

	public boolean validatePbpin(String pbId, String pbPin) throws Exception {
		if (StringUtils.isBlank(pbId) || StringUtils.isBlank(pbPin)) {
			throw new Exception("pbPin/pbId is null");
		}
		String pinValidateStr = PbPinValidateUtil.getPbPinEncryptStr(pbId,pbPin);
		String respPinStr = callNF1150(pinValidateStr);
		if(StringUtils.isBlank(respPinStr)) {
			throw new Exception("respPinStr is blank/null !");
		}
		char returnCode = respPinStr.charAt(11);
		logger.info("returnCode="+returnCode);
		return (CPBLOGNNormalRtn == returnCode);
	}
	
	
	public String callNF1150(String reqStr) throws Exception {
		if(StringUtils.isBlank(reqStr)) {
			throw new Exception("reqStr is blank/null !");
		}
		String pbReqMsg = String.format(PbPinValidateUtil.NF1150_REQMSG_FORMAT, reqStr);
		NF1150ReqData req1150 = new NF1150ReqData();
		req1150.setPbReqMsg(pbReqMsg);
		NF1150RepData resp1150 = new NF1150RepData();
		EmsRepMsg emsRepMsg = emsQueueConnector.getEmsRepMsg(req1150, resp1150);
		resp1150 = (NF1150RepData) emsRepMsg.getFrmData();
		return resp1150.getPbReplyMsg();
	}


	public String getRealPbIdFromNF1150(String pbId) throws Exception {
		if(StringUtils.isBlank(pbId)) {
			throw new Exception("pbId is blank/null !");
		}
		String pbIdEncryptStr = PbPinValidateUtil.getpbIdEncryptStr(pbId);
		logger.info("pbIdEncryptStr="+pbIdEncryptStr);
		String realPbidStr = callNF1150(pbIdEncryptStr);
		if(StringUtils.isBlank(realPbidStr)) {
			throw new Exception("realPbidStr is blank/null !");
		}
		String realPbId = realPbidStr.substring(13, 33);
		realPbId = realPbId.replace(realSpace, hostSpace); 
		logger.info("realPbId="+realPbId);
		return realPbId;
	}


	public String getCustIdFromNF1150(String realPbId) throws Exception {
		String custIdEncryptStr = PbPinValidateUtil.getCustIdEncryptStr(realPbId);
		logger.info("custIdEncryptStr="+custIdEncryptStr);
		String respMsg = callNF1150(custIdEncryptStr);
		if(StringUtils.isBlank(respMsg)) {
			throw new Exception("respMsg is blank/null !");
		}
		char cCifRtnCde = respMsg.charAt(170);
		logger.info("cCifRtnCde="+cCifRtnCde);
		String custId = null;
		if (cCifRtnCde == CCifNormalRtn) {
			custId = respMsg.substring(67, 87);
		}
		logger.info("custId="+custId);
		return custId;
	}
	
	public void storeCustIdInSession(String custID,HttpServletRequest request,boolean isResetSession) {
		HttpSession httpSession = request.getSession();
		if(isResetSession) {
			httpSession.invalidate();
			httpSession = request.getSession(true);
		}
		UserSession userSession = (UserSession) request.getSession().getAttribute("USER_SESSION");
		if(null != userSession) {
			userSession.setCustID(custID);
			userSession.setSessionID(httpSession.getId());
		} else {
			userSession = new UserSession(httpSession);
			userSession.setCustID(custID);
			httpSession.setAttribute("USER_SESSION", userSession);
		}
	}

	public void insertActivityLog(String custId, String details, int returnCode, int subType) {
		try {
			ActivityLogBean bean = new ActivityLogBean();
			bean.setCustId(custId);
			bean.setMainType(FunctionType.MF_LOGIN);
			bean.setSubType(subType);
			bean.setDetails(details);
			bean.setReturnCode(returnCode);
			activityLog.record(bean);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}

}
