package com.dsb.eb2.sso.model;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Hashtable;
import java.util.Map;
import java.util.Vector;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.dsb.eb2.api.model.CnOceanCust;
import com.dsb.eb2.api.services.CustomerService;
import com.dsb.eb2.backOffice.connect.emsMsg.nf1108.NF1108RepData;
import com.dsb.eb2.bankApp.System.FunctionType;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.System.exeption.SystemException;
import com.dsb.eb2.bankApp.System.maintenance.ActivityLog;
import com.dsb.eb2.bankApp.account.ATMCardAct;
import com.dsb.eb2.bankApp.account.Account;
import com.dsb.eb2.bankApp.account.AccountProfolio;
import com.dsb.eb2.bankApp.account.Current;
import com.dsb.eb2.bankApp.account.FixedDeposit;
import com.dsb.eb2.bankApp.account.Savings;
import com.dsb.eb2.bankApp.account.ThirdPartyRegistration;
import com.dsb.eb2.bankApp.dao.activityLog.ActivityLogBean;
import com.dsb.eb2.bankApp.dao.customer.CustomerBean;

public class CustomerInfo extends Object implements java.io.Serializable {

	@Autowired
	private CustomerService customerService;
	
	@Autowired
	private ActivityLog activityLog;

	private static Logger logger = LoggerFactory.getLogger(CustomerInfo.class);

	// customer ID type
	public static final String HKID_ID_TYPE = "ID";
	public static final String PASSPORT_ID_TYPE = "PP";
	public static final String BUSINESS_REG_ID_TYPE = "BR";
	public static final String OTHERS_ID_TYPE = "OT";
	public static final String DUMMY_ID_TYPE = "XX";
	public static final String CHINESEID_ID_TYPE = "CI";

	// customer type
	private static final String PERSONAL_CUST_TYPE = "P";

	// token type for PDM14338
	public static final String TOKEN_TYPE_GA = "GA";
	public static final String TOKEN_TYPE_GATP = "GATP";

	// language
	public static final int LANG_PREF_ENGLISH = 0;
	public static final int LANG_PREF_CHINESE = 1;

	public static final String LANG_PREF_ZH_TW = "zh_TW";
	public static final String LANG_PREF_EN_US = "en_US";

	public static final int LOGIN_BY_PHONE_BANKING = 0;

	// opted out type in check_show_message
	public static final String OPTED_OUT_TYPE1 = "OPTEDOUT_1";
	public static final String OPTED_OUT_TYPE2 = "OPTEDOUT_2";

	protected static Map paramsMap = null;

	// generic
	protected String custType;
	protected String custId;
	protected String name;
	protected String title;
	protected char sex;
	protected String idType;
	protected String id;
	protected Date dateOfBirth;
	protected String[] emailAddr = new String[2];
	protected Date lastLoginDateTime;
	protected String staffInd;
	protected String mobileNo;

	// login related
	protected int loginBy;
	protected String phBkId;
	protected String realPhId;

	// system related
	protected boolean firstVisit;

	// preference
	protected boolean emailNotifyPref;
	protected int langPref;

	// accounts
	protected Hashtable ownAccounts = new Hashtable();
	protected Hashtable r3pAccounts = new Hashtable();
	protected Hashtable uavAccounts = new Hashtable();
	// initialization
	protected boolean hasOwnAcctInit = false;
	protected boolean has3pAcctInit = false;
	protected SystemException initOwnAcctEx = null;
	protected SystemException init3pAcctEx = null;

	protected boolean ownCcUnavailable = false;
	protected boolean thirdPartyCcUnavailable = false;

	protected boolean isCertLogin = false;
	protected boolean certLoginOnly;
	protected String nonreg3PtyAllowed; // CVM09032
	protected String nonregHrbrAllowed; // PDM12180

	// email
	protected String permEmail;
	protected String tempEmail;
	protected Date permEmailLastUpdateDate;
	protected String permEmailLastUpdateBy;

	public String getPermEmail() {
		return permEmail;
	}

	public void setPermEmail(String permEmail) {
		this.permEmail = permEmail;
	}

	public Date getPermEmailLastUpdateDate() {
		return permEmailLastUpdateDate;
	}

	public void setPermEmailLastUpdateDate(Date permEmailLastUpdateDate) {
		this.permEmailLastUpdateDate = permEmailLastUpdateDate;
	}

	public String getPermEmailLastUpdateBy() {
		return permEmailLastUpdateBy;
	}

	public void setPermEmailLastUpdateBy(String permEmailLastUpdateBy) {
		this.permEmailLastUpdateBy = permEmailLastUpdateBy;
	}

	protected Vector securitiesAccounts = null;

	protected boolean isSMIDLogin = false;// PDM05381 at 20050706

	protected boolean isPromoOptedOut = false; // CVM09029

	protected int custDetailsLoadingCode = SystemStatusCode.SSC_NORMAL;

	protected String firstTimeLoginDateTime = null;
	protected String firstTimeLoginPbsid = null;

	protected String eduLevel = null;
	protected String occupation = null;
	protected String langFromEMS = null;// Language Preference Indicator

	protected String InvSrvAlreadyPass2FA = null;

	// SCR-PDM13729 Start

	protected static SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");

	protected String address1 = null;
	protected String address2 = null;
	protected String address3 = null;
	protected String address4 = null;
	protected String homeTel = null;

	// SCR-PBD15049 start
	protected boolean isPbSolo = false; // the customer has PB CA/SA/FD account only (i.e. no retail CA/SA/FD account)
	protected boolean isPbHasAcct = false; // the customer has one or more PB CA/SA/FD account
	// SCR-PBD15049 end

	// PDM15125 Email Consolidation BEG
	protected String oldPermanentEmail = "";
	protected String permanentEmail = "";
	protected String referenceNumber = "";
	protected GregorianCalendar hostEmailUpdateDate;
	// ITD16001 start
	public String showMaskEmailFlag;

	// fixed prd issue
	protected boolean hasBio = false;

	// E2010002 Start
	protected String edmEmail;
	protected String oldEdmEmail;

	// E2011005 Start
	protected String oldEmail1;

	protected String oldEmail2;

	protected String isVIP = null;

	// SCR-PDM10588 Start
	protected ATMCardAct[] atmCardList;
	protected String[] creditCardList;
	protected String[] cashCardList;

	// SCR-OPC12002 Start
	protected boolean isOcean = false;

	protected boolean isCross = false;

	protected CnOceanCust[] cnAcctList;

	/** Creates new Customer */

	public CustomerInfo() {
	}

	public CustomerInfo(String custId, String phBkId, Map paramsMap) throws Exception {
		this(custId, phBkId, true, paramsMap);
	}

	public CustomerInfo(String custId, String phBkId, boolean isPersonalInd, Map paramsMap) throws Exception {
		this(custId, phBkId, isPersonalInd, true, paramsMap);
	}

	public CustomerInfo(String custId, String phBkId, boolean isPersonalInd, boolean isCustDetailLoad, Map paramsMap)
			throws Exception {

		// TODO
		this.custId = custId;
		this.phBkId = phBkId;
		this.paramsMap = paramsMap;
		loginBy = LOGIN_BY_PHONE_BANKING;
		langPref = LANG_PREF_ENGLISH;

		CustomerBean cust = customerService.getCustomerByCustId(custId);

		if (cust != null) {
//			this.permEmail = cust.getPermanentEmail();
//			this.tempEmail = cust.getTempEmail();
//			this.permEmailLastUpdateDate = cust.getEmailLastUpdateDate();
//			this.permEmailLastUpdateBy = cust.getPermEmailLastUpdateBy();
			this.name = cust.getFullName();
			this.title = cust.getTitle();
			this.sex = cust.getSex().charAt(0);
			this.dateOfBirth = cust.getDateOfBirth();
//			this.staffInd = cust.getStaffIndicator();
//			this.mobileNo = cust.getMobileNumber();

			// loadCustDetailsFromProfile
			Date loginSuccDate = cust.getLastLoginSuccessDate();
			lastLoginDateTime = loginSuccDate;
			if (loginSuccDate == null) {
				firstVisit = true;
			} else {
				firstVisit = false;
			}

			if (permanentEmail != null && permanentEmail != null) {
				emailAddr[0] = permanentEmail;
				emailAddr[1] = permanentEmail;
			}

			// 鏈兘璧嬪�煎瓧娈� certLoginOnly nonreg3PtyAllowed firstTimeLoginDateTime
			// firstTimeLoginPbsid nonregHrbrAllowed webPinStatus TKN_LOGIN emailNotifyPref
		} else {
			firstVisit = true;
		}

		if (isCustDetailLoad) {
			final String DOB_PATTERN = "yyyyMMdd";
			NF1108RepData response = customerService.loadCustDetailsFromAgent(custId);
			if (response != null) {
				this.custType = response.getCustType();
				this.name = response.getCustNameLine1() + response.getCustNameLine2();
				this.title = response.getTitle();
				this.sex = response.getSex().charAt(0);
				SimpleDateFormat sdf = new SimpleDateFormat(DOB_PATTERN);
				this.dateOfBirth = sdf.parse(response.getDateOfBirth());
				this.staffInd = response.getStaffInd();

				isVIP = response.getVIPFlag();
				mobileNo = response.getMobileNum();

				address1 = response.getAddrLine1();
				address2 = response.getAddrLine2();
				address3 = response.getAddrLine3();
				address4 = response.getAddrLine4();

				homeTel = response.getHomeNum();

				// 鏈兘璧嬪�煎瓧娈� eduLevel occupation langFromEMS
			}
		}

	}

	public CustomerInfo(String custId, String phBkId) throws Exception {
		this(custId, phBkId, true);
	}

	public CustomerInfo(String custId, String phBkId, String realPhId) throws Exception {
		this(custId, phBkId, true);
		this.realPhId = realPhId;
	}

	public CustomerInfo(String custId, String phBkId, boolean isPersonalInd) throws Exception {
		this(custId, phBkId, isPersonalInd, true);
	}

	public CustomerInfo(String custId, String phBkId, boolean isPersonalInd, boolean isCustDetailLoad, String realPhId)
			throws Exception {
		this(custId, phBkId, isPersonalInd, isCustDetailLoad);
		this.realPhId = realPhId;
	}

	public CustomerInfo(String custId, String phBkId, boolean isPersonalInd, boolean isCustDetailLoad) throws Exception {
		// TODO
		this.custId = custId;
		this.phBkId = phBkId;
		loginBy = LOGIN_BY_PHONE_BANKING;
		langPref = LANG_PREF_ENGLISH;

		CustomerBean cust = customerService.getCustomerByCustId(custId);

		if (cust != null) {
//			this.permEmail = cust.getPermanentEmail();
//			this.tempEmail = cust.getTempEmail();
//			this.permEmailLastUpdateDate = cust.getEmailLastUpdateDate();
//			this.permEmailLastUpdateBy = cust.getPermEmailLastUpdateBy();
			this.name = cust.getFullName();
			this.title = cust.getTitle();
			this.sex = cust.getSex().charAt(0);
			this.dateOfBirth = cust.getDateOfBirth();
//			this.staffInd = cust.getStaffIndicator();
//			this.mobileNo = cust.getMobileNumber();

			// loadCustDetailsFromProfile
			Date loginSuccDate = cust.getLastLoginSuccessDate();
			lastLoginDateTime = loginSuccDate;
			if (loginSuccDate == null) {
				firstVisit = true;
			} else {
				firstVisit = false;
			}

			if (permanentEmail != null && permanentEmail != null) {
				emailAddr[0] = permanentEmail;
				emailAddr[1] = permanentEmail;
			}

			// 鏈兘璧嬪�煎瓧娈� certLoginOnly nonreg3PtyAllowed firstTimeLoginDateTime
			// firstTimeLoginPbsid nonregHrbrAllowed webPinStatus TKN_LOGIN emailNotifyPref
		} else {
			firstVisit = true;
		}

	}

	public static Map getParamsMap() {
		return paramsMap;
	}

	public static void setParamsMap(Map paramsMap) {
		CustomerInfo.paramsMap = paramsMap;
	}

	public String getCustType() {
		return custType;
	}

	public void setCustType(String custType) {
		this.custType = custType;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public char getSex() {
		return sex;
	}

	public void setSex(char sex) {
		this.sex = sex;
	}

	public String getIdType() {
		return idType;
	}

	public void setIdType(String idType) {
		this.idType = idType;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String[] getEmailAddr() {
		return emailAddr;
	}

	public void setEmailAddr(String[] emailAddr) {
		this.emailAddr = emailAddr;
	}

	public Date getLastLoginDateTime() {
		return lastLoginDateTime;
	}

	public void setLastLoginDateTime(Date lastLoginDateTime) {
		this.lastLoginDateTime = lastLoginDateTime;
	}

	public String getStaffInd() {
		return staffInd;
	}

	public void setStaffInd(String staffInd) {
		this.staffInd = staffInd;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public int getLoginBy() {
		return loginBy;
	}

	public void setLoginBy(int loginBy) {
		this.loginBy = loginBy;
	}

	public String getPhBkId() {
		return phBkId;
	}

	public void setPhBkId(String phBkId) {
		this.phBkId = phBkId;
	}

	public String getRealPhId() {
		return realPhId;
	}

	public void setRealPhId(String realPhId) {
		this.realPhId = realPhId;
	}

	public boolean isFirstVisit() {
		return firstVisit;
	}

	public void setFirstVisit(boolean firstVisit) {
		this.firstVisit = firstVisit;
	}

	public boolean isEmailNotifyPref() {
		return emailNotifyPref;
	}

	public void setEmailNotifyPref(boolean emailNotifyPref) {
		this.emailNotifyPref = emailNotifyPref;
	}

	public int getLangPref() {
		return langPref;
	}

	public void setLangPref(int langPref) {
		this.langPref = langPref;
	}

	public Hashtable getOwnAccounts() {
		return ownAccounts;
	}

	public void setOwnAccounts(Hashtable ownAccounts) {
		this.ownAccounts = ownAccounts;
	}

	public Hashtable getR3pAccounts() {
		return r3pAccounts;
	}

	public void setR3pAccounts(Hashtable r3pAccounts) {
		this.r3pAccounts = r3pAccounts;
	}

	public Hashtable getUavAccounts() {
		return uavAccounts;
	}

	public void setUavAccounts(Hashtable uavAccounts) {
		this.uavAccounts = uavAccounts;
	}

	public boolean isHasOwnAcctInit() {
		return hasOwnAcctInit;
	}

	public void setHasOwnAcctInit(boolean hasOwnAcctInit) {
		this.hasOwnAcctInit = hasOwnAcctInit;
	}

	public boolean isHas3pAcctInit() {
		return has3pAcctInit;
	}

	public void setHas3pAcctInit(boolean has3pAcctInit) {
		this.has3pAcctInit = has3pAcctInit;
	}

	public Exception getInitOwnAcctEx() {
		return initOwnAcctEx;
	}

	public void setInitOwnAcctEx(SystemException initOwnAcctEx) {
		this.initOwnAcctEx = initOwnAcctEx;
	}

	public Exception getInit3pAcctEx() {
		return init3pAcctEx;
	}

	public void setInit3pAcctEx(SystemException init3pAcctEx) {
		this.init3pAcctEx = init3pAcctEx;
	}

	public boolean isOwnCcUnavailable() {
		return ownCcUnavailable;
	}

	public void setOwnCcUnavailable(boolean ownCcUnavailable) {
		this.ownCcUnavailable = ownCcUnavailable;
	}

	public boolean isThirdPartyCcUnavailable() {
		return thirdPartyCcUnavailable;
	}

	public void setThirdPartyCcUnavailable(boolean thirdPartyCcUnavailable) {
		this.thirdPartyCcUnavailable = thirdPartyCcUnavailable;
	}

	public boolean isCertLogin() {
		return isCertLogin;
	}

	public void setCertLogin(boolean isCertLogin) {
		this.isCertLogin = isCertLogin;
	}

	public boolean isCertLoginOnly() {
		return certLoginOnly;
	}

	public void setCertLoginOnly(boolean certLoginOnly) {
		this.certLoginOnly = certLoginOnly;
	}

	public String getNonreg3PtyAllowed() {
		return nonreg3PtyAllowed;
	}

	public void setNonreg3PtyAllowed(String nonreg3PtyAllowed) {
		this.nonreg3PtyAllowed = nonreg3PtyAllowed;
	}

	public String getNonregHrbrAllowed() {
		return nonregHrbrAllowed;
	}

	public void setNonregHrbrAllowed(String nonregHrbrAllowed) {
		this.nonregHrbrAllowed = nonregHrbrAllowed;
	}

	public Vector getSecuritiesAccounts() {
		return securitiesAccounts;
	}

	public void setSecuritiesAccounts(Vector securitiesAccounts) {
		this.securitiesAccounts = securitiesAccounts;
	}

	public boolean isSMIDLogin() {
		return isSMIDLogin;
	}

	public void setSMIDLogin(boolean isSMIDLogin) {
		this.isSMIDLogin = isSMIDLogin;
	}

	public boolean isPromoOptedOut() {
		return isPromoOptedOut;
	}

	public void setPromoOptedOut(boolean isPromoOptedOut) {
		this.isPromoOptedOut = isPromoOptedOut;
	}

	public int getCustDetailsLoadingCode() {
		return custDetailsLoadingCode;
	}

	public void setCustDetailsLoadingCode(int custDetailsLoadingCode) {
		this.custDetailsLoadingCode = custDetailsLoadingCode;
	}

	public String getFirstTimeLoginDateTime() {
		return firstTimeLoginDateTime;
	}

	public void setFirstTimeLoginDateTime(String firstTimeLoginDateTime) {
		this.firstTimeLoginDateTime = firstTimeLoginDateTime;
	}

	public String getFirstTimeLoginPbsid() {
		return firstTimeLoginPbsid;
	}

	public void setFirstTimeLoginPbsid(String firstTimeLoginPbsid) {
		this.firstTimeLoginPbsid = firstTimeLoginPbsid;
	}

	public String getEduLevel() {
		return eduLevel;
	}

	public void setEduLevel(String eduLevel) {
		this.eduLevel = eduLevel;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getLangFromEMS() {
		return langFromEMS;
	}

	public void setLangFromEMS(String langFromEMS) {
		this.langFromEMS = langFromEMS;
	}

	public String getInvSrvAlreadyPass2FA() {
		return InvSrvAlreadyPass2FA;
	}

	public void setInvSrvAlreadyPass2FA(String invSrvAlreadyPass2FA) {
		InvSrvAlreadyPass2FA = invSrvAlreadyPass2FA;
	}

	public static SimpleDateFormat getDf() {
		return df;
	}

	public static void setDf(SimpleDateFormat df) {
		CustomerInfo.df = df;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getAddress3() {
		return address3;
	}

	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	public String getAddress4() {
		return address4;
	}

	public void setAddress4(String address4) {
		this.address4 = address4;
	}

	public String getHomeTel() {
		return homeTel;
	}

	public void setHomeTel(String homeTel) {
		this.homeTel = homeTel;
	}

	public boolean isPbSolo() {
		return isPbSolo;
	}

	public void setPbSolo(boolean isPbSolo) {
		this.isPbSolo = isPbSolo;
	}

	public boolean isPbHasAcct() {
		return isPbHasAcct;
	}

	public void setPbHasAcct(boolean isPbHasAcct) {
		this.isPbHasAcct = isPbHasAcct;
	}

	public String getOldPermanentEmail() {
		return oldPermanentEmail;
	}

	public void setOldPermanentEmail(String oldPermanentEmail) {
		this.oldPermanentEmail = oldPermanentEmail;
	}

	public String getPermanentEmail() {
		return permanentEmail;
	}

	public void setPermanentEmail(String permanentEmail) {
		this.permanentEmail = permanentEmail;
	}

	public String getTempEmail() {
		return tempEmail;
	}

	public void setTempEmail(String tempEmail) {
		this.tempEmail = tempEmail;
	}

	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	public GregorianCalendar getHostEmailUpdateDate() {
		return hostEmailUpdateDate;
	}

	public void setHostEmailUpdateDate(GregorianCalendar hostEmailUpdateDate) {
		this.hostEmailUpdateDate = hostEmailUpdateDate;
	}

	public String getShowMaskEmailFlag() {
		return showMaskEmailFlag;
	}

	public void setShowMaskEmailFlag(String showMaskEmailFlag) {
		this.showMaskEmailFlag = showMaskEmailFlag;
	}

	public boolean isHasBio() {
		return hasBio;
	}

	public void setHasBio(boolean hasBio) {
		this.hasBio = hasBio;
	}

	public String getEdmEmail() {
		return edmEmail;
	}

	public void setEdmEmail(String edmEmail) {
		this.edmEmail = edmEmail;
	}

	public String getOldEdmEmail() {
		return oldEdmEmail;
	}

	public void setOldEdmEmail(String oldEdmEmail) {
		this.oldEdmEmail = oldEdmEmail;
	}

	public String getOldEmail1() {
		return oldEmail1;
	}

	public void setOldEmail1(String oldEmail1) {
		this.oldEmail1 = oldEmail1;
	}

	public String getOldEmail2() {
		return oldEmail2;
	}

	public void setOldEmail2(String oldEmail2) {
		this.oldEmail2 = oldEmail2;
	}

	public String getIsVIP() {
		return isVIP;
	}

	public void setIsVIP(String isVIP) {
		this.isVIP = isVIP;
	}

	public ATMCardAct[] getAtmCardList() {
		return atmCardList;
	}

	public void setAtmCardList(ATMCardAct[] atmCardList) {
		this.atmCardList = atmCardList;
	}

	public String[] getCreditCardList() {
		return creditCardList;
	}

	public void setCreditCardList(String[] creditCardList) {
		this.creditCardList = creditCardList;
	}

	public String[] getCashCardList() {
		return cashCardList;
	}

	public void setCashCardList(String[] cashCardList) {
		this.cashCardList = cashCardList;
	}

	public boolean isOcean() {
		return isOcean;
	}

	public void setOcean(boolean isOcean) {
		this.isOcean = isOcean;
	}

	public boolean isCross() {
		return isCross;
	}

	public void setCross(boolean isCross) {
		this.isCross = isCross;
	}

	public CnOceanCust[] getCnAcctList() {
		return cnAcctList;
	}

	public void setCnAcctList(CnOceanCust[] cnAcctList) {
		this.cnAcctList = cnAcctList;
	}

	public static String getHkidIdType() {
		return HKID_ID_TYPE;
	}

	public static String getPassportIdType() {
		return PASSPORT_ID_TYPE;
	}

	public static String getBusinessRegIdType() {
		return BUSINESS_REG_ID_TYPE;
	}

	public static String getOthersIdType() {
		return OTHERS_ID_TYPE;
	}

	public static String getDummyIdType() {
		return DUMMY_ID_TYPE;
	}

	public static String getChineseidIdType() {
		return CHINESEID_ID_TYPE;
	}

	public static String getPersonalCustType() {
		return PERSONAL_CUST_TYPE;
	}

	public static String getTokenTypeGa() {
		return TOKEN_TYPE_GA;
	}

	public static String getTokenTypeGatp() {
		return TOKEN_TYPE_GATP;
	}

	public static int getLangPrefEnglish() {
		return LANG_PREF_ENGLISH;
	}

	public static int getLangPrefChinese() {
		return LANG_PREF_CHINESE;
	}

	public static String getLangPrefZhTw() {
		return LANG_PREF_ZH_TW;
	}

	public static String getLangPrefEnUs() {
		return LANG_PREF_EN_US;
	}

	public static int getLoginByPhoneBanking() {
		return LOGIN_BY_PHONE_BANKING;
	}

	public static String getOptedOutType1() {
		return OPTED_OUT_TYPE1;
	}

	public static String getOptedOutType2() {
		return OPTED_OUT_TYPE2;
	}

	// add by Franky Cheung 29Nov2002
	// after successful login, previous 'Locked' record in PB Pin Regen
	// will be reset to zero
	public synchronized void resetPinRegenRecordCnt() throws Exception {
		// TODO SELECT ATTEMPT_COUNT FROM PIN_REGEN_ATTEMPT WHERE PBID = ?
		// RegenPinFailureLog pinLog = new RegenPinFailureLog();
		// pinLog.checkFailCnt(phBkId)
		int cnt = 0;// pinLog.checkFailCnt(phBkId);
		if (cnt > 3) {
			// TODO UPDATE PIN_REGEN_ATTEMPT SET ATTEMPT_COUNT = 0 WHERE PBID = ?
			// pinLog.resetFailCnt(phBkId);
	    	ActivityLogBean bean = new ActivityLogBean(custId,FunctionType.MF_PIN_REGEN,FunctionType.MF_PIN_REGEN,SystemStatusCode.SSC_NORMAL,
	    			"Customer (" + custId + ") successfully reset the PIN Regeneration Record Count");
	    	activityLog.record(bean);
		}
	}

	public void certLogin(boolean isCertLogin) {
		this.isCertLogin = isCertLogin;
	}

	// Check whether the account is a personal account or not.
	public boolean isPersonal() {
		// ebank log added 2012-09-28 start
		logger.debug("The Customer.isPersonal() idType = |" + idType + "|, custType = |" + custType + "|, custId = |"
				+ custId + "|");
		// ebank log added 2012-09-28 end
		if ((idType.equals(HKID_ID_TYPE)) || (idType.equals(PASSPORT_ID_TYPE)) || (idType.equals(CHINESEID_ID_TYPE)))
			return true;
		if ((custType != null) && (custType.equals(PERSONAL_CUST_TYPE))
				&& ((idType.equals(OTHERS_ID_TYPE)) || (idType.equals(DUMMY_ID_TYPE))))
			return true;
		if (idType.equals(OTHERS_ID_TYPE) && phBkId.startsWith("428357"))
			return true;
		StringBuffer sb = new StringBuffer();
		sb.append("Customer ID=[" + custId + "]\n");
		sb.append("ID Type=[" + idType + "]\n");
		sb.append("Customer Type=[" + custType + "]\n");
		sb.append("Customer Type != null? " + (custType != null) + "\n");
		// Fix on 2012-10-03 start
		sb.append("Customer Type equals [" + PERSONAL_CUST_TYPE + "] ? "
				+ ((custType != null) && (custType.equals(PERSONAL_CUST_TYPE))) + "\n");
		// Fix on 2012-10-03 end
		sb.append("ID Type equals [" + OTHERS_ID_TYPE + "] ? " + (idType.equals(OTHERS_ID_TYPE)) + "\n");
		sb.append("ID Type equals [" + DUMMY_ID_TYPE + "] ? " + (idType.equals(DUMMY_ID_TYPE)) + "\n");
		sb.append("Overall ? " + ((custType != null) && (custType.equals(PERSONAL_CUST_TYPE))
				&& ((idType.equals(OTHERS_ID_TYPE)) || (idType.equals(DUMMY_ID_TYPE)))) + "\n");
		return false;
	}

	public void setIsSMIDLogin(boolean _isSMIDLogin) { // PDM05381 at 20050706
		isSMIDLogin = _isSMIDLogin;
	}

	public boolean isEmailSkip() throws Exception {
		// TODO select EMAIL_SKIP from CUST_EMAIL_ADD WHERE CUST_ID = ?
		String skip = "";// getEmailSkip();
		if (skip != null && skip.equals("Y")) {
			return true;
		} else {
			return false;
		}
	}

	public boolean getCertLoginOnly() {
		return certLoginOnly;
	}

	public void storeCustDetailsToProfile() throws Exception {
		storeCustDetailsToProfile(null);
	}

	public void storeCustDetailsToProfile(String custType) throws Exception {
		storeCustDetailsToProfile(custType, "N");
	}

	public void storeCustDetailsToProfileForISEC() throws Exception {
		storeCustDetailsToProfile(null, "Y");
	}

	public void storeCustDetailsToProfile(String custType, String toISecurities) {

	}

	public String getMassagedMobileNoForISec() {
		return getMassagedMobileNo();
	}

	// 鏆傛椂鍏堜繚鐣欏湪姝�
	public String getMassagedMobileNo() {
		return "";
	}

	private synchronized void initOwnAccounts() throws SystemException {
		// initialize if necessary
		if (initOwnAcctEx != null) {
			SystemException ex = initOwnAcctEx;
			initOwnAcctEx = null;
			throw ex;
		}
		if (hasOwnAcctInit)
			return;
		logger.info("Before Refresh Customer [" + custId + "," + hasOwnAcctInit + "]");

		try {
			refreshOwnAccounts();
		} catch (SystemException ex) {
			initOwnAcctEx = ex;
			throw ex;
		}
		hasOwnAcctInit = true;
		logger.info("After Refresh Customer [" + custId + "," + hasOwnAcctInit + "]");
	}

	public synchronized void refreshOwnAccounts() throws SystemException {
		// AccountProfolio acctProf = new AccountProfolio(custId,phBkId);
		logger.info(new Date() + " refreshOwnAccounts before acctProf.load()");
		AccountProfolio acctProf = new AccountProfolio(this);
		acctProf.load();
		logger.info(new Date() + " refreshOwnAccounts after acctProf.load()");
		Account[] availAccts = acctProf.getAvailAccts();
		Account[] unavailAccts = acctProf.getUnavailAccts();

		// SCR-PDM10588 Start
		logger.info(new Date() + " Customer.refreshOwnAccounts() start");
		setATMCardAct(acctProf.getATMCard());
		setCreditCard(acctProf.getCreditCard());
		setCashCard(acctProf.getCashCard());
		logger.info(new Date() + " Customer.refreshOwnAccounts() end");
		// SCR-PDM10588 End

		// ownCcUnavailable = acctProf.hasCcError();
		if ((!ownCcUnavailable) && ((availAccts == null) || (unavailAccts == null)
				|| ((availAccts.length + unavailAccts.length) == 0))) {
			throw new SystemException(SystemStatusCode.SSC_ACCT_PROFOLIO_NOT_FOUND);
		}

		ownAccounts.clear();

		// SCR-PBD15049 end
		logger.info("Customer:" + this.getCustId() + " - handle owned accounts and determine PBD");
		int pbCnt = 0, rbCnt = 0; // PB & retail account counters
		for (int i = 0; i < availAccts.length; i++) {
			ownAccounts.put(availAccts[i].getAcctNum(), availAccts[i]);

			if (availAccts[i] instanceof Savings || availAccts[i] instanceof Current
					|| availAccts[i] instanceof FixedDeposit) {
				// determine if Solo PB customer
				if (availAccts[i].getAcctNum().startsWith("07")) {
					pbCnt++;
				} else {
					rbCnt++;
				}
			}

		}

		if (pbCnt >= 1 && rbCnt == 0) {
			isPbSolo = true;
		}

		if (pbCnt >= 1) {
			isPbHasAcct = true;
		}

		logger.info("Customer:" + this.getCustId() + " - pbCnt:" + pbCnt + "  rbCnt:" + rbCnt + "  isPbSolo:"
				+ this.isPbSolo + "  isPbHasAcct:" + this.isPbHasAcct);

		uavAccounts.clear();
		for (int i = 0; i < unavailAccts.length; i++) {
			uavAccounts.put(unavailAccts[i].getAcctNum(), unavailAccts[i]);
		}

		phBkId = acctProf.getPhBkId();

	}

	private synchronized void init3pAccounts() throws SystemException {
		// initialize if necessary
		if (init3pAcctEx != null) {
			SystemException ex = init3pAcctEx;
			init3pAcctEx = null;
			throw ex;
		}
		if (has3pAcctInit)
			return;
		try {
			refresh3pAccounts();
		} catch (SystemException ex) {
			init3pAcctEx = ex;
			throw ex;
		}
		has3pAcctInit = true;
	}

	public synchronized void refresh3pAccounts() throws SystemException {
		
		ThirdPartyRegistration thirdPartyReg = new ThirdPartyRegistration(custId, phBkId);

		String channelId = "";

		Account[] accts = null;

		if (null != channelId && !"".equals(channelId)) {
			logger.info("Customer refresh3pAccounts channelId=" + channelId);
			accts = thirdPartyReg.getThirdPartyAccounts(channelId);
		} else {
			accts = thirdPartyReg.getThirdPartyAccounts();
		}
		r3pAccounts.clear();
		if ((accts != null) && (accts.length > 0)) {
			for (int i = 0; i < accts.length; i++)
				r3pAccounts.put(accts[i].getAcctNum(), accts[i]);
		}
	}

	public void setATMCardAct(ATMCardAct[] v) {

		atmCardList = v;

	}

	public ATMCardAct[] getATMCardAct() {
		logger.info("return the ATM Card in Customer object");
		return atmCardList;
	}

	public void setCreditCard(String[] v) {
		creditCardList = v;
	}

	public String[] getCreditCard() throws SystemException {
		String[] result = null;

		return result;
	}

	public void setCashCard(String[] v) {
		cashCardList = v;
	}

	public String[] getCashCard() {
		return cashCardList;
	}

}
