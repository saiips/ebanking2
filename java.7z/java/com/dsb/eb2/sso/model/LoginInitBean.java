package com.dsb.eb2.sso.model;

import com.dsb.eb2.framework.controller.BaseObject;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class LoginInitBean extends BaseObject{
	
	private String zhPath;
	private String enPath;
	private String loginType;
	private boolean popupSchedule;
	private String eBankLoginMedium;
	private String rsaKey;
	private String random;
	private String keyIndex;
	private String webPinKeyModule;
	private String webPinKeyExponent;
	private String bioAuthTimingVal;
	private String bioAuthTimeOutVal;
	private String display;
	private String randomNum;
}
