package com.dsb.eb2.sso.model;

import com.dsb.eb2.framework.controller.BaseObject;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class LoginBean extends BaseObject{
	
	private String userId;
	private String loginEBID;
	private String checkSum;
	private String ToSecurities;
	private String returnErr;
	private String secPkg;
	private String randomNumber;
	private String biometricLogin;
	private String page;
	private String epin;
}
