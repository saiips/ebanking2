package com.dsb.eb2.sso.model;

public class EBankingUserId
{
	public static final String EBID_STATUS_AMEND = "A";
	public static final String EBID_STATUS_NORMAL = "N";
	public static final String EBID_STATUS_FORGET = "F";
	public static final String EBID_STATUS_TERMINATE = "T";
	
	public static final String DEFAULT_USER = "SYSTEM";

	private String userid = null;
	private String ebid = null;
	private String pbid = null;
	private String eCertPbid = null;
	private String custId = null;
	private String ebid_status = null;
	private boolean create_self_assign_id_flag = false;
	private boolean first_time_login_flag = false;
	private boolean to_isecurities = false;
	private boolean skip_registration = false;
	private boolean display_ebid_flag = false;
	
	public EBankingUserId()
	{
	}
	
	public String getUserId()
	{
		return userid;
	}

	public String getEbId()
	{
		return ebid;
	}

	public String getPbId()
	{
		return pbid;
	}

	public String getECertPbId()
	{
		return eCertPbid;
	}
	
	public String getCustId()
	{
		return custId;
	}
	
	public String getEbIdStatus()
	{
		return ebid_status;
	}

	public boolean isCreateSelfAssignID()
	{
		return create_self_assign_id_flag;
	}

	public boolean isFirstTimeLogin()
	{
		return first_time_login_flag;
	}

	public boolean isToISecurities()
	{
		return to_isecurities;
	}

	public boolean isSkipRegistration()
	{
		return skip_registration;
	}
	
	public boolean isDisplayEBID()
	{
		return display_ebid_flag;
	}
	
	public void setUserId(String userid)
	{
		this.userid = userid;
	}

	public void setEbId(String ebid)
	{
		this.ebid = ebid;
	}

	public void setPbId(String pbid)
	{
		this.pbid = pbid;
	}

	public void setECertPbId(String eCertPbid)
	{
		this.eCertPbid = eCertPbid;
	}
	
	public void setCustId(String custId)
	{
		this.custId = custId;
	}

	public void setEbIdStatus(String ebid_status)
	{
		this.ebid_status = ebid_status;
	}

	public void setCreateSelfAssignID(boolean create_self_assign_id_flag)
	{
		this.create_self_assign_id_flag = create_self_assign_id_flag;
	}

	public void setFirstTimeLoginFlag(boolean first_time_login_flag)
	{
		this.first_time_login_flag = first_time_login_flag;
	}

	public void setToISecurities(boolean to_isecurities)
	{
		this.to_isecurities = to_isecurities;
	}
	
	public void setSkipRegistration(boolean skip_registration)
	{
		this.skip_registration = skip_registration;
	}
	
	public void setDisplayEBIDFlag(boolean display_ebid_flag)
	{
		this.display_ebid_flag = display_ebid_flag;
	}
	
	public boolean isNumericForUserId()
	{
		try {
			boolean isNumber = true;
			for (int i=0; i < userid.length(); i++)
			{
				int n = (int)userid.charAt(i);
				if (n < 48 || n > 57)
				{
					isNumber = false;
					break;
				}
			}
		
			return isNumber;
		}
		catch (Exception e)
		{
			return false;
		}
	}
}