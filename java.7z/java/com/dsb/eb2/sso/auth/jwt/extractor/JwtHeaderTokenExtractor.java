package com.dsb.eb2.sso.auth.jwt.extractor;

import org.apache.commons.lang3.StringUtils;
import org.springframework.security.authentication.AuthenticationServiceException;

public class JwtHeaderTokenExtractor implements TokenExtractor {
    public static String HEADER_PREFIX = "Bearer ";

    @Override
    public String extract(String header) {
    	String token = header;

		if (StringUtils.isEmpty(header)) {
			throw new AuthenticationServiceException("Authorization header cannot be blank!");
		}

		if (header.length() < HEADER_PREFIX.length()) {
			throw new AuthenticationServiceException("Invalid authorization header size.");
		}

		if (header.startsWith(HEADER_PREFIX)) {
			token = header.substring(HEADER_PREFIX.length(), header.length());
		}

		return token;
    }
}
