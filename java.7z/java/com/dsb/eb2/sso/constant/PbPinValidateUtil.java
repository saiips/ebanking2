package com.dsb.eb2.sso.constant;

import java.util.Hashtable;

import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.System.exeption.SystemException;
import com.dsb.eb2.util.StringUtils;

public class PbPinValidateUtil {

	private static final String strHostSpace = " ";
	private static final int LengthPBPw = 6;
	private static final int ModPBPwChar = 38;
	private static final int PwRangeShf = 120;
	private static final int SizePBPwChar = 38;
	private static Hashtable siHash = new Hashtable(SizePBPwChar);
	private static Hashtable isHash = new Hashtable(SizePBPwChar);
	private static final String SPBLMsgHdr = "PBT1LOGN00E";
	private static final String TLGNMsgHdr = "PBT1TLGN00E";
	private static final String StrPBMsgTrl = "___________________________________________________________________________________";
	public static final String NF1150_REQMSG_FORMAT = "%1$-1918s";
	private static final String StrCifMsgHdr = "CFPP/56K014HB";
	private static final String StrCifMsgTrl = "_00";


	static {
		fillSiHash();
		fillIsHash();
	}

	private static void pSi(int i, char s) {
		siHash.put(new Character(s), new Integer(i));
	}

	private static void pIs(char s, int i) {
		isHash.put(new Integer(i), new Character(s));
	}

	private static void fillSiHash() {
		pSi(1, '0');
		pSi(5, '1');
		pSi(12, '2');
		pSi(2, '3');
		pSi(3, '4');
		pSi(13, '5');
		pSi(10, '6');
		pSi(14, '7');
		pSi(4, '8');
		pSi(15, '9');
		pSi(7, 'A');
		pSi(16, 'B');
		pSi(17, 'C');
		pSi(9, 'D');
		pSi(8, 'E');
		pSi(11, 'F');
		pSi(19, 'G');
		pSi(24, 'H');
		pSi(20, 'I');
		pSi(31, 'J');
		pSi(36, 'K');
		pSi(25, 'L');
		pSi(30, 'M');
		pSi(34, 'N');
		pSi(23, 'O');
		pSi(35, 'P');
		pSi(28, 'Q');
		pSi(26, 'R');
		pSi(18, 'S');
		pSi(21, 'T');
		pSi(33, 'U');
		pSi(27, 'V');
		pSi(37, 'W');
		pSi(22, 'X');
		pSi(32, 'Y');
		pSi(29, 'Z');
		pSi(38, ' ');
	}

	private static void fillIsHash() {
		pIs('Z', 0);
		pIs('Y', 1);
		pIs('X', 2);
		pIs('W', 3);
		pIs('V', 4);
		pIs('U', 5);
		pIs('T', 6);
		pIs('S', 7);
		pIs('R', 8);
		pIs('Q', 9);
		pIs('P', 10);
		pIs('O', 11);
		pIs('N', 12);
		pIs('M', 13);
		pIs('L', 14);
		pIs('K', 15);
		pIs('J', 16);
		pIs('I', 17);
		pIs('H', 18);
		pIs('G', 19);
		pIs('F', 20);
		pIs('E', 21);
		pIs('D', 22);
		pIs('C', 23);
		pIs('B', 24);
		pIs('A', 25);
		pIs('9', 26);
		pIs('8', 27);
		pIs('7', 28);
		pIs('6', 29);
		pIs('5', 30);
		pIs('4', 31);
		pIs('3', 32);
		pIs('2', 33);
		pIs('1', 34);
		pIs('0', 35);
		pIs('&', 36);
		pIs('/', 37);
	}
	
	private static String pbEncryptId(String pbId) {
		return (pbId + filler(20 - pbId.length()));
	}

	private static String filler(int iSize) {
		String sFiller = "";
		for (int i = 0; i < iSize; i++)
			sFiller += strHostSpace;
		return sFiller;
	}

	private static String pbEncryptPw(String pbPassword) throws SystemException {
		String mName = "Operator.pbEncryptPw:";
		String ePbPassword = "";
		int[] aI = new int[LengthPBPw + 1];
		/*
		 * Algorithm for encryption: 1.map char[0..5] into int[1..6] 2a.int[0] = 0
		 * 2b.int[i] = (int[i-1] + int[i]) mod 38 {i > 0} 3.map int[1..6] back into
		 * char[0..5]
		 */
		aI[0] = 0;
		for (int i = 1; i <= LengthPBPw; i++) {

			// 1.char to int
			try {
				aI[i] = pwStr2Int(pbPassword.charAt(i - 1));
			} catch (Exception e) {
				throw new SystemException(SystemStatusCode.SSC_PB_PIN_ENCRYPT_ERROR,
						mName + "Error happened in 1st pass " + e.toString());
			}

			// 2.encryt
			aI[i] = (aI[i] + aI[i - 1]) % ModPBPwChar;

			// 3.int to char
			try {
				ePbPassword += pwInt2Str(aI[i]).toString();
			} catch (Exception e) {
				throw new SystemException(SystemStatusCode.SSC_PB_PIN_ENCRYPT_ERROR,
						mName + "Error happened in 3rd pass " + e.toString());
			}
		}
		return ePbPassword;
	}

	private static Character pwInt2Str(int i) throws SystemException {
		String mName = "Operator.pbInt2Str:";

		Character s = (Character) isHash.get(new Integer(i));
		if (s == null) {
			throw new SystemException(SystemStatusCode.SSC_PB_INVALID_INT, mName);
		}
		return s;
	}

	private static int pwStr2Int(char s) throws SystemException {
		String mName = "Operator.pbStr2Int:";
		Integer i = (Integer) siHash.get(new Character(s));
		if (i == null) {
			throw new SystemException(SystemStatusCode.SSC_PB_INVALID_CHAR, mName);
		}
		return i.intValue() + PwRangeShf;
	}
	
	public static String getPbPinEncryptStr(String pbId, String pbPin) throws Exception {
		if (StringUtils.isBlank(pbId) || StringUtils.isBlank(pbPin)) {
			throw new Exception("pbPin/pbid is null");
		}
		return SPBLMsgHdr + pbEncryptId(pbId) + pbEncryptPw(pbPin) + StrPBMsgTrl;
	}
	
	public static String getpbIdEncryptStr(String pbId) throws Exception {
		if (StringUtils.isBlank(pbId)) {
			throw new Exception("pbid is null");
		}
		return TLGNMsgHdr + pbEncryptId(pbId) + "      " + StrPBMsgTrl;
	}

	public static String getCustIdEncryptStr(String realPbId) {
		return StrCifMsgHdr + pbEncryptId(realPbId) + StrCifMsgTrl;
	}

}
