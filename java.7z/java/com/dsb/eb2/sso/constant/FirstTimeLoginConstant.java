package com.dsb.eb2.sso.constant;

public class FirstTimeLoginConstant {

    
    // request fields on first time login AuthenCard
    public static final String CARDNUM = "cardNum";
    public static final String CVV2 = "cvv2";
    public static final String HKIDPARTIAL = "hkidPartial";
    public static final String WEBPIN_CODE = "webpincode";
    public static final String RANDOM_NUMBER = "randomNum";
    public static final String CHECK_SUM = "checkSum";
    
    //EXCEPTION PARAMETER
    public static final String EXCEPTION_CARDAUTHEN= "exception_cardAuthen";
    public static final String NF1120_SEQUENCE_NUMBER = "01";
    
  //e-Statement / e-Advice / e-Alert
    public static final String TYPE_SMS = "S";
	public static final String TYPE_EMAIL = "E";

	public static final String OPTIN_YES = "Y";
	public static final String OPTIN_NO = "N";
  
	public static final String TYPE_STMT = "1";
	public static final String TYPE_ADVICE = "2";
	
	public static final String DEPOSIT_STATEMENT = "S01";
	public static final String CREDIT_CARD_STATEMENT = "S02"; 
	public static final String SECURITIES_TRADING_STATEMENT = "S03"; 
	public static final String FIXED_DEPOSIT_ADVICE = "A01"; 
	public static final String REMITTANCE_ADVICE = "A02"; 
	public static final String SECURITIES_TRADING_ADVICE = "A03"; 
	public static final String FX_PRICE_WATCH = "FS01";
	
	public static final String Service_InwardRemittance = "RS01";
    
}
