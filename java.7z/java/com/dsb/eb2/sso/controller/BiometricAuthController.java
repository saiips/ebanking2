package com.dsb.eb2.sso.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.logging.LogLevel;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.biometric.BiometricConstants;
import com.dsb.eb2.bankApp.biometric.BiometricHandler;
import com.dsb.eb2.bankApp.biometric.BiometricTransAuthService;
import com.dsb.eb2.bankApp.biometric.BiometricUtils;
import com.dsb.eb2.bankApp.dao.bioAuthDetail.BioAuthDetailDao;
import com.dsb.eb2.framework.controller.ApiController;
import com.dsb.eb2.framework.controller.BaseController;
import com.dsb.eb2.framework.log.Loggable;
import com.dsb.eb2.util.StringUtils;

@RestController
@RequestMapping(ApiController.SSO_PATH)
@Loggable
public class BiometricAuthController extends BaseController {

	private static Logger logger = LoggerFactory.getLogger(BiometricAuthController.class);

	@Autowired
	private BioAuthDetailDao bioAuthDetailDao;

	@Autowired
	private BiometricHandler bioHandler;
	
	@Autowired
	private BiometricTransAuthService bioAuthSrv;

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/user/bioAuthRefreshQRCode", method = RequestMethod.POST)
	@Loggable(result = false, value = LogLevel.INFO)
	public ResponseEntity<Map<String, Object>> bioAuthRefreshQRCode(HttpServletRequest request,
			HttpServletResponse response, @RequestBody Map<String, Object> payload) {
		String path = request.getRequestURI();
		boolean toSecurities = Boolean.getBoolean(payload.get("toSecurities").toString());
		String token = "";
		String custId = "";
		HttpHeaders headers = new HttpHeaders();
		headers.add(ApiController.CONTENT_TYPE, ApiController.CONTENT_TYPE_APPL_JSON);
		Map<String, Object> map = new HashMap<String, Object>();
		int errorCode = SystemStatusCode.SSC_UNEXPECTED;
		try {
			String loginType = toSecurities ? BiometricConstants.LOGIN_TYPE_ISEC : BiometricConstants.LOGIN_TYPE_EB;
			token = bioHandler.createLoginBioAuth(BiometricConstants.GEN_LOGIN_QRCODE, custId, loginType);
			if(!StringUtils.isEmpty(token)) {
				map.put("qrCodeStr", token);
				errorCode = SystemStatusCode.SSC_NORMAL;
			}		
			
		} catch (Exception e) {
			logger.error("BiometricAuthController bioAuthRefreshQRCode get token error!");
			errorCode = SystemStatusCode.SSC_UNEXPECTED;
		}
		if(errorCode==SystemStatusCode.SSC_NORMAL) {
			return (new ResponseEntity<Map<String, Object>>(map, headers, HttpStatus.OK));
		}else {
			map = getReturnModel(errorCode, path);
			return (new ResponseEntity<Map<String, Object>>(map, headers, HttpStatus.UNAUTHORIZED));
		}		
	}

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/user/bioAuthCheckStatus", method = RequestMethod.POST)
	@Loggable(result = false, value = LogLevel.INFO)
	public ResponseEntity<Map<String, Object>> bioAuthCheckStatus(HttpServletRequest request,
			HttpServletResponse response, @RequestBody Map<String, Object> payload) {
		String path = request.getRequestURI();   
		String tlkToken = payload.get(BiometricConstants.TLK_TOKEN).toString();
		HttpHeaders headers = new HttpHeaders();
		headers.add(ApiController.CONTENT_TYPE, ApiController.CONTENT_TYPE_APPL_JSON);
		Map<String, Object> map = new HashMap<String, Object>();
		String tokenStatus = "";
		int errorCode = SystemStatusCode.SSC_UNEXPECTED;
		try {
			if (StringUtils.isEmpty(tlkToken)) {
				map = getReturnModel(errorCode, path);
				return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.BAD_REQUEST));
			}
			JSONObject json = bioAuthDetailDao.getAuthDetailByToken(tlkToken, "A");
			tokenStatus = json.getString("TOKEN_STATUS");
			if (!StringUtils.isEmpty(tokenStatus)&&"A".equals(tokenStatus)) {
				map = getReturnModel(SystemStatusCode.SSC_NORMAL, path);
				return (new ResponseEntity<Map<String, Object>>(map, headers, HttpStatus.OK));
			}			
		} catch (Exception e) {
			logger.info("bioAuthCheckStatus getAuthDetailByToken error");			
		}
		map = getReturnModel(errorCode, path);
		return (new ResponseEntity<Map<String, Object>>(map, headers, HttpStatus.UNAUTHORIZED));
	}

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/user/bioAuthSendPushNotif", method = RequestMethod.POST)
	@Loggable(result = false, value = LogLevel.INFO)
	public ResponseEntity<Map<String, Object>> bioAuthSendPushNotif(HttpServletRequest request,
			HttpServletResponse response, @RequestBody Map<String, Object> payload) throws Exception {
		String path = request.getRequestURI(); 
		HttpHeaders headers = new HttpHeaders();
		headers.add(ApiController.CONTENT_TYPE, ApiController.CONTENT_TYPE_APPL_JSON);
		Map<String, Object> json = new HashMap<String, Object>();
		String token = "";
		int errorCode = SystemStatusCode.SSC_UNEXPECTED;
		try {
			boolean toSecurities = Boolean.getBoolean(payload.get("toSecurities").toString());
			String ebid = payload.get("ebid").toString();
			int lang = BiometricConstants.convertLangType(payload.get("lang").toString());			
			
			String custId = "";
			String fioId = "";
			String deviceId = "";
			String msgTitle = "";
			String msgBody = "";
			boolean isIOS = false;

			if (StringUtils.isEmpty(ebid)) {
				token = BiometricConstants.EBID_NOT_EXIST;
			} else {
				custId = bioHandler.getCustIdByEbId(ebid);
				if(StringUtils.isEmpty(custId)) {
					logger.error("custId is empty!");
					json = getReturnModel(errorCode, path);
					return (new ResponseEntity<Map<String, Object>>(json, headers, HttpStatus.UNAUTHORIZED));
				}
				String[] pushNotificationInfo = bioHandler.getPushNotificationInfo(custId);
				if (pushNotificationInfo == null || pushNotificationInfo.length < 2) {
					token = BiometricConstants.NO_REG_BIOAUTH;
				} else {
					logger.info("CreateLoginBioAuthServlet.processRequest ebid(" + ebid + ") pushNotificationInfo[0]="
							+ pushNotificationInfo[0] + ", pushNotificationInfo[1]=" + pushNotificationInfo[1]);
					fioId = pushNotificationInfo[0];
					isIOS = ("Apple".equals(pushNotificationInfo[1]) ? true : false);
					deviceId = pushNotificationInfo[2];
					if (StringUtils.isEmpty(fioId)) {
						token = BiometricConstants.NO_REG_BIOAUTH;
					}
				}
			}

			if (StringUtils.isEmpty(token)) {
				String loginType = toSecurities ? BiometricConstants.LOGIN_TYPE_ISEC : BiometricConstants.LOGIN_TYPE_EB;

				token = bioHandler.createLoginBioAuth(BiometricConstants.GEN_LOGIN_NOTIF, custId, loginType);

				msgTitle = BiometricConstants.BIO_AUTH_NOTIFICATION_TITLE[lang];
				BiometricUtils biometricUtils = new BiometricUtils();
				if (toSecurities) {
					msgBody = biometricUtils.getPushMessage(BiometricConstants.BIO_AUTH_TYPE_ISECURITY_EB_TITLE, lang);
				} else {
					msgBody = biometricUtils.getPushMessage(BiometricConstants.BIO_AUTH_TYPE_LOGIN_EB_TITLE, lang);
				}
				
				HashMap<String, String> result = bioAuthSrv.pushNotification(fioId, msgTitle, msgBody, isIOS, true);				
				
	    		if(result != null && BiometricConstants.BIOMETRIC_FIDO_OK_CODE.equals(result.get("status")))
	    		{
	    			String msg_status = JSONObject.parseObject(result.get("responseBody")).getJSONObject("message").getString("status");
	    			if(!"FAILED".equalsIgnoreCase(msg_status)){
	    				boolean flag = bioAuthSrv.logPushMessage(BiometricConstants.LOGPUSH_EB_LOGIN, null, custId, deviceId, msgTitle, msgBody, lang, null);
	    				if(flag) {
	    					errorCode = SystemStatusCode.SSC_NORMAL;
	    				}
	    			}
	    		}
			}			
	    		
		} catch (Exception e) {
			logger.info("CreateLoginBioAuthServlet.processRequest pushNotification catch exception:" + e.getMessage(),e);
			errorCode = SystemStatusCode.SSC_UNEXPECTED;
		}
		if(errorCode == SystemStatusCode.SSC_NORMAL) {
			json = getReturnModel(errorCode, path);
			return (new ResponseEntity<Map<String, Object>>(json, headers, HttpStatus.OK));
		}else {
			json = getReturnModel(errorCode, path);
			if(BiometricConstants.EBID_NOT_EXIST.equals(token)) {
				return (new ResponseEntity<Map<String, Object>>(json, headers, HttpStatus.BAD_REQUEST));
			}			
			return (new ResponseEntity<Map<String, Object>>(json, headers, HttpStatus.UNAUTHORIZED));
		}
	}

	 public Map<String,Object> getReturnModel(int errorCode, String path){
	    	Map<String,Object> map = new HashMap<String,Object>();
	    	if(errorCode == SystemStatusCode.SSC_NORMAL) {
	    		map.put("status", "Success!");
				map.put("message", "Success!");    		
	    	}else {
	    		map.put("timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()));
				map.put("status", "Failed!");
				map.put("error", String.valueOf(errorCode));
				map.put("message", "Failed!");
				map.put("path", path);
	    	}
	    	return map;
	    }

}
