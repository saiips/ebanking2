package com.dsb.eb2.sso.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.logging.LogLevel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dsb.eb2.bankApp.System.DateUtils;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.System.exeption.ExtendedException;
import com.dsb.eb2.bankApp.pinServer.PinServer;
import com.dsb.eb2.framework.controller.ApiController;
import com.dsb.eb2.framework.controller.BaseController;
import com.dsb.eb2.framework.log.Loggable;
import com.dsb.eb2.sso.service.LoginService;
import com.dsb.eb2.sso.service.LoginValidateService;
import com.dsb.eb2.util.StringUtils;

@RestController
@RequestMapping(ApiController.API_PATH)
@Loggable
public class PasswordHandleController extends BaseController{

	private static Logger logger = LoggerFactory.getLogger(LoginController.class);
    
	@Autowired
	private LoginValidateService loginValidateService;
	
	@Autowired
	private LoginService loginService;
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value="user/ebidPwdSetup", method = RequestMethod.POST)
    @Loggable(result = false, value = LogLevel.INFO)
    public ResponseEntity<Map<String, Object>> ebidPwdSetup(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> payload) {
		
		String ebid = "";
		String pinblock = "";
		String randomNum = "";
		String checkSum = "";
		String publicKeyIndex = "";
		int errorCode = SystemStatusCode.SSC_NORMAL;
		String errorStr = "";
		Map<String, Object> map = new HashMap<String, Object>();
		
		try {
			map.put("timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date())); 
			map.put("path", ApiController.SSO_PATH + "/user/authenByAtm"); 
			ebid = payload.get(ApiController.EBID).toString();
			publicKeyIndex = payload.get(ApiController.PUBLIC_KEY_INDEX).toString();
	        pinblock = payload.get(ApiController.PINBLOCK).toString();
	        randomNum = payload.get(ApiController.RANDOM_NUMBER).toString();
	        checkSum = payload.get(ApiController.CHECK_SUM).toString();
	        
	        if(StringUtils.isBlank(ebid) || StringUtils.isBlank(publicKeyIndex) || StringUtils.isBlank(checkSum)) {
	        	map.put("status", SystemStatusCode.SSC_UNEXPECTED);
				map.put("message","atmPin/atmNum/checkSum validate error");
				return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
	        }
	        errorCode = loginValidateService.validatePinRetrunAndRandom(pinblock,randomNum, "");
	        logger.info("FirstTimeLoginController.authenByAtm call loginValidateService.validatePinRetrunAndRandom errorCode=" + errorCode);
			if (errorCode != SystemStatusCode.SSC_NORMAL) {
				map.put("status", errorCode);
				map.put("message", "fail!");
				return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
			}
			loginService.saveCustomerBean(ebid);
			PinServer pinServer = new PinServer();
			errorCode = pinServer.initPin(ebid,publicKeyIndex,pinblock,checkSum,DateUtils.getCurrentEmsTsStr()); 
			if (errorCode != SystemStatusCode.SSC_NORMAL) {
				map.put("status", errorCode);
				map.put("message", "initPin error !");
				return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
			}
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			if(e instanceof ExtendedException) {
				errorCode = ((ExtendedException) e).getErrorCode();
			}else {
				errorCode = SystemStatusCode.SSC_UNEXPECTED;
			}
		}
		
		HttpStatus httpStatus = null;
		if(errorCode == SystemStatusCode.SSC_NORMAL) {
			errorStr = "success!";
			map.put("status", "");
			map.put("message", errorStr);
			httpStatus = HttpStatus.OK;
		} else {
			map.put("status", errorCode);
			map.put("message", errorStr);
			httpStatus = HttpStatus.UNAUTHORIZED;
		}
		return (new ResponseEntity<Map<String, Object>>(map, null, httpStatus));
	}

	
}
