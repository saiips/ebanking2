package com.dsb.eb2.sso.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.boot.logging.LogLevel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dsb.eb2.bankApp.pinServer.PinServer;
import com.dsb.eb2.framework.controller.ApiController;
import com.dsb.eb2.framework.controller.BaseController;
import com.dsb.eb2.framework.log.Loggable;

@RestController
@RequestMapping(ApiController.SSO_PATH)
@CrossOrigin
public class InitLoginController extends BaseController {
	
	private final Log log = LogFactory.getLog(this.getClass());
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/webpin/getThalesPKI", method = RequestMethod.POST)
	@ResponseBody
	@Loggable(result = false, value = LogLevel.INFO)
	public ResponseEntity<Map<String, Object>> loginInit(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		PinServer ps = new PinServer(); // Autowired
		getPinServerAttr(map,ps);
		return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.OK));
	}

	private void getPinServerAttr(Map<String, Object> map,PinServer ps) {
		String random = ps.getWebPinRandom("");
		String webPinKeyExponent = ps.getWebPinKeyExponent();
		String keyIndex = ps.getWebPinKeyIndex();
		String webPinKeyModule = ps.getWebPinKeyModule();
		map.put("RandomNum", random);
		map.put("PublicKeyIndex", keyIndex);
		map.put("PublicKey", webPinKeyModule);
		map.put("Exp", webPinKeyExponent);
	}
	
}
