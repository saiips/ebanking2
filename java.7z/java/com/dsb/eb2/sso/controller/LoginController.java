package com.dsb.eb2.sso.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.logging.LogLevel;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.System.exeption.ExtendedException;
import com.dsb.eb2.bankApp.System.maintenance.ActivityLog;
import com.dsb.eb2.bankApp.pinServer.PinServer;
import com.dsb.eb2.framework.controller.ApiController;
import com.dsb.eb2.framework.controller.BaseController;
import com.dsb.eb2.framework.log.Loggable;
import com.dsb.eb2.framework.security.AuthService;
import com.dsb.eb2.framework.security.exceptions.InvalidJwtToken;
import com.dsb.eb2.framework.security.exceptions.JwtExpiredTokenException;
import com.dsb.eb2.sso.service.CustomerAuthenticationService;
import com.dsb.eb2.sso.service.LoginService;
import com.dsb.eb2.sso.service.LoginValidateService;
import com.dsb.eb2.util.StringUtils;

@RestController
@RequestMapping(ApiController.SSO_PATH)
@Loggable
public class LoginController extends BaseController {
	
	private static Logger logger = LoggerFactory.getLogger(LoginController.class);
	
    @Autowired
    private AuthService authService;
    
	@Autowired
	private LoginValidateService loginValidateService;
	
	@Autowired
	private CustomerAuthenticationService customerAuthenticationService;
	
	@Autowired
	private ActivityLog activityLog;
	
	@Autowired
	private LoginService loginService;
	
    
	@CrossOrigin(origins = "*")
	@RequestMapping(value="/user/authenticate", method = RequestMethod.POST)
    @Loggable(result = false, value = LogLevel.INFO)
    public ResponseEntity<Map<String, Object>> authenticate(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> payload) {
    	// request payload
		String path = ApiController.SSO_PATH + "/user/authenticate";
		int errorCode = SystemStatusCode.SSC_NORMAL;
		Map<String, Object> map = new HashMap<String, Object>();
		String username = "";
		String pinblock = "";
		String errorStr = "";

        username = payload.get(ApiController.USERNAME).toString();
        pinblock = payload.get(ApiController.PINBLOCK).toString();
        
		try {
			String publicKeyIndex = null;
	        username = payload.get(ApiController.USERNAME).toString();
	        pinblock = payload.get(ApiController.PINBLOCK).toString();
	        String randomNumber = payload.get(ApiController.RANDOM_NUMBER).toString();
	        String checkSum = payload.get(ApiController.CHECK_SUM).toString();
	        if (payload.get(ApiController.PUBLIC_KEY_INDEX) != null) publicKeyIndex = payload.get(ApiController.PUBLIC_KEY_INDEX).toString();
	        if(StringUtils.isBlank(username) || StringUtils.isBlank(checkSum)) {
	        	errorStr = "username/checkSum validate error";
	        	activityLog.insertActivityLog(username, errorStr, SystemStatusCode.SSC_UNEXPECTED);
	        	map.put("status", SystemStatusCode.SSC_UNEXPECTED);
				map.put("message",errorStr);
				return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
	        }
			
	        // logic of login module (EBID & PINBlock)
			map.put("timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date())); 
			map.put("path", path); 
			errorCode = loginValidateService.validatePinRetrunAndRandom(pinblock,randomNumber, "");
			logger.info(path+" call loginValidateService.validatePinRetrunAndRandom errorCode=" + errorCode);
			if (errorCode != SystemStatusCode.SSC_NORMAL) {
	        	errorStr = "Call webPin library return error/Random Number validate error";
	        	activityLog.insertActivityLog(username, errorStr, errorCode);
				map.put("status", errorCode);
				map.put("message",errorStr);
				return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
			} 
			
			PinServer pinServer = new PinServer();
			errorCode = customerAuthenticationService.validate("", checkSum, publicKeyIndex, randomNumber, false, false, "", pinServer, pinblock, username);
			logger.info(path+" call customerAuthenticationService.validate errorCode=" + errorCode);
			if (errorCode != SystemStatusCode.SSC_NORMAL) {
	        	errorStr = "Call emsSOALogon or queryEBID  error";
	        	activityLog.insertActivityLog(username, errorStr, errorCode);
				map.put("status", errorCode);
				map.put("message", errorStr);
				return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
			}
		} catch (ExtendedException e) {
			logger.error(e.getMessage(),e);
			if(e instanceof ExtendedException) {
				errorCode = ((ExtendedException) e).getErrorCode();
			}else {
				errorCode = SystemStatusCode.SSC_UNEXPECTED;
			}
        	errorStr = e.getMessage();
        	activityLog.insertActivityLog(username, errorStr, errorCode);
			map.put("status", errorCode);
			map.put("message", errorStr);
			return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
		}
		
		// invoke Auth Service for CAS SSO login and generate the JWT 
		HttpHeaders headers = authService.login(request, response, username, pinblock);

		try {
			loginService.saveCusSession();
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
        	errorStr = e.getMessage();
        	activityLog.insertActivityLog(username, errorStr, errorCode);
			map.put("status", SystemStatusCode.SSC_UNEXPECTED);
			map.put("message", errorStr);
			return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
		}
		
		errorStr = "success!";
		map.put("status", "");
		map.put("message", errorStr);
		activityLog.insertActivityLog(username, errorStr, errorCode);
		
		
	    return (new ResponseEntity<Map<String, Object>>(map, headers, HttpStatus.OK));
    }
    
	@CrossOrigin(origins = "*")
	@RequestMapping(value="/user/logout", method = RequestMethod.POST)
    @Loggable(result = false, value = LogLevel.INFO)
	public ResponseEntity<Map<String, Object>> logout(HttpServletRequest request, HttpServletResponse response, @RequestHeader Map<String, Object> headerMap) throws ParseException {
		
		String header = headerMap.get(ApiController.REFRESH_AUTHORIZATION.toLowerCase()).toString();
		
		String uuid = authService.logout(request, response, header);
		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("sessionUUID", uuid);
		
		return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.OK));
	}
	
	
	
   
    @CrossOrigin(origins = "*")
	@RequestMapping(value="/token/refresh", method = RequestMethod.POST)
    @Loggable(result = false, value = LogLevel.INFO)    
    public ResponseEntity<Map<String, Object>> refresh(HttpServletRequest request, HttpServletResponse response, @RequestHeader Map<String, Object> headerMap) throws ParseException {
    	
    	String header = headerMap.get(ApiController.REFRESH_AUTHORIZATION.toLowerCase()).toString();
		
    	HttpHeaders headers = authService.refresh(request, response, header);
		
    	return (new ResponseEntity<Map<String, Object>>(null, headers, HttpStatus.OK));
    }
    
    
    @CrossOrigin(origins = "*")
	@RequestMapping(value="/token/validate", method = RequestMethod.POST)
    @Loggable(result = false, value = LogLevel.INFO)    
    public ResponseEntity<Map<String, Object>> validate(HttpServletRequest request, HttpServletResponse response, @RequestHeader Map<String, Object> headers) {
    	Map<String, Object> json = null;
    	
    	try {
        	String header = headers.get(ApiController.AUTHORIZATION.toLowerCase()).toString();
        	
        	HashMap<String, Object> result = authService.validate(request, response, header);
    		final String tokenStatus = (String) result.get(ApiController.TOKEN_STATUS);
    		
        	if (ApiController.TOKEN_EXPIRED.equals(tokenStatus)) {
        		 json = responseMsgValidate(401, new JwtExpiredTokenException("JWT is expired").getClass().getSimpleName(), "AUTHENTICATION_FAILED", ApiController.SSO_PATH + "/token/validate");
        		 return (new ResponseEntity<Map<String, Object>>(json, null, HttpStatus.UNAUTHORIZED));
        		
        	} else if (ApiController.TOKEN_INVALID.equals(tokenStatus)) {
        		 json = responseMsgValidate(401,  new InvalidJwtToken().getClass().getSimpleName(), "AUTHENTICATION_FAILED", ApiController.SSO_PATH + "/token/validate");
        		 return (new ResponseEntity<Map<String, Object>>(json, null, HttpStatus.UNAUTHORIZED));
        	}

        } catch (Exception ex) {
        	ex.printStackTrace();
        	return (new ResponseEntity<Map<String, Object>>(null, null, HttpStatus.UNAUTHORIZED));
        }    
        
        return (new ResponseEntity<Map<String, Object>>(null, null, HttpStatus.OK));
    }
    
    private Map<String, Object> responseMsgValidate(int status, String exptionClass, String message, String path) {
		Map<String, Object> json = new HashMap<String, Object>();
    	json.put("timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()));
		json.put("status", status);
		json.put("error", exptionClass);
	    json.put("message", message);
	    json.put("path", path);
	    
	    return json;
    }
    
}
