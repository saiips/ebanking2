package com.dsb.eb2.sso.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.logging.LogLevel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dsb.eb2.bankApp.System.FunctionType;
import com.dsb.eb2.bankApp.System.SystemStatusCode;
import com.dsb.eb2.bankApp.System.exeption.ExtendedException;
import com.dsb.eb2.bankApp.System.exeption.SystemException;
import com.dsb.eb2.bankApp.System.maintenance.ActivityLog;
import com.dsb.eb2.bankApp.dao.activityLog.ActivityLogBean;
import com.dsb.eb2.bankApp.dao.ccAcctInfo.CreditCardDAO;
import com.dsb.eb2.framework.controller.ApiController;
import com.dsb.eb2.framework.controller.BaseController;
import com.dsb.eb2.framework.log.Loggable;
import com.dsb.eb2.sso.constant.FirstTimeLoginConstant;
import com.dsb.eb2.sso.service.FirstTimeLoginService;
import com.dsb.eb2.sso.service.LoginValidateService;
import com.dsb.eb2.util.StringUtils;

@RestController
@RequestMapping(ApiController.SSO_PATH)
@Loggable
public class FirstTimeLoginController extends BaseController{
	
	private static Logger log = LoggerFactory.getLogger(FirstTimeLoginController.class);

	@Autowired
	private FirstTimeLoginService firstLoginService;
	
	@Autowired
	private LoginValidateService loginValidateService;
	
	@Autowired
	private CreditCardDAO creditCardDao;
	
	@Autowired
	private ActivityLog activityLog;
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value="/user/authenByPhoneBank", method = RequestMethod.POST)
    @Loggable(result = false, value = LogLevel.INFO)
    public ResponseEntity<Map<String, Object>> authenByPhoneBank(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> payload) {
		
		String pbId = "";
		String checkSum = "";
		String encPin = "";
		int errorCode = SystemStatusCode.SSC_NORMAL;
		Map<String, Object> map = new HashMap<String, Object>();
		
		try {
			map.put("timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date())); 
			map.put("path", ApiController.SSO_PATH + "/user/authenByPhoneBank"); 
			pbId = payload.get(ApiController.PBID).toString();
	        encPin = payload.get(ApiController.ENCPIN).toString();
	        checkSum = payload.get(ApiController.CHECK_SUM).toString();
	        if(StringUtils.isBlank(pbId) || StringUtils.isBlank(encPin) || StringUtils.isBlank(checkSum)) {
	        	map.put("status", SystemStatusCode.SSC_UNEXPECTED);
				map.put("message","pbid/pbPin/checkSum validate error");
				return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
	        }
	        /*errorCode = loginValidateService.validatePinRetrunAndRandom(pinblock,randomNum, "");
	        log.info("FirstTimeLoginController.authenByPhoneBank call loginValidateService.validatePinRetrunAndRandom errorCode=" + errorCode);
			if (errorCode != SystemStatusCode.SSC_NORMAL) {
				map.put("status", errorCode);
				map.put("message", "fail!");
				return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
			}*/
			
			boolean validateFlag = firstLoginService.validatePbpin(pbId, encPin);
			if(!validateFlag) {
				map.put("status", SystemStatusCode.SSC_UNEXPECTED);
				map.put("message", "validate pbPin error!");
				return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
			}
			
			/*String custId = firstLoginService.getCustIdFromNF1150(pbId);
			if(StringUtils.isBlank(custId)) {
				log.error("custId is null/blank");
				map.put("status", SystemStatusCode.SSC_UNEXPECTED);
				map.put("message", "custId is null/blank");
				return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
			}*/

			String custId = firstLoginService.getCustIdFromNF1122(pbId);
			if(StringUtils.isBlank(custId)) {
				log.error("getCustIdFromNF1122,custId is null/blank");
				map.put("status", SystemStatusCode.SSC_UNEXPECTED);
				map.put("message", "custId is null/blank");
				return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
			}
		} catch (Exception e) {
			log.error(e.getMessage(),e);
			if(e instanceof ExtendedException) {
				errorCode = ((ExtendedException) e).getErrorCode();
			}else {
				errorCode = SystemStatusCode.SSC_UNEXPECTED;
			}
		}
		if(errorCode == SystemStatusCode.SSC_NORMAL) {
			map.put("status", "");
			map.put("message", "success!");
			return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.OK));
		} else {
			map.put("status", errorCode);
			map.put("message", "fail!");
			return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
		}
	}
	
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value="/user/authenByAtm", method = RequestMethod.POST)
    @Loggable(result = false, value = LogLevel.INFO)
    public ResponseEntity<Map<String, Object>> authenByAtm(HttpServletRequest request, HttpServletResponse response, @RequestBody Map<String, Object> payload) {
		
		String atmNum = "";
		String pinblock = "";
		String randomNum = "";
		String checkSum = "";
		int errorCode = SystemStatusCode.SSC_NORMAL;
		Map<String, Object> map = new HashMap<String, Object>();
		
		try {
			map.put("timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date())); 
			map.put("path", ApiController.SSO_PATH + "/user/authenByAtm"); 
			atmNum = payload.get(ApiController.ATMNUM).toString();
	        pinblock = payload.get(ApiController.PINBLOCK).toString();
	        randomNum = payload.get(ApiController.RANDOM_NUMBER).toString();
	        checkSum = payload.get(ApiController.CHECK_SUM).toString();

	        if(StringUtils.isBlank(atmNum) || StringUtils.isBlank(checkSum)) {
	        	map.put("status", SystemStatusCode.SSC_UNEXPECTED);
				map.put("message","atmPin/atmNum/checkSum validate error");
				return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
	        }
	        errorCode = loginValidateService.validatePinRetrunAndRandom(pinblock,randomNum, "");
	        log.info("FirstTimeLoginController.authenByAtm call loginValidateService.validatePinRetrunAndRandom errorCode=" + errorCode);
			if (errorCode != SystemStatusCode.SSC_NORMAL) {
				map.put("status", errorCode);
				map.put("message", "fail!");
				return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
			}
			// TODO 1、validate atmPin;
			String custId = firstLoginService.getCustIdFromNF1120(atmNum);
			if(StringUtils.isBlank(custId)) {
				log.error("getCustIdFromNF1120,custId is null/blank");
				map.put("status", SystemStatusCode.SSC_UNEXPECTED);
				map.put("message", "custId is null/blank");
				return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
			}
		} catch (Exception e) {
			log.error(e.getMessage(),e);
			if(e instanceof ExtendedException) {
				errorCode = ((ExtendedException) e).getErrorCode();
			}else {
				errorCode = SystemStatusCode.SSC_UNEXPECTED;
			}
		}
		if(errorCode == SystemStatusCode.SSC_NORMAL) {
			map.put("status", "");
			map.put("message", "success!");
			return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.OK));
		} else {
			map.put("status", errorCode);
			map.put("message", "fail!");
			return (new ResponseEntity<Map<String, Object>>(map, null, HttpStatus.UNAUTHORIZED));
		}
	}
	

    @CrossOrigin(origins = "*")
	@RequestMapping(value = "/user/authenByCard", method = RequestMethod.POST)
	@Loggable(result = false, value = LogLevel.INFO)
	public ResponseEntity<Map<String, Object>> authenByCard(HttpServletRequest request, HttpServletResponse response,
			@RequestBody Map<String, Object> payload) throws IOException, Exception {
		
    	String path = request.getRequestURI();    	
    	
		Map<String, Object> map = new HashMap<String, Object>();
		HttpHeaders headers = new HttpHeaders();
		headers.add(ApiController.CONTENT_TYPE, ApiController.CONTENT_TYPE_APPL_JSON);		
		int errorCode = SystemStatusCode.SSC_UNEXPECTED;
		String custId = "";
		try {
			String cardNum = payload.get(FirstTimeLoginConstant.CARDNUM).toString();
			String cvv2 = payload.get(FirstTimeLoginConstant.CVV2).toString();
			String hkidPartial = payload.get(FirstTimeLoginConstant.HKIDPARTIAL).toString();
			if(StringUtils.isEmpty(cardNum)||StringUtils.isEmpty(cvv2)||StringUtils.isEmpty(hkidPartial)) {
				map = getReturnModel(errorCode, path);
				return (new ResponseEntity<Map<String, Object>>(map, headers, HttpStatus.BAD_REQUEST));
			}
			custId = creditCardDao.getCustIdByAcctNum(cardNum);
			request.getSession().setAttribute("custId", custId);
			String idNum = "";
			if(hkidPartial.length()==8) {
				idNum = hkidPartial.substring(1,5);
			}else {
				map = getReturnModel(errorCode, path);
				return (new ResponseEntity<Map<String, Object>>(map, headers, HttpStatus.BAD_REQUEST));
			}
			
			log.info("LoginController.authenByCard cardNum" + cardNum + ";cvv2" + cvv2 + ";hkidPartial" + hkidPartial + ";idNum" + idNum);
			errorCode = firstLoginService.callNF1530(cardNum, idNum, cvv2, custId);
			
		}catch(Exception e) {
			log.error(e.getMessage(),e);
			if(e instanceof SystemException) {
				errorCode = ((SystemException) e).getErrorCode();
			}else {
				errorCode = SystemStatusCode.SSC_UNEXPECTED;
			}
		}
		try {
			ActivityLogBean logBean = new ActivityLogBean(custId, FunctionType.MF_LOGIN, FunctionType.SF_CCARD_AUTHEN, errorCode);
			activityLog.record(logBean);
		}catch(Exception e) {
			e.printStackTrace();
			log.error("record activityLog error!");
			errorCode = SystemStatusCode.SSC_UNEXPECTED;
		}				
		
		if(errorCode==SystemStatusCode.SSC_NORMAL_EMS_RESPONE) {	
			errorCode = SystemStatusCode.SSC_NORMAL;
			map = getReturnModel(errorCode, path);
			return (new ResponseEntity<Map<String, Object>>(map, headers, HttpStatus.OK));
			
		}else {
			map = getReturnModel(errorCode, path);
			return (new ResponseEntity<Map<String, Object>>(map, headers, HttpStatus.UNAUTHORIZED));
		}
	}
    
    @CrossOrigin(origins = "*")
	@RequestMapping(value = "/user/serviceEnrol", method = RequestMethod.POST)
	@Loggable(result = false, value = LogLevel.INFO)
	public ResponseEntity<Map<String, Object>> serviceEnrol(HttpServletRequest request, HttpServletResponse response,
			@RequestBody Map<String, Object> payload) throws IOException, Exception {
    	Map<String, Object> map = new HashMap<String, Object>();
		HttpHeaders headers = new HttpHeaders();
		headers.add(ApiController.CONTENT_TYPE, ApiController.CONTENT_TYPE_APPL_JSON);
    	return (new ResponseEntity<Map<String, Object>>(map, headers, HttpStatus.OK));
    }
    
    public Map<String,Object> getReturnModel(int errorCode, String path){
    	Map<String,Object> map = new HashMap<String,Object>();
    	if(errorCode == SystemStatusCode.SSC_NORMAL) {
    		map.put("status", "Success!");
			map.put("message", "Success!");    		
    	}else {
    		map.put("timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()));
			map.put("status", "Failed!");
			map.put("error", String.valueOf(errorCode));
			map.put("message", "Failed!");
			map.put("path", path);
    	}
    	return map;
    }
}
