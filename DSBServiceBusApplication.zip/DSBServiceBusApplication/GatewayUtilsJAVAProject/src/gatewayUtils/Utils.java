package gatewayUtils;

import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStreamReader;

import java.io.OutputStreamWriter;

import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

import java.nio.charset.Charset;

import javax.script.Bindings;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;


public class Utils {
    public Utils() {
        super();
    }

    public static String convertStringToJSON(String jsonString) throws ScriptException {
        ScriptEngineManager manager = new ScriptEngineManager();
        ScriptEngine engine = manager.getEngineByName("javascript");
        Bindings bindings = engine.createBindings();
        return (String) engine.eval("JSON.parse(" + jsonString + ")", bindings);
        //        return (String)engine.eval(jsonString,bindings);
        //        return (String)engine.eval("JSON.stringify("+jsonString+")",bindings);
        //        return "{\"gatewayRequest\":{\"reqID\":\"ggyutuy68767nmvvnb\",\"type\":\"SESSION\",\"dataType\":\"USER_PROFILE\",\"coherenceRequired\":\"Y\",\"coherenceID\":\"123456ABCDE\",\"serviceURL\":\"http://129.213.113.4/DemoSBProject/RestService/DemoRestService\",\"serviceMethod\":\"POST\",\"requestPayload\":{\"groupId\":\"0a3687cf-65b4-1aaa-99a0-672000001da8\",\"entityType\":\"INDIVIDUAL\",\"providerTypes\":[\"WATCHLIST\"],\"name\":\"xuchenTest01\",\"customFields\":[{\"typeId\":\"0a3687d0-66ec-160d-99bd-82f0000001c3\",\"value\":\"custom field 1 sample value\"}],\"secondaryFields\":[{\"typeId\":\"SFCT_1\",\"value\":\"MALE\"},{\"typeId\":\"SFCT_2\",\"dateTimeValue\":\"2016-10-12\"},{\"typeId\":\"SFCT_3\",\"value\":\"USA\"},{\"typeId\":\"SFCT_4\",\"value\":\"AUS\"},{\"typeId\":\"SFCT_5\",\"value\":\"ABW\"}]}}}";
    }

    public static String callRestService(String serviceURL, String serviceMethod,
                                         String requestPayload) throws MalformedURLException, ProtocolException,
                                                                       IOException, ScriptException {
        return callRestService(serviceURL, serviceMethod, requestPayload, 60000);
    }

    public static String callRestService(String serviceURL, String serviceMethod, String requestPayload,
                                         int timeout) throws MalformedURLException, ProtocolException, IOException,
                                                             ScriptException {

        StringBuffer jsonString = null;
        String jsonReturn = "";
        HttpURLConnection conn = null;
        OutputStreamWriter writer = null;
        BufferedReader br = null;
        URL url = null;
        String bufString = "";
        //        JSONObject jsonObj = null;

        try {

            url = new URL(serviceURL);
            conn = (HttpURLConnection) url.openConnection();

            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setRequestMethod(serviceMethod);
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setConnectTimeout(timeout);

            if (requestPayload != null) {

                writer = new OutputStreamWriter(conn.getOutputStream(), "UTF-8");
                writer.write(requestPayload);
                writer.flush();
                writer.close();
            }
            
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
            }

            Charset charset = Charset.forName("UTF8");
            br = new BufferedReader(new InputStreamReader(conn.getInputStream(), charset));
            jsonString = new StringBuffer();
            while ((bufString = br.readLine()) != null) {
                jsonString.append(bufString);
            }

            br.close();

            //            jsonReturn = convertStringToJSON(jsonString.toString());
            jsonReturn = jsonString.toString();

        } catch (Exception e) {

            throw e;

        } finally {

            try {
                if (writer != null)
                    writer.close();
            } catch (Exception e) {
                // do nothing
            }

            try {
                if (br != null )
                    br.close();
            } catch (Exception e) {
                // do nothing
            }

            try {
                if (conn != null)
                    conn.disconnect();
            } catch (Exception e) {
                // do nothing
            }
        }

        return jsonReturn;

    }
}
