package com.dsb.eb2.cache.config;

import java.util.HashSet;
import java.util.Set;

import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.dsb.eb2.cache.CoherenceCacheManager;

@Configuration
@EnableCaching
@ComponentScan(basePackages = { "com.dsb.eb2.cache.*" })
public class CacheConfiguration {

	@Bean("cacheManager")
	public CacheManager getCacheManger() {
		Set<String> cacheNames = new HashSet<String>();
		cacheNames.add("simple-cache");
		CoherenceCacheManager cacheManager = new CoherenceCacheManager(cacheNames);
		return cacheManager;
	}
}
