package com.dsb.eb2.cache.service;

import java.util.Collection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.Cache.ValueWrapper;
import org.springframework.stereotype.Component;

import com.dsb.eb2.cache.CoherenceCacheManager;
import com.dsb.eb2.cache.model.Customer;

@Component("customerService")
public class CustomerService {
	
	private final Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private CoherenceCacheManager cacheManager;		
	
	private ICacheService cacheService;

    public ICacheService getCacheService() {
        return cacheService;
    }
 
    public void setCacheService(ICacheService cacheService) {
        this.cacheService = cacheService;
    }
	
	
    public void setCustomer(String customerID, Customer customer) {
    	
    	// getCacheService().addToCache(customerID, customer);
    	
    	// printCacheEntries();
    	
    	Cache cache = cacheManager.getCache("simple-cache");
    	
    	cache.put(customerID, customer);
    }
    
		
    public Customer getCustomer(String customerID) {
    	
    	// Customer customer = (Customer) getCacheService().getCache().get(customerID);
    	
    	
    	Cache cache = cacheManager.getCache("simple-cache");
    	ValueWrapper valueWrapper = cache.get(customerID);
    	
    	log.debug("valueWrapper=" + valueWrapper.get());
    	
    	Customer customer = (Customer) valueWrapper.get();
    	
    	return customer;
    }
	
	
    private void printCacheEntries() {
        Collection<Customer> customerCollection = null;
        try {
            while(true) {
                customerCollection = (Collection<Customer>)getCacheService().getCache().values();
                for(Customer customer : customerCollection) {
                    log.debug("Cache Content : "+customer);
                }
                Thread.sleep(10000);            
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }	

}
