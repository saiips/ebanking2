package com.dsb.eb2.cache.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dsb.eb2.cache.model.Customer;
import com.dsb.eb2.cache.service.CustomerService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/api")
public class CustomerApiController {

	private final Log logger = LogFactory.getLog(this.getClass());
	
	@Autowired
	private CustomerService customerService;
	
	@RequestMapping(value = "/customer", method = RequestMethod.GET)
	public String getCustomer() throws JsonProcessingException {
		logger.info("getCustomer");
		
		ObjectMapper objectMapper = new ObjectMapper();
		
		Customer customer = customerService.getCustomer("1");
		
		String jsonString = objectMapper.writeValueAsString(customer);
		
		return jsonString;
	}
	
	@RequestMapping(value = "/set", method = RequestMethod.GET)
	public void setCustomer() throws JsonProcessingException {
		logger.info("setCustomer");
		
		String customerID = "12321321321";
		
		Customer customer = new Customer(new Long(1), new Long(1234567), "CAHN TAI MAN", "MR.", "M", null, "852-9999999", customerID, customerID, customerID, null, customerID, customerID, customerID, customerID, null, null, null, 0, null, customerID, null, customerID);
		
		logger.info("customer=" + customer.toString());
		
		customerService.setCustomer("1", customer);
		
	}	

	
}
