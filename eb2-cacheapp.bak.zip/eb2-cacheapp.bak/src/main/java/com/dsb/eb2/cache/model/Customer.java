package com.dsb.eb2.cache.model;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonAutoDetect;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter @Setter @NoArgsConstructor @JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class Customer implements Serializable {

	private static final long serialVersionUID = -3373951833797462261L;
	
	private Long customerID;
    private Long ebid;
    private String fullName;
    private String title;
    private String sex;
    private Date dob;
    private String mobileNo;
    private String optIn;
    private String permEmail;
    private String tempEmail;
    private Date lastUpdDateEmail;
    private String lastUpdByEmail;
    private String skipEmailUpdProcess;
    private String ebankType;
    private String staffInd;
    private Date frstRegDate;
    private Date reRegDate;
    private Date lstLogonSuccDate;
    private int loginFailCnt;
    private Date lastLoginFailDate;
    private String bioRemdrFlg;
    private Date bioRemdrDate;
    private String status;
    
    public Customer(Long customerID, Long ebid, String fullName, String title, String sex, Date dob, String mobileNo, String optIn, String permEmail, String tempEmail, Date lastUpdDateEmail,
    		String lastUpdByEmail, String skipEmailUpdProcess, String ebankType, String staffInd, Date frstRegDate, Date reRegDate, Date lstLogonSuccDate, 
    		int loginFailCnt, Date lastLoginFailDate, String bioRemdrFlg, Date bioRemdrDate, String status ) {
        this.customerID = customerID;
        this.ebid = ebid;
        this.fullName = fullName;
        this.title = title;
        this.sex = sex;
        this.dob = dob;
        this.mobileNo = mobileNo;
        this.optIn = optIn;
        this.permEmail = permEmail;
        this.tempEmail = tempEmail;
        this.lastUpdDateEmail = lastUpdDateEmail;
        this.lastUpdByEmail = lastUpdByEmail;
        this.skipEmailUpdProcess = skipEmailUpdProcess;
        this.ebankType = ebankType;
        this.staffInd = staffInd;
        this.frstRegDate = frstRegDate;
        this.reRegDate = reRegDate;
        this.lstLogonSuccDate = lstLogonSuccDate;
        this.loginFailCnt = loginFailCnt;
        this.lastLoginFailDate = lastLoginFailDate;
        this.bioRemdrFlg = bioRemdrFlg;
        this.bioRemdrDate = bioRemdrDate;
        this.status = status;
    }    

}