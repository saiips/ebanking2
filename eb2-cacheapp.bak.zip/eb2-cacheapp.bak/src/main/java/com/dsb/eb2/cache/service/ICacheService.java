package com.dsb.eb2.cache.service;

import com.tangosol.net.NamedCache;

@SuppressWarnings({"unused", "rawtypes", "unchecked"})
public interface ICacheService {
	
	public NamedCache getCache();
    public void addToCache(Object key, Object value);
    public void deleteFromCache(Object key);

}
