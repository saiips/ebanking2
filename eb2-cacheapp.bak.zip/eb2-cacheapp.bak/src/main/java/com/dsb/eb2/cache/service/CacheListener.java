package com.dsb.eb2.cache.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.tangosol.util.MapEvent;
import com.tangosol.util.MapListener;

@SuppressWarnings({"unused", "rawtypes", "unchecked"})
public class CacheListener implements MapListener  {
	
    private final Log logger = LogFactory.getLog(this.getClass());
    
    public void entryDeleted(MapEvent me) {
         logger.debug("Deleted Key = " + me.getKey() + ", Value = " + me.getOldValue());
    }
 
    public void entryInserted(MapEvent me) {
        logger.debug("Inserted Key = " + me.getKey() + ", Value = " + me.getNewValue());
    }
 
    public void entryUpdated(MapEvent me) {
    	logger.debug("Updated Key = " + me.getKey() + ", New_Value = " + me.getNewValue() + ", Old Value = " + me.getOldValue());
    }   
}


