function encryptPassword(key, exp, pin) {
	var publicKey = key;
	var exponent = exp;
    var triDesKeyLen = '3';
    var iv = null;
	var password = pin;
	var MacData = '';
	
	var result = E2EE.encryptAlphaPINAndGenerateMAC(publicKey, exponent, triDesKeyLen, iv, password, MacData);

	return result;
}

function encryptChangePassword(key,exp,oldPw,newPw){
	var publicKey = key;
	var exponent = exp;
    var triDesKeyLen = '3';
    var iv = null;
	var oldPassword = oldPw;
	var newPassword = newPw;
	var MacData = '';
	var result = E2EE.encryptChangeAlphaPINAndGenerateMAC(publicKey, exponent, triDesKeyLen, iv, oldPassword,newPassword,MacData);

	return result;
}

/*
 * calculate checksum
 */
function findPinCheckSum(pin) {
	var checkSumValue = 0;	
	var weight = new Array(85, 64, 58, 48, 36, 88, 49, 32, 85, 64, 58, 48, 36, 88, 49);
	
	//1. find out the ascii value of every digit in the pin
	//2. multiply the digit with the  weight
	var len = pin.length;
	if (len > 15)
		len = 15;
	for (var i=0;i<len;i++) {
		//find out ascii value
		var d = pin.charCodeAt(i);
		checkSumValue += (d *  weight[i]);
	}
	return checkSumValue;
}