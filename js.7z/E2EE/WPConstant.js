var WPConstant = {
    HASH_MODE_SHA1_XOR_LONG32: 5,
    HASH_MODE_SHA256_LONG32: 6,
    HASH_MODE_NONE_LONG32: 7,
    WP_Major_Version_4: 4,
    WP_Minor_Version_0: 0,
    DIGEST_MD5: 1,
    DIGEST_SHA1: 2,
    DIGEST_SHA256: 3,
    AES_MODE_ECB: '1',
    AES_MODE_CBC: '2',
    DES_MODE_ECB: '1',
    DES_MODE_CBC: '2',
    ENV_PS_RSA_PKCS : "6",
    WP_VERSION: '4.0.01'
};