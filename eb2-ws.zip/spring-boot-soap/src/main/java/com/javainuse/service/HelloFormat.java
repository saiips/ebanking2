package com.javainuse.service;

import org.springframework.stereotype.Component;

@Component("helloFormat")
public class HelloFormat {


    public String format() {
        return "[HelloFormat Component] : ";
    }
    
	
}
