
package com.dsb.eb2.sso.support.osb.core.utils;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;


/**
 * <p>Java class for ThalesVerifyPin_Response complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ThalesVerifyPin_Response">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="EmsHeader" type="{http://soaobj.ws.ems.dsbg/}EmsHeaderType"/>
 *         &lt;element name="FailCount" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="SuspendCount" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="FirstTimeLoginFlag" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="LastLoginTime" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@Getter @Setter
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ThalesVerifyPin_Response", propOrder = {
    "emsHeader",
    "failCount",
    "suspendCount",
    "firstTimeLoginFlag",
    "lastLoginTime"
})
public class ThalesVerifyPinResponse {

    @XmlElement(name = "EmsHeader", required = true)
    @JSONField(name="EmsHeader")
    protected EmsHeaderType emsHeader;
    
    @XmlElement(name = "FailCount")
    @JSONField(name="FailCount")
    protected int failCount;
    
    @XmlElement(name = "SuspendCount")
    @JSONField(name="SuspendCount")
    protected int suspendCount;
    
    @XmlElement(name = "FirstTimeLoginFlag")
    @JSONField(name="FirstTimeLoginFlag")
    protected boolean firstTimeLoginFlag;
    
    @XmlElement(name = "LastLoginTime", required = true)
    @JSONField(name="LastLoginTime")
    protected String lastLoginTime;

    /**
     * Gets the value of the emsHeader property.
     * 
     * @return
     *     possible object is
     *     {@link EmsHeaderType }
     *     
     */
    public EmsHeaderType getEmsHeader() {
        return emsHeader;
    }

    /**
     * Sets the value of the emsHeader property.
     * 
     * @param value
     *     allowed object is
     *     {@link EmsHeaderType }
     *     
     */
    public void setEmsHeader(EmsHeaderType value) {
        this.emsHeader = value;
    }

    /**
     * Gets the value of the failCount property.
     * 
     */
    public int getFailCount() {
        return failCount;
    }

    /**
     * Sets the value of the failCount property.
     * 
     */
    public void setFailCount(int value) {
        this.failCount = value;
    }

    /**
     * Gets the value of the suspendCount property.
     * 
     */
    public int getSuspendCount() {
        return suspendCount;
    }

    /**
     * Sets the value of the suspendCount property.
     * 
     */
    public void setSuspendCount(int value) {
        this.suspendCount = value;
    }

    /**
     * Gets the value of the firstTimeLoginFlag property.
     * 
     */
    public boolean isFirstTimeLoginFlag() {
        return firstTimeLoginFlag;
    }

    /**
     * Sets the value of the firstTimeLoginFlag property.
     * 
     */
    public void setFirstTimeLoginFlag(boolean value) {
        this.firstTimeLoginFlag = value;
    }

    /**
     * Gets the value of the lastLoginTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastLoginTime() {
        return lastLoginTime;
    }

    /**
     * Sets the value of the lastLoginTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastLoginTime(String value) {
        this.lastLoginTime = value;
    }

}
