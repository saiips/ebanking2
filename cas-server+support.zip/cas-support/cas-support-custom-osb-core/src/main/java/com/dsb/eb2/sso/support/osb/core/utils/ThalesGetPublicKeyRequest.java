
package com.dsb.eb2.sso.support.osb.core.utils;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;


/**
 * <p>Java class for ThalesGetPublicKey_Request complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ThalesGetPublicKey_Request">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="EmsHeader" type="{http://soaobj.ws.ems.dsbg/}EmsHeaderType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@Getter @Setter
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ThalesGetPublicKey_Request", propOrder = {
    "emsHeader"
})
public class ThalesGetPublicKeyRequest {

    @XmlElement(name = "EmsHeader", required = true)
    @JSONField(name="EmsHeader")
    protected EmsHeaderType emsHeader;

    /**
     * Gets the value of the emsHeader property.
     * 
     * @return
     *     possible object is
     *     {@link EmsHeaderType }
     *     
     */
    public EmsHeaderType getEmsHeader() {
        return emsHeader;
    }

    /**
     * Sets the value of the emsHeader property.
     * 
     * @param value
     *     allowed object is
     *     {@link EmsHeaderType }
     *     
     */
    public void setEmsHeader(EmsHeaderType value) {
        this.emsHeader = value;
    }

}
