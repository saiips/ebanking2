package com.dsb.eb2.sso.support.osb.core.config;

import org.apereo.cas.configuration.CasConfigurationProperties;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jasig.cas.client.validation.AbstractUrlBasedTicketValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;

import com.dsb.eb2.sso.support.osb.core.HandleEmsSOABuilder;
import com.dsb.eb2.sso.support.osb.core.Handle_emsSOALogon;

import lombok.extern.slf4j.Slf4j;



/**
 * This is {@link OsbCoreConfiguration}.
 *
 * @author Misagh Moayyed
 * @since 5.0.0
 */
@Slf4j
@Configuration("osbCoreConfiguration")
@EnableConfigurationProperties(CasConfigurationProperties.class)
@Order(Ordered.HIGHEST_PRECEDENCE)
public class OsbCoreConfiguration {
	
    @Bean
    public HandleEmsSOABuilder handleEmsSOABuilder() {
    	log.info("[EB2] initialize Handle_emsSOALogon [{}]");
        return new HandleEmsSOABuilder();
    }
    
}