
package com.dsb.eb2.sso.support.osb.core.utils;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;


/**
 * <p>Java class for ThalesRanNum_Request complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ThalesRanNum_Request">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="EmsHeader" type="{http://soaobj.ws.ems.dsbg/}EmsHeaderType"/>
 *         &lt;element name="SessionID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@Getter @Setter
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ThalesRanNum_Request", propOrder = {
    "emsHeader",
    "sessionID"
})
public class ThalesRanNumRequest {

    @XmlElement(name = "EmsHeader", required = true)
    @JSONField(name="EmsHeader")
    protected EmsHeaderType emsHeader;
    
    @XmlElement(name = "SessionID", required = true)
    @JSONField(name="SessionID")
    protected String sessionID;

    /**
     * Gets the value of the emsHeader property.
     * 
     * @return
     *     possible object is
     *     {@link EmsHeaderType }
     *     
     */
    public EmsHeaderType getEmsHeader() {
        return emsHeader;
    }

    /**
     * Sets the value of the emsHeader property.
     * 
     * @param value
     *     allowed object is
     *     {@link EmsHeaderType }
     *     
     */
    public void setEmsHeader(EmsHeaderType value) {
        this.emsHeader = value;
    }

    /**
     * Gets the value of the sessionID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSessionID() {
        return sessionID;
    }

    /**
     * Sets the value of the sessionID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSessionID(String value) {
        this.sessionID = value;
    }

}
