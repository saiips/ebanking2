package com.dsb.eb2.sso.support.osb.core.utils;

import java.io.IOException;

import net.sf.json.JSONObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class ApiGateway {

	private static Logger logger = LoggerFactory.getLogger(ApiGateway.class);

	@Autowired
	private WebAppProperties webApp;

	private final boolean isGatewayEnabled = true;

	private final static String GATEWAY_RESPONSE = "gatewayResponse";
	
	private final static String EMPTY_RESPONSE = "{}";

	public <T> Object doCoherenceRequest(String type, String operation, String dataType, String coherenceMethod, String serviceUrl, String serviceMethod, String requestPayload, Class<T> responseClass) throws IOException,
			Exception {

		String coherenceID = "";

		return doRequest(type, operation, dataType, "Y", coherenceMethod, coherenceID, serviceUrl, serviceMethod, requestPayload, responseClass, (webApp == null) ? isGatewayEnabled : webApp.isGatewayEnabled());
	}
	
	public <T> Object doRequest(String type, String operation, String dataType, String coherenceRequired, String coherenceMethod, String coherenceID, String serviceURL, String serviceMethod, String requestPayload,
			Class<T> responseClass) throws IOException, Exception {

		return doRequest(type, operation, dataType, coherenceRequired, coherenceMethod, coherenceID, serviceURL, serviceMethod, requestPayload, responseClass,
				(webApp == null) ? isGatewayEnabled : webApp.isGatewayEnabled());
	}

	public <T> Object doRequest(String type, String operation, String dataType, String coherenceRequired, String coherenceMethod, String coherenceID, String serviceURL, String serviceMethod, String requestPayload,
			Class<T> responseClass, boolean direct2Target) throws Exception {
		final String functionName = "ApiGateway.doRequest -";
		logger.debug("{} type:[{}]; operation:[{}]; dataType:[{}]; coherenceRequired:[{}]; coherenceMethod:[{}]; coherenceID:[{}]; serviceURL:[{}]; serviceMethod:[{}]; requestPayload:[{}]; direct2Target:[{}]", 
				functionName, type, operation, dataType, coherenceRequired, coherenceMethod, coherenceID, serviceURL, serviceMethod, requestPayload, direct2Target);

		String gatewayServiceURL;
		HttpMethod gatewayMethod = HttpMethod.POST;
		HttpEntity<Object> request = null;
		T object = null;
		try
		{
			RestTemplate restTemplate = new RestTemplate();
			restTemplate.setRequestFactory(clientHttpRequestFactory());

			if (!direct2Target) {
				gatewayServiceURL = serviceURL;
				gatewayMethod = HttpMethod.resolve(serviceMethod);
				request = new HttpEntity<>(requestPayload);
				if (request != null) {
					logger.debug("request=" + request.toString());					
				}

			} else {
				gatewayServiceURL = getGatewayEndpoint();
				gatewayMethod = HttpMethod.POST;
				RequestGateway requestGateway = constructGatewayRequest(type, operation, dataType, coherenceRequired, coherenceMethod, coherenceID, serviceURL, serviceMethod, requestPayload);
				request = new HttpEntity<>(requestGateway);
				if (request != null) {					
					logger.debug("request=" + request.toString());
				}
			}

			ResponseEntity<String> response = restTemplate.exchange(gatewayServiceURL, gatewayMethod, request, String.class);
			
			object = constructGatewayResponse(response.getBody(), responseClass);
			
		} catch (Exception ex) {
		    ex.printStackTrace();
		}

		return object;
	}

	public String doRequest(String type, String operation, String dataType, String coherenceRequired, String coherenceID, String serviceURL, String serviceMethod, String requestPayload)
			throws IOException, Exception {

		return doRequest(type, operation, dataType, coherenceRequired, "GET", coherenceID, serviceURL, serviceMethod, requestPayload, (webApp == null) ? isGatewayEnabled : webApp.isGatewayEnabled());
	}

	public String doRequest(String type, String operation, String dataType, String coherenceRequired, String coherenceMethod, String coherenceID, String serviceURL, String serviceMethod, String requestPayload,
			boolean direct2Target) throws Exception {
		String gatewayServiceURL;
		HttpMethod gatewayMethod = HttpMethod.POST;
		HttpEntity<Object> request = null;
		
		final String functionName = "ApiGateway.doRequest -";
		logger.debug("{} type:[{}]; operation:[{}]; dataType:[{}]; coherenceRequired:[{}]; coherenceMethod:[{}]; coherenceID:[{}]; serviceURL:[{}]; serviceMethod:[{}]; requestPayload:[{}]; direct2Target:[{}]", 
				functionName, type, operation, dataType, coherenceRequired, coherenceMethod, coherenceID, serviceURL, serviceMethod, requestPayload, direct2Target);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		String rtnLine = "";
		try {
			RestTemplate restTemplate = new RestTemplate();
			restTemplate.setRequestFactory(clientHttpRequestFactory());
	
			if (!direct2Target) {
				gatewayServiceURL = serviceURL;
				gatewayMethod = HttpMethod.resolve(serviceMethod);
				request = new HttpEntity<>(requestPayload, headers);
				if (request != null) {
					logger.trace("request=" + request.getBody());
				}
	
			} else {
				gatewayServiceURL = getGatewayEndpoint();
				gatewayMethod = HttpMethod.POST;
				RequestGateway requestGateway = constructGatewayRequest(type, operation, dataType, coherenceRequired, coherenceMethod, coherenceID, serviceURL, serviceMethod, requestPayload);
				request = new HttpEntity<>(requestGateway, headers);
				if (request != null) {
					logger.trace("request.getBody():" + request.toString());
				}
			}
	
			ResponseEntity<String> response = restTemplate.exchange(gatewayServiceURL, gatewayMethod, request, String.class);
			if (!direct2Target) {
				rtnLine = response.getBody();
			} else {
				rtnLine = constructGatewayResponse(response.getBody(), String.class);
			}
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return rtnLine;
	}

	public <T> Object getObject(String url, String requestPayload, Class<T> responseClass) throws IOException, Exception {
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.setRequestFactory(clientHttpRequestFactory());

		String result = restTemplate.getForObject(url, String.class);
		ObjectMapper objectMapper = new ObjectMapper();
		T object = objectMapper.readValue(result, responseClass);

		return object;
	}

	private String getGatewayEndpoint() {
		if (webApp != null) {
			return webApp.getUrl() + ApiController.GATEWAY_ENDPOINT;
		} else {
			return ApiController.GATEWAY_URL + ApiController.GATEWAY_ENDPOINT;
		}
	}

	public String getGatewayURL() {
		if (webApp != null) {
			return webApp.getUrl();
		} else {
			return ApiController.GATEWAY_URL;
		}
	}

	private ClientHttpRequestFactory clientHttpRequestFactory() {
		String readTimeout = "50000", connectTimeout = "50000";

		HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
		if (webApp != null) {
			readTimeout = webApp.getReadTimeout();
			connectTimeout = webApp.getConnectionTimeout();
		}
		factory.setReadTimeout(Integer.valueOf(readTimeout));
		factory.setConnectTimeout(Integer.valueOf(connectTimeout));
		return factory;
	}

	private RequestGateway constructGatewayRequest(String type, String operation, String dataType, String coherenceRequired, String coherenceMethod, String coherenceID, String serviceURL, String serviceMethod,
			String requestPayload) {

		RequestGateway requestGateway = new RequestGateway();
		RequestGateway.GatewayRequest gatewayRequest = new RequestGateway.GatewayRequest();

		gatewayRequest.setReqID("AAAAAAAAAAAAAAAAAAAAAAAAAAA");
		gatewayRequest.setType(type);
		gatewayRequest.setOperation(operation);
		gatewayRequest.setDataType(dataType);
		gatewayRequest.setCoherenceRequired(coherenceRequired);
		gatewayRequest.setCoherenceMethod(coherenceMethod);
		gatewayRequest.setCoherenceID(coherenceID);
		gatewayRequest.setServiceURL(serviceURL);
		gatewayRequest.setServiceMethod(serviceMethod);
		gatewayRequest.setRequestPayload(requestPayload);

		requestGateway.setGatewayRequest(gatewayRequest);

		return requestGateway;
	}

	private <T> T constructGatewayResponse(final byte[] result, final Class<T> responseClass) throws IOException {

		// Convert to JSON string
		String jsonRequest = new String(result);

		String gatewayResponse = getGatewayResponse(jsonRequest);

		ObjectMapper mapper = new ObjectMapper();
		T object = mapper.readValue(gatewayResponse, responseClass);

		return object;
	}

	private <T> T constructGatewayResponse(final String result, final Class<T> responseClass) throws IOException {

		String gatewayResponse = getGatewayResponse(result);
		logger.trace(gatewayResponse);

		return (T) gatewayResponse;
	}

	private String getGatewayResponse(final String result) throws IOException {

		if (result == null || "".equals(result)) {			
			return EMPTY_RESPONSE;
		}

		JSONObject jsonObject = JSONObject.fromObject(result);
		String gatewayResponse = jsonObject.getString(GATEWAY_RESPONSE);
		if(gatewayResponse == null || "".equals(gatewayResponse))
		{
			return "";
		}
		
		logger.trace("gatewayResponse.toString() = " + gatewayResponse.toString());
		
		return gatewayResponse;
	}

}