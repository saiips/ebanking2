package com.dsb.eb2.sso.support.osb.core.utils;


public abstract class ApiController {
    // resource path 
	public static final String API_PATH = "/api";
    public static final String SSO_PATH = "/sso";
    public static final String PWS_PATH = "/pws";
    public static final String REG_PATH = "/reg";

    public static final String WEBPIN = "/webpin";
    public static final String DAO = "/dao";
    
    // response header
    public static final String X_AUTH_TOKEN = "X-AUTH-TOKEN";
    public static final String CONTENT_TYPE = "Content-Type";
    public static final String CONTENT_TYPE_APPL_JSON = "application/json; charset=UTF-8";
    public static final String AUTHORIZATION = "X-Authorization";
    public static final String REFRESH_AUTHORIZATION = "X-Refresh-Authorization";
    public static final String BEARER = "Bearer ";
    public static final String IS_REFRESH_TOKEN_REQUIRED = "isRefreshTokenRequired";
    
    // cookie 
    public static final String COOKIE_FOR_TOKEN = "t";
    public static final String COOKIE_FOR_REFRESH_TOKEN = "rt";
        
    // request fields on login EBID & Password
    public static final String USERNAME = "username";
    public static final String PASSWORD = "password";
    public static final String PINBLOCK = "pinblock";
    public static final String WEBPIN_CODE = "webpincode";
    public static final String RANDOM_NUMBER = "randomNum";
    public static final String CHECK_SUM = "checkSum";
    public static final String PUBLIC_KEY_INDEX = "publicKeyIndex";
    public static final String SUBJECT = "subject";
    public static final String TGT = "TGT";
    public static final String JTI = "jti";
    public static final String UUID = "UUID";
    public static final String PBID = "pbid";
    public static final String ENCPIN = "encPin";
    public static final String ATMPIN = "atmPin";
    public static final String ATMNUM = "atmNum";
    public static final String EBID = "ebid";
    public static final String FILTERVALUE = "filterValue";
    public static final String FROMCACHE = "fromCache";
    public static final String CHECK_SUM_OLD = "checkSumOld";
    public static final String PERMISSION_LEVEL = "permissionLevel";
    
    public static final String BIOREQUESTTYPE = "bioRequestType";
    public static final String BIOREQUESTDATA = "bioRequestData";
    
    public static final String FIRST_TIME_REG  = "firstTimeReg";

    // hashmap key
    public static final String TOKEN_STATUS = "TOKEN_STATUS";
    public static final String CAS_PROFILE = "CAS_PROFILE";
    
    // token status
    public static final String TOKEN_EXPIRED = "E";
    public static final String TOKEN_INVALID = "I";
    public static final String TOKEN_VALID = "V";
    public static final String SESSION_INVALID = "S";
    
    // Session Key
    public static final String USER_SESSION = "USER_SESSION";
    
    // OSB service endpoints
    public static final String GATEWAY_REQ_TYPE_DATA = "DATA";
    public static final String GATEWAY_REQ_TYPE_SESSION = "SESSION";
    public static final String GATEWAY_ENDPOINT = "/GatewayService/getData";
    public static final String NF1107_EMSERVICE_ENDPOINT = "/NF1107Service/emsService/emsService";
    
    public static final String AUTHENTICATE_URL = API_PATH + "/authenticate";
    public static final String STUFF_URL = API_PATH + "/stuff";

    // Spring Boot Actuator services
    public static final String AUTOCONFIG_ENDPOINT = "/autoconfig";
    public static final String BEANS_ENDPOINT = "/beans";
    public static final String CONFIGPROPS_ENDPOINT = "/configprops";
    public static final String ENV_ENDPOINT = "/env";
    public static final String MAPPINGS_ENDPOINT = "/mappings";
    public static final String METRICS_ENDPOINT = "/metrics";
    public static final String SHUTDOWN_ENDPOINT = "/shutdown";
    
    // request fields on PaymentTemplateController
    public static final String TRANSFER_TYPE = "transferType";
    public static final String TEMPLATE_ID = "templateId";
    public static final String INCLUDE_FROZEN = "includeFrozen";
    
    public static final String GATEWAY_URL = "http://eb2int01:7001";
    //public static final String GATEWAY_URL = "http://10.26.129.131:7001";
    
    public static final String LANG_PREF_ZH_TW = "zh_TW";
	public static final String LANG_PREF_EN_US = "en_US";
	
	public static final int LANG_PREF_ENGLISH = 0;
	public static final int LANG_PREF_CHINESE = 1;
	
	public static final String LOGIN_CUST_ID = "LOGIN_CUST_ID";
	
	public static final String DUMMY = "DUMMY123456";
	
	public static final String DELIMITER = "#";
    
}