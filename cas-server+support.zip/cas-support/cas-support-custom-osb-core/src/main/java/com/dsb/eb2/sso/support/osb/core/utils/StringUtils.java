package com.dsb.eb2.sso.support.osb.core.utils;

import java.io.UnsupportedEncodingException;

/**
 * <p>
 * 字符串处理类 提供一些常用的字符串处理工具
 * </p>
 * 
 * @author
 * 
 * 
 */

public class StringUtils
{

    /**
     * Check that the given CharSequence is neither <code>null</code> nor of
     * length 0. Note: Will return <code>true</code> for a CharSequence that
     * purely consists of whitespace.
     * <p>
     * 
     * <pre>
     * StringUtils.hasLength(null) = false
     * StringUtils.hasLength(&quot;&quot;) = false
     * StringUtils.hasLength(&quot; &quot;) = true
     * StringUtils.hasLength(&quot;Hello&quot;) = true
     * </pre>
     * 
     * @param str
     *            the CharSequence to check (may be <code>null</code>)
     * @return <code>true</code> if the CharSequence is not null and has
     *         length
     * @see #hasText(String)
     */
    public static boolean hasLength(CharSequence str)
    {
        return (str != null && str.length() > 0);
    }

    /**
     * Check that the given String is neither <code>null</code> nor of length
     * 0. Note: Will return <code>true</code> for a String that purely
     * consists of whitespace.
     * 
     * @param str
     *            the String to check (may be <code>null</code>)
     * @return <code>true</code> if the String is not null and has length
     * @see #hasLength(CharSequence)
     */
    public static boolean hasLength(String str)
    {
        return hasLength((CharSequence) str);
    }
    
    /**
     * Check whether the given CharSequence has actual text.
     * More specifically, returns <code>true</code> if the string not <code>null</code>,
     * its length is greater than 0, and it contains at least one non-whitespace character.
     * <p><pre>
     * StringUtils.hasText(null) = false
     * StringUtils.hasText("") = false
     * StringUtils.hasText(" ") = false
     * StringUtils.hasText("12345") = true
     * StringUtils.hasText(" 12345 ") = true
     * </pre>
     * @param str the CharSequence to check (may be <code>null</code>)
     * @return <code>true</code> if the CharSequence is not <code>null</code>,
     * its length is greater than 0, and it does not contain whitespace only
     * @see java.lang.Character#isWhitespace
     */
    public static boolean hasText(CharSequence str) {
        if (!hasLength(str)) {
            return false;
        }
        int strLen = str.length();
        for (int i = 0; i < strLen; i++) {
            if (!Character.isWhitespace(str.charAt(i))) {
                return true;
            }
        }
        return false;
    }

    /**
     * Check whether the given String has actual text.
     * More specifically, returns <code>true</code> if the string not <code>null</code>,
     * its length is greater than 0, and it contains at least one non-whitespace character.
     * @param str the String to check (may be <code>null</code>)
     * @return <code>true</code> if the String is not <code>null</code>, its length is
     * greater than 0, and it does not contain whitespace only
     * @see #hasText(CharSequence)
     */
    public static boolean hasText(String str) {
        return hasText((CharSequence) str);
    }

    /**
     * 判断是否是boolean值(不区分大小写)
     * 
     * @param string --
     *            输入
     * @return 如果输入字符串为"true" 或者 "false" 返回true，否则返回false
     */
    public static boolean isBoolean(String string)
    {
        return "true".equalsIgnoreCase(string)
            || "false".equalsIgnoreCase(string);
    }

    /**
     * 判断是否double类型
     * 
     * @param string --
     *            输入
     * @return 如果能被Double.parseDouble解析则认为是数值，返回true，否则返回false
     */
    public static boolean isDouble(String string)
    {
        try
        {
            Double.parseDouble(string);
        } catch (NumberFormatException nfe)
        {
            return false;
        }
        return true;
    }

    /**
     * 判断是否是数字
     * 
     * @param string --
     *            输入
     * @return 如果输入字符串长度不为0，并且所有的字符都为数字则返回ture，否则返回false
     */
    public static boolean isDigit(String string)
    {
        if (string.length() == 0) {
        	return false;
        }

        char[] chars = string.toCharArray();
        for (int i = 0; i < chars.length; i++)
        {
            if (!Character.isDigit(chars[i])) {
            	return false;
            }
        }
        return true;
    }

    /**
     * 判断字符串是否为空
     * 
     * @param string --
     *            待检查的字符串
     * @return -- 如果为null或者长度为0返回true，否则返回false
     */
    public static boolean isEmpty(String string)
    {
        if (string == null) {
        	return true;
        }

        return (string.length() == 0);
    }

    /**
     * 判断字符串是否为空白
     * 
     * @param string --
     *            待检查的字符串
     * @return 如果为null或者全部为空格字符返回true，否则返回false;
     */
    public static boolean isBlank(String string)
    {
        if (string == null) {
        	return true;
        }

        return "".equals(string.trim());
    }

    // ------------------- hex string --------------------------

    /**
     * 把字节码转换成16进制字符串，与hexToBytes对应
     * 
     * @param bytes --
     *            字节码
     * @return -- 16进制的字符串，一字节对应2个字符
     */
    public static String toHexString(byte[] bytes)
    {
        StringBuffer sb = new StringBuffer();

        for (int i = 0; i < bytes.length; i++)
        {
            int v = bytes[i] & 0xFF;
            if (v < 0x10) {
            	sb.append("0");
            }
            sb.append(Integer.toString(v, 16));
        }
        return sb.toString();
    }

    /**
     * 把16进制字符串转换成字节码，与toHexString对应
     * 
     * @param hex --
     *            16进制的字符串，长度必须为2的倍数
     * @return -- 字节码，2个字符对应一个字节
     */
    public static byte[] hexStringToBytes(String hex)
    {
        byte[] bytes = new byte[hex.length() / 2];
        for (int i = 0; i < hex.length() / 2; i++)
        {
            bytes[i] = (byte) Integer.parseInt(
                hex.substring(i * 2, (i + 1) * 2), 16);
        }
        return bytes;
    }

    // ------------------------- encode ----------------------------

    /**
     * 把字符串从当前系统的默认编码转换成GBK编码
     * 
     * @param string --
     *            系统默认编码的字符串
     * @return -- GBK编码的字符串
     * @throws UnsupportedEncodingException
     */
    public static String encodeFromLocalToGBK(String string)
        throws UnsupportedEncodingException
    {
        return encodeFromLocal(string, "GBK");
    }

    /**
     * 把字符串从当前系统的默认编码转换成指定的编码
     * 
     * @param string --
     *            系统默认编码的字符串
     * @param targetCharset --
     *            目标编码格式
     * @return -- targetCharset编码的字符串
     * @throws UnsupportedEncodingException
     */
    public static String encodeFromLocal(String string, String targetCharset)
        throws UnsupportedEncodingException
    {
        return encode(string, System.getProperty("file.encoding"),
            targetCharset);
    }

    /**
     * 把字符串从指定的编码（本身的编码格式）转换成当前系统的默认编码
     * 
     * @param string --
     *            系统默认编码的字符串
     * @param srcCharset --
     *            源编码格式
     * @return -- 本地编码的字符串
     * @throws UnsupportedEncodingException
     */
    public static String encodeToLocal(String string, String srcCharset)
        throws UnsupportedEncodingException
    {
        return encode(string, srcCharset, System.getProperty("file.encoding"));
    }

    /**
     * 把字符串转码
     * 
     * @param string --
     *            待处理的字符串
     * @param srcCharset --
     *            待处理字符串的原编码格式
     * @param targetCharset --
     *            目标编码格式
     * @return -- targetCharset编码的字符串
     * @throws UnsupportedEncodingException
     */
    public static String encode(String string, String srcCharset,
        String targetCharset) throws UnsupportedEncodingException
    {
        return new String(string.getBytes(srcCharset), targetCharset);
    }

    // --------------------------- join string ---------------------

    /**
     * 用指定的分隔符，连接字符串
     * 
     * @param strings --
     *            待连接的字符串数组
     * @param spacer --
     *            分隔符
     * @return -- 连接好的字符串
     */
    public static String join(String[] strings, String spacer)
    {
        return join(strings, "", "", spacer, "");
    }

    /**
     * 用指定的分隔符，连接字符串。字符串为：prefix + string + suffix。 如果string包含filter，则忽列该字符串。
     * 
     * @param strings --
     *            待连接的字符串数组
     * @param prefix --
     *            前缀
     * @param suffix --
     *            后缀
     * @param spacer --
     *            分隔符
     * @param filter --
     *            过滤条件
     * @return -- 连接好的字符串
     */
    public static String join(String[] strings, String prefix, String suffix,
        String spacer, String filter)
    {
        if (strings == null) {
        	return null;
        }

        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < strings.length; i++)
        {
            if ("".equals(filter) || strings[i].indexOf(filter) == -1)
            {
                sb.append(prefix);
                sb.append(strings[i]);
                sb.append(suffix);
            } else
            {
                sb.append(strings[i]);
            }
            sb.append(spacer);
        }
        if (strings.length > 0)
        {
            sb.delete(sb.length() - spacer.length(), sb.length());
        }
        return sb.toString();
    }

    /**
     * 用指定的分隔符，连接指定次数的字符串。
     * 
     * @param number --
     *            连接的次数
     * @param string --
     *            字符单元
     * @param spacer --
     *            分隔符
     * @return -- 连接好的字符串
     */
    public static String join(int number, String string, String spacer)
    {
        return join(number, string, "", "", spacer);
    }

    /**
     * 连接字符串，string = prefix + string + suffix
     * 
     * @param number --
     *            连接的次数
     * @param string --
     *            字符单元
     * @param prefix --
     *            前缀
     * @param suffix --
     *            后缀
     * @param spacer --
     *            分隔符
     * @return -- 连接好的字符串
     */
    public static String join(int number, String string, String prefix,
        String suffix, String spacer)
    {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < number; i++)
        {
            sb.append(prefix);
            sb.append(string);
            sb.append(suffix);
            sb.append(spacer);
        }
        if (number > 0)
        {
            sb.delete(sb.length() - spacer.length(), sb.length());
        }
        return sb.toString();
    }

    // --------------------- fill/unfill string -------------------------------

    /**
     * 填充字符串
     * 
     * 根据填充类型(fillType)把指定的字符串(src)用填充符(fillString)填充至指定的长度(length)
     * 
     * 示例1: String s = "a"; String result = StringDeal.fill("Right", s, "b", 5);
     * result的结果为abbbb
     * 
     * 注意: 1.若length 大于src.length() 则不填充 2.若填充符不是单个字符,则会出现如下情况: 示例2: String s =
     * "a"; String result = StringDeal.fill("Right", s, "bo", 6);
     * result的结果为abobob
     * 
     * 
     * @param fillType --
     *            填充类型(Left or Right)
     * @param src --
     *            要填充的字符串
     * @param fillString --
     *            用来填充的字符串
     * @param length --
     *            填充后的长度
     * @return -- 填充好的字符串
     */
    public static String fill(String fillType, String src, String fillString,
        int length)
    {

        if ("Left".equalsIgnoreCase(fillType)
            && "Right".equalsIgnoreCase(fillType))
        {
            throw new IllegalArgumentException(
                " [ The fillType must be Right or Left! ] ");
        }

        int fillLength = length - src.length();
        if (fillLength == 0)
        {
            // not need to fill
            return src;
        } else if (fillLength < 0)
        {
            throw new IllegalArgumentException(
                " [ The src' length is longer than expected ! ] ");
        }

        StringBuffer sb = new StringBuffer();
        while (sb.length() < fillLength)
        {
            sb.append(fillString);
        }
        sb.delete(fillLength, sb.length());

        if ("Left".equalsIgnoreCase(fillType))
        {
            return sb + src;
        } else if ("Right".equalsIgnoreCase(fillType))
        {
            return src + sb;
        }

        return src;
    }

    /**
     * 去除填充符 与fill()正好相反,详见fill()的说明
     * 
     * @param fillType --
     *            填充类型(Left or Right)
     * @param src --
     *            被填充后的字符串
     * @param fillString --
     *            用来填充的字符串
     * @return -- 去掉填充符的字符串
     */
    public static String unfill(String fillType, String src, String fillString)
    {

        // 判断填充类型
        if ("Left".equalsIgnoreCase(fillType)
            && "Right".equalsIgnoreCase(fillType))
        {
            throw new IllegalArgumentException(
                " [ The fillType must be Right or Left! ] ");
        }

        // 生成填充符
        StringBuffer sb = new StringBuffer();
        while (sb.length() < src.length())
        {
            sb.append(fillString);
        }

        // 去掉填充符
        if (fillType.equalsIgnoreCase("Left"))
        {
            for (int i = 0; i < src.length(); i++)
            {
                if (sb.charAt(i) != src.charAt(i))
                {
                    return src.substring(i, src.length());
                }
            }
        } else if (fillType.equalsIgnoreCase("Right"))
        {
            for (int i = src.length() - 1; i >= 0; i--)
            {
                if (sb.charAt(i) != src.charAt(i))
                {
                    return src.substring(0, i + 1);
                }
            }
        }
        return src;
    }

    /**
     * 轉換 Xml 保留字符 &->&amp; <->&lt; >->&lt; "->&quot; '->&apos;
     * 
     * @param str
     * @return
     */
    public static String escapeXml(String str)
    {
        if (str == null) {
        	return null;
        }

        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < str.length(); i++)
        {
            char c = str.charAt(i);
            switch (c)
            {
                case '&':
                    sb.append("&amp;");
                    break;
                case '<':
                    sb.append("&lt;");
                    break;
                case '>':
                    sb.append("&gt;");
                    break;
                case '"':
                    sb.append("&quot;");
                    break;
                case '\'':
                    sb.append("&apos;");
                    break;
                default:
                    sb.append(c);
                    break;
            }
        }
        return sb.toString();
    }
    
    /**
     * trim掉字符串首位和末尾的全部空格
     * 字符串中间有多于一个空格的处理为只剩下一个空格
     * @param str
     * @return
     */
    public static String trimSpace(String str)
    {
        String returnStr = "";
        if(StringUtils.isBlank(str)) {
            return returnStr;
        }else {
            str = str.trim();
        }
        String[] strArray = str.split(" ");
        for(int i=0;i<strArray.length;i++)
        {
            if(!StringUtils.isBlank(strArray[i]))
            {
                returnStr += strArray[i];
                if(i<strArray.length-1) {
                    returnStr += " ";
                }
            }
        }
        
        return returnStr;
    }
    
    /**
     * 
     * 
     * @param string --
     *            判定的字符串
     * @return 如果为null或者全部为空格字符返回“NaN”，否则返回原字符;
     */
    public static String getBankToNaN(String str)
    {
    	if(StringUtils.isBlank(str))
    	{
    		return "NaN";
    	}
    	return str;
    }
    
    
    /**
     * 
     * 
     * @param string --
     *            判定的字符串
     * @return 如果为null或者长度为0返回“NaN”，否则返回原字符;
     */
    public static String getEmptyToNaN(String str)
    {
    	if(StringUtils.isEmpty(str))
    	{
    		return "NaN";
    	}
    	return str;
    }
    
    /**
     * @param string
     * 			判定字符串
     * @param boolean
     * 			是否需要trim
     * 
     * @return
     * 		如果字符串為null，返回"";
     * 		如果字符串為非null， 返回 str or str.trim();
     */
    public static String getTrimStr(String str, Boolean flag)
    {
    	if(isEmpty(str))
    	{
    		return "";
    	}
    	
    	if(flag)
    	{
    		return str.trim();
    	}
    	return str;
    }
    
    public static boolean isNumeric(String str)
    {
      if (str == null)
        return false;

      int sz = str.length();
      for (int i = 0; i < sz; ++i)
        if (!(Character.isDigit(str.charAt(i))))
          return false;


      return true;
    }
}
