
package com.dsb.eb2.sso.support.osb.core.utils;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;


/**
 * <p>Java class for ThalesInitPin_Request complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ThalesInitPin_Request">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="EmsHeader" type="{http://soaobj.ws.ems.dsbg/}EmsHeaderType"/>
 *         &lt;element name="PBID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PKI" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Message" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PINCheckSum" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="PINAssignedDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@Getter @Setter
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ThalesInitPin_Request", propOrder = {
    "emsHeader",
    "pbid",
    "pki",
    "message",
    "pinCheckSum",
    "pinAssignedDate"
})
public class ThalesInitPinRequest {

    @XmlElement(name = "EmsHeader", required = true)
    @JSONField(name="EmsHeader")
    protected EmsHeaderType emsHeader;
    
    @XmlElement(name = "PBID", required = true)
    @JSONField(name="PBID")
    protected String pbid;
    
    @XmlElement(name = "PKI", required = true)
    @JSONField(name="PKI")
    protected String pki;
    
    @XmlElement(name = "Message", required = true)
    @JSONField(name="Message")
    protected String message;
    
    @XmlElement(name = "PINCheckSum")
    @JSONField(name="PINCheckSum")
    protected int pinCheckSum;
    
    @XmlElement(name = "PINAssignedDate", required = true)
    @JSONField(name="PINAssignedDate")
    protected String pinAssignedDate;

    /**
     * Gets the value of the emsHeader property.
     * 
     * @return
     *     possible object is
     *     {@link EmsHeaderType }
     *     
     */
    public EmsHeaderType getEmsHeader() {
        return emsHeader;
    }

    /**
     * Sets the value of the emsHeader property.
     * 
     * @param value
     *     allowed object is
     *     {@link EmsHeaderType }
     *     
     */
    public void setEmsHeader(EmsHeaderType value) {
        this.emsHeader = value;
    }

    /**
     * Gets the value of the pbid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPBID() {
        return pbid;
    }

    /**
     * Sets the value of the pbid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPBID(String value) {
        this.pbid = value;
    }

    /**
     * Gets the value of the pki property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPKI() {
        return pki;
    }

    /**
     * Sets the value of the pki property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPKI(String value) {
        this.pki = value;
    }

    /**
     * Gets the value of the message property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets the value of the message property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessage(String value) {
        this.message = value;
    }

    /**
     * Gets the value of the pinCheckSum property.
     * 
     */
    public int getPINCheckSum() {
        return pinCheckSum;
    }

    /**
     * Sets the value of the pinCheckSum property.
     * 
     */
    public void setPINCheckSum(int value) {
        this.pinCheckSum = value;
    }

    /**
     * Gets the value of the pinAssignedDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPINAssignedDate() {
        return pinAssignedDate;
    }

    /**
     * Sets the value of the pinAssignedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPINAssignedDate(String value) {
        this.pinAssignedDate = value;
    }

}
