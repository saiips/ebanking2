
package com.dsb.eb2.sso.support.osb.core.utils;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;


/**
 * <p>Java class for ThalesGetPublicKey_Response complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ThalesGetPublicKey_Response">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="EmsHeader" type="{http://soaobj.ws.ems.dsbg/}EmsHeaderType"/>
 *         &lt;element name="PublicKey" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Exp" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="PublicKeyIndex" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@Getter @Setter
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ThalesGetPublicKey_Response", propOrder = {
    "emsHeader",
    "publicKey",
    "exp",
    "publicKeyIndex"
})
public class ThalesGetPublicKeyResponse {

    @XmlElement(name = "EmsHeader", required = true)
    @JSONField(name="EmsHeader")
    protected EmsHeaderType emsHeader;
    
    @XmlElement(name = "PublicKey", required = true)
    @JSONField(name="PublicKey")
    protected String publicKey;
    
    @XmlElement(name = "Exp", required = true)
    @JSONField(name="Exp")
    protected String exp;
    
    @XmlElement(name = "PublicKeyIndex", required = true)
    @JSONField(name="PublicKeyIndex")
    protected String publicKeyIndex;

    /**
     * Gets the value of the emsHeader property.
     * 
     * @return
     *     possible object is
     *     {@link EmsHeaderType }
     *     
     */
    public EmsHeaderType getEmsHeader() {
        return emsHeader;
    }

    /**
     * Sets the value of the emsHeader property.
     * 
     * @param value
     *     allowed object is
     *     {@link EmsHeaderType }
     *     
     */
    public void setEmsHeader(EmsHeaderType value) {
        this.emsHeader = value;
    }

    /**
     * Gets the value of the publicKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPublicKey() {
        return publicKey;
    }

    /**
     * Sets the value of the publicKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPublicKey(String value) {
        this.publicKey = value;
    }

    /**
     * Gets the value of the exp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExp() {
        return exp;
    }

    /**
     * Sets the value of the exp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExp(String value) {
        this.exp = value;
    }

    /**
     * Gets the value of the publicKeyIndex property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPublicKeyIndex() {
        return publicKeyIndex;
    }

    /**
     * Sets the value of the publicKeyIndex property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPublicKeyIndex(String value) {
        this.publicKeyIndex = value;
    }

}
