package com.dsb.eb2.sso.support.osb.core;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

import com.dsb.eb2.sso.support.osb.core.utils.ThalesGetPublicKeyRequest;
import com.dsb.eb2.sso.support.osb.core.utils.ThalesGetPublicKeyResponse;

@Slf4j
@Getter
@NoArgsConstructor
public class HandleEmsSOABuilder {

    @SneakyThrows
    public ThalesGetPublicKeyResponse getThalesPublicKeyInfo() {
    	
    	Handle_emsSOALogon handle_emsSOALogon = new Handle_emsSOALogon();
    	
    	ThalesGetPublicKeyRequest request = new ThalesGetPublicKeyRequest();
    	
    	return handle_emsSOALogon.invoke(request);
    	
    }

    @SneakyThrows
    public String signMessage(final String data) {
    	
    	Handle_emsSOALogon handle_emsSOALogon = new Handle_emsSOALogon();
    	
    	return handle_emsSOALogon.sign(data);
    	
    }    

    @SneakyThrows
    public String verifyMessage(final String data) {
    	
    	Handle_emsSOALogon handle_emsSOALogon = new Handle_emsSOALogon();
    	
    	return handle_emsSOALogon.verify(data);
    	
    }    
    
    
}
