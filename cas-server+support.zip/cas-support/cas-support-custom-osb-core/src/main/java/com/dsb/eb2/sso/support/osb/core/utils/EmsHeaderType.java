
package com.dsb.eb2.sso.support.osb.core.utils;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import com.alibaba.fastjson.annotation.JSONField;

import lombok.Getter;
import lombok.Setter;


/**
 * <p>Java class for EmsHeaderType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EmsHeaderType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BankCode">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CustNo">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}long">
 *               &lt;maxExclusive value="999999999"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="CustID">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="ChannelID">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="4"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="LoginID">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="BranchID">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="3"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="TerminalID">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="ServiceID">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="ServiceVersion">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}int">
 *               &lt;maxExclusive value="999"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="EMSMsgID">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="48"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="TxDateTime">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="14"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="AgentID">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="20"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="ServiceCharge">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}long">
 *               &lt;maxExclusive value="9999999999999999"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="Language">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="AutoResubmitFlag">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="RetriedCount">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}short">
 *               &lt;maxExclusive value="99"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="ReturnCode">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="16"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="ReturnMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Remarks" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="TxRefNo">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}long">
 *               &lt;maxExclusive value="99999999"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="MessageSequence">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}short">
 *               &lt;maxExclusive value="99"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="OverrideLevel">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}short">
 *               &lt;maxExclusive value="9"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="ErrorCorrectionFlag">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="ReservedbyHost">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="13"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="BranchNumber">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="99"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="StaffInfoAccessAuthLevel">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}short">
 *               &lt;maxExclusive value="9"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="RejectDetail" type="{http://soaobj.ws.ems.dsbg/}RejectDetailType" maxOccurs="8" minOccurs="0"/>
 *         &lt;element name="CycleDate">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="8"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="SysTraceNum">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="8"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="RetryProcessFlag">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="1"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="DeptCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="EmsSeqNo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@Getter @Setter
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EmsHeaderType", propOrder = {
    "bankCode",
    "custNo",
    "custID",
    "channelID",
    "loginID",
    "branchID",
    "terminalID",
    "serviceID",
    "serviceVersion",
    "emsMsgID",
    "txDateTime",
    "agentID",
    "serviceCharge",
    "language",
    "autoResubmitFlag",
    "retriedCount",
    "returnCode",
    "returnMessage",
    "remarks",
    "txRefNo",
    "messageSequence",
    "overrideLevel",
    "errorCorrectionFlag",
    "reservedbyHost",
    "branchNumber",
    "staffInfoAccessAuthLevel",
    "rejectDetail",
    "cycleDate",
    "sysTraceNum",
    "retryProcessFlag",
    "deptCode",
    "emsSeqNo"
})
public class EmsHeaderType {

	@JSONField(name="BankCode")
	@XmlElement(name = "BankCode", required = true)
	protected String bankCode;
	
	
	@JSONField(name="CustNo")
	@XmlElement(name = "CustNo")
	protected long custNo;
	
	
	@JSONField(name="CustID")
	@XmlElement(name = "CustID", required = true)
	protected String custID;
	
	
	@JSONField(name="ChannelID")
	@XmlElement(name = "ChannelID", required = true)
	protected String channelID;
	
	
	@JSONField(name="LoginID")
	@XmlElement(name = "LoginID", required = true)
	protected String loginID;
	
	
	@JSONField(name="BranchID")
	@XmlElement(name = "BranchID", required = true)
	protected String branchID;
	
	
	@JSONField(name="TerminalID")
	@XmlElement(name = "TerminalID", required = true)
	protected String terminalID;
	
	
	@JSONField(name="ServiceID")
	@XmlElement(name = "ServiceID", required = true)
	protected String serviceID;
	
	
	@JSONField(name="ServiceVersion")
	@XmlElement(name = "ServiceVersion")
	protected int serviceVersion;
	
	
	@JSONField(name="EMSMsgID")
	@XmlElement(name = "EMSMsgID", required = true)
	protected String emsMsgID;
	
	
	@JSONField(name="TxDateTime")
	@XmlElement(name = "TxDateTime", required = true)
	protected String txDateTime;
	
	
	@JSONField(name="AgentID")
	@XmlElement(name = "AgentID", required = true)
	protected String agentID;
	
	@JSONField(name="ServiceCharge")
	@XmlElement(name = "ServiceCharge")
	protected long serviceCharge;
	
	@JSONField(name="Language")
	@XmlElement(name = "Language", required = true)
	protected String language;
	
	@JSONField(name="AutoResubmitFlag")
	@XmlElement(name = "AutoResubmitFlag", required = true)
	protected String autoResubmitFlag;
	
	@JSONField(name="RetriedCount")
	@XmlElement(name = "RetriedCount")
	protected short retriedCount;
	
	@JSONField(name="ReturnCode")
	@XmlElement(name = "ReturnCode", required = true)
	protected String returnCode;
	
	@JSONField(name="ReturnMessage")
	@XmlElement(name = "ReturnMessage", required = true)
	protected String returnMessage;
	
	@JSONField(name="Remarks")
	@XmlElement(name = "Remarks", required = true)
	protected String remarks;
	
	@JSONField(name="TxRefNo")
	@XmlElement(name = "TxRefNo")
	protected long txRefNo;
	
	@JSONField(name="MessageSequence")
	@XmlElement(name = "MessageSequence")
	protected short messageSequence;
	
	@JSONField(name="OverrideLevel")
	@XmlElement(name = "OverrideLevel")
	protected short overrideLevel;
	
	@JSONField(name="ErrorCorrectionFlag")
	@XmlElement(name = "ErrorCorrectionFlag", required = true)
	protected String errorCorrectionFlag;
	
	@JSONField(name="ReservedbyHost")
	@XmlElement(name = "ReservedbyHost", required = true)
	protected String reservedbyHost;
	
	@JSONField(name="BranchNumber")
	@XmlElement(name = "BranchNumber", required = true)
	protected String branchNumber;
	
	@JSONField(name="StaffInfoAccessAuthLevel")
	@XmlElement(name = "StaffInfoAccessAuthLevel")
	protected short staffInfoAccessAuthLevel;
	
	@JSONField(name="RejectDetail")
	@XmlElement(name = "RejectDetail")
	protected List<RejectDetailType> rejectDetail;
	
	@JSONField(name="CycleDate")
	@XmlElement(name = "CycleDate", required = true)
	protected String cycleDate;
	
	@JSONField(name="SysTraceNum")
	@XmlElement(name = "SysTraceNum", required = true)
	protected String sysTraceNum;
	
	@JSONField(name="RetryProcessFlag")
	@XmlElement(name = "RetryProcessFlag", required = true)
	protected String retryProcessFlag;
	
	@JSONField(name="DeptCode")
	@XmlElement(name = "DeptCode", required = true)
	protected String deptCode;
	
	@JSONField(name="EmsSeqNo")
	@XmlElement(name = "EmsSeqNo", required = true)
	protected String emsSeqNo;

    /**
     * Gets the value of the bankCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBankCode() {
        return bankCode;
    }

    /**
     * Sets the value of the bankCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBankCode(String value) {
        this.bankCode = value;
    }

    /**
     * Gets the value of the custNo property.
     * 
     */
    public long getCustNo() {
        return custNo;
    }

    /**
     * Sets the value of the custNo property.
     * 
     */
    public void setCustNo(long value) {
        this.custNo = value;
    }

    /**
     * Gets the value of the custID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustID() {
        return custID;
    }

    /**
     * Sets the value of the custID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustID(String value) {
        this.custID = value;
    }

    /**
     * Gets the value of the channelID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChannelID() {
        return channelID;
    }

    /**
     * Sets the value of the channelID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChannelID(String value) {
        this.channelID = value;
    }

    /**
     * Gets the value of the loginID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLoginID() {
        return loginID;
    }

    /**
     * Sets the value of the loginID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLoginID(String value) {
        this.loginID = value;
    }

    /**
     * Gets the value of the branchID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBranchID() {
        return branchID;
    }

    /**
     * Sets the value of the branchID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBranchID(String value) {
        this.branchID = value;
    }

    /**
     * Gets the value of the terminalID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTerminalID() {
        return terminalID;
    }

    /**
     * Sets the value of the terminalID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTerminalID(String value) {
        this.terminalID = value;
    }

    /**
     * Gets the value of the serviceID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceID() {
        return serviceID;
    }

    /**
     * Sets the value of the serviceID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceID(String value) {
        this.serviceID = value;
    }

    /**
     * Gets the value of the serviceVersion property.
     * 
     */
    public int getServiceVersion() {
        return serviceVersion;
    }

    /**
     * Sets the value of the serviceVersion property.
     * 
     */
    public void setServiceVersion(int value) {
        this.serviceVersion = value;
    }

    /**
     * Gets the value of the emsMsgID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEMSMsgID() {
        return emsMsgID;
    }

    /**
     * Sets the value of the emsMsgID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEMSMsgID(String value) {
        this.emsMsgID = value;
    }

    /**
     * Gets the value of the txDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTxDateTime() {
        return txDateTime;
    }

    /**
     * Sets the value of the txDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTxDateTime(String value) {
        this.txDateTime = value;
    }

    /**
     * Gets the value of the agentID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgentID() {
        return agentID;
    }

    /**
     * Sets the value of the agentID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgentID(String value) {
        this.agentID = value;
    }

    /**
     * Gets the value of the serviceCharge property.
     * 
     */
    public long getServiceCharge() {
        return serviceCharge;
    }

    /**
     * Sets the value of the serviceCharge property.
     * 
     */
    public void setServiceCharge(long value) {
        this.serviceCharge = value;
    }

    /**
     * Gets the value of the language property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLanguage() {
        return language;
    }

    /**
     * Sets the value of the language property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLanguage(String value) {
        this.language = value;
    }

    /**
     * Gets the value of the autoResubmitFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAutoResubmitFlag() {
        return autoResubmitFlag;
    }

    /**
     * Sets the value of the autoResubmitFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAutoResubmitFlag(String value) {
        this.autoResubmitFlag = value;
    }

    /**
     * Gets the value of the retriedCount property.
     * 
     */
    public short getRetriedCount() {
        return retriedCount;
    }

    /**
     * Sets the value of the retriedCount property.
     * 
     */
    public void setRetriedCount(short value) {
        this.retriedCount = value;
    }

    /**
     * Gets the value of the returnCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReturnCode() {
        return returnCode;
    }

    /**
     * Sets the value of the returnCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReturnCode(String value) {
        this.returnCode = value;
    }

    /**
     * Gets the value of the returnMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReturnMessage() {
        return returnMessage;
    }

    /**
     * Sets the value of the returnMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReturnMessage(String value) {
        this.returnMessage = value;
    }

    /**
     * Gets the value of the remarks property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRemarks() {
        return remarks;
    }

    /**
     * Sets the value of the remarks property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRemarks(String value) {
        this.remarks = value;
    }

    /**
     * Gets the value of the txRefNo property.
     * 
     */
    public long getTxRefNo() {
        return txRefNo;
    }

    /**
     * Sets the value of the txRefNo property.
     * 
     */
    public void setTxRefNo(long value) {
        this.txRefNo = value;
    }

    /**
     * Gets the value of the messageSequence property.
     * 
     */
    public short getMessageSequence() {
        return messageSequence;
    }

    /**
     * Sets the value of the messageSequence property.
     * 
     */
    public void setMessageSequence(short value) {
        this.messageSequence = value;
    }

    /**
     * Gets the value of the overrideLevel property.
     * 
     */
    public short getOverrideLevel() {
        return overrideLevel;
    }

    /**
     * Sets the value of the overrideLevel property.
     * 
     */
    public void setOverrideLevel(short value) {
        this.overrideLevel = value;
    }

    /**
     * Gets the value of the errorCorrectionFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrorCorrectionFlag() {
        return errorCorrectionFlag;
    }

    /**
     * Sets the value of the errorCorrectionFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrorCorrectionFlag(String value) {
        this.errorCorrectionFlag = value;
    }

    /**
     * Gets the value of the reservedbyHost property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReservedbyHost() {
        return reservedbyHost;
    }

    /**
     * Sets the value of the reservedbyHost property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReservedbyHost(String value) {
        this.reservedbyHost = value;
    }

    /**
     * Gets the value of the branchNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBranchNumber() {
        return branchNumber;
    }

    /**
     * Sets the value of the branchNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBranchNumber(String value) {
        this.branchNumber = value;
    }

    /**
     * Gets the value of the staffInfoAccessAuthLevel property.
     * 
     */
    public short getStaffInfoAccessAuthLevel() {
        return staffInfoAccessAuthLevel;
    }

    /**
     * Sets the value of the staffInfoAccessAuthLevel property.
     * 
     */
    public void setStaffInfoAccessAuthLevel(short value) {
        this.staffInfoAccessAuthLevel = value;
    }

    /**
     * Gets the value of the rejectDetail property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the rejectDetail property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRejectDetail().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RejectDetailType }
     * 
     * 
     */
    public List<RejectDetailType> getRejectDetail() {
        if (rejectDetail == null) {
            rejectDetail = new ArrayList<RejectDetailType>();
        }
        return this.rejectDetail;
    }

    /**
     * Gets the value of the cycleDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCycleDate() {
        return cycleDate;
    }

    /**
     * Sets the value of the cycleDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCycleDate(String value) {
        this.cycleDate = value;
    }

    /**
     * Gets the value of the sysTraceNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSysTraceNum() {
        return sysTraceNum;
    }

    /**
     * Sets the value of the sysTraceNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSysTraceNum(String value) {
        this.sysTraceNum = value;
    }

    /**
     * Gets the value of the retryProcessFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRetryProcessFlag() {
        return retryProcessFlag;
    }

    /**
     * Sets the value of the retryProcessFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRetryProcessFlag(String value) {
        this.retryProcessFlag = value;
    }

    /**
     * Gets the value of the deptCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeptCode() {
        return deptCode;
    }

    /**
     * Sets the value of the deptCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeptCode(String value) {
        this.deptCode = value;
    }

    /**
     * Gets the value of the emsSeqNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmsSeqNo() {
        return emsSeqNo;
    }

    /**
     * Sets the value of the emsSeqNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmsSeqNo(String value) {
        this.emsSeqNo = value;
    }

}
