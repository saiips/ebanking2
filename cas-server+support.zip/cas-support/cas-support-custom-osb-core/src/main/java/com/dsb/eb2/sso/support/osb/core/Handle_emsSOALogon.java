package com.dsb.eb2.sso.support.osb.core;

import java.io.IOException;
import java.text.SimpleDateFormat;

import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Component;

import com.dsb.eb2.sso.support.osb.core.utils.ApiGateway;
import com.dsb.eb2.sso.support.osb.core.utils.EmsHeaderType;
import com.dsb.eb2.sso.support.osb.core.utils.JSONUtils;
import com.dsb.eb2.sso.support.osb.core.utils.StringUtils;
import com.dsb.eb2.sso.support.osb.core.utils.ThalesGetPublicKeyRequest;
import com.dsb.eb2.sso.support.osb.core.utils.ThalesGetPublicKeyResponse;
import com.dsb.eb2.sso.support.osb.core.utils.ThalesInitPinRequest;
import com.dsb.eb2.sso.support.osb.core.utils.ThalesInitPinResponse;
import com.dsb.eb2.sso.support.osb.core.utils.ThalesRanNumRequest;
import com.dsb.eb2.sso.support.osb.core.utils.ThalesRanNumResponse;
import com.dsb.eb2.sso.support.osb.core.utils.ThalesVerifyPinRequest;
import com.dsb.eb2.sso.support.osb.core.utils.ThalesVerifyPinResponse;

@Slf4j
@Component
public class Handle_emsSOALogon extends ApiGateway{
	
	
	private String serviceID;
	private String channelID;
	
	public String getServiceID() {
		return serviceID;
	}

	public void setServiceID(String serviceID) {
		this.serviceID = serviceID;
	}
	
	public String getChannelID() {
		return channelID;
	}

	public void setChannelID(String channelID) {
		this.channelID = channelID;
	}
	
	
	public String sign(final String message) throws IOException, Exception {
		
		log.debug("sign the request: [{}]", message);
		
		return "signed";
	}
	
	public String verify(final String message) throws IOException, Exception {
		
		log.debug("verify the message: [{}]", message);
		
		return "plain";
	}
	

	public ThalesGetPublicKeyResponse invoke(ThalesGetPublicKeyRequest request) throws IOException, Exception {
		
		String responseData;
		
		request.setEmsHeader(prepareEmsHeaderTypeParam());
		
		String serviceURL = super.getGatewayURL() + "/EmsSOALogonSBProject/thalesGetPublicKeyRestService/thalesGetPublicKeyRestService";
		
		responseData  = super.doRequest("DATA", "POST", "OTHERS", "N", null, serviceURL, "POST", JSONUtils.objToJson(request));		
		
		return (ThalesGetPublicKeyResponse) JSONUtils.JsonToObj(responseData, new ThalesGetPublicKeyResponse());
	}
	
	public ThalesRanNumResponse invoke(ThalesRanNumRequest request) throws IOException, Exception
	{
		String responseData;
		
		request.setEmsHeader(prepareEmsHeaderTypeParam());
		
		String serviceURL = super.getGatewayURL() + "/EmsSOALogonService/thalesGetRandomNumRestService/thalesGetRandomNumRestService";
		
		responseData  = super.doRequest("DATA", "POST", "OTHERS", "N", null, serviceURL, "POST", JSONUtils.objToJson(request));	
		
		return (ThalesRanNumResponse) JSONUtils .JsonToObj(responseData, new ThalesRanNumResponse());
	}
	
	public ThalesVerifyPinResponse invoke(ThalesVerifyPinRequest verifyPinRequest) throws IOException, Exception
	{
		String responseData;
		
		verifyPinRequest.setEmsHeader(prepareEmsHeaderTypeParam());

		String serviceURL = super.getGatewayURL() + "/EmsSOALogonService/thalesVerifyPinRestService/thalesVerifyPinRestService";
			
	    responseData  = super.doRequest("DATA", "POST", "OTHERS", "N", null, serviceURL, "POST", JSONUtils.objToJson(verifyPinRequest));
	    	
		return (ThalesVerifyPinResponse) JSONUtils.JsonToObj(responseData, new ThalesVerifyPinResponse());
	}
	

	public ThalesInitPinResponse invoke(ThalesInitPinRequest thalesInitPinRequest) throws IOException, Exception
	{
		String responseData;
		
		thalesInitPinRequest.setEmsHeader(prepareEmsHeaderTypeParam());

		String serviceURL = super.getGatewayURL() + "/EmsSOALogonService/thalesInitPinRestService/thalesInitPinRestService";
			
	    responseData  = super.doRequest("DATA", "POST", "OTHERS", "N", null, serviceURL, "POST", JSONUtils.objToJson(thalesInitPinRequest));
	    	
		return (ThalesInitPinResponse) JSONUtils.JsonToObj(responseData, new ThalesInitPinResponse());
	}

	private EmsHeaderType prepareEmsHeaderTypeParam()
	{
		EmsHeaderType result = new EmsHeaderType();
		
		result.setBankCode("6");
		if(StringUtils.isBlank(serviceID))
		{
			serviceID = "IB";
		}
		
		if(StringUtils.isBlank(channelID))
		{
			channelID = "EB";
		}
		
		result.setChannelID(channelID);
        result.setServiceID(serviceID);
		result.setServiceVersion(1);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		String formattedDate = sdf.format(new java.util.Date());
		result.setTxDateTime(formattedDate);
		return result;
	}
	
}
