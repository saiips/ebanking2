package com.dsb.eb2.sso.support.token.core.config;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apereo.cas.CipherExecutor;
import org.apereo.cas.configuration.CasConfigurationProperties;
import org.apereo.cas.configuration.model.core.util.EncryptionOptionalSigningOptionalJwtCryptographyProperties;
import org.apereo.cas.services.ServicesManager;
import org.apereo.cas.ticket.ExpirationPolicy;
import org.apereo.cas.token.TokenTicketBuilder;
import org.jasig.cas.client.validation.AbstractUrlBasedTicketValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.dsb.eb2.sso.support.osb.core.HandleEmsSOABuilder;
import com.dsb.eb2.sso.support.token.core.token.JWTTokenTicketBuilder;
import com.dsb.eb2.sso.support.token.core.token.cipher.TokenTicketCipherExecutor;

import lombok.extern.slf4j.Slf4j;

/**
 * This is {@link TokenCoreConfiguration}.
 *
 * @author Misagh Moayyed
 * @since 5.0.0
 */
@Slf4j
@Configuration("tokenCoreConfiguration")
@EnableConfigurationProperties(CasConfigurationProperties.class)
public class TokenCoreConfiguration {
	
    @Autowired
    @Qualifier("servicesManager")
    private ServicesManager servicesManager;

    @Autowired
    private CasConfigurationProperties casProperties;

    @Autowired
    @Qualifier("casClientTicketValidator")
    private AbstractUrlBasedTicketValidator casClientTicketValidator;

    @Autowired
    @Qualifier("grantingTicketExpirationPolicy")
    private ExpirationPolicy grantingTicketExpirationPolicy;
    
    @Autowired
    @Qualifier("handleEmsSOABuilder")
    private HandleEmsSOABuilder handleEmsSOABuilder;    

    @Bean
    public CipherExecutor tokenCipherExecutor() {
        final EncryptionOptionalSigningOptionalJwtCryptographyProperties crypto = casProperties.getAuthn().getToken().getCrypto();
        boolean enabled = crypto.isEnabled();
        if (!enabled && (StringUtils.isNotBlank(crypto.getEncryption().getKey())) && StringUtils.isNotBlank(crypto.getSigning().getKey())) {
            log.warn("[EB2] Token encryption/signing is not enabled explicitly in the configuration, yet signing/encryption keys "
                + "are defined for operations. CAS will proceed to enable the token encryption/signing functionality.");
            enabled = true;
        }

        if (enabled) {
            return new TokenTicketCipherExecutor(crypto.getEncryption().getKey(),
                crypto.getSigning().getKey(),
                crypto.getAlg(),
                crypto.isEncryptionEnabled(),
                crypto.isSigningEnabled());
        }
        log.info("[EB2] Token cookie encryption/signing is turned off. This "
            + "MAY NOT be safe in a production environment. Consider using other choices to handle encryption, "
            + "signing and verification of generated tokens.");
        return CipherExecutor.noOp();
    }


    @Bean
    public TokenTicketBuilder tokenTicketBuilder() {
        return new JWTTokenTicketBuilder(casClientTicketValidator,
            casProperties.getServer().getPrefix(),
            tokenCipherExecutor(),
            grantingTicketExpirationPolicy,
            this.servicesManager,
            this.handleEmsSOABuilder);
    }
    
}