package com.dsb.eb2.sso.support.token.core.token;

import java.time.ZonedDateTime;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

import org.apereo.cas.CipherExecutor;
import org.apereo.cas.authentication.Authentication;
import org.apereo.cas.authentication.principal.Service;
import org.apereo.cas.services.RegisteredService;
import org.apereo.cas.services.RegisteredServiceAccessStrategyUtils;
import org.apereo.cas.services.RegisteredServiceCipherExecutor;
import org.apereo.cas.services.ServicesManager;
import org.apereo.cas.ticket.ExpirationPolicy;
import org.apereo.cas.ticket.TicketGrantingTicket;
import org.apereo.cas.token.TokenTicketBuilder;
import org.apereo.cas.util.DateTimeUtils;
import org.hjson.JsonValue;
import org.hjson.Stringify;
import org.jasig.cas.client.validation.Assertion;
import org.jasig.cas.client.validation.TicketValidator;

import com.dsb.eb2.sso.support.token.core.token.cipher.RegisteredServiceTokenTicketCipherExecutor;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.PlainJWT;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import net.minidev.json.JSONObject;

import com.dsb.eb2.sso.support.osb.core.HandleEmsSOABuilder;

@Slf4j
@Getter
@RequiredArgsConstructor
public class JWTTokenTicketBuilder implements TokenTicketBuilder {

    private final TicketValidator ticketValidator;
    private final String casSeverPrefix;
    private final CipherExecutor<String, String> defaultTokenCipherExecutor;
    private final ExpirationPolicy expirationPolicy;
    private final ServicesManager servicesManager;
    private final HandleEmsSOABuilder handleEmsSOABuilder;
    
    @Override
    @SneakyThrows
    public String build(final String serviceTicketId, final Service service) {
        final Assertion assertion = this.ticketValidator.validate(serviceTicketId, service.getId());
        final Map<String, Object> attributes = new LinkedHashMap<>(assertion.getAttributes());
        attributes.putAll(assertion.getPrincipal().getAttributes());
        
        log.debug("[EB2] build from ST [{}]", attributes);

        final Date validUntilDate;
        if (assertion.getValidUntilDate() != null) {
            validUntilDate = assertion.getValidUntilDate();
        } else {
            final ZonedDateTime dt = ZonedDateTime.now().plusSeconds(expirationPolicy.getTimeToLive());
            validUntilDate = DateTimeUtils.dateOf(dt);
        }
        return buildJwt(serviceTicketId, service.getId(), assertion.getAuthenticationDate(),
            assertion.getPrincipal().getName(), validUntilDate, attributes);
    }

    @Override
    @SneakyThrows
    public String build(final TicketGrantingTicket ticketGrantingTicket) {
        final Authentication authentication = ticketGrantingTicket.getAuthentication();
        final Map<String, Object> attributes = new LinkedHashMap<>(authentication.getAttributes());
        attributes.putAll(authentication.getPrincipal().getAttributes());
        
        log.debug("[EB2] build from TGT [{}], attributes");

        final ZonedDateTime dt = ZonedDateTime.now().plusSeconds(expirationPolicy.getTimeToLive());
        final Date validUntilDate = DateTimeUtils.dateOf(dt);
        return buildJwt(ticketGrantingTicket.getId(),
            casSeverPrefix,
            DateTimeUtils.dateOf(ticketGrantingTicket.getCreationTime()),
            authentication.getPrincipal().getId(),
            validUntilDate,
            attributes);
    }

    private String buildJwt(final String jwtId,
                            final String serviceAudience,
                            final Date issueDate,
                            final String subject,
                            final Date validUntilDate,
                            final Map<String, Object> attributes) {
        final JWTClaimsSet.Builder claims =
            new JWTClaimsSet.Builder()
                .audience(serviceAudience)
                .issuer(casSeverPrefix)
                .jwtID(jwtId)
                .issueTime(issueDate)
                .subject(subject);
        
        log.info("[EB2] attributes [{}], attributes");

        attributes.forEach(claims::claim);
        claims.expirationTime(validUntilDate);

        final JWTClaimsSet claimsSet = claims.build();
        final JSONObject object = claimsSet.toJSONObject();

        final String jwtJson = object.toJSONString();
        log.info("[EB2] Generated JWT [{}]", JsonValue.readJSON(jwtJson).toString(Stringify.FORMATTED));

        log.info("[EB2] Locating service [{}] in service registry", serviceAudience);
        final RegisteredService registeredService = this.servicesManager.findServiceBy(serviceAudience);
        RegisteredServiceAccessStrategyUtils.ensureServiceAccessIsAllowed(registeredService);

        log.info("[EB2] Locating service specific signing and encryption keys for [{}] in service registry", serviceAudience);
        // final RegisteredServiceCipherExecutor serviceCipher = new RegisteredServiceTokenTicketCipherExecutor();
        final RegisteredServiceTokenTicketCipherExecutor serviceCipher = new RegisteredServiceTokenTicketCipherExecutor();
        serviceCipher.setHandleEmsSOABuilder(this.handleEmsSOABuilder);
        if (serviceCipher.supports(registeredService)) {
            log.info("[EB2] Encoding JWT based on keys provided by service [{}]", registeredService.getServiceId());
            return serviceCipher.encode(jwtJson, Optional.of(registeredService));
        }

        if (defaultTokenCipherExecutor.isEnabled()) {
            log.info("[EB2] Encoding JWT based on default global keys for [{}]", serviceAudience);
            return defaultTokenCipherExecutor.encode(jwtJson);
        }
        
        final String token = new PlainJWT(claimsSet).serialize();
        log.info("[EB2] Generating plain JWT as the ticket: [{}]", token);
        
        return token;
    }

}
