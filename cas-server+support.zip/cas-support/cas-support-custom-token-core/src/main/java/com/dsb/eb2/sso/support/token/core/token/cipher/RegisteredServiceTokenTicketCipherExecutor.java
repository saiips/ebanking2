package com.dsb.eb2.sso.support.token.core.token.cipher;



import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apereo.cas.services.RegisteredService;
import org.apereo.cas.services.RegisteredServiceCipherExecutor;
import org.apereo.cas.services.RegisteredServiceProperty.RegisteredServiceProperties;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import com.dsb.eb2.sso.support.osb.core.HandleEmsSOABuilder;
import com.dsb.eb2.sso.support.osb.core.utils.ThalesGetPublicKeyResponse;

/**
 * This is {@link RegisteredServiceTokenTicketCipherExecutor}.
 *
 * @author Misagh Moayyed
 * @since 5.3.0
 */
@Slf4j
@NoArgsConstructor
public class RegisteredServiceTokenTicketCipherExecutor extends TokenTicketCipherExecutor implements RegisteredServiceCipherExecutor {
	
	private static final boolean DIGITAL_SIGNATURE_FROM_THALES = false;
	
	private HandleEmsSOABuilder handleEmsSOABuilder;
	
	public void setHandleEmsSOABuilder(HandleEmsSOABuilder handleEmsSOABuilder) {
		this.handleEmsSOABuilder = handleEmsSOABuilder;
	}
	
	public HandleEmsSOABuilder getHandleEmsSOABuilder() {
		return this.handleEmsSOABuilder;
	}
	
    @Override
    public String decode(final String data, final Optional<RegisteredService> service) {
    	if (DIGITAL_SIGNATURE_FROM_THALES) {
    		return verifyMessage(data);
    	}
    	
        if (service.isPresent()) {
            final RegisteredService registeredService = service.get();
            if (supports(registeredService)) {
                log.info("[EB2] Found signing and/or encryption keys for [{}] in service registry to decode", registeredService.getServiceId());
                final String encryptionKey = getEncryptionKey(registeredService).get();
                final String signingKey = getSigningKey(registeredService).get();
                final TokenTicketCipherExecutor cipher = new TokenTicketCipherExecutor(encryptionKey, signingKey, StringUtils.isNotBlank(encryptionKey), StringUtils.isNotBlank(signingKey));
                if (cipher.isEnabled()) {
                    return cipher.decode(data);
                }
            }
        }
        return decode(data);
    }

    @Override
    public String encode(final String data, final Optional<RegisteredService> service) {
    	if (DIGITAL_SIGNATURE_FROM_THALES) {
    		return signMessage(data);
    	}
    	
        if (service.isPresent()) {
            final RegisteredService registeredService = service.get();
            if (supports(registeredService)) {
                log.info("[EB2] Found signing and/or encryption keys for [{}] in service registry to encode", registeredService.getServiceId());
                final String encryptionKey = getEncryptionKey(registeredService).get();
                final String signingKey = getSigningKey(registeredService).get();
                final TokenTicketCipherExecutor cipher = new TokenTicketCipherExecutor(encryptionKey, signingKey, StringUtils.isNotBlank(encryptionKey), StringUtils.isNotBlank(signingKey));
                if (cipher.isEnabled()) {
                    return cipher.encode(data);
                }
            }
        }
        return encode(data);
    }

    @Override
    public boolean supports(final RegisteredService registeredService) {
        return getSigningKey(registeredService).isPresent() || getEncryptionKey(registeredService).isPresent();
    }
    
    
    private String signMessage(final String data) {
    	return handleEmsSOABuilder.signMessage(data);
    }
    
    private String verifyMessage(final String data) {
    	return handleEmsSOABuilder.verifyMessage(data);
    }
    
    private ThalesGetPublicKeyResponse getThalesPublicKeyInfo() {
    	ThalesGetPublicKeyResponse response = null;
    	try {
    		response = handleEmsSOABuilder.getThalesPublicKeyInfo();
    		log.info("[EB2] found public key response: [{}]", response);
    		log.info("[EB2] response.getPublicKey(): [{}]", response.getPublicKey());
    		log.info("[EB2] response.getPublicKeyIndex(): [{}]", response.getPublicKeyIndex());
    		log.info("[EB2] response.getExp(): [{}]", response.getExp());
    	} catch (Exception ex) {
    		ex.printStackTrace();
    	}    	
    	return response;
    }
    
    
    

    /**
     * Gets signing key.
     *
     * @param registeredService the registered service
     * @return the signing key
     */
    public Optional<String> getSigningKey(final RegisteredService registeredService) {
        if (RegisteredServiceProperties.TOKEN_AS_SERVICE_TICKET_SIGNING_KEY.isAssignedTo(registeredService)) {
            final String signingKey = RegisteredServiceProperties.TOKEN_AS_SERVICE_TICKET_SIGNING_KEY.getPropertyValue(registeredService).getValue();
            return Optional.of(signingKey);
        }
        return Optional.empty();
    }

    /**
     * Gets encryption key.
     *
     * @param registeredService the registered service
     * @return the encryption key
     */
    public Optional<String> getEncryptionKey(final RegisteredService registeredService) {
        if (RegisteredServiceProperties.TOKEN_AS_SERVICE_TICKET_ENCRYPTION_KEY.isAssignedTo(registeredService)) {
            final String key = RegisteredServiceProperties.TOKEN_AS_SERVICE_TICKET_ENCRYPTION_KEY.getPropertyValue(registeredService).getValue();
            return Optional.of(key);
        }
        return Optional.empty();
    }
}
