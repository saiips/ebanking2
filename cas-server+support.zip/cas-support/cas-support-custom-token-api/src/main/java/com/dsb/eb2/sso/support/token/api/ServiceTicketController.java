package com.dsb.eb2.sso.support.token.api;

import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apereo.cas.services.RegisteredService;
import org.apereo.cas.services.RegisteredServiceAccessStrategyUtils;
import org.apereo.cas.services.RegisteredServiceCipherExecutor;
import org.apereo.cas.services.ServicesManager;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.dsb.eb2.sso.support.osb.core.HandleEmsSOABuilder;
import com.dsb.eb2.sso.support.token.core.token.cipher.RegisteredServiceTokenTicketCipherExecutor;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Getter
@RequiredArgsConstructor
@RestController("serviceTicketController")
public class ServiceTicketController {
	
    private final String casSeverPrefix;
    private final ServicesManager servicesManager;	
    private final HandleEmsSOABuilder handleEmsSOABuilder;

    @PostMapping(path = CasProtocolConstants.ENDPOINT_GET_CLAIMS, produces = MediaType.APPLICATION_JSON_VALUE)
    protected @ResponseBody String handle(final HttpServletRequest request, final HttpServletResponse response) throws Exception {
        String message = "";
        String jwtJson = request.getParameter("token");
        String service = request.getParameter("service");
        
        final RegisteredService registeredService = this.servicesManager.findServiceBy(service);
        RegisteredServiceAccessStrategyUtils.ensureServiceAccessIsAllowed(registeredService);
        
        log.debug("[EB2] Locating service specific signing and encryption keys for [{}] in service registry", service);
        // final RegisteredServiceCipherExecutor serviceCipher = new RegisteredServiceTokenTicketCipherExecutor();
        final RegisteredServiceTokenTicketCipherExecutor serviceCipher = new RegisteredServiceTokenTicketCipherExecutor();
        serviceCipher.setHandleEmsSOABuilder(handleEmsSOABuilder);
        if (serviceCipher.supports(registeredService)) {
            log.debug("[EB2] Decode JWT based on keys provided by service [{}]", registeredService.getServiceId());
            message = serviceCipher.decode(jwtJson, Optional.of(registeredService));
        }        
        
        return message;
    }
}
