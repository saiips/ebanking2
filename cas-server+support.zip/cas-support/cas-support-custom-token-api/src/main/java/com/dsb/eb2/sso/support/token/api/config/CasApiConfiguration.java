package com.dsb.eb2.sso.support.token.api.config;

import org.apereo.cas.configuration.CasConfigurationProperties;
import org.apereo.cas.services.ServicesManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.dsb.eb2.sso.support.osb.core.HandleEmsSOABuilder;
import com.dsb.eb2.sso.support.token.api.ServiceTicketController;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Configuration("casApiConfiguration")
@EnableConfigurationProperties(CasConfigurationProperties.class)
public class CasApiConfiguration {
	
    @Autowired
    @Qualifier("servicesManager")
    private ServicesManager servicesManager;

    @Autowired
    private CasConfigurationProperties casProperties;
    
    @Autowired
    @Qualifier("handleEmsSOABuilder")
    private HandleEmsSOABuilder handleEmsSOABuilder;
    
    @Autowired
    @Bean
    public ServiceTicketController serviceTicketController() {
    	log.debug("[EB2] Initialize Bean serviceTicketController: [{}]", casProperties.getServer().getPrefix());
        return new ServiceTicketController(casProperties.getServer().getPrefix(), servicesManager, handleEmsSOABuilder);
    }    

    
}