package com.dsb.eb2.sso.support.token.api;

public interface CasProtocolConstants {

	String ENDPOINT_GET_CLAIMS = "/getClaims";
	
	String CONTENT_TYPE = "Content-Type";
	
	String APPLICATION_JSON = "application/json; charset=UTF-8";
	
}
