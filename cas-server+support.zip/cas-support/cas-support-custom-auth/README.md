# 自定义认证模块

https://apereo.github.io/cas/development/installation/Webflow-Customization-Extensions.html

https://apereo.github.io/cas/development/installation/Configuring-Custom-Authentication.html

自定义认证包括两个核心内容：

1. 验证码校验
2. 扩展用户名密码加部门选择
3. 认证用户名密码加部分

