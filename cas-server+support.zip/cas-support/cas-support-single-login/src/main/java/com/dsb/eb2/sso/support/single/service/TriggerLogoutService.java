package com.dsb.eb2.sso.support.single.service;

import java.net.InetAddress;
import java.net.UnknownHostException;

import java.util.Collection;
import java.util.HashMap;
import java.util.StringTokenizer;
import java.util.function.Predicate;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apereo.cas.CentralAuthenticationService;
import org.apereo.cas.authentication.Authentication;
import org.apereo.cas.configuration.CasConfigurationProperties;
import org.apereo.cas.ticket.Ticket;
import org.apereo.cas.ticket.TicketGrantingTicket;

public class TriggerLogoutService {
    private final Log logger = LogFactory.getLog(this.getClass());
    private CentralAuthenticationService service;
    private CasConfigurationProperties casProperties;    
    
    public TriggerLogoutService(CentralAuthenticationService service, CasConfigurationProperties casProperties) {
       this.service = service;
       this.casProperties = casProperties;
   }

    public void triggerLogout(String id, String tgt) {

    	Predicate<Ticket> ticketPredicate = ticket -> {
            if(ticket instanceof TicketGrantingTicket) {
                TicketGrantingTicket t = ((TicketGrantingTicket)ticket).getRoot();
                Authentication authentication = t.getAuthentication();
                return t != null && authentication != null
                        && authentication.getPrincipal() != null && id.equals(authentication.getPrincipal().getId())
                        && !skipSingleLogon(id)
                        && !tgt.equals(t.getId());
            } else {
                return false;
            }
        };

        try {
	        Collection<Ticket> tickets = this.service.getTickets(ticketPredicate);
	        if (tickets != null && tickets.size() > 0) {
                logger.info(String.format("[%s] force to remove the session [%s]", id, tickets.size()));
	            for (Ticket ticket : tickets) {
	            	service.destroyTicketGrantingTicket(ticket.getId());
	            }
	        }
        } catch (Exception ex) {
        	ex.printStackTrace();
        }
        
    }
    
	private boolean skipSingleLogon(String id) {
		String _token = casProperties.getCustom().getProperties().get("skipSingleLogon");
		logger.debug(String.format("[%s] skip single logout", _token));
		HashMap<String, String> whiteList = new HashMap<String, String>();
		
		StringTokenizer st = new StringTokenizer(_token, "|");
		while (st.hasMoreTokens()) {
			String token = st.nextToken();
			if (token !=null && !"".equals(token)) {
				String[] envAndID = token.split(":");
				// envAndID[0] - env [dev|sit]
				// envAndID[1] - EBID List
				whiteList.put(envAndID[0], envAndID[1]);
			}
		}
		
		String skipID = whiteList.get(getCurentEnv());
		if (skipID != null && !"".equals(skipID)) {
			if (skipID.contains(id)) {
				logger.info(String.format("[%s] skip single logout", skipID));
			}
			return skipID.contains(id);
		}

		return false;
	}
	
	private String getCurentEnv() {
		String env = "";
		try {
			InetAddress ip = InetAddress.getLocalHost();
			String hostname = ip.getHostName().toLowerCase();
			env = hostname.substring(0, 3);
			logger.debug(String.format("[%s] current environment", env));
			
		} catch (UnknownHostException ex) {
			
		}
		return env;
	}
	
}
